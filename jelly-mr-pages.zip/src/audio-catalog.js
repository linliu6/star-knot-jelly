export const AUDIO_CATALOG = [
  {
    "id": "apple-1",
    "group": "apple",
    "label": "Soft gel press",
    "description": "Soft, rounded wet clicks",
    "publisher": "Mattia Cellotto",
    "library": "The Borax Experiment",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/apple-1.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -8.45,
      "sha256": "bbd773020d9434085e51dc94a5b4492f1a5d65e1d561b742289848b4903e37ed"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.7626666666666667,
      "highpassHz": 45,
      "lowpassHz": 4300,
      "gain": 4.194761,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "apple-2",
    "group": "apple",
    "label": "Silky stretch",
    "description": "A long, sticky pull",
    "publisher": "Mattia Cellotto",
    "library": "The Borax Experiment",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/apple-2.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -8.65,
      "sha256": "3fb7db6743c5fdc8800e27095ae3abaed7134184937abade8c224b32c644478d"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 1.0346666666666666,
      "highpassHz": 45,
      "lowpassHz": 4300,
      "gain": 2.645743,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "apple-3",
    "group": "apple",
    "label": "Deep squish",
    "description": "A fuller, softer squeeze",
    "publisher": "Mattia Cellotto",
    "library": "The Borax Experiment",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/apple-3.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.51,
      "peakDBFS": -7.88,
      "sha256": "305c31f2228844d1d1733ee5f982e6d2670c587000228ac8030a251bb50d2b75"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 1.9626666666666666,
      "highpassHz": 45,
      "lowpassHz": 4300,
      "gain": 2.186091,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "apple-4",
    "group": "apple",
    "label": "Tiny bubbles",
    "description": "Fine bubbles and sticky pops",
    "publisher": "Mattia Cellotto",
    "library": "The Borax Experiment",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/apple-4.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -8.97,
      "sha256": "52a8f810bf0c68037900cc27c0e71bdc4c094fb814bca66f15211503b6f173be"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 2.037333333333333,
      "highpassHz": 45,
      "lowpassHz": 4300,
      "gain": 4.386545,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "apple-5",
    "group": "apple",
    "label": "Water ripples",
    "description": "Light, watery movement",
    "publisher": "Eiravaein Works",
    "library": "Unfathomed",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/apple-5.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -13.01,
      "sha256": "711268820bc5deedb07c8d0f2fb01ece249ccf1235a838b6d24682f8c48fb451"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 2.941625,
      "highpassHz": 45,
      "lowpassHz": 4300,
      "gain": 1.8559,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "orbit-1",
    "group": "orbit",
    "label": "Soft glide",
    "description": "Smooth, airy motion",
    "publisher": "Airborne Sound",
    "library": "Organic Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/orbit-1.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -11.45,
      "sha256": "de30c81dad779df21e178694e57ba0d2f8b3855aedbe149147a94f5c2735a6d8"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.8903333333333333,
      "highpassHz": 110,
      "lowpassHz": 3100,
      "gain": 3.553134,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "orbit-2",
    "group": "orbit",
    "label": "Warm breeze",
    "description": "A rounded passing breeze",
    "publisher": "Airborne Sound",
    "library": "Airy Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/orbit-2.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -12.14,
      "sha256": "08ca29a692266d7f38032f6fd1a045fee931cbead7cb251def07518b7b703630"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.8140625,
      "highpassHz": 110,
      "lowpassHz": 3100,
      "gain": 1.412072,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "orbit-3",
    "group": "orbit",
    "label": "Slow current",
    "description": "A soft, slowly rising wave",
    "publisher": "Airborne Sound",
    "library": "Airy Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/orbit-3.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -12.21,
      "sha256": "ef98cfd7a27f5bd4d46706e517ffd8acb973d93ad6e59fca4364d549886cf29d"
    },
    "edit": {
      "startSeconds": 1.375,
      "durationSeconds": 3.2,
      "highpassHz": 110,
      "lowpassHz": 3100,
      "gain": 5.498685,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "orbit-4",
    "group": "orbit",
    "label": "Brief gust",
    "description": "A short, focused air movement",
    "publisher": "Airborne Sound",
    "library": "Airy Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/orbit-4.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -11.91,
      "sha256": "1ff639cc6b04ec716f2fb06c42585cb8c67f290ca601d28deb47d1189673a543"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 3.0637291666666666,
      "highpassHz": 110,
      "lowpassHz": 3100,
      "gain": 2.838267,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "orbit-5",
    "group": "orbit",
    "label": "Gentle swirl",
    "description": "A loose, flowing swirl",
    "publisher": "Airborne Sound",
    "library": "Eclectic Whooshes 2",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/orbit-5.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.49,
      "peakDBFS": -13.74,
      "sha256": "6dd240c32a94829fa11bca0f973d284f8e87a83ffd20230aa7dac13988030d8b"
    },
    "edit": {
      "startSeconds": 2.125,
      "durationSeconds": 3.2,
      "highpassHz": 110,
      "lowpassHz": 3100,
      "gain": 4.773117,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "ribbon-1",
    "group": "ribbon",
    "label": "Sheer flutter",
    "description": "Light and airy fabric",
    "publisher": "Airborne Sound",
    "library": "Organic Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/ribbon-1.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -11.7,
      "sha256": "26f6b5db8ae3efce9966c943e37759d07e51abbdd85539ef715366e6c2e6e7aa"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.46089583333333334,
      "highpassHz": 110,
      "lowpassHz": 6500,
      "gain": 3.972026,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "ribbon-2",
    "group": "ribbon",
    "label": "Ribbon brush",
    "description": "A fine, focused fabric rub",
    "publisher": "Airborne Sound",
    "library": "Organic Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/ribbon-2.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -12.47,
      "sha256": "4de72993940eb365a60724d2a1e62d3a92166c8d88640b6fa17600e0384d8b88"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.8186875,
      "highpassHz": 110,
      "lowpassHz": 6500,
      "gain": 2.560437,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "ribbon-3",
    "group": "ribbon",
    "label": "Fine weave",
    "description": "A close, fine fabric texture",
    "publisher": "SoundBits",
    "library": "Tiny Transitions 2",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/ribbon-3.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -13.78,
      "sha256": "2204722570c022d41daa58684577007106e24cc2774d0a97fee00e0e760cd95e"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.5845,
      "highpassHz": 110,
      "lowpassHz": 6500,
      "gain": 1.518471,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "ribbon-4",
    "group": "ribbon",
    "label": "Cotton swish",
    "description": "Soft, slightly fuller fabric",
    "publisher": "Soundholder",
    "library": "Swipes And Whooshes",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/ribbon-4.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.7,
      "peakDBFS": -10.71,
      "sha256": "7bce724aaa5ffc8723c18c194d24ae2153c2c1eae23c052b9e74f2f48740dc26"
    },
    "edit": {
      "startSeconds": 7.325,
      "durationSeconds": 3.2,
      "highpassHz": 110,
      "lowpassHz": 6500,
      "gain": 4.103833,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "ribbon-5",
    "group": "ribbon",
    "label": "Soft rustle",
    "description": "Loose folds of soft cloth",
    "publisher": "Systematic-Sound",
    "library": "Sound Themes - Modern Cloth Foley 01",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/ribbon-5.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -11.01,
      "sha256": "56763a2082c4881667c892ec4a55651a28904c7e9393b8a9826b2e3ef3bda4e1"
    },
    "edit": {
      "startSeconds": 7.875,
      "durationSeconds": 3.2,
      "highpassHz": 110,
      "lowpassHz": 6500,
      "gain": 1.136473,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "stem-1",
    "group": "stem",
    "label": "Wood tap",
    "description": "A short, dry wooden touch",
    "publisher": "BlueZone",
    "library": "Wood Sound Effects",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/stem-1.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.48,
      "peakDBFS": -11.13,
      "sha256": "a44d38e5bdd99102e767e76cf06a602a96273417476fb67ef6f9b003bc4a0239"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 2.1140208333333335,
      "highpassHz": 85,
      "lowpassHz": 4800,
      "gain": 1.173225,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "stem-2",
    "group": "stem",
    "label": "Gentle bend",
    "description": "A low, subtle wooden creak",
    "publisher": "BlueZone",
    "library": "Wood Sound Effects",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/stem-2.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.49,
      "peakDBFS": -10.79,
      "sha256": "74074ecf98a7395cf99adb627a75b6ee6b67a02aaf1da499b3af5644d1c83e13"
    },
    "edit": {
      "startSeconds": 0.125,
      "durationSeconds": 3.193208333333333,
      "highpassHz": 85,
      "lowpassHz": 4800,
      "gain": 1.819042,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "stem-3",
    "group": "stem",
    "label": "Bamboo click",
    "description": "Light and slightly hollow",
    "publisher": "Eiravaein Works",
    "library": "Eulerian",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/stem-3.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.54,
      "peakDBFS": -13.28,
      "sha256": "909bd34fe16d21e000cec7f07b3182a25743e31904dc595007d154ed764e9d19"
    },
    "edit": {
      "startSeconds": 5.275,
      "durationSeconds": 3.2,
      "highpassHz": 85,
      "lowpassHz": 4800,
      "gain": 5.458793,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "stem-4",
    "group": "stem",
    "label": "Wood brush",
    "description": "A clean wooden scrape",
    "publisher": "Eiravaein Works",
    "library": "Eulerian",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/stem-4.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.5,
      "peakDBFS": -13.38,
      "sha256": "b83235388a85a008aef779b596ae3c6f21ce43cacb6c2c2f072a44808151d5ba"
    },
    "edit": {
      "startSeconds": 9.225,
      "durationSeconds": 3.2,
      "highpassHz": 85,
      "lowpassHz": 4800,
      "gain": 2.892748,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  },
  {
    "id": "stem-5",
    "group": "stem",
    "label": "Twig texture",
    "description": "Fine, dry twig clicks",
    "publisher": "BlueZone",
    "library": "Wood Sound Effects",
    "sourcePage": "https://sonniss.com/gameaudiogdc/",
    "licenseUrl": "https://sonniss.com/gdc-bundle-license/",
    "file": "/star-knot-jelly/mr/audio/stem-5.wav",
    "runtime": {
      "sampleRate": 48000,
      "bitDepth": 16,
      "channels": 1,
      "rmsDBFS": -23.49,
      "peakDBFS": -9.45,
      "sha256": "1b7764541f26b5dfaf531c8518a6a0917d6ac2a415ed1470e8bf203eba71df2e"
    },
    "edit": {
      "startSeconds": 0.0,
      "durationSeconds": 0.822875,
      "highpassHz": 85,
      "lowpassHz": 4800,
      "gain": 2.892138,
      "fadeMs": 45,
      "softPeakGuard": 0.23
    }
  }
];
export const AUDIO_GROUPS={apple:"Apple",ribbon:"Ribbon",stem:"Stem",orbit:"Turn"};
export const choiceKey=kind=>kind+"Choice";
export const validChoice=(x,kind)=>Number.isInteger(x)&&x>=0&&x<=5;
export const choiceFor=(kind,index)=>AUDIO_CATALOG.find(x=>x.id===kind+"-"+index);
