import {applePoint,surfaceFrame} from './geometry.js';
import {crustTopology} from './crust-topology.js';
import {g as PhysicalMaterial} from '../jelly-painting/assets/three-CU5tkW7F.js';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const mix=(a,b,t)=>a+(b-a)*t;
const sample={u:[0,0,0],grad:Array(9).fill(0),w:[0,0,0]};
// Pressure fractures an attached coating. Pieces deform against the soft core;
// they do not hinge out like petals or instantly shrink away after breaking.
export function makeSugarShell(api,E,params,settings,patch,audio){
  const group=new E.Group();group.name='Attached fractured sugar coating';api.cup.root.add(group);api.pipeline.refractionExclude.push(group);
  let plates=[],fragments=[],rest=[],crackRest=[],shapeKey='',revision=0,events=[],lastUpdateKey='',needsPaint=true;
  let materialSets=[],shellGeometry,crackGeometry,lastPoint=null,lastGesture=-1,rub=0,moving=false;
  function layerMesh(geometry,crack=false){
    const m=new E.Mesh(geometry);m.name=crack?'Thin irregular fracture rims':'Clear attached sugar cells';m.frustumCulled=false;
    const glass={...api.settings.lid,color:'#fff6fb',roughness:.12,thickness:settings.shellThickness,ior:1.43,transmission:.8};
    const uniforms=E.glassUniforms(glass,api.settings.highlights);
    const surface=E.makeGlass({mesh:m,map:api.cup.package.body.materials.painted.mapNode.value,glass,uniforms,surface:null,environment:E.environment.environment,name:m.name,pipeline:api.pipeline});
    const replacements=new Map();
    for(const old of surface.materials.all){
      const mat=new PhysicalMaterial({color:crack?'#fff7f2':'#fff4f8',roughness:crack?.32:.11,metalness:0,transparent:true,depthWrite:false,side:0,envMap:E.environment.environment,envMapIntensity:crack?.22:.65,clearcoat:crack?.08:1,clearcoatRoughness:.08,specularIntensity:crack?.4:1.1,vertexColors:true});
      if(crack){mat.emissive.set('#fff0e9');mat.emissiveIntensity=.4;}
      mat.maskNode=old.maskNode;mat.opacity=crack?.68:(1-settings.shellClarity)*.42;mat.name=m.name+' · '+old.name;replacements.set(old,mat);
    }
    m.traverse(o=>{if(o.isMesh&&replacements.has(o.material)){o.material=replacements.get(o.material);o.frustumCulled=false;}});
    for(const old of replacements.keys())old.dispose();materialSets.push({crack,materials:[...replacements.values()]});group.add(m);return m;
  }
  const vertex=(u,v)=>({q:applePoint(u,v,params),normal:surfaceFrame((a,b)=>applePoint(a,b,params),u,clamp(v,.0001,.9999)).normal,uv:[u,v]});
  function rebuild(){
    const key=JSON.stringify([params.width,params.height,params.depth,params.fullness,params.dimple,params.dimpleWidth,params.lobes,params.asymmetry]);if(key===shapeKey)return;
    shapeKey=key;for(const m of materialSets)for(const v of m.materials)v.dispose();materialSets=[];
    shellGeometry?.dispose();crackGeometry?.dispose();group.clear();plates=[];fragments=[];rest=[];crackRest=[];
    const positions=[],uvs=[],indices=[],cracks=[],cuv=[],colors=[],surfaceColors=[],ci=[];
    for(const site of crustTopology()){
      const center=[site.u,site.v],cv=vertex(...center),id=plates.length;
      plates.push({...site,uv:center,center:cv.q,normal:cv.normal,state:0,reveal:0,stress:0,work:0,lastStress:0,crush:0,gridU:[0,0,0],gridGrad:Array(9).fill(0)});
      for(let edge=0;edge<site.polygon.length;edge++){
        const a=site.polygon[edge],b=site.polygon[(edge+1)%site.polygon.length],c=center;
        const fuv=[(a[0]+b[0]+c[0])/3,(a[1]+b[1]+c[1])/3],fv=vertex(...fuv),fid=fragments.length;
        fragments.push({id:fid,plate:id,center:fv.q,normal:fv.normal,sinA:Math.sin(fid*3.7),cosB:Math.cos(fid*7.1),wave:0});
        const put=(uv,inner=false,wall=false)=>{const v=vertex(...uv),index=rest.length;rest.push({...v,id,fid,inner,wall,coreIndex:clamp(Math.round(v.uv[1]*80),0,80)*113+clamp(Math.round((((v.uv[0]%1)+1)%1)*112),0,112)});positions.push(...v.q);uvs.push(...uv);surfaceColors.push(1,1,1,1);return index;};
        const bary=(i,j)=>[a[0]+(b[0]-a[0])*i+(c[0]-a[0])*j,a[1]+(b[1]-a[1])*i+(c[1]-a[1])*j];
        const face=[[],[]];for(let side=0;side<2;side++)for(let j=0;j<=2;j++)for(let i=0;i<=2-j;i++)face[side].push(put(bary(i/2,j/2),!!side));
        for(const tri of [[0,1,3],[1,4,3],[1,2,4],[3,4,5]]){indices.push(...tri.map(i=>face[0][i]));indices.push(...[...tri].reverse().map(i=>face[1][i]));}
        for(const [x,y] of [[a,b],[b,c],[c,a]]){const ix=[put(x,false,true),put(x,true,true),put(y,false,true),put(y,true,true)];indices.push(ix[0],ix[1],ix[2],ix[2],ix[1],ix[3]);}
        // Subtle shaded gap plus lit inner rim. Secondary seams appear on crushing.
        for(const [x,y,secondary] of [[a,b,false],[a,c,true]])for(let k=0;k<2;k++){
          const at=t=>[mix(x[0],y[0],t),mix(x[1],y[1],t)],xy=[at(k/2),at((k+1)/2)],base=crackRest.length;
          for(const [uv,side] of [[xy[0],-1],[xy[1],-1],[xy[0],1],[xy[1],1]]){
            const v=vertex(...uv),d=cv.q.map((q,i)=>q-v.q[i]),len=Math.hypot(...d)||1;
            crackRest.push({...v,id,fid,side,secondary,inward:d.map(q=>q/len)});cracks.push(...v.q);cuv.push(...uv);colors.push(...(side<0?[.66,.35,.51]:[1,.95,.88]));
          }ci.push(base,base+1,base+2,base+1,base+3,base+2);
        }
      }
    }
    const geo=(p,u,ix)=>{const g=new E.Geometry();g.setAttribute('position',new E.Attribute(new Float32Array(p),3));g.setAttribute('uv',new E.Attribute(new Float32Array(u),2));g.setIndex(ix);g.computeVertexNormals();g.computeBoundingSphere();g.attributes.position.setUsage(35048);g.attributes.normal.setUsage(35048);return g;};
    shellGeometry=geo(positions,uvs,indices);shellGeometry.setAttribute('color',new E.Attribute(new Float32Array(surfaceColors),4).setUsage(35048));crackGeometry=geo(cracks,cuv,ci);crackGeometry.setAttribute('color',new E.Attribute(new Float32Array(colors),3));
    layerMesh(shellGeometry);layerMesh(crackGeometry,true);lastPoint=null;revision++;needsPaint=true;
  }
  function contact(point,effort,gesture,dt=1/60){
    const distance=lastPoint&&gesture===lastGesture?Math.hypot(...point.map((v,i)=>v-lastPoint[i])):0;
    const travelRate=Math.min(.35,distance/Math.max(.008,dt));lastPoint=[...point];lastGesture=gesture;
    const r=settings.contactRadius*settings.shellSpread*1.5,thickness=Math.sqrt(settings.shellThickness/.00065);
    let fresh=0,broken=0,crumbled=0;
    for(const p of plates){
      const d=Math.hypot(...p.center.map((v,i)=>v-point[i])),weight=Math.exp(-d*d/(r*r));if(weight<.16){p.lastStress=0;continue;}
      const stress=effort*weight/(.62+.48*settings.shellHardness)/thickness*(.91+.18*p.seed);
      p.work+=Math.max(0,stress-p.lastStress)+distance/settings.contactRadius*weight*.52;p.lastStress=stress;
      const before=p.state,threshold=settings.shellCrack*(.88+.24*p.seed);
      if(stress>threshold&&p.state===0){p.state=1;fresh++;}
      if(p.state===1&&stress>threshold+.22){p.state=2;broken++;}
      if(p.state===2&&stress>threshold+.31&&p.work>threshold+.53){p.state=3;crumbled++;}
      p.stress=Math.max(p.stress,stress);if(p.state!==before)p.changedAt=performance.now();
    }
    if(fresh+broken+crumbled){revision++;const event={fresh,broken,crumbled,effort,t:performance.now()};events.push(event);if(events.length>60)events.shift();audio.gel?.fracture?.(event);}
    rub=Math.max(rub,travelRate);
  }
  function integrity(point){let total=0,intact=0;for(const p of plates){const d=Math.hypot(...p.center.map((v,i)=>v-point[i])),w=Math.exp(-((d/settings.contactRadius)**2));total+=w;intact+=w*[1,.76,.18,.035][p.state];}return intact/Math.max(.00001,total);}
  // Same indexed triangle accumulation as BufferGeometry, with closed cells using
  // the core normals they already received in the original coating. Hidden seams
  // and collapsed walls have zero area, so they need no triangle work.
  function updateNormals(geometry,vertices,crack,coreNormals){
    const p=geometry.attributes.position.array,n=geometry.attributes.normal.array,ix=geometry.index.array;n.fill(0);
    for(let i=0;i<ix.length;i+=3){
      const v=vertices[ix[i]],state=plates[v.id].state;
      if(crack?(state===0||v.secondary&&state<3):state<2)continue;
      const a=ix[i]*3,b=ix[i+1]*3,c=ix[i+2]*3;
      const x=p[c]-p[b],y=p[c+1]-p[b+1],z=p[c+2]-p[b+2],u=p[a]-p[b],v2=p[a+1]-p[b+1],w=p[a+2]-p[b+2];
      const nx=y*w-z*v2,ny=z*u-x*w,nz=x*v2-y*u;
      n[a]+=nx;n[a+1]+=ny;n[a+2]+=nz;n[b]+=nx;n[b+1]+=ny;n[b+2]+=nz;n[c]+=nx;n[c+1]+=ny;n[c+2]+=nz;
    }
    for(let i=0;i<vertices.length;i++){
      const v=vertices[i],k=i*3;
      if(!crack&&!v.wall&&plates[v.id].state<2){const sign=v.inner?-1:1,index=v.coreIndex;n[k]=coreNormals.getX(index)*sign;n[k+1]=coreNormals.getY(index)*sign;n[k+2]=coreNormals.getZ(index)*sign;}
      else{const x=n[k],y=n[k+1],z=n[k+2],scale=1/(Math.sqrt(x*x+y*y+z*z)||1);n[k]=x*scale;n[k+1]=y*scale;n[k+2]=z*scale;}
    }
    geometry.attributes.normal.needsUpdate=true;
  }
  const q=[0,0,0];
  function update(dt){
    rebuild();dt=clamp(dt,0,.05);rub*=Math.exp(-dt*32);if(rub<.0001)rub=0;
    const body=api.jelly.body,thickness=settings.shellThickness,key=JSON.stringify([revision,thickness,settings.shellAdhesion,settings.shellClarity,...patch.point.map(v=>Math.round(v*1e7)),...patch.displacement.map(v=>Math.round(v*1e7)),Math.round((patch.volumeScale??1)*1e7)]);
    moving=plates.some(p=>Math.abs(p.reveal-p.state)>.001);if(!moving&&body?.asleep&&key===lastUpdateKey&&!needsPaint)return;
    needsPaint=!body?.asleep||moving;lastUpdateKey=key;const coreNormals=api.cup.liquid.mesh.geometry.attributes.normal;
    for(const entry of materialSets)for(const m of entry.materials)m.opacity=entry.crack?.68:(1-settings.shellClarity)*.42;
    for(const p of plates){
      p.reveal=mix(p.reveal,p.state,1-Math.exp(-dt*27));if(Math.abs(p.reveal-p.state)<.001)p.reveal=p.state;
      const d=Math.hypot(...p.center.map((v,i)=>v-patch.point[i]));p.affected=d<patch.radius*3.2;p.crush=Math.exp(-((d/(patch.radius*1.2))**2))*patch.maxMove/settings.pressDepth;
      if(body){body.sample(...p.center,sample);for(let k=0;k<3;k++)p.gridU[k]=sample.u[k];for(let k=0;k<9;k++)p.gridGrad[k]=sample.grad[k];}
      p.broken=clamp(p.reveal-1);p.crumbled=clamp(p.reveal-2);p.facet=p.broken*(1-settings.shellAdhesion*.76);p.grain=p.crumbled*(.2+.8*(1-settings.shellAdhesion));p.shrink=1-p.broken*.012-p.crumbled*(.026+.038*(1-settings.shellAdhesion));p.crackWidth=(.000085+p.broken*.00012+p.crumbled*.00007)*(thickness/.00065)*clamp(p.reveal);
    }
    for(const f of fragments)f.wave=Math.sin(f.id*11.9+plates[f.plate].crush*3);
    function place(v,out,index,crack){
      const p=plates[v.id],f=fragments[v.fid],broken=p.broken,crumbled=p.crumbled;
      if((crack&&(p.state===0||v.secondary&&p.state<3))||(v.wall&&p.state<2)){const k=index*3;out.array[k]=p.center[0];out.array[k+1]=p.center[1];out.array[k+2]=p.center[2];return;}
      const facet=p.facet,grain=p.grain;
      const center=crumbled>0?f.center:p.center,shrink=p.shrink;
      let x=center[0]+(v.q[0]-center[0])*shrink,y=center[1]+(v.q[1]-center[1])*shrink,z=center[2]+(v.q[2]-center[2])*shrink;
      if(crack){const w=p.crackWidth*(v.secondary?.65:1);x+=v.inward[0]*w*v.side;y+=v.inward[1]*w*v.side;z+=v.inward[2]*w*v.side;}
      if(p.affected)patch.deform(x,y,z,q);else{q[0]=x;q[1]=y;q[2]=z;}const scale=patch.volumeScale??1,cy=patch.centerY??.055;q[0]*=scale;q[1]=cy+(q[1]-cy)*scale;q[2]*=scale;
      const slope=((v.q[0]-f.center[0])*f.sinA+(v.q[2]-f.center[2])*f.cosB);
      const lift=thickness*(v.inner?.08:1.08)+(crack?.000055:0)+facet*(thickness*.35+slope*.4)+grain*thickness*.24*f.wave;
      for(let a=0;a<3;a++)q[a]+=v.normal[a]*lift+p.gridU[a]+p.gridGrad[a*3]*(x-p.center[0])+p.gridGrad[a*3+1]*(y-p.center[1])+p.gridGrad[a*3+2]*(z-p.center[2]);const k=index*3;out.array[k]=q[0];out.array[k+1]=q[1];out.array[k+2]=q[2];
    }
    const a=shellGeometry.attributes.position,b=crackGeometry.attributes.position,alpha=shellGeometry.attributes.color;for(let i=0;i<rest.length;i++){place(rest[i],a,i,false);const reveal=plates[rest[i].id].reveal;alpha.setW(i,1+clamp(reveal-1)*.5+clamp(reveal-2)*1.7);}alpha.needsUpdate=true;for(let i=0;i<crackRest.length;i++)place(crackRest[i],b,i,true);
    a.needsUpdate=b.needsUpdate=true;updateNormals(shellGeometry,rest,false,coreNormals);updateNormals(crackGeometry,crackRest,true,coreNormals);
  }
  function reset(){needsPaint=true;for(const p of plates){p.state=0;p.reveal=p.stress=p.work=p.lastStress=p.crush=0;}events=[];lastPoint=null;lastGesture=-1;rub=0;revision++;}
  rebuild();return {contact,integrity,update,reset,group,get moving(){return moving;},get rubRate(){return rub;},snapshot:()=>({plates:plates.length,fragments:fragments.length,intact:plates.filter(p=>p.state===0).length,cracked:plates.filter(p=>p.state===1).length,opened:plates.filter(p=>p.state===2).length,crumbled:plates.filter(p=>p.state===3).length,revision,events:[...events],thickness:settings.shellThickness,rubRate:rub,attached:true})};
}
