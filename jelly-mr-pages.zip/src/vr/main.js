import {On as Vector3,mn as Geometry,hn as Attribute,un as Mesh,bn as Group,
  yn as Color,_ as StandardMaterial,b as BasicMaterial,ln as DataTexture,ot as texture}
  from '../../jelly-painting/assets/three-CU5tkW7F.js';
import {PartContacts} from './part-contacts.js';
import {XRMetrics} from './telemetry.js';
import {EyePresenter} from './present.js';
import {ContactSystem,pinchState,clamp,distance} from './contact.js';
import {JellyAudio} from './legacy-audio.js';
import {JOINTS,TIPS,VisibleHand,virtualHand,TouchButtons} from './hands.js';

import {ApplePhysics,preparePhysics} from '../mr/physics.js';
import {RoomModel} from '../mr/room.js';
import {PickupStars} from '../mr/stars.js';
import {MRSurfaceMask} from '../mr/render.js';
import {MRStatus} from '../mr/status.js';
import {ContactShadow} from '../mr/shadow.js';

const E={Vector3,Geometry,Attribute,Mesh,Group,Color,StandardMaterial,BasicMaterial,DataTexture,texture};
export const VR_DEFAULTS={scale:1.8,distance:.48,heightOffset:-.30,quality:'balanced',paintDetail:'balanced',autoQuality:true,
  volume:.5,muted:false,gpuTiming:false,pressStiffness:1600,gripStiffness:1100,contactDamping:14,contactRadius:.018,mrMode:true,bodyOpacity:.74,ribbonOpacity:.58,starAmount:1,holdStiffness:180,restitution:.3};
const KEY='jelly-play-mr40-settings';
const QUALITY={fast:448,balanced:640,sharp:832};
const LENGTHS={bodyOpacity:[.4,.95],ribbonOpacity:[.2,.9],starAmount:[0,2],holdStiffness:[70,400],restitution:[.05,.65],scale:[1.2,2.6],distance:[.35,.8],heightOffset:[-.55,-.1],volume:[0,1],
  pressStiffness:[500,2600],gripStiffness:[400,2200],contactDamping:[8,30],contactRadius:[.012,.03]};

export function validateVR(value){
  const result={...VR_DEFAULTS};
  for(const key of Object.keys(result))if(key in (value??{})){
    const v=value[key];if(typeof v!==typeof result[key])throw Error(`VR 参数类型错误：${key}`);
    if(LENGTHS[key]&&(!Number.isFinite(v)||v<LENGTHS[key][0]||v>LENGTHS[key][1]))throw Error(`VR 参数超出范围：${key}`);
    if(key==='quality'&&!QUALITY[v])throw Error('未知 VR Quality');if(key==='paintDetail'&&!['full','balanced'].includes(v))throw Error('未知Paint detail');result[key]=v;
  }
  result.mrMode=true;return result;
}

export function installQuestVR(api,study,bridge){
  document.title='Jelly Play · Mixed Reality';
  const saved=(()=>{try{return validateVR(JSON.parse(localStorage.getItem(KEY)))}catch{return {...VR_DEFAULTS}}})();
  const settings=saved,audio=new JellyAudio(settings,study),camera=api.camera,renderer=api.renderer;
  let lastFailure='',entering=false,presenter=null;
  let physics=null,room=null,stars=null,mask=null,mrHUD=null,contactShadow=null,placeRequested=true,roomReport=null;
  let mode='desktop',session=null,reference=null,layer=null,lastTime=0,time=0,previewRequest=0;
  let hands=[],buttons=null,contact=null,partContacts=null,snapshot=null,needRecenter=true,anchor=null,inverse=null,headMatrix=null;
  let oldUI=null,oldOverlay=null,oldExclude=null,previewSurface=null,eyeTarget=null,eyeW=0,eyeH=0;
  let qualityCap=QUALITY[settings.quality],sampleStart=0,sampleFrames=0,slowWindows=0;
  let previewPressed=false,previewPinch=false,previewX=0,previewY=0,previewAuto=false,previewStart=0;
  let pressureInputs=[],latestInputs=[],lastAudioPosition=[0,0,-.5],buttonDown=new Map();
  const stats={version:'4.0.0',output:'textured-draw',glError:0,viewerPose:false,audioWarning:null,mode:'desktop',sessionFrames:0,eyeRenders:0,hands:0,controllers:0,contacts:0,
    grips:0,fps:0,eyeWidth:0,eyeHeight:0,input:'尚未进入',cpuPhysicsMs:0,cpuRenderMs:0,errors:[],deviceVerified:false};
  const gl=renderer.getContext();
  const telemetry=new XRMetrics(gl);telemetry.enabled=settings.gpuTiming;let resourcesReady=false,handPool=[];
  const prepareHands=async()=>{await preparePhysics();handPool=['left','right'].map(side=>new VisibleHand(E,api.scene,side,api.assets.gltf,message=>{throw Error(message)}));await Promise.all(handPool.map(h=>h.loaded));const warmStarted=performance.now();for(const h of handPool)await renderer.compileAsync(h.model,camera,api.scene);if(window.jellyLoad)window.jellyLoad.handShaderWarmupMs=performance.now()-warmStarted;const warmRoom={occluders:new Group()},warmMask=new MRSurfaceMask(api,E,warmRoom,settings);warmMask.resize(16,16);warmMask.render();warmMask.dispose();resourcesReady=true;detect();};
  if(!gl?.createVertexArray)throw Error('VR 需要 WebGL 2，请使用 ?vr=1&renderer=webgl');
  const identity=()=>api.cup.root.matrixWorld.clone().identity();
  const eyeWorld=identity(),eyePose=identity();
  const v3=(a)=>new Vector3(...a);
  const fromXR=(a)=>v3(a).applyMatrix4(inverse).toArray();
  const orientationFrom=(q,matrix)=>camera.quaternion.clone().setFromRotationMatrix(identity().extractRotation(matrix)).multiply(camera.quaternion.clone().fromArray(q)).normalize().toArray();
  const transformJoint=(j,matrix,scale)=>({position:v3(j.position).applyMatrix4(matrix).toArray(),orientation:orientationFrom(j.orientation,matrix),radius:j.radius*scale});
  const toXR=(a)=>v3(a).applyMatrix4(anchor).toArray();

  const css=document.createElement('link');css.rel='stylesheet';css.href='/star-knot-jelly/mr/src/vr/vr.css';document.head.append(css);
  const host=document.createElement('section');host.id='quest-ui';
  host.innerHTML=`<div class="quest-bar"><div><strong>Jelly Play</strong><small>Mixed reality · Quest 3</small></div><button id="quest-enter" disabled>Preparing…</button><button id="quest-exit" hidden>Exit MR</button><button id="quest-preview">Stereo preview</button><button id="quest-options" aria-expanded="false">MR settings</button></div>
    <output id="quest-status" role="status">Checking MR support…</output>
    <aside id="quest-settings" hidden><div class="quest-actions"><button id="quest-sounds">Sound choices</button><button id="quest-art">Edit scene</button><button id="quest-diagnostics">Export diagnostics</button></div><h2>Touch and feel</h2><p>Poke with a fingertip. Pinch to pick up. While holding with one hand, pinch a small patch with the other hand to stretch it. Touch or pinch the ribbon and stem for their own response. Controllers: touch with the virtual fingertip, hold trigger to pick up.</p>
    <label>Volume<input id="quest-volume" type="range" min="0" max="1" step=".05" value="${settings.volume}"></label>
    <label><input id="quest-mute" type="checkbox" ${settings.muted?'checked':''}>Mute</label>
    <label>Size<input id="quest-scale" type="range" min="1.2" max="2.6" step=".1" value="${settings.scale}"></label>
    <label>Distance<input id="quest-distance" type="range" min=".35" max=".8" step=".01" value="${settings.distance}"></label>
    <label>Height<input id="quest-height" type="range" min="-.55" max="-.1" step=".01" value="${settings.heightOffset}"></label>
    <label>Press response<input id="quest-pressure" type="range" min="500" max="2600" step="50" value="${settings.pressStiffness}"></label>
    <label>Pinch response<input id="quest-grip" type="range" min="400" max="2200" step="50" value="${settings.gripStiffness}"></label>
    <h2>Mixed reality</h2><p>Allow room access. Scan if no surfaces appear. Pinch the apple to pick it up; release above a scanned surface. Calibrate: pinch three consecutive horizontal surface corners.</p>
    <label>Apple opacity<input id="quest-bodyOpacity" type="range" min=".4" max=".95" step=".01" value="${settings.bodyOpacity}"></label>
    <label>Ribbon opacity<input id="quest-ribbonOpacity" type="range" min=".2" max=".9" step=".01" value="${settings.ribbonOpacity}"></label>
    <label>Pickup stars<input id="quest-starAmount" type="range" min="0" max="2" step=".1" value="${settings.starAmount}"></label>
    <label>Hold response<input id="quest-holdStiffness" type="range" min="70" max="400" step="10" value="${settings.holdStiffness}"></label>
    <label>Landing bounce<input id="quest-restitution" type="range" min=".05" max=".65" step=".05" value="${settings.restitution}"></label>
    <label>Texture<select id="quest-variant"><option value="1">1 Classic</option><option value="2">2 Soft</option><option value="3">3 Crisp</option></select></label><label>Quality<select id="quest-quality"><option value="fast">Fast</option><option value="balanced">Balanced</option><option value="sharp">Sharp</option></select></label>
    <label>Paint detail<select id="quest-paint-detail"><option value="balanced">Balanced strokes</option><option value="full">Full strokes</option></select></label>
    <label><input id="quest-auto" type="checkbox" ${settings.autoQuality?'checked':''}>Adapt resolution when rendering slows</label>
    <label><input id="quest-gpu" type="checkbox" ${settings.gpuTiming?'checked':''}>Record GPU timings (diagnostics)</label><small>GPU queries may add overhead. Off during normal play.</small><div class="quest-actions"><button id="quest-save">Save settings</button><button id="quest-export">Export recipe</button><button id="quest-import">Import recipe</button><input id="quest-file" type="file" accept="application/json,.json" hidden><button id="quest-reset">Reset MR settings</button><button id="quest-tone">Test sound</button></div>
    <p>Bare hands use visual and audio feedback. Compatible controllers also give a light haptic pulse.</p></aside>
    <div id="quest-rehearsal" hidden><strong>Stereo rehearsal · simulated hands, not headset tracking</strong><div class="quest-actions"><button id="quest-press">Hold to press</button><button id="quest-pinch">Pinch and pull</button><button id="quest-auto-demo">Auto demo</button><button id="quest-center">Recenter</button><button id="quest-leave">Exit preview</button></div><label>Hand horizontal<input id="quest-hand-x" type="range" min="-.025" max=".025" step=".001" value="0"></label><label>Hand vertical<input id="quest-hand-y" type="range" min="-.025" max=".025" step=".001" value="0"></label><small>Separate left and right eye views. Touch, pressure and release produce different sounds.</small></div>`;
  document.body.append(host);const $=(id)=>host.querySelector('#quest-'+id);
  const status=(s)=>{$('status').textContent=s;};
  const failure=(prefix,error)=>{lastFailure=prefix+error.message;stats.errors.push(lastFailure);status(lastFailure+' · Export diagnostics, then retry.');};
  const unlockAudio=()=>{Promise.resolve(audio.unlock()).catch(error=>{stats.audioWarning=error.message;});};
  const report=()=>({room:room?.report()??roomReport,physics:physics?.report()??stats.rigidBody,stars:stars?{active:stars.particles.filter(p=>p.life>0).length,total:stars.total}:null,passthroughRefraction:'Alpha composition only; camera pixels are not sampled',version:'4.0.0',date:new Date().toISOString(),userAgent:navigator.userAgent,secure:isSecureContext,url:location.origin+location.pathname,settings:{...settings},load:window.jellyLoad??null,stats:{...stats},lastFailure,audio:audio.snapshot(),performance:telemetry.report(),layer:layer?{antialias:layer.antialias,width:layer.framebufferWidth,height:layer.framebufferHeight}:null});
  $('diagnostics').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(report(),null,2)],{type:'application/json'}));a.download='jelly-mr-diagnostics.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
  const save=()=>{localStorage.setItem(KEY,JSON.stringify(settings));status('MR settings saved in this browser.');};
  const sync=()=>{for(const k of ['bodyOpacity','ribbonOpacity','starAmount','holdStiffness','restitution'])$(k).value=settings[k];for(const [id,key]of [['volume','volume'],['scale','scale'],['distance','distance'],['height','heightOffset'],['pressure','pressStiffness'],['grip','gripStiffness'],['quality','quality'],['paint-detail','paintDetail']])$(id).value=settings[key];$('mute').checked=settings.muted;$('auto').checked=settings.autoQuality;$('gpu').checked=settings.gpuTiming;telemetry.enabled=settings.gpuTiming;};
  $('sounds').onclick=()=>{document.querySelector('#phone-sound-library,#open-sound-library')?.click();};
  $('art').onclick=()=>{const u=new URL(location.href);u.searchParams.set('mode','editor');location.href=u.href;};
  $('variant').value=new URLSearchParams(location.search).get('variant')||'1';$('variant').onchange=e=>window.dispatchEvent(new CustomEvent('star-variant',{detail:Number(e.target.value)}));
  $('options').onclick=()=>{const p=$('settings');p.hidden=!p.hidden;$('options').setAttribute('aria-expanded',String(!p.hidden));};
  $('quality').value=settings.quality;$('paint-detail').value=settings.paintDetail;
  function applyPaintDetail(){if(mode==='desktop')return;const value=settings.paintDetail==='full'?1:.5;api.settings.post.vrPaintScale=value;api.pipeline.transmissionPaintSettings.vrPaintScale=value;}
  $('paint-detail').onchange=e=>{settings.paintDetail=e.target.value;applyPaintDetail();};
  for(const [id,key]of [['volume','volume'],['scale','scale'],['distance','distance'],['height','heightOffset'],['pressure','pressStiffness'],['grip','gripStiffness']])$(id).oninput=e=>{
    settings[key]=Number(e.target.value);audio.configure();if(['scale','distance','heightOffset'].includes(key))needRecenter=true;
  };
  $('mute').onchange=e=>{settings.muted=e.target.checked;audio.configure();};
  $('gpu').onchange=e=>{settings.gpuTiming=e.target.checked;telemetry.enabled=settings.gpuTiming;if(!settings.gpuTiming)telemetry.disposeQueries();};
  $('auto').onchange=e=>settings.autoQuality=e.target.checked;
  $('quality').onchange=e=>{settings.quality=e.target.value;qualityCap=QUALITY[settings.quality];eyeW=0;};
  for(const k of ['bodyOpacity','ribbonOpacity','starAmount','holdStiffness','restitution'])$(k).oninput=e=>{settings[k]=Number(e.target.value);};
  $('save').onclick=save;
  $('reset').onclick=()=>{Object.assign(settings,VR_DEFAULTS);qualityCap=QUALITY[settings.quality];eyeW=0;needRecenter=true;sync();applyPaintDetail();audio.configure();save();};
  $('export').onclick=()=>{const data={schema:'star-apple-quest-mr',version:1,variant:Number($('variant').value),vr:{...settings},apple:mode==='desktop'?study.documentState():snapshot.state};const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.download='jelly-mr-recipe.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
  $('import').onclick=()=>$('file').click();
  $('file').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>1000000)throw Error('配方过大');const data=JSON.parse(await file.text());if(data.schema!=='star-apple-quest-mr'||data.version!==1||!data.apple)throw Error('不是此版本的 VR 配方');const next=validateVR(data.vr);if(data.variant!==undefined&&![1,2,3].includes(data.variant))throw Error('Invalid texture in recipe');if(data.variant&&data.variant!==Number($('variant').value)){if(mode!=='desktop')await exit();sessionStorage.setItem('jelly-mr-pending-recipe',JSON.stringify(data));localStorage.setItem(KEY,JSON.stringify(next));const u=new URL(location.href);u.searchParams.set('variant',String(data.variant));location.href=u.href;return;}if(mode!=='desktop')await exit();await study.restore(data.apple);Object.assign(settings,next);qualityCap=QUALITY[settings.quality];eyeW=0;needRecenter=true;sync();applyPaintDetail();audio.configure();save();status('MR and apple settings restored.');}catch(error){status('恢复失败：'+error.message);}e.target.value='';};
  $('tone').onclick=async()=>{await audio.unlock();audio.event('touch',.6);};
  $('preview').onclick=()=>{unlockAudio();startPreview();};
  $('enter').onclick=enter;$('exit').onclick=()=>exit();
  $('center').onclick=()=>needRecenter=true;
  $('leave').onclick=()=>exit();
  $('auto-demo').onclick=()=>{previewAuto=!previewAuto;previewStart=time;$('auto-demo').textContent=previewAuto?'Stop demo':'Auto demo';};
  const hold=(button,key)=>{button.onpointerdown=e=>{button.setPointerCapture(e.pointerId);previewAuto=false;previewStart=time;if(key==='press')previewPressed=true;else previewPinch=true;};button.onpointerup=button.onpointercancel=()=>{if(key==='press')previewPressed=false;else previewPinch=false;};};
  hold($('press'),'press');hold($('pinch'),'pinch');
  $('hand-x').oninput=e=>previewX=+e.target.value;$('hand-y').oninput=e=>previewY=+e.target.value;

  async function detect(){
    if(mode!=='desktop'||entering||!resourcesReady)return;
    if(!isSecureContext){$('enter').disabled=true;$('enter').textContent='需要安全连接';status('Open the public HTTPS link in Meta Quest Browser. HTTP cannot start mixed reality.');return;}
    try{const supported=await navigator.xr?.isSessionSupported('immersive-ar');$('enter').disabled=!supported;$('enter').textContent=supported?'Enter MR':'MR unavailable';status(lastFailure?lastFailure+' · Export diagnostics, then retry.':supported?'Ready · Enter MR. Allow hand tracking and room access.':'2D preview · Mixed reality is unavailable here. Open this same HTTPS link in Meta Quest Browser.');}
    catch(error){status('未能检查头显：'+error.message);$('enter').textContent='Retry MR';$('enter').disabled=false;}
  }
  navigator.xr?.addEventListener('devicechange',detect);detect();

  function setup(nextMode){
    if(mode!=='desktop')throw Error('已在预演或 VR 中');
    telemetry.reset(nextMode);if(session)telemetry.setSession(session);
    snapshot={state:study.documentState(),camera:camera.clone(),root:api.cup.root.position.clone(),rootRotation:api.cup.root.quaternion.clone(),pixelRatio:renderer.getPixelRatio()};
    mode=nextMode;audio.activate(true);study.mobile?.cancel();stats.mode=mode;stats.sessionFrames=stats.eyeRenders=0;stats.errors=[];stats.glError=0;stats.viewerPose=false;lastFailure='';time=0;lastTime=0;needRecenter=true;
    renderer.setAnimationLoop(null);document.body.classList.add('quest-presenting');
    api.view.controls.enabled=false;oldUI=api.pipeline.ui;oldOverlay=api.pipeline.overlay;oldExclude=api.pipeline.refractionExclude;
    api.pipeline.ui=api.pipeline.overlay=null;
    api.settings.post.frame=false;applyPaintDetail();api.pipeline.postfx.update();
    api.pipeline.configure({antialias:false,liquid:true});
    hands=handPool;placeRequested=true;
    physics=new ApplePhysics(api,E,settings,(event,intensity)=>{
      if(event==='pickup'){const p=physics.body.translation();stars?.emit([p.x,p.y,p.z],Math.round(9*settings.starAmount));audio.pickup();}
      if(event==='impact')audio.impact(intensity);
      if(event==='putdown'&&intensity>0)audio.putdown(intensity);
    });
    room=new RoomModel(E,api,physics);if(session)room.setSession(session);
    stars=new PickupStars(api,E,settings);mask=new MRSurfaceMask(api,E,room,settings);mrHUD=new MRStatus(api,E);contactShadow=new ContactShadow(api,E,settings);
    contact=new ContactSystem(api,E,settings,(kind,input,value)=>{
      if(kind==='lost'){if(physics.holder?.id!==input.id)audio.silence();return;}
      const position=input.xrPosition??(anchor?toXR(input.pinchPoint):[0,0,-.5]);
      if(kind==='pressure'){pressureInputs.push({value,position});return;}
      audio.event(kind,value,position,input.id);
      const actuator=input.source?.gamepad?.hapticActuators?.[0]??input.source?.gamepad?.vibrationActuator;
      if(actuator?.pulse)Promise.resolve(actuator.pulse(Math.min(.35,value*.28),35)).catch(()=>{});
    });
    partContacts=new PartContacts(api,E,study,audio);
    buttons=new TouchButtons(api,E,[()=>{settings.muted=!settings.muted;audio.configure();sync();},()=>{placeRequested=true;room.guides(true);},()=>room.scan(),()=>{physics.suspend();room.beginCalibration();room.guides(true);},()=>exit()],['Sound','Place','Scan','Calibrate','Exit']);
    api.pipeline.refractionExclude=[...(oldExclude??[]),...hands.map(h=>h.mesh),...buttons.buttons.map(b=>b.mesh)];
    qualityCap=QUALITY[settings.quality];eyeW=0;sampleStart=0;sampleFrames=slowWindows=0;
    eyeTarget=new api.pipeline.targetScene.constructor(1,1,{depthBuffer:false});eyeTarget.texture.name='VR painted eye';presenter=new EyePresenter(renderer);
    $('settings').hidden=true;$('exit').hidden=mode!=='vr';$('enter').disabled=true;$('preview').disabled=true;
    $('rehearsal').hidden=mode!=='preview';
    status(mode==='preview'?'MR rehearsal · simulated room and hands':'Mixed reality · scanning, touch and pickup');
  }
  function recenter(poseMatrix){
    const head=identity().fromArray(poseMatrix),hp=new Vector3().setFromMatrixPosition(head);
    const fw=new Vector3(0,0,-1).transformDirection(head);fw.y=0;fw.normalize();
    if(fw.length()<.1)fw.set(0,0,-1);
    const at=hp.clone().addScaledVector(fw,settings.distance);at.y+=settings.heightOffset;
    const original=snapshot.camera.position.clone();original.y=0;original.normalize();
    const yaw=Math.atan2(-fw.x,-fw.z)-Math.atan2(original.x,original.z);
    const rot=identity().makeRotationY(yaw),scale=identity().makeScale(settings.scale,settings.scale,settings.scale);
    anchor=identity().makeTranslation(at.x,at.y,at.z).multiply(rot).multiply(scale)
      .multiply(identity().makeTranslation(0,-.055,0));
    inverse=anchor.clone().invert();needRecenter=false;study.tactile?.setXRContact(null,true);partContacts?.clear();contact.clear();
  }
  async function enter(){
    if(entering)return;if(mode==='vr'){await exit();return;}if(mode!=='desktop')await exit();
    entering=true;lastFailure='';$('enter').disabled=true;status('Starting mixed reality…');
    // requestSession is issued in the click handler before any asynchronous gap.
    // AudioContext.resume() can remain pending while XR changes visibility.
    // Unlock in the gesture, but never gate the first headset frame on sound.
    unlockAudio();
    let requested;
    try{requested=navigator.xr.requestSession('immersive-ar',{requiredFeatures:['local-floor'],optionalFeatures:['hand-tracking','plane-detection','mesh-detection']});}
    catch(error){entering=false;failure('Could not enter MR: ',error);detect();return;}
    try{
      session=await requested;
      session.addEventListener('end',finish,{once:true});
      await gl.makeXRCompatible();
      reference=await session.requestReferenceSpace('local-floor');
      layer=new XRWebGLLayer(session,gl,{alpha:true,depth:false,stencil:false,antialias:false,framebufferScaleFactor:.7,ignoreDepthValues:true});
      layer.fixedFoveation=.5;session.updateRenderState({baseLayer:layer,depthNear:.02,depthFar:12});
      session.addEventListener('visibilitychange',()=>{telemetry.onVisibility(session.visibilityState);if(session?.visibilityState!=='visible'){contact?.clear();partContacts?.clear();physics?.suspend();study.tactile?.setXRContact(null,true);audio.silence();}});
      reference.addEventListener('reset',()=>{room?.clearManual();physics?.suspend();needRecenter=true;});
      setup('vr');
      telemetry.setSession(session);
      if(session.supportedFrameRates?.includes(72)&&session.updateTargetFrameRate){telemetry.refreshRequest='pending';session.updateTargetFrameRate(72).then(()=>{telemetry.refreshRequest='accepted';if(session)telemetry.setSession(session);}).catch(error=>{telemetry.refreshRequest='rejected: '+error.message;});}else telemetry.refreshRequest='72 Hz not exposed by this browser';
      session.addEventListener('frameratechange',()=>{if(session)telemetry.setSession(session);});
      session.requestAnimationFrame(onXRFrame);
    }catch(error){failure('Could not enter MR: ',error);try{await session?.end();}catch{}finish();}
    finally{entering=false;if(mode==='desktop')detect();}
  }
  function inputSources(frame){
    const inputs=[];stats.hands=stats.controllers=0;
    for(const h of hands)h.hide();
    for(const source of session.inputSources){
      const side=source.handedness==='left'?'left':'right',id=side+'-'+(source.hand?'hand':'controller');
      const hand=hands[side==='left'?0:1];let joints=new Map(),midpoint,pinch=false,xrPosition;
      if(source.hand){
        if(!hand.ready)continue;
        for(const name of JOINTS){const space=source.hand.get(name);const pose=space?frame.getJointPose(space,reference):null;
          if(pose){const p=pose.transform.position,q=pose.transform.orientation;
            joints.set(name,{position:fromXR([p.x,p.y,p.z]),orientation:orientationFrom([q.x,q.y,q.z,q.w],inverse),radius:clamp(pose.radius??.006,.003,.018)/settings.scale});}}
        // Partial tracking must not leave an invisible colliding hand or stale fingers.
        if(JOINTS.some(name=>!joints.has(name)))continue;
        const a=joints.get('thumb-tip').position,b=joints.get('index-finger-tip').position;
        midpoint=a.map((x,i)=>(x+b[i])*.5);const old=contact.hands.get(id)?.pinched??false;
        pinch=pinchState(physics.hands.get(id)??old,distance(a,b)*settings.scale);xrPosition=toXR(midpoint);stats.hands++;
      }else{
        const pose=frame.getPose(source.gripSpace??source.targetRaySpace,reference);if(!pose)continue;
        const m=identity().fromArray(pose.transform.matrix),p=new Vector3(0,0,-.065).applyMatrix4(m);
        xrPosition=p.toArray();midpoint=fromXR(xrPosition);
        const trigger=source.gamepad?.buttons?.[0],squeeze=source.gamepad?.buttons?.[1];pinch=(trigger?.value??0)>.55||(squeeze?.value??0)>.55;
        // Visible controller-hand proxy follows the real grip orientation.
        const proxy=virtualHand(E,[0,0,-.065],side,pinch,1);
        const poseToScene=inverse.clone().multiply(m);
        for(const [name,j]of proxy)joints.set(name,transformJoint(j,poseToScene,1/settings.scale));
        stats.controllers++;
        const menu=!!source.gamepad?.buttons?.[4]?.pressed;if(menu&&!buttonDown.get(id))needRecenter=true;buttonDown.set(id,menu);
      }
      const tips=(source.hand?TIPS:['index-finger-tip']).filter(n=>joints.has(n)).map(name=>({position:joints.get(name).position,radius:joints.get(name).radius+.0015/settings.scale}));
      const input={id,side,source,pinch,pinchPoint:midpoint,tips,joints,xrPosition,orientation:joints.get('wrist')?.orientation??[0,0,0,1]};inputs.push(input);
    }
    stats.input=stats.hands?'手部追踪':stats.controllers?'手柄':'未追踪到手或手柄';return inputs;
  }
  function advance(inputs,dt){
    const started=performance.now();pressureInputs=[];
    if(room.calibrating){room.calibrate(inputs.find(i=>i.side==='right')??inputs[0]);if(!room.calibrating)placeRequested=true;}
    if(placeRequested&&room.items.size&&headMatrix){
      const head=identity().fromArray(headMatrix),at=new Vector3(0,-.2,-settings.distance).applyMatrix4(head);const point=room.preferredPoint??fromXR(at.toArray());
      if(physics.place(point,room)){room.preferredPoint=null;placeRequested=false;room.guides(false);study.tactile?.reset();api.jelly.body?.reset();}
    }
    const active=room.calibrating?[]:inputs;stats.rigidBody=physics.update(active,dt,contact,room);stats.room=room.report();contactShadow.update(room,physics);audio.objectMotion(stats.rigidBody.speed,!!physics.holder,toXR(stats.rigidBody.position));
    stars.update(dt,stats.rigidBody.position,!!physics.holder,stats.rigidBody.speed);mrHUD.update(room,stats.rigidBody,settings.muted);
    for(const input of active)input.patchPinch=!!physics.holder&&!input.grabbed;
    partContacts.update(active.filter(i=>!i.grabbed),dt);stats.part=partContacts.active;const r=contact.update(active.filter(input=>input.id!==partContacts.owner&&!input.grabbed),dt);stats.contacts=r.contacts;stats.grips=physics.holder?1:0;
    latestInputs=inputs;
    for(const input of inputs)hands[input.side==='left'?0:1].update(input.joints,settings.scale);
    buttons.update(inputs);if(mode==='desktop')return;
    if(study.tactile){const c=partContacts.active?[]:contact.contacts??[];study.tactile.setXRContact(c.find(x=>x.mode==='grip')??c.reduce((a,b)=>(!a||(b.depth??0)>(a.depth??0))?b:a,null),inputs.length===0);}
    bridge.advance(dt,time);
    let strongest=null;for(const item of pressureInputs)if(!strongest||item.value.pressure*item.value.speed>strongest.value.pressure*strongest.value.speed)strongest=item;
    if(strongest){lastAudioPosition=strongest.position;audio.pressure(strongest.value.pressure,strongest.value.speed,strongest.position);}
    else audio.pressure(0,physics.holder?stats.rigidBody.speed:0,toXR(stats.rigidBody.position));stats.cpuPhysicsMs=performance.now()-started;
  }
  function resize(width,height,preview=false){
    const cap=qualityCap,ratio=width/height,w=Math.max(320,Math.round(Math.min(width,cap)/8)*8),h=Math.round(w/ratio/8)*8;
    if(w===eyeW&&h===eyeH)return;
    eyeW=w;eyeH=h;eyeTarget.setSize(w,h);renderer.setPixelRatio(1);renderer.setSize(preview?w*2:w,h,false);
    for(const name of ['peelTarget','refractionTarget','liquidBackTarget','targetA','targetB','targetC','targetScene'])api.pipeline[name].setSize(w,h);
    api.pipeline.postfx.setSize(w,h,1);api.pipeline.transmissionPaint.setSize(w,h,1);
    api.pipeline.postfx.setRenderSize(w,h);api.pipeline.transmissionPaint.setRenderSize(w,h);api.pipeline.sceneKept=false;
    mask?.resize(w,h);stats.eyeWidth=w;stats.eyeHeight=h;
    if(preview){disposePreviewSurface();const old=gl.getParameter(gl.FRAMEBUFFER_BINDING),oldTexture=gl.getParameter(gl.TEXTURE_BINDING_2D),tex=gl.createTexture(),fb=gl.createFramebuffer();
      gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,w*2,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
      gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
      gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
      if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('双眼预演缓冲区不完整');
      gl.bindFramebuffer(gl.FRAMEBUFFER,old);gl.bindTexture(gl.TEXTURE_2D,oldTexture);previewSurface={texture:tex,framebuffer:fb};
    }
  }
  function setEye(view){
    const world=eyeWorld.copy(inverse).multiply(eyePose.fromArray(view.transform.matrix));
    world.decompose(camera.position,camera.quaternion,camera.scale);camera.scale.set(1,1,1);
    camera.near=.02/settings.scale;camera.far=12/settings.scale;
    camera.projectionMatrix.fromArray(view.projectionMatrix);camera.projectionMatrix.elements[14]/=settings.scale;
    camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();camera.updateMatrixWorld(true);camera.matrixWorldInverse.copy(camera.matrixWorld).invert();
  }
  function drawViews(views,framebuffer,viewports,preview=false){
    const started=performance.now(),firstDraw=renderer.info.render.drawCalls;resize(viewports[0].width,viewports[0].height,preview);
    for(let i=0;i<views.length;i++){
      setEye(views[i]);stars?.face(camera);bridge.renderEye(eyeTarget);const coverage=mask.render();
      const painted=renderer.backend.get(eyeTarget.texture).textureGPU;
      const vp=preview?{x:i*eyeW,y:0,width:eyeW,height:eyeH}:viewports[i];
      presenter.draw(painted,preview?previewSurface.framebuffer:framebuffer,vp,coverage);stats.eyeRenders++;
    }
    if(preview)presenter.draw(previewSurface.texture,null,{x:0,y:0,width:eyeW*2,height:eyeH});
    // Bound GPU-error polling to startup and once per 120 frames. Silent GL
    // errors do not throw JS exceptions; retain the diagnosis after leaving XR.
    if(stats.sessionFrames<3||stats.sessionFrames%120===0){const error=gl.getError();if(error!==gl.NO_ERROR){stats.glError=error;throw Error('显示提交失败（WebGL '+error+'）');}}
    stats.cpuRenderMs=performance.now()-started;stats.drawCalls=renderer.info.render.drawCalls-firstDraw+views.length+(preview?1:0);
  }
  function metrics(now){
    stats.sessionFrames++;if(!sampleStart){sampleStart=now;sampleFrames=0;}else sampleFrames++;
    if(now-sampleStart>2500){stats.fps=Math.round(sampleFrames*1000/(now-sampleStart));sampleStart=now;sampleFrames=0;
      if(mode==='vr'&&settings.autoQuality){slowWindows=stats.fps<(telemetry.actualHz??72)*.90?slowWindows+1:0;
        if(slowWindows>=2&&qualityCap>448){const previous=qualityCap;qualityCap=Math.max(448,Math.round(qualityCap*.85/8)*8);telemetry.quality(previous,qualityCap,'Two low frame-rate windows; physics unchanged');eyeW=0;slowWindows=0;}}
      if(hands.some(h=>h.error)){status(hands.find(h=>h.error).error);return;}
      status(`${mode==='vr'?'Mixed reality':'Stereo rehearsal'} · ${stats.contacts} contacts · ${stats.fps} rendered fps · XR rate ${telemetry.actualHz??'unavailable'} · ${stats.eyeWidth}×${stats.eyeHeight} / eye`);
    }
  }
  function updateListener(matrix){
    const m=identity().fromArray(matrix);audio.listener(new Vector3().setFromMatrixPosition(m).toArray(),new Vector3(0,0,-1).transformDirection(m).toArray(),new Vector3(0,1,0).transformDirection(m).toArray());
  }
  function onXRFrame(now,frame){
    if(!session||mode!=='vr')return;session.requestAnimationFrame(onXRFrame);
    try{
      const callbackStarted=telemetry.beginCallback(now);
      const pose=frame.getViewerPose(reference);stats.viewerPose=!!pose;if(!pose){telemetry.noPose++;physics?.suspend();contact.clear();partContacts?.clear();study.tactile?.setXRContact(null,true);hands.forEach(h=>h.hide());audio.silence();return;}
      headMatrix=Array.from(pose.transform.matrix);if(needRecenter){recenter(headMatrix);placeRequested=true;}room.update(frame,reference,inverse);
      const dt=lastTime?clamp((now-lastTime)/1000,0,.035):1/72;lastTime=now;time+=dt;updateListener(headMatrix);
      let inputs=[];if(session.visibilityState==='visible'){physics.resume();inputs=inputSources(frame);}else{hands.forEach(h=>h.hide());stats.hands=stats.controllers=0;stats.input='系统菜单暂停';}advance(inputs,dt);if(mode!=='vr')return;
      telemetry.beginGPU();
      try{drawViews(pose.views,layer.framebuffer,Array.from(pose.views,v=>layer.getViewport(v)));}finally{telemetry.endGPU();}
      metrics(now);telemetry.frame(now,callbackStarted,stats,renderer);
    }catch(error){failure('MR rendering stopped: ',error);exit().catch(()=>finish());}
  }
  function previewPose(){
    const c=snapshot.camera.clone();c.position.set(0,1.55,0);c.lookAt(0,1.25,-.48);c.updateMatrixWorld(true);
    c.fov=75;c.aspect=1;c.near=.02;c.far=12;c.updateProjectionMatrix();
    const views=[-.032,.032].map(x=>{const v=c.clone();v.position.add(new Vector3(x,0,0).applyQuaternion(c.quaternion));v.updateMatrixWorld(true);return {transform:{matrix:v.matrixWorld.toArray()},projectionMatrix:v.projectionMatrix.toArray()};});
    return {head:c.matrixWorld.toArray(),views};
  }
  function previewInputs(){
    const toward=snapshot.camera.position.clone();toward.y=0;toward.normalize();
    const right=new Vector3(0,1,0).cross(toward).normalize();
    const p=study.params,t=(time-previewStart)%7;
    const press=previewAuto?(t>1&&t<3?Math.sin((t-1)/2*Math.PI):0):(previewPressed?1:0);
    const pinch=previewAuto?t>3.8&&t<5.5:previewPinch;
    const pull=pinch?(previewAuto?Math.min((t-3.8)*.025,.03):Math.min((time-previewStart)*.012,.025)):0;
    const inputs=[];
    for(const [i,side]of ['left','right'].entries()){
      const sideOffset=(i===0?-.022:.022)+previewX;
      const center=new Vector3(0,.064*p.height+previewY,0).addScaledVector(toward,.062-press*.019+pull).addScaledVector(right,sideOffset);
      if(pinch)center.addScaledVector(toward,-.008);
      const localJoints=virtualHand(E,[0,0,0],side,pinch,1/settings.scale,Math.PI/6);
      const poseToScene=identity().makeBasis(right,new Vector3(0,1,0),toward).setPosition(center);
      const joints=new Map();
      for(const [name,j]of localJoints)joints.set(name,transformJoint(j,poseToScene,1));
      const a=joints.get('thumb-tip').position,b=joints.get('index-finger-tip').position;
      // Start a pinch at the surface; pull after the hold has been acquired.
      const mid=a.map((x,k)=>(x+b[k])*.5);
      inputs.push({id:side+'-preview',side,pinch,pinchPoint:mid,joints,xrPosition:toXR(mid),
        tips:TIPS.map(name=>({position:joints.get(name).position,radius:joints.get(name).radius+.001}))});
    }
    stats.input='模拟双手';stats.hands=0;stats.controllers=0;return inputs;
  }
  function startPreview(){
    if(mode!=='desktop'||!resourcesReady)return;setup('preview');previewStart=0;previewAuto=true;$('auto-demo').textContent='Stop demo';
    const run=(now)=>{if(mode!=='preview')return;previewRequest=requestAnimationFrame(run);
      try{const callbackStarted=telemetry.beginCallback(now);const pose=previewPose();if(needRecenter)recenter(pose.head);headMatrix=pose.head;updateListener(pose.head);
        if(!room.items.size){const poly=[[-.25,0,-.25],[.25,0,-.25],[.25,0,.25],[-.25,0,.25]];room.add('preview-table',poly.flat(),[0,2,1,0,3,2],{kind:'manual',key:'preview',horizontal:true,polygon:poly,label:'simulated table'});room.status='Simulated table · not a room scan';}
        const dt=lastTime?clamp((now-lastTime)/1000,0,.035):1/60;lastTime=now;time+=dt;
        advance(previewInputs(),dt);if(mode!=='preview')return;
        telemetry.beginGPU();try{drawViews(pose.views,null,[{x:0,y:0,width:QUALITY[settings.quality],height:QUALITY[settings.quality]},{x:0,y:0,width:QUALITY[settings.quality],height:QUALITY[settings.quality]}],true);}finally{telemetry.endGPU();}metrics(now);telemetry.frame(now,callbackStarted,stats,renderer);
      }catch(error){failure('预演中止：',error);finish();}
    };previewRequest=requestAnimationFrame(run);
  }
  function disposePreviewSurface(){if(previewSurface){gl.deleteFramebuffer(previewSurface.framebuffer);gl.deleteTexture(previewSurface.texture);previewSurface=null;}}
  async function exit(){if(mode==='vr'&&session){await session.end();}else finish();}
  function finish(){
    if(mode==='desktop'){session=reference=layer=null;return;}roomReport=room?.report();mask?.dispose();mask=null;stars?.dispose();stars=null;mrHUD?.dispose();mrHUD=null;contactShadow?.dispose();contactShadow=null;room?.dispose();room=null;physics?.dispose();physics=null;study.tactile?.setXRContact(null,true);partContacts?.clear();partContacts=null;audio.activate(false);telemetry.stop();cancelAnimationFrame(previewRequest);contact?.clear();audio.silence();
    for(const hand of hands)hand.hide();hands=[];buttons?.dispose();buttons=null;disposePreviewSurface();presenter?.dispose();presenter=null;eyeTarget?.dispose();eyeTarget=null;
    api.pipeline.refractionExclude=oldExclude;api.pipeline.ui=oldUI;api.pipeline.overlay=oldOverlay;
    api.pipeline.postfx.setRenderSize(null,null);api.pipeline.transmissionPaint.setRenderSize(null,null);
    delete api.settings.post.vrPaintScale;delete api.pipeline.transmissionPaintSettings.vrPaintScale;
    const state=snapshot.state;mode='desktop';stats.mode=mode;session=reference=layer=null;
    document.body.classList.remove('quest-presenting');api.view.controls.enabled=true;
    study.restore(state);camera.copy(snapshot.camera);api.cup.root.position.copy(snapshot.root);api.cup.root.quaternion.copy(snapshot.rootRotation);api.cup.root.updateMatrixWorld(true);
    renderer.setPixelRatio(snapshot.pixelRatio);bridge.resume();snapshot=null;eyeW=0;
    $('exit').hidden=true;$('preview').disabled=false;$('rehearsal').hidden=true;previewPressed=previewPinch=previewAuto=false;buttonDown.clear();detect();
  }
  window.addEventListener('keydown',e=>{if(e.code==='Escape'&&mode==='preview')exit();});
  window.addEventListener('pagehide',()=>{audio.silence();if(session)session.end().catch(()=>{});});
  prepareHands().catch(error=>{failure('Hand preparation failed: ',error);document.documentElement.dataset.state='failed';});
  return {get ready(){return resourcesReady},report,get active(){return mode!=='desktop'},get mode(){return mode},settings,stats,startPreview,exit,
    recenter:()=>needRecenter=true,save,audio,scanRoom:()=>room?.scan(),placeApple:()=>{placeRequested=true;},calibrate:()=>{physics?.suspend();room?.beginCalibration();},
    snapshot:()=>({mode,settings:{...settings},stats:{...stats},handModels:hands.map(h=>h.snapshot()),contact:contact?{...contact.stats}:null,audio:audio.snapshot(),physics:study.snapshot(),room:room?.report(),rigid:physics?.report(),pickupStars:stars?{total:stars.total,active:stars.particles.filter(p=>p.life>0).length}:null}),
    // Deterministic rehearsal input for automated verification of the same solver.
    setPreviewInput(value){if(mode!=='preview')throw Error('仅可在电脑预演中使用');if(!!value.pinch!==previewPinch)previewStart=time;previewAuto=false;previewPressed=!!value.press;previewPinch=!!value.pinch;previewX=clamp(value.x??0,-.025,.025);previewY=clamp(value.y??0,-.025,.025);},
  };
}
