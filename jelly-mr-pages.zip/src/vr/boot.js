const base=new URL('../../',import.meta.url);
const panel=document.querySelector('#boot-panel'),progress=document.querySelector('#boot-progress'),text=document.querySelector('#boot-text'),retry=document.querySelector('#boot-retry');
window.jellyLoad={version:'4.0.0',startedAt:new Date().toISOString(),startedMs:performance.now(),loadedBytes:0,totalBytes:0,files:0,status:'loading'};
function fail(error){window.jellyLoad.status='failed';window.jellyLoad.error=String(error?.message??error);panel.hidden=false;text.textContent='Could not load the experience. '+window.jellyLoad.error;retry.hidden=false;}
retry.onclick=()=>location.reload();
window.addEventListener('star-variant',async e=>{await window.questJelly?.exit();const u=new URL(location.href);u.searchParams.set('variant',String(e.detail));location.href=u.href;});
window.addEventListener('unhandledrejection',e=>{if(window.jellyLoad.status!=='ready')fail(e.reason);});
document.querySelector('canvas').addEventListener('webglcontextlost',e=>{e.preventDefault();window.questJelly?.exit();fail(Error('Graphics context lost. Please retry.'));});
try {
  if(!new URLSearchParams(location.search).has('vr')){const u=new URL(location.href);u.searchParams.set('vr','1');history.replaceState(null,'',u);}
  const response=await fetch(new URL('manifest.json',base),{cache:'no-cache',signal:AbortSignal.timeout(60000)});if(!response.ok)throw Error('Manifest HTTP '+response.status);
  const manifest=await response.json(),deferred=manifest.assets.filter(a=>a.path.startsWith('audio/')),queue=manifest.assets.filter(a=>!a.path.startsWith('audio/'));window.jellyLoad.totalBytes=queue.reduce((n,a)=>n+a.bytes,0);window.jellyLoad.deferredAudio={files:0,totalFiles:deferred.length,loadedBytes:0,totalBytes:deferred.reduce((n,a)=>n+a.bytes,0),status:'waiting',errors:[]};let loaded=0;
  async function worker(){while(queue.length&&window.jellyLoad.status==='loading'){
    const asset=queue.shift(),url=new URL(asset.path,base);let verified=false;
    for(let attempt=0;attempt<2;attempt++){
      let r;try{r=await fetch(url,{cache:attempt?'reload':'force-cache',signal:AbortSignal.timeout(60000)});}catch(e){throw Error(asset.path+': '+e.message);}
      if(!r.ok)throw Error(asset.path+' HTTP '+r.status);const bytes=await r.arrayBuffer();
      const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');
      if(bytes.byteLength===asset.bytes&&hash===asset.sha256){verified=true;loaded+=bytes.byteLength;break;}
    }
    if(!verified)throw Error('Asset version mismatch: '+asset.path+'. Please retry.');
    window.jellyLoad.loadedBytes=loaded;window.jellyLoad.files++;
    if(window.jellyLoad.status==='loading'){progress.value=loaded/window.jellyLoad.totalBytes*100;text.textContent=`Loading assets · ${Math.round(progress.value)}%`;}
  }}
  await Promise.all(Array.from({length:4},worker));window.jellyLoad.downloadMs=performance.now()-window.jellyLoad.startedMs;
  text.textContent='Preparing shaders and hands…';
  const {initStorage}=await import('../../xhs/storage.js');await initStorage();
  const {selectVariant}=await import('../tactile-config.js');selectVariant(new URLSearchParams(location.search).get('variant')||1);
  await import('../../jelly-painting/assets/script-D2W4FU0H.js');
  const deadline=performance.now()+90000;
  while(!window.questJelly?.ready||document.querySelector('.loader')){if(document.documentElement.dataset.state==='failed')throw Error('Scene initialization failed.');if(performance.now()>deadline)throw Error('Scene initialization timed out.');await new Promise(r=>setTimeout(r,100));}
  const pending=sessionStorage.getItem('jelly-mr-pending-recipe');if(pending){const recipe=JSON.parse(pending);if(recipe.variant===Number(new URLSearchParams(location.search).get('variant')||1)){await window.appleStudy.restore(recipe.apple);sessionStorage.removeItem('jelly-mr-pending-recipe');}}
  window.jellyLoad.status='ready';window.jellyLoad.readyMs=performance.now()-window.jellyLoad.startedMs;panel.hidden=true;
  // Sound selections stay available immediately through RecordedFoley's loader.
  // Warm their HTTP cache only after the scene is usable, one request at a time.
  setTimeout(async()=>{const state=window.jellyLoad.deferredAudio;state.status='loading';
    for(const asset of deferred){try{
      let verified=false;
      for(let attempt=0;attempt<2;attempt++){
        const r=await fetch(new URL(asset.path,base),{cache:attempt?'reload':'force-cache',signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error('HTTP '+r.status);
        const bytes=await r.arrayBuffer(),hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');
        if(bytes.byteLength===asset.bytes&&hash===asset.sha256){verified=true;state.files++;state.loadedBytes+=bytes.byteLength;break;}
      }if(!verified)throw Error('Version mismatch');
    }catch(error){state.errors.push({path:asset.path,message:error.message});}}
    state.status=state.errors.length?'partial':'ready';
  },2500);
} catch(error){console.error('Jelly startup failed',error);fail(error);}
