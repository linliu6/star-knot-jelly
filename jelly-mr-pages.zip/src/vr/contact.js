import {SurfaceIndex} from './spatial.js';
import { appleData, surfaceFrame, applePoint } from '../geometry.js';

export const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
export const distance = (a, b) => Math.hypot(a[0]-b[0], a[1]-b[1], a[2]-b[2]);
const sub = (a,b) => a.map((x,i)=>x-b[i]);
const dot = (a,b) => a.reduce((s,x,i)=>s+x*b[i],0);

// Pinch hysteresis is in real-world metres, independent of fruit display scale.
export function pinchState(previous, gap) {
  return previous ? gap < .037 : gap < .024;
}

// Forces are applied at each original solver substep, not once per display
// frame. Opposite hands add forces, so squeezing never becomes last-hand-wins.
const weightCaches=new WeakMap();
export function fillContactAccelerations(body, contacts, settings) {
  const a = body.externalAcceleration ??= new Float64Array(body.X.length);
  a.fill(0);
  const sigma = settings.contactRadius;
  let cache=weightCaches.get(body);
  if(!cache||cache.sigma!==sigma||cache.X!==body.X||cache.free!==body.free){
    cache={sigma,X:body.X,free:body.free,points:new WeakMap()};weightCaches.set(body,cache);
  }
  for (const contact of contacts) {
    let weights=cache.points.get(contact.point);
    if(!weights){weights=[];for(const i of body.free){const j=i*3,d2=(body.X[j]-contact.point[0])**2+(body.X[j+1]-contact.point[1])**2+(body.X[j+2]-contact.point[2])**2;
      if(d2<=sigma*sigma*9)weights.push(j,Math.exp(-d2/(sigma*sigma*2)));}cache.points.set(contact.point,weights);}
    for(let index=0;index<weights.length;index+=2){
      const j=weights[index],w=weights[index+1];
      if(contact.mode==='grip') {
        for(let k=0;k<3;k++)a[j+k]+=w*(settings.gripStiffness*
          (clamp(contact.delta[k],-.018,.018)-body.U[j+k])-settings.contactDamping*body.V[j+k]);
      } else {
        const n=contact.normal,v=body.V,vn=v[j]*n[0]+v[j+1]*n[1]+v[j+2]*n[2];
        const f=Math.max(0,settings.pressStiffness*contact.depth+settings.contactDamping*vn);
        for(let k=0;k<3;k++)a[j+k]-=n[k]*f*w;
      }
    }
  }
  let maximum=0;
  for(let i=0;i<a.length;i+=3){
    const m=Math.hypot(a[i],a[i+1],a[i+2]), scale=m>70?70/m:1;
    for(let k=0;k<3;k++)a[i+k]*=scale;
    maximum=Math.max(maximum,Math.min(m,70));
  }
  if(maximum>1e-5)body.wake();
  return maximum;
}

export class ContactSystem {
  constructor(api, E, settings, onEvent) {
    this.api=api;this.E=E;this.settings=settings;this.onEvent=onEvent;
    this.hands=new Map();this.points=[];this.key='';this.home=api.cup.root.position.clone();
    this.rootVelocity=new E.Vector3();this.frame=0;
    this.stats={contacts:0,grips:0,peakForce:0,pressEvents:0,releaseEvents:0};
    this.sample={u:[0,0,0],w:[0,0,0],grad:Array(9).fill(0)};
  }
  rebuild() {
    const p=window.appleStudy.params;
    const key=[p.width,p.height,p.depth,p.dimple,p.fullness,p.dimpleWidth,p.lobes,p.asymmetry].join('|');
    if(key===this.key)return;
    this.key=key;this.points=[];
    const g=appleData(p,48,32);
    for(let j=1;j<32;j++)for(let i=0;i<48;i++){
      const u=i/48,v=j/32,point=applePoint(u,v,p);
      let normal=surfaceFrame((u,v)=>applePoint(u,v,p),u,v).normal;
      if(dot(normal,[point[0],point[1]-.055*p.height,point[2]])<0)normal=normal.map(x=>-x);
      this.points.push({point,normal});
    }
    this.spatial=new SurfaceIndex(this.points);
    this.bounds={low:g.base,high:g.top,r:.061*p.width,z:.061*p.width*p.depth};
  }
  local(point) {return this.api.cup.root.worldToLocal(new this.E.Vector3(...point)).toArray();}
  hit(point,radius=.004) {
    this.rebuild();const b=this.bounds;
    if(Math.abs(point[0])>b.r+radius+.02||Math.abs(point[2])>b.z+radius+.02||
      point[1]<b.low-radius-.01||point[1]>b.high+radius+.01)return null;
    const nearest=this.spatial.nearest(point);
    if(!nearest)return null;
    this.api.jelly.field.sample(...nearest.point,this.sample);
    const deformed=nearest.point.map((x,i)=>x+this.sample.u[i]);
    const delta=sub(point,deformed), signed=dot(delta,nearest.normal);
    // Reject distant tangential neighbours; finger radius includes tracking tolerance.
    const tangent=Math.sqrt(Math.max(0,dot(delta,delta)-signed*signed));
    if(tangent>radius+.008)return null;
    return {point:nearest.point,normal:nearest.normal,depth:clamp(radius-signed,0,.012),
      signed,near:signed<radius+.012,position:deformed};
  }
  update(inputs,dt) {
    dt=clamp(dt,0,.035);this.frame++;
    this.api.scene.updateMatrixWorld(true);
    const active=new Set(),contacts=[],targets=[];
    for(const input of inputs){
      active.add(input.id);let state=this.hands.get(input.id);
      if(!state){state={pinched:false,grip:null,contact:false,position:null,lastEvent:-10};this.hands.set(input.id,state);}
      const midpoint=input.pinchPoint, local=this.local(midpoint), hit=this.hit(local,.005);
      const pinched=input.pinch;
      if((!this.settings.mrMode||input.patchPinch)&&pinched&&!state.pinched&&hit?.near){
        state.grip={point:hit.point.slice(),normal:hit.normal.slice(),start:midpoint.slice(),root:this.api.cup.root.position.clone()};
        this.onEvent?.('grab',input,1);state.lastEvent=performance.now()/1000;
      }
      if(!pinched&&state.grip){
        this.onEvent?.('release',input,.55);state.grip=null;this.stats.releaseEvents++;
      }
      state.pinched=pinched;
      if(state.grip){
        contacts.push({mode:'grip',normal:state.grip.normal,point:state.grip.point,delta:sub(local,state.grip.point)});
        const offset=new this.E.Vector3(...sub(midpoint,state.grip.start)).clampLength(0,.13);
        targets.push(state.grip.root.clone().add(offset.multiplyScalar(.72)));
      }
      let pressure=0;
      if(!state.grip)for(const finger of input.tips){
        const h=this.hit(this.local(finger.position),finger.radius);
        if(h&&h.depth>0){contacts.push({...h,mode:'press'});pressure=Math.max(pressure,h.depth/.008);}
      }
      pressure=clamp(pressure,0,1);
      const speed=state.position?distance(midpoint,state.position)/Math.max(dt,.001):0;
      const now=performance.now()/1000;
      if(pressure>.025&&!state.contact&&now-state.lastEvent>.12){
        this.onEvent?.('touch',input,clamp(.25+pressure*.6+speed*.2,0,1));
        this.stats.pressEvents++;state.lastEvent=now;
      }
      if(!pressure&&state.contact&&!state.grip){this.onEvent?.('release',input,.25);this.stats.releaseEvents++;}
      this.onEvent?.('pressure',input,{pressure,speed:Math.min(speed,1),grip:!!state.grip});
      state.contact=pressure>0;state.position=midpoint.slice();input.pressure=pressure;
    }
    for(const [id,state]of this.hands)if(!active.has(id)){
      // Losing tracking releases silently and clears force. No phantom throw.
      this.hands.delete(id);this.onEvent?.('lost',{id},0);
    }
    const target=this.home.clone();
    if(targets.length){target.set(0,0,0);for(const t of targets)target.add(t);target.multiplyScalar(1/targets.length);}
    target.y=Math.max(this.home.y,target.y);
    const root=this.api.cup.root, delta=target.clone().sub(root.position);
    if(!this.settings.mrMode){
    this.rootVelocity.addScaledVector(delta,90*dt).multiplyScalar(Math.exp(-15*dt));
    root.position.addScaledVector(this.rootVelocity,dt);root.updateMatrixWorld(true);}
    const body=this.api.jelly.body;
    if(body){const force=fillContactAccelerations(body,contacts,this.settings);this.stats.peakForce=Math.max(this.stats.peakForce,force);}
    this.contacts=contacts;this.stats.contacts=contacts.length;this.stats.grips=targets.length;
    return this.stats;
  }
  clear() {
    this.contacts=[];this.hands.clear();this.rootVelocity.set(0,0,0);
    if(!this.settings.mrMode)this.api.cup.root.position.copy(this.home);this.api.cup.root.updateMatrixWorld(true);
    if(this.api.jelly.body?.externalAcceleration)this.api.jelly.body.externalAcceleration.fill(0);
    this.stats.contacts=this.stats.grips=0;
  }
}
