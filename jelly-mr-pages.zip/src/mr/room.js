// Room geometry stays on the headset. Reports contain counts and capability state only.
export function polygonTriangles(points) {
  if(points.length<3)return [];
  // Ear clipping in the plane's local X/Z coordinates, including concave floors.
  const a=points.map((_,i)=>i),out=[],cross=(i,j,k)=>(points[j][0]-points[i][0])*(points[k][2]-points[i][2])-(points[j][2]-points[i][2])*(points[k][0]-points[i][0]);
  const area=points.reduce((s,p,i)=>{const q=points[(i+1)%points.length];return s+p[0]*q[2]-q[0]*p[2]},0);
  if(area<0)a.reverse();let guard=0;
  while(a.length>3&&guard++<points.length*points.length){let found=false;for(let j=0;j<a.length;j++){
    const i=a[(j+a.length-1)%a.length],k=a[(j+1)%a.length],b=a[j];if(cross(i,b,k)<1e-10)continue;
    if(a.some(v=>v!==i&&v!==b&&v!==k&&cross(i,b,v)>=-1e-9&&cross(b,k,v)>=-1e-9&&cross(k,i,v)>=-1e-9))continue;
    out.push(i,k,b);a.splice(j,1);found=true;break;
  }if(!found)return [];}
  if(a.length===3)out.push(a[0],a[2],a[1]);return out;
}
export function insideXZ(p,poly){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){
  const a=poly[i],b=poly[j];if((a[2]>p[2])!==(b[2]>p[2])&&p[0]<(b[0]-a[0])*(p[2]-a[2])/(b[2]-a[2])+a[0])inside=!inside;}return inside;}
export class RoomModel {
  constructor(E,api,physics){this.E=E;this.api=api;this.physics=physics;this.items=new Map();this.ids=new WeakMap();this.nextId=1;this.captureAttempted=false;this.captureBusy=false;this.captureResult='not requested';this.manual=[];this.status='Waiting for room data';this.occluders=new E.Group();this.occluders.name='Room occlusion only';this.showGuides=false;this.calibrating=false;this.calibration=[];this.lastPinch=false;this.missingSince=null;this.depthMaterial=new E.BasicMaterial({colorWrite:false,depthWrite:true,side:2});this.guideMaterial=new E.BasicMaterial({color:'#b7e8dc',transparent:true,opacity:.13,depthWrite:false,side:2});}
  setSession(session){this.session=session;this.started=performance.now();this.captureAttempted=false;this.captureResult='not requested';}
  async scan(){
    if(this.captureBusy)return;
    if(!this.session?.initiateRoomCapture){this.captureResult='System scan is not exposed. Use Quest Space Setup, re-enter, or Calibrate.';return;}
    if(this.captureAttempted){if(!this.captureResult.includes('already requested'))this.captureResult+=' System scan already requested; exit and re-enter to retry.';return;}
    this.captureAttempted=true;this.captureBusy=true;this.captureResult='Scanning in Quest Space Setup';
    try{const result=await this.session.initiateRoomCapture();this.captureResult=result===false?'Scan cancelled. Existing surfaces kept.':'Scan returned. Waiting for room surfaces.';}
    catch(e){this.captureResult='Scan failed: '+e.message;}
    finally{this.captureBusy=false;}
  }
  update(frame,reference,inverse){
    const alive=new Set();const planes=frame.detectedPlanes??this.session?.detectedPlanes??[],meshes=frame.detectedMeshes??[];
    this.capabilities={planes:'detectedPlanes' in frame||!!this.session?.detectedPlanes,meshes:'detectedMeshes' in frame,capture:typeof this.session?.initiateRoomCapture==='function'};
    for(const [kind,objects]of [['plane',planes],['mesh',meshes]])for(const source of objects){
      let id=this.ids.get(source);if(!id){id='xr-'+this.nextId++;this.ids.set(source,id);}alive.add(id);
      const pose=frame.getPose(source.planeSpace??source.meshSpace,reference);if(!pose){this.remove(id);continue;}
      const matrix=this.api.cup.root.matrix.clone().fromArray(pose.transform.matrix).premultiply(inverse);
      const key=[source.lastChangedTime??0,...matrix.elements.map(v=>Math.round(v*100000))].join(',');
      if(this.items.get(id)?.key===key)continue;
      let positions,indices,polygon;
      if(kind==='plane'){
        polygon=Array.from(source.polygon,p=>[p.x,p.y,p.z]);if(polygon.length>3&&polygon[0].every((v,i)=>Math.abs(v-polygon.at(-1)[i])<1e-6))polygon.pop();
        indices=polygonTriangles(polygon);positions=polygon.flat();
      }else{
        if(!source.vertices||!source.indices||source.indices.length>120000){this.meshBudgetExceeded=true;this.remove(id);continue;}
        positions=Array.from(source.vertices);indices=Array.from(source.indices);
      }
      if(!indices.length||positions.some(v=>!Number.isFinite(v))||indices.some(i=>i<0||i*3+2>=positions.length)){this.remove(id);continue;}
      const world=[];for(let i=0;i<positions.length;i+=3)world.push(...new this.E.Vector3(positions[i],positions[i+1],positions[i+2]).applyMatrix4(matrix).toArray());
      const normal=new this.E.Vector3(0,1,0).transformDirection(matrix);
      this.add(id,world,indices,{key,kind,label:source.semanticLabel??'',horizontal:kind==='plane'&&Math.abs(normal.y)>.94,polygon:kind==='plane'?world.reduce((a,_,i)=>{if(i%3===0)a.push(world.slice(i,i+3));return a},[]):null});
    }
    for(const [id,item]of this.items)if(item.kind!=='manual'&&!alive.has(id))this.remove(id);
    const n=this.items.size;if(!this.calibrating)this.status=n?`${n} room surfaces ready`:performance.now()-this.started<3000?'Reading room surfaces…':'No room surfaces. Scan room or Calibrate.';
  }
  add(id,vertices,indices,meta){
    this.remove(id);const g=new this.E.Geometry();g.setAttribute('position',new this.E.Attribute(new Float32Array(vertices),3));g.setIndex(indices);g.computeVertexNormals();
    const mesh=new this.E.Mesh(g,this.depthMaterial);mesh.frustumCulled=false;mesh.name='Room '+meta.kind;this.occluders.add(mesh);
    const guide=new this.E.Mesh(g,this.guideMaterial);guide.name='Room guide';guide.layers.set(0);guide.visible=this.showGuides;this.api.scene.add(guide);
    const body=this.physics.addSurface(vertices,indices);this.items.set(id,{...meta,vertices,indices,mesh,guide,body});
  }
  remove(id){const old=this.items.get(id);if(!old)return;this.physics.removeSurface(old.body);old.mesh.removeFromParent();old.guide.removeFromParent();old.mesh.geometry.dispose();this.items.delete(id);}
  guides(value){this.showGuides=value;for(const s of this.items.values())s.guide.visible=value;}
  choose(point){
    let best=null;for(const s of this.items.values())if(s.horizontal&&s.polygon&&insideXZ(point,s.polygon)){
      const y=s.polygon.reduce((n,p)=>n+p[1],0)/s.polygon.length;
      if(y<=point[1]+.015&&(!best||y>best.y))best={y,id:[...this.items].find(([,v])=>v===s)[0]};
    }return best;
  }
  clearManual(){for(const [id,item]of this.items)if(item.kind==='manual')this.remove(id);this.preferredPoint=null;this.calibrating=false;this.calibration=[];}
  beginCalibration(){this.calibrating=true;this.calibration=[];this.lastPinch=false;this.status='Calibration: pinch three consecutive table corners.';}
  calibrate(input){
    const pinched=!!input?.pinch;if(pinched&&!this.lastPinch){this.calibration.push([...input.pinchPoint]);
      if(this.calibration.length===3){const [a,b,c]=this.calibration,y=(a[1]+b[1]+c[1])/3;
        if(Math.max(a[1],b[1],c[1])-Math.min(a[1],b[1],c[1])>.045){this.status='Corners must be on one horizontal surface. Try again.';this.calibration=[];}
        else{const p=[a,b,c,[a[0]+c[0]-b[0],y,a[2]+c[2]-b[2]]].map(v=>[v[0],y,v[2]]),tri=polygonTriangles(p);
          if(tri.length&&Math.abs((b[0]-a[0])*(c[2]-a[2])-(b[2]-a[2])*(c[0]-a[0]))>.002){this.add('manual-'+this.nextId++,p.flat(),tri,{key:'manual',kind:'manual',label:'user calibrated',horizontal:true,polygon:p});this.preferredPoint=p[0].map((_,k)=>p.reduce((sum,v)=>sum+v[k],0)/4);this.preferredPoint[1]+=.15;this.calibrating=false;this.status='Calibrated surface ready. Place apple.';}
          else{this.calibration=[];this.status='Corners are too close or collinear. Try again.';}}
      }else this.status=`Calibration: ${this.calibration.length}/3 corners. Pinch next corner.`;
    }this.lastPinch=pinched;
  }
  report(){return {surfaces:this.items.size,planes:[...this.items.values()].filter(v=>v.kind==='plane').length,meshes:[...this.items.values()].filter(v=>v.kind==='mesh').length,manual:[...this.items.values()].filter(v=>v.kind==='manual').length,capabilities:this.capabilities??{},status:this.status,capture:this.captureResult,captureBusy:this.captureBusy,calibrating:this.calibrating,meshBudgetExceeded:!!this.meshBudgetExceeded,roomCoordinatesExported:false};}
  dispose(){for(const id of [...this.items.keys()])this.remove(id);this.depthMaterial.dispose();this.guideMaterial.dispose();this.occluders.clear();}
}
