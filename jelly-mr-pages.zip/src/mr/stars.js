import {starData} from '../geometry.js';
// Reuse the authored four-point silhouette. One bounded buffer, no particle bodies.
export class PickupStars{
 constructor(api,E,settings){this.api=api;this.E=E;this.settings=settings;this.capacity=48;this.particles=Array.from({length:this.capacity},()=>({life:0,duration:1,p:[0,0,0],v:[0,0,0],size:0,angle:0}));this.base=starData(1,.0006,4);this.g=new E.Geometry();this.positions=new Float32Array(this.capacity*24*3);this.colors=new Float32Array(this.capacity*24*4);this.g.setAttribute('position',new E.Attribute(this.positions,3));this.g.setAttribute('color',new E.Attribute(this.colors,4));this.m=new E.BasicMaterial({vertexColors:true,transparent:true,opacity:.85,depthWrite:false,side:2});this.mesh=new E.Mesh(this.g,this.m);this.mesh.frustumCulled=false;this.mesh.visible=false;this.mesh.name='Pickup painted star trail';this.mesh.layers.set(0);api.scene.add(this.mesh);this.cursor=0;this.budget=0;this.total=0;this.right=new E.Vector3();this.up=new E.Vector3();}
 emit(center,count){for(let n=0;n<count;n++){const p=this.particles[this.cursor++%this.capacity],a=Math.random()*Math.PI*2;p.life=p.duration=.6+Math.random()*.65;p.p=center.map((x,k)=>x+(k===1?.025:Math.cos(a+k)*.025));p.v=[Math.cos(a)*.024,.02+Math.random()*.025,Math.sin(a)*.024];p.size=.0025+Math.random()*.0025;p.angle=a;this.total++;}}
 update(dt,center,held,speed){this.budget+=held?Math.min(18,speed*18)*this.settings.starAmount*dt:0;if(this.budget>=1){const n=Math.floor(this.budget);this.emit(center,n);this.budget-=n;}for(const p of this.particles)if(p.life>0){p.life-=dt;for(let k=0;k<3;k++)p.p[k]+=p.v[k]*dt;p.v[1]-=.016*dt;p.angle+=dt*.6;}this.mesh.visible=this.particles.some(p=>p.life>0);}
 face(camera){const right=this.right.set(1,0,0).applyQuaternion(camera.quaternion),up=this.up.set(0,1,0).applyQuaternion(camera.quaternion);let i=0;
  for(const p of this.particles){const t=Math.max(0,p.life/p.duration),fade=Math.sin(Math.min(1,t*4)*Math.PI/2)*Math.min(1,t*3),size=p.life>0?p.size*fade:0;
   const ca=Math.cos(p.angle),sa=Math.sin(p.angle);
   for(let j=0;j<8;j++)for(const index of [0,2+j,2+(j+1)%8]){const bx=this.base.positions[index*3],by=this.base.positions[index*3+1],x=(bx*ca-by*sa)*size,y=(bx*sa+by*ca)*size;
    for(let k=0;k<3;k++)this.positions[i*3+k]=p.p[k]+right.getComponent(k)*x+up.getComponent(k)*y;
    this.colors[i*4]=1;this.colors[i*4+1]=.86;this.colors[i*4+2]=.62;this.colors[i*4+3]=fade;i++;
   }
  }this.g.attributes.position.needsUpdate=true;this.g.attributes.color.needsUpdate=true;}
 dispose(){this.mesh.removeFromParent();this.g.dispose();this.m.dispose();}
}
