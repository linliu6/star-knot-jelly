import RAPIER from '../vendor/rapier/rapier.mjs';
import {applePoint} from '../geometry.js';
const v=a=>({x:a[0],y:a[1],z:a[2]});
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
let loading;
export function preparePhysics(){return loading??=RAPIER.init();}
export class ApplePhysics {
  constructor(api,E,settings,onEvent){
    this.api=api;this.E=E;this.settings=settings;this.onEvent=onEvent;this.scale=settings.scale;
    this.world=new RAPIER.World({x:0,y:-9.81/this.scale,z:0});this.world.integrationParameters.numSolverIterations=8;
    this.events=new RAPIER.EventQueue(true);this.hands=new Map();this.fingers=new Map();this.surfaces=new Set();this.accumulator=0;this.elapsed=0;this.lastImpact=-10;
    this.initialRotation=api.cup.root.quaternion.clone();this.center=new E.Vector3();const pts=[],p=window.appleStudy.params;
    let min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
    for(let j=0;j<=12;j++)for(let i=0;i<20;i++){const q=applePoint(i/20,j/12,p);pts.push(q);for(let k=0;k<3;k++){min[k]=Math.min(min[k],q[k]);max[k]=Math.max(max[k],q[k]);}}
    this.center.fromArray(min.map((x,i)=>(x+max[i])/2));this.radius=(max[1]-min[1])/2;
    const start=this.center.clone().applyQuaternion(this.initialRotation).add(api.cup.root.position);
    const desc=RAPIER.RigidBodyDesc.dynamic().setTranslation(...start.toArray()).setRotation(this.initialRotation).setCcdEnabled(true).setLinearDamping(.7).setAngularDamping(1.2).setCanSleep(true);
    this.body=this.world.createRigidBody(desc);
    const shape=RAPIER.ColliderDesc.convexHull(new Float32Array(pts.flatMap(q=>q.map((x,i)=>x-this.center.toArray()[i]))));
    if(!shape)throw Error('Apple collider construction failed');
    shape.setMass(.18).setFriction(.7).setRestitution(settings.restitution).setActiveEvents(RAPIER.ActiveEvents.COLLISION_EVENTS);
    this.collider=this.world.createCollider(shape,this.body);this.body.setGravityScale(0,true);this.state='waiting';this.holder=null;this.force=[0,0,0];this.positionHistory=[];this.stats={grabs:0,releases:0,impacts:0,settled:false,trackingLosses:0};this.applyRoot();
  }
  addSurface(vertices,indices){const b=this.world.createRigidBody(RAPIER.RigidBodyDesc.fixed());this.world.createCollider(RAPIER.ColliderDesc.trimesh(new Float32Array(vertices),new Uint32Array(indices)).setFriction(.85).setRestitution(.08),b);this.surfaces.add(b);return b;}
  removeSurface(b){if(this.surfaces.has(b)){this.world.removeRigidBody(b);this.surfaces.delete(b);}}
  place(point,room){
    let hit=room.choose(point);
    if(!hit&&this.surfaces.size){const ray=new RAPIER.Ray(v(point),{x:0,y:-1,z:0});const h=this.world.castRay(ray,5/this.scale,true,undefined,undefined,this.collider,this.body);if(h)hit={y:point[1]-h.timeOfImpact};}
    if(!hit){this.state='waiting';this.body.setGravityScale(0,true);return false;}
    this.holder=null;this.body.setTranslation({x:point[0],y:hit.y+this.radius+.006/this.scale,z:point[2]},true);this.body.setRotation(this.initialRotation,true);this.body.setLinvel({x:0,y:0,z:0},true);this.body.setAngvel({x:0,y:0,z:0},true);this.body.setGravityScale(1,true);this.state='free';this.stats.settled=false;this.applyRoot();return true;
  }
  acquire(input){
    if(this.holder||this.state==='waiting'||this.state==='suspended')return false;
    const q=this.api.cup.root.quaternion.clone(),center=new this.E.Vector3().copy(this.center).applyQuaternion(q).add(this.api.cup.root.position);
    const handQ=this.api.cup.root.quaternion.clone().fromArray(input.orientation??[0,0,0,1]);
    this.holder={id:input.id,offset:center.sub(new this.E.Vector3(...input.pinchPoint)).applyQuaternion(handQ.clone().invert()),rotation:handQ.clone().invert().multiply(q),previousTarget:null};
    this.body.setGravityScale(0,true);this.body.wakeUp();this.state='held';this.stats.grabs++;this.positionHistory=[];this.onEvent?.('pickup',.5);return true;
  }
  release(cancelled=false){if(!this.holder)return;this.holder=null;this.stats.releases++;if(cancelled){this.stats.trackingLosses++;this.body.setLinvel({x:0,y:0,z:0},true);this.body.setAngvel({x:0,y:0,z:0},true);}this.body.setGravityScale(this.surfaces.size?1:0,true);this.state=this.surfaces.size?'free':'waiting';this.onEvent?.('putdown',cancelled?0:.3);}
  suspend(){this.release(true);this.body.setGravityScale(0,true);this.body.setLinvel({x:0,y:0,z:0},true);this.body.setAngvel({x:0,y:0,z:0},true);this.state='suspended';for(const b of this.fingers.values())b.setEnabled(false);}
  resume(){if(this.state==='suspended'){this.state=this.surfaces.size?'free':'waiting';this.body.setGravityScale(this.surfaces.size?1:0,true);}}
  update(inputs,dt,contact,room){
    this.elapsed+=dt;this.collider.setRestitution(this.settings.restitution);
    if(!this.surfaces.size){this.release(true);this.body.setGravityScale(0,true);this.body.setLinvel({x:0,y:0,z:0},true);this.body.setAngvel({x:0,y:0,z:0},true);this.state='waiting';}
    const active=new Set(inputs.map(i=>i.id));for(const id of this.hands.keys())if(!active.has(id))this.hands.delete(id);
    if(this.holder&&!active.has(this.holder.id))this.release(true);
    for(const input of inputs){
      const prior=this.hands.get(input.id)??false;
      if(input.pinch&&!prior&&!this.holder&&!room.calibrating){const hit=contact.hit(contact.local(input.pinchPoint),.009/this.scale);if(hit?.near&&hit.signed>-.02)this.acquire(input);}
      if(this.holder?.id===input.id&&!input.pinch)this.release(false);
      this.hands.set(input.id,input.pinch);input.grabbed=this.holder?.id===input.id;
    }
    const aliveFingers=new Set();for(const input of inputs)for(let j=0;j<input.tips.length;j++){
      const tip=input.tips[j],id=input.id+':'+j;aliveFingers.add(id);let b=this.fingers.get(id);
      if(!b){b=this.world.createRigidBody(RAPIER.RigidBodyDesc.kinematicPositionBased().setTranslation(...tip.position));this.world.createCollider(RAPIER.ColliderDesc.ball(Math.min(.009/this.scale,tip.radius)).setFriction(.3).setRestitution(0),b);this.fingers.set(id,b);}
      b.setEnabled(!input.grabbed&&this.state!=='waiting'&&this.state!=='suspended'&&!room.calibrating);b.setNextKinematicTranslation(v(tip.position));
    }
    for(const [id,b]of this.fingers)if(!aliveFingers.has(id))b.setEnabled(false);
    this.accumulator=Math.min(this.accumulator+dt,.05);const step=1/90;
    while(this.accumulator>=step){
      if(this.holder){const input=inputs.find(i=>i.id===this.holder.id),handQ=this.api.cup.root.quaternion.clone().fromArray(input.orientation??[0,0,0,1]);
        const target=this.holder.offset.clone().applyQuaternion(handQ).add(new this.E.Vector3(...input.pinchPoint));const pos=this.body.translation(),vel=this.body.linvel();
        this.body.resetForces(true);const k=this.settings.holdStiffness,d=2*Math.sqrt(k)*.9;
        const f=[target.x-pos.x,target.y-pos.y,target.z-pos.z].map((x,i)=>.18*clamp(k*x-d*[vel.x,vel.y,vel.z][i],-14/this.scale,14/this.scale));this.body.addForce(v(f),true);
        const wanted=handQ.multiply(this.holder.rotation),current=this.api.cup.root.quaternion.clone().copy(this.body.rotation()),dq=wanted.clone().multiply(current.invert());if(dq.w<0){dq.x*=-1;dq.y*=-1;dq.z*=-1;dq.w*=-1;}
        this.body.setAngvel({x:clamp(dq.x*14,-6,6),y:clamp(dq.y*14,-6,6),z:clamp(dq.z*14,-6,6)},true);
      }else this.body.resetForces(true);
      const before=this.body.linvel(),speed=Math.hypot(before.x,before.y,before.z)*this.scale;
      this.world.timestep=step;this.world.step(this.events);
      this.events.drainCollisionEvents((a,b,started)=>{if(!started||this.holder||speed<.12||this.elapsed-this.lastImpact<.14)return;
        if(a!==this.collider.handle&&b!==this.collider.handle)return;const other=this.world.getCollider(a===this.collider.handle?b:a);if(!other||!this.surfaces.has(other.parent()))return;
        this.lastImpact=this.elapsed;this.stats.impacts++;this.impact(Math.min(speed,2.4));this.onEvent?.('impact',clamp(speed/1.6,.08,1));
      });this.accumulator-=step;
    }
    const v0=this.body.linvel();const speed=Math.hypot(v0.x,v0.y,v0.z)*this.scale;
    this.stillTime=this.state==='free'&&speed<.025?(this.stillTime??0)+dt:0;this.stats.settled=this.stillTime>.6;this.applyRoot();
    const pos=this.body.translation();if(pos.y<-3/this.scale){this.suspend();room.status='Apple left the scanned room. Place it again.';}
    return {holder:this.holder?.id??null,state:this.state,speed,position:[pos.x,pos.y,pos.z],...this.stats};
  }
  impact(speed){
    const b=this.api.jelly.body;if(!b)return;const direction=new this.E.Vector3(0,1,0).applyQuaternion(this.api.cup.root.quaternion.clone().invert());
    for(const i of b.free){const j=i*3,p=new this.E.Vector3(b.X[j],b.X[j+1],b.X[j+2]).sub(this.center),h=p.dot(direction),w=clamp(.6-h/(this.radius*2),0,1),f=Math.min(.06,speed*.025)*w;
      b.V[j]+=direction.x*f;b.V[j+1]+=direction.y*f;b.V[j+2]+=direction.z*f;}
    b.wake();
  }
  applyRoot(){const p=this.body.translation(),q=this.body.rotation(),root=this.api.cup.root;root.quaternion.copy(q);root.position.copy(p).sub(this.center.clone().applyQuaternion(root.quaternion));root.updateMatrixWorld(true);}
  report(){return {state:this.state,held:!!this.holder,...this.stats,rigidBodies:this.world.bodies.len(),surfaces:this.surfaces.size};}
  dispose(){this.events.free();this.world.free();}
}
