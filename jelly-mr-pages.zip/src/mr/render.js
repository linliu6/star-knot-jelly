// The original painted eye remains the color source. A deformed geometry pass
// provides alpha and scanned-room occlusion; passthrough pixels are never sampled.
export class MRSurfaceMask{
 constructor(api,E,room,settings){this.api=api;this.E=E;this.room=room;this.settings=settings;this.target=new api.pipeline.targetA.constructor(1,1,{depthBuffer:true});this.target.texture.name='MR virtual surface alpha';this.materials=new Map();this.oldColor=new E.Color();this.hidden=[api.backdrop.mesh,api.table.mesh,api.sparkles.sprite,window.appleStudy.decor];}
 resize(w,h){if(this.target.width!==w||this.target.height!==h)this.target.setSize(w,h);}
 render(){const {renderer:r,scene,camera}=this.api,oldMask=camera.layers.mask,clearAlpha=r.getClearAlpha(),auto=r.autoClear;this.oldColor.copy(r.getClearColor(this.oldColor));const hidden=this.hidden.map(o=>[o,o.visible]),changed=[];
  scene.traverse(o=>{if(!o.isMesh||!o.material||Array.isArray(o.material))return;const source=o.material;let mat=this.materials.get(source);
   if(!mat){mat=new this.E.BasicMaterial({color:'#ffffff',depthWrite:true,depthTest:true,side:source.side,transparent:true});if(source.positionNode)mat.positionNode=source.positionNode;if(source.opacityNode)mat.opacityNode=source.opacityNode;mat.toneMapped=false;this.materials.set(source,mat);}
   mat.opacity=o===this.api.cup.liquid.mesh?this.settings.bodyOpacity:(o.layers.mask&(1<<2))?this.settings.ribbonOpacity:Math.min(1,source.opacity??1);
   changed.push([o,source]);o.material=mat;
  });
  try{for(const [o]of hidden)o.visible=false;camera.layers.mask=(1<<0)|(1<<1)|(1<<2)|(1<<4)|(1<<5);
   r.setClearColor(0,0);r.setRenderTarget(this.target);r.autoClear=true;this.room.occluders.updateMatrixWorld(true);r.render(this.room.occluders,camera);
   r.autoClear=false;r.render(scene,camera);
  }finally{for(const [o,m]of changed)o.material=m;for(const [o,v]of hidden)o.visible=v;camera.layers.mask=oldMask;r.autoClear=auto;r.setClearColor(this.oldColor,clearAlpha);r.setRenderTarget(null);}
  return r.backend.get(this.target.texture).textureGPU;
 }
 dispose(){for(const m of this.materials.values())m.dispose();this.materials.clear();this.target.dispose();}
}
