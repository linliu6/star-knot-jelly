import { configureAppleDefaults, installApple } from "/star-knot-jelly/mr/src/apple.js";
const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/Controls-CCUdmDEh.js",
      "assets/presets-Dsv3aenh.js",
      "assets/PostFX-4zhHfKLG.js",
      "assets/three-CU5tkW7F.js",
    ]),
) => i.map((i) => d[i]);
import {
  _ as e,
  a as t,
  c as n,
  d as r,
  f as i,
  g as a,
  h as o,
  i as s,
  l as c,
  m as l,
  n as u,
  o as d,
  p as f,
  r as p,
  s as m,
  t as h,
  u as g,
} from "./presets-Dsv3aenh.js";
import {
  a as _,
  i as v,
  n as y,
  r as b,
  t as x,
} from "./preload-helper-DXy7VkNq.js";
import {
  $ as S,
  $t as C,
  An as w,
  At as T,
  B as E,
  Bn as D,
  C as O,
  Cn as k,
  Ct as A,
  Dn as j,
  Dt as ee,
  En as te,
  Et as M,
  Fn as N,
  Ft as P,
  G as F,
  H as ne,
  Hn as re,
  Ht as ie,
  I as ae,
  In as oe,
  It as I,
  J as se,
  Jt as L,
  K as ce,
  Kt as R,
  L as le,
  Lt as ue,
  Mn as de,
  Mt as fe,
  N as pe,
  Nn as me,
  Nt as z,
  O as he,
  On as B,
  Ot as V,
  P as ge,
  Pn as _e,
  Q as ve,
  Qt as ye,
  Rn as be,
  Rt as xe,
  S as Se,
  St as Ce,
  Tn as we,
  U as Te,
  Ut as H,
  V as Ee,
  Vn as De,
  Vt as Oe,
  W as ke,
  Wt as Ae,
  X as je,
  Xt as Me,
  Y as Ne,
  Yt as Pe,
  Z as Fe,
  Zt as Ie,
  _ as Le,
  _n as Re,
  _t as ze,
  a as Be,
  an as Ve,
  at as He,
  b as Ue,
  bn as We,
  bt as Ge,
  c as Ke,
  cn as qe,
  ct as Je,
  dn as Ye,
  dt as Xe,
  en as Ze,
  f as Qe,
  fn as $e,
  ft as et,
  gn as tt,
  gt as nt,
  h as rt,
  hn as it,
  ht as at,
  i as ot,
  in as st,
  j as ct,
  jn as U,
  jt as lt,
  kn as ut,
  kt as dt,
  l as ft,
  lt as pt,
  m as mt,
  mn as ht,
  mt as gt,
  n as _t,
  nn as vt,
  nt as yt,
  on as bt,
  ot as xt,
  pn as St,
  qt as W,
  rn as Ct,
  rt as wt,
  s as Tt,
  sn as Et,
  t as Dt,
  tn as Ot,
  un as kt,
  v as At,
  vn as jt,
  vt as Mt,
  w as Nt,
  wn as Pt,
  wt as Ft,
  x as It,
  xn as Lt,
  xt as Rt,
  y as zt,
  yn as G,
  yt as Bt,
  z as Vt,
  zn as Ht,
  zt as Ut,
} from "./three-CU5tkW7F.js";
import {
  C as Wt,
  E as Gt,
  S as Kt,
  T as qt,
  _ as Jt,
  a as K,
  b as Yt,
  c as Xt,
  d as Zt,
  f as Qt,
  g as $t,
  h as en,
  i as tn,
  l as nn,
  m as rn,
  n as an,
  o as on,
  r as sn,
  s as cn,
  u as ln,
  v as un,
  w as dn,
  y as fn,
} from "./PostFX-4zhHfKLG.js";
var pn = {
    models: [`cup_p4.glb`, `cup_p7.glb`, `fruits.glb`, `table.glb`],
    textures: [
      `cup9_p4_normal.webp`,
      `cup9_p7_normal.webp`,
      `fruit_normal.webp`,
      `lid9_p4_normal.webp`,
      `lid9_p7_normal.webp`,
    ],
  },
  mn = [`P4`, `P7`],
  hn = {
    P4: { id: `P4`, label: `Deli cup` },
    P7: { id: `P7`, label: `Bulky cup` },
  },
  gn = (e) => mn.includes(e),
  _n = (e) => {
    let t = e.userData?.part ?? e.parent?.userData?.part;
    if (typeof t == `string`) return t.toLowerCase();
    let n = e.name ?? ``;
    return /^(CupBody|Body|Cup)/i.test(n)
      ? `cup`
      : /^Lid/i.test(n)
        ? `lid`
        : null;
  };
function vn(e) {
  let t = {};
  if (!e) return t;
  for (let n of mn) {
    let r = e.getObjectByName(`Pkg_${n}`);
    if (!r) continue;
    let i = {
      id: n,
      root: r,
      body: null,
      lid: null,
      extras: { ...r.userData },
    };
    if (
      (r.traverse((e) => {
        if (!e.isMesh) return;
        let t = _n(e);
        t === `cup` || t === `body`
          ? (i.body ??= e)
          : t === `lid`
            ? (i.lid ??= e)
            : (e.visible = !1);
      }),
      !i.body || !i.lid)
    ) {
      console.warn(`Package export: ${n} has no body / lid mesh.`);
      continue;
    }
    (r.position.set(0, 0, 0),
      r.quaternion.identity(),
      r.scale.set(1, 1, 1),
      (t[n] = i));
  }
  return t;
}
var yn = { table: `models/table.glb`, fruits: `models/fruits.glb` },
  bn = (e) => `models/cup_${String(e).toLowerCase()}.glb`,
  xn = (e, t) => pn[e]?.includes(t),
  Sn = [`avif`, `webp`, `jpg`, `png`];
function Cn(e) {
  let t = /^(\w+)\/(\d+)\/(\w+)$/.exec(e ?? ``);
  if (!t) return null;
  let [, n, r, i] = t,
    a = i.startsWith(`webp`)
      ? `webp`
      : i.startsWith(`jpg`)
        ? `jpg`
        : i.startsWith(`avif`)
          ? `avif`
          : `png`;
  return { stroke: n, size: Number(r), format: i, ext: a };
}
var wn = (e) => `/star-knot-jelly/mr/jelly-painting/${e}`;
function Tn(e, t) {
  let n = e.getObjectByName(t);
  return (
    n ||
      e.traverse((e) => {
        !n && e.name.split(`.`)[0] === t && (n = e);
      }),
    n ?? null
  );
}
function En(e) {
  if (!e) return null;
  if (e.isMesh) return e;
  let t = null;
  return (
    e.traverse((e) => {
      !t && e.isMesh && (t = e);
    }),
    t
  );
}
var Dn = (e) =>
    typeof e == `string`
      ? e.replace(/^.*\//, ``).replace(/\.(png|webp|avif|jpe?g)$/i, ``)
      : null,
  On = (e) => Dn(e?.userData?.normalMap);
function kn(
  e,
  { color: t = !1, repeat: n = !1, anisotropy: r = 8, name: i } = {},
) {
  return (
    (e.name = i ?? e.name),
    (e.flipY = !1),
    (e.colorSpace = t ? D : ``),
    (e.wrapS = e.wrapT = n ? Ht : de),
    (e.anisotropy = r),
    (e.generateMipmaps = !0),
    (e.minFilter = N),
    (e.magFilter = _e),
    (e.needsUpdate = !0),
    e
  );
}
function An() {
  if (typeof createImageBitmap > `u` || typeof navigator > `u`) return !1;
  let e = navigator.userAgent,
    t = /^((?!chrome|android).)*safari/i.test(e)
      ? Number(e.match(/Version\/(\d+)/)?.[1] ?? 0)
      : 1 / 0,
    n = /firefox|fxios/i.test(e)
      ? Number(e.match(/Firefox\/(\d+)/)?.[1] ?? 0)
      : 1 / 0;
  return t >= 17 && n >= 98;
}
function jn(e, t, n) {
  let r = { ...e.userData },
    i = (e) =>
      e
        ? new Re().setFromBufferAttribute(e.geometry.attributes.position)
        : null,
    a = i(t),
    o = i(n),
    s = (e) => Math.max(e.max.x, -e.min.x, e.max.z, -e.min.z);
  if (
    a &&
    ((r.height ??= a.max.y), (r.rimRadius ??= s(a)), r.baseRadius == null)
  ) {
    let e = t.geometry.attributes.position,
      n = 0;
    for (let t = 0; t < e.count; t++)
      e.getY(t) < a.min.y + 0.002 &&
        (n = Math.max(n, Math.hypot(e.getX(t), e.getZ(t))));
    r.baseRadius = n || r.rimRadius * 0.65;
  }
  return (
    o && ((r.lidTopY ??= o.max.y), (r.lidRadius ??= s(o))),
    (r.lidTopY ??= r.height),
    r
  );
}
var Mn = class {
    constructor({ mapVariant: e = null } = {}) {
      ((this.mapVariant = e),
        (this.gltf = new _t()),
        (this.bitmaps = An()),
        (this.textureLoader = this.bitmaps
          ? new Me().setOptions({
              imageOrientation: `none`,
              premultiplyAlpha: `none`,
              colorSpaceConversion: `none`,
            })
          : new vt()),
        (this.sources = {}),
        (this.textures = {}),
        (this.packages = {}),
        (this.models = {}),
        (this.roots = {}),
        (this.disposables = []));
    }
    available(e) {
      let t = e.lastIndexOf(`/`);
      return xn(e.slice(0, t), e.slice(t + 1));
    }
    async loadGltf(e, t = yn[e]) {
      if (!this.available(t)) throw Error(`static/${t} is missing.`);
      let n = await this.gltf.loadAsync(wn(t));
      return ((this.sources[e] = t), n);
    }
    mapFile(e, t) {
      let n = Sn.find((n) => xn(e, `${t}.${n}`));
      return n ? `${e}/${t}.${n}` : null;
    }
    mapPath(e) {
      let t = this.mapVariant;
      return t
        ? `textures/lab/${t.stroke}/${t.size}/${t.format}/${e}.${t.ext}`
        : this.mapFile(`textures`, e);
    }
    async loadImage(e) {
      let t = await this.textureLoader.loadAsync(wn(e));
      return this.bitmaps ? t : t.image;
    }
    async loadTexture(e, t = {}) {
      let n = this.mapPath(e);
      if (!n) return null;
      try {
        let r = new we(await this.loadImage(n));
        return (
          (r.userData.map = e),
          this.disposables.push(r),
          kn(r, {
            ...t,
            name: n.replace(/^textures\//, ``).replace(/\.\w+$/, ``),
          })
        );
      } catch (e) {
        return (console.warn(`Could not load ${n}.`, e), null);
      }
    }
    async load(e = `P4`) {
      let t = String(e).toLowerCase();
      (this.namedTexture(`cup9_${t}_normal`),
        this.namedTexture(`lid9_${t}_normal`));
      let n = this.available(yn.fruits)
          ? this.loadGltf(`fruits`).catch(
              (e) => (console.warn(`Could not load ${yn.fruits}.`, e), null),
            )
          : null,
        r = this.loadTexture(`fruit_normal`, { anisotropy: 4 }),
        [i, , a, o] = await Promise.all([
          this.loadGltf(`table`),
          this.packageModel(e),
          n,
          r,
        ]);
      ((this.fruitModel = a),
        o && ((this.textures.fruit = o), (this.sources[`tex:fruit`] = o.name)));
      let s = En(Tn(i.scene, `Table`)) ?? En(i.scene);
      if (!s)
        throw Error(
          `Asset contract violated: models/table.glb has no Table mesh.`,
        );
      return (
        (this.table = s),
        (this.roots.tableScene = i.scene),
        (this.roots.fruitsScene = a?.scene ?? null),
        this
      );
    }
    packageModel(e) {
      return (
        (this.models[e] ??= this.loadGltf(`package ${e}`, bn(e))
          .then((t) => {
            let n = vn(t.scene);
            if (!n[e])
              throw Error(`Asset contract violated: ${bn(e)} has no Pkg_${e}.`);
            return (
              (this.packages[e] = n[e]),
              (this.roots[`package ${e}`] = t.scene),
              !0
            );
          })
          .catch((t) => {
            throw (delete this.models[e], t);
          })),
        this.models[e]
      );
    }
    namedTexture(e, t = {}) {
      return (
        (this.named ??= new Map()),
        !e || !this.mapFile(`textures`, e)
          ? Promise.resolve(null)
          : (this.named.has(e) || this.named.set(e, this.loadTexture(e, t)),
            this.named.get(e))
      );
    }
    async partTexture(e, t = {}) {
      for (let n of new Set(e.filter(Boolean))) {
        let e = await this.namedTexture(n, t);
        if (e) return e;
      }
      return null;
    }
    loadPackage(e) {
      return (
        (this.packageLoads ??= {}),
        (this.packageLoads[e] ??= this.buildPackageParts(e).catch((t) => {
          throw (delete this.packageLoads[e], t);
        })),
        this.packageLoads[e]
      );
    }
    packageInfo(e) {
      let t = this.packages?.[e];
      return t
        ? ((this.extras ??= {}),
          this.extras[e] ||
            ((this.extras[e] = jn(t.root, t.body, t.lid)),
            (this.extras[e].package = e)),
          { id: e, extras: this.extras[e] })
        : null;
    }
    async buildPackageParts(e) {
      await this.packageModel(e);
      let t = this.packages[e],
        n = this.packageInfo(e).extras,
        r = e.toLowerCase(),
        i = n.normalMaps ?? {},
        [a, o] = await Promise.all([
          this.partTexture([On(t.body), Dn(i.cup), `cup9_${r}_normal`]),
          this.partTexture([On(t.lid), Dn(i.lid), `lid9_${r}_normal`]),
        ]);
      if (!a || !o)
        throw Error(
          `Package ${e}: missing painted normal map (textures/cup9_${r}_normal.png / lid9_${r}_normal.png).`,
        );
      return (
        (this.textures[`cup_${e}`] = a),
        (this.textures[`lid_${e}`] = o),
        (this.sources[`tex:cup_${e}`] = a.name),
        (this.sources[`tex:lid_${e}`] = o.name),
        {
          ...t,
          extras: n,
          textures: { cup: a, lid: o },
          source: bn(e).replace(/^.*\//, ``),
        }
      );
    }
    async setMapVariant(e) {
      this.mapVariant = e;
      let t = this.disposables.filter((e) => e.userData.map),
        n = await Promise.all(
          t.map((e) => this.loadImage(this.mapPath(e.userData.map))),
        );
      if (this.mapVariant !== e) {
        for (let e of n) e.close?.();
        return 0;
      }
      t.forEach((e, t) => {
        let r = e.image;
        (e.dispose(),
          (e.image = n[t]),
          (e.name = this.mapPath(e.userData.map)
            .replace(/^textures\//, ``)
            .replace(/\.\w+$/, ``)),
          (e.needsUpdate = !0),
          r !== n[t] && r?.close?.());
      });
      for (let [e, t] of Object.entries(this.textures))
        t?.userData?.map && (this.sources[`tex:${e}`] = t.name);
      return t.length;
    }
    describe() {
      return Object.entries(this.sources)
        .map(([e, t]) => `${e}: ${t}`)
        .join(`, `);
    }
    dispose() {
      for (let e of this.disposables)
        (e.dispose(), this.bitmaps && e.image?.close?.());
      for (let e of Object.values(this.roots ?? {}))
        e?.traverse((e) => e.geometry?.dispose());
    }
  },
  Nn = { on: !0, bias: 0.2, farBias: 1.5, rayBias: 0.1, contact: 6 };
function Pn(e) {
  let t = (e) => I(e / 1e3),
    n = {
      on: I(+!!Nn.on),
      bias: t(Nn.bias),
      farBias: t(Nn.farBias),
      rayBias: t(Nn.rayBias),
      contact: t(Nn.contact),
    },
    r = (e) => Ae(e.mul(yt).floor().clamp(R(0), yt.sub(1))),
    i = (e, t) => xt(e).load(r(t)).x,
    a = (e, t) => Se(i(e, t), Ne, se),
    o = (e, t) => {
      let n = ve.mul(L(e.x.mul(2).sub(1), e.y.mul(-2).add(1), 0.5, 1)),
        r = n.xyz.div(n.w);
      return r.mul(t.div(r.z.min(-1e-7)));
    },
    s = (e) => {
      let t = Fe.mul(L(e, 1)),
        n = t.xy.div(t.w.max(1e-7));
      return R(n.x.mul(0.5).add(0.5), n.y.mul(-0.5).add(0.5));
    },
    c = (t, r, s) => {
      let c = a(s.depth, t),
        l = s.ray
          ? c.greaterThan(r.add(n.rayBias))
          : o(t, c).sub(s.position).dot(s.facing).greaterThan(s.bias);
      if (s.contact) {
        let r = i(e.peel, t),
          a = Se(r, Ne, se).sub(c);
        l = l.or(
          r.lessThan(1).and(a.greaterThan(-5e-5)).and(a.lessThan(n.contact)),
        );
      }
      return l;
    },
    l = (e, t) => {
      let r = t.position,
        i = r.normalize(),
        o = t.refractNormal.normalize(),
        l = o.dot(i).lessThan(0).select(o, o.negate()),
        u = t.normal.dot(r).lessThan(0).select(t.normal, t.normal.negate()),
        d = he.max(1.0001),
        f = d
          .sub(1)
          .mul(
            pe(`dispersion`, `float`)
              .mul(0.025)
              .add(pe(`chromaticAberration`, `float`)),
          ),
        p = ct.mul(ce.x).add(pe(`backdropDistance`, `float`).max(0)),
        m = lt(i, l, H(1).div(d.sub(f).max(1.0001)))
          .normalize()
          .mul(p)
          .toVar(),
        h = lt(i, l, H(1).div(d.add(f)))
          .normalize()
          .mul(p)
          .toVar(),
        g = t.own,
        _ = s(r.add(m)).sub(g).toVar(),
        v = s(r.add(h)).sub(g).toVar(),
        y = v.div(v.length().max(1e-7)).div(yt).mul(2).toVar(),
        b = { ...t, facing: u },
        x = (e) => {
          let n = null;
          for (let i = 0; i < t.points; i++) {
            let a = t.points === 1 ? 1 : i / (t.points - 1),
              o = _.add(v.sub(_).mul(a))
                .mul(e)
                .add(y.mul(t.points === 1 ? 1 : a * 2 - 1)),
              s = r.z.add(m.z.add(h.z.sub(m.z).mul(a)).mul(e)),
              l = c(g.add(o), s, b);
            n = n ? n.or(l) : l;
          }
          return n;
        };
      ie(n.on.greaterThan(0.5), () => {
        t.contact &&
          e.assign(z(n.contact, n.contact.add(0.002), r.z.sub(a(t.depth, g))));
        let i = v.mul(yt).length().greaterThan(0.5);
        ie(
          e
            .greaterThan(0)
            .and(i)
            .and(x(H(1))),
          () => {
            let t = H(0).toVar(),
              n = H(1).toVar();
            (Nt(5, () => {
              let e = t.add(n).mul(0.5).toVar();
              ie(x(e), () => {
                n.assign(e);
              }).Else(() => {
                t.assign(e);
              });
            }),
              e.assign(e.min(t)));
          },
        );
      });
    };
  return (
    (n.attach = (t, r = {}) => {
      if (!t?.isMeshTransmissionNodeMaterial || t.refractionGuard) return t;
      let i = r.mode === `ray`,
        a = {
          position: Te,
          refractNormal: ae,
          normal: r.normal ?? le,
          depth: e.opaque,
          bias: r.far ? n.farBias : n.bias,
          ray: i,
          contact: !!r.contact,
          points: Math.max(1, r.points ?? (i ? 2 : 1)),
        },
        o = H(1).toVar(`refractionKeep`),
        s = t.viewportBuffer,
        c = s.getBase ? s.getBase() : s,
        u = c.sample,
        d = c.clone();
      ((d.referenceNode = c),
        (d.sample = function (e) {
          let t = R(wt);
          return u.call(this, t.add(e.sub(t).mul(o)));
        }),
        (t.viewportBuffer = d));
      let f = t.setupDiffuseColor;
      return (
        (t.setupDiffuseColor = function (e) {
          let t = f.call(this, e);
          o.assign(1);
          let r = {
            refractNormal: a.refractNormal.toVar(),
            normal: a.normal.toVar(),
            own: wt.toVar(),
          };
          return (
            ie(n.on.greaterThan(0.5).and(this.maskNode ?? !0), () =>
              l(o, { ...a, ...r }),
            ),
            t
          );
        }),
        (t.refractionGuard = { keep: o, options: a }),
        (t.needsUpdate = !0),
        t
      );
    }),
    n
  );
}
var q = {
    opaque: 0,
    glassBehind: 1,
    glassNear: 2,
    sparkles: 3,
    liquid: 4,
    glassMiddle: 5,
    liquidBack: 6,
  },
  Fn = (...e) => e.reduce((e, t) => e | (1 << t), 0),
  In = class {
    constructor(e, t, n, r = {}) {
      ((this.renderer = e),
        (this.scene = t),
        (this.camera = n),
        (this.liquid = !1),
        (this.antialias = !1),
        (this.stats = { passes: 0 }));
      let i = { type: me },
        a = () => {
          let e = new k(1, 1, { type: De, format: be });
          return ((e.depthTexture = new bt(1, 1, re)), e);
        };
      ((this.peelTarget = a()),
        (this.peelTarget.texture.name = `Glass peel (depth)`),
        (this.liquidBackTarget = a()),
        (this.liquidBackTarget.texture.name = `Liquid back faces (depth)`),
        // A valid alpha output is required even when an inherited transparent
        // render context retains blending after a material / gray-mode change.
        (this.peelMaterial = new Ue({ colorWrite: !0, side: 0, blending: 0 })),
        (this.peelMaterial.name = `Glass peel (depth only)`),
        (this.targetA = new k(1, 1, {
          ...i,
          generateMipmaps: !0,
          minFilter: N,
        })),
        (this.targetA.depthTexture = new bt(1, 1, re)),
        (this.targetA.texture.name = `A · opaque + glass behind the liquid`),
        (this.refractionTarget = new k(1, 1, {...i,generateMipmaps:!0,minFilter:N})),
        (this.refractionTarget.texture.name = `Clean backdrop without foreground attachments`),
        (this.targetB = new k(1, 1, {
          ...i,
          generateMipmaps: !0,
          minFilter: N,
        })),
        (this.targetB.texture.name = `B · A + liquid + glass over it`),
        (this.targetC = new k(1, 1, i)),
        (this.targetC.texture.name = `Screen · B + nearest glass`),
        (this.targetScene = new k(1, 1, { ...i, depthBuffer: !1 })),
        (this.targetScene.texture.name = `Screen · the scene, kept for UI-only frames`),
        (this.keepScene = new Qe(
          this.copyMaterial(this.targetC.texture, `Copy screen → kept scene`),
        )),
        (this.restoreScene = new Qe(
          this.copyMaterial(
            this.targetScene.texture,
            `Copy kept scene → screen`,
          ),
        )),
        (this.sceneKept = !1),
        (this.copyA = new Qe(
          this.copyMaterial(this.targetA.texture, `Copy A → B`),
        )),
        (this.copySource = xt(this.targetB.texture, wt)),
        (this.copyToC = new Qe(
          this.copyMaterial(this.copySource, `Copy B → screen`),
        )),
        (this.textures = {
          peelDepth: this.peelTarget.depthTexture,
          opaqueDepth: this.targetA.depthTexture,
          liquidBackDepth: this.liquidBackTarget.depthTexture,
          opaqueColor: this.targetA.texture,
        }),
        (this.glassBackdrop = xt(this.targetB.texture)),
        (this.viewports = { behind: O(), middle: O() }),
        (this.ghosts = { guard: !0 }),
        (this.guard = Pn({
          opaque: this.targetA.depthTexture,
          peel: this.peelTarget.depthTexture,
        })),
        (this.output = new ot(e)),
        (this.outputTexture = xt(this.targetC.texture, wt)),
        (this.output.outputNode = this.outputTexture),
        (this.postfx = an({
          renderer: e,
          inputNode: this.outputTexture,
          subjectDepth: this.liquidBackTarget.depthTexture,
          subjectOpaqueDepth: this.targetA.depthTexture,
          subjectGlassDepth: this.peelTarget.depthTexture,
          settings: r,
        })),
        this.postfx.attach(this.output),
        (this.transmissionPaintSettings = {...r, frame:false}),
        (this.transmissionPaint = an({renderer:e, inputNode:xt(this.refractionTarget.texture, wt), settings:this.transmissionPaintSettings, linearInput:true})),
        (this.transmissionTexture = this.transmissionPaint.getTransmissionTexture()),
        (this.transmissionBackdrop = xt(this.transmissionTexture.value)),
        (this.ui = this.overlay = null),
        (this._css = new w()));
    }
    copyMaterial(e, t) {
      let n = new Ue({ depthTest: !1, depthWrite: !1 });
      return ((n.colorNode = e.isNode ? e : xt(e, wt)), (n.name = t), n);
    }
    configure({ antialias: e, liquid: t }) {
      ((this.liquid = t), (this.antialias = e));
      let n = t ? this.targetB.texture : this.targetA.texture;
      ((this.glassBackdrop.value = n), (this.copySource.value = n));
      let r = e ? 4 : 0,
        i = !1;
      for (let e of [this.targetA, this.targetB, this.targetC])
        e.samples !== r && ((e.samples = r), e.dispose(), (i = !0));
      i &&
        this.renderer.backend?.isWebGPUBackend &&
        this.renderer.contextNode &&
        (this.renderer.contextNode.needsUpdate = !0);
    }
    resize() {
      let e = this.renderer.getDrawingBufferSize(new w());
      for (let t of [
        this.peelTarget,
        this.refractionTarget,
        this.liquidBackTarget,
        this.targetA,
        this.targetB,
        this.targetC,
        this.targetScene,
      ])
        t.setSize(e.x, e.y);
      this.sceneKept = !1;
      let t = this.renderer.getSize(this._css);
      this.postfx.setSize(t.x, t.y, this.renderer.getPixelRatio());
      this.transmissionPaint.setSize(t.x, t.y, this.renderer.getPixelRatio());
    }
    pass(e, t, { copy: n = null, override: r = null } = {}) {
      let { renderer: i, scene: a, camera: o } = this;
      i.setRenderTarget(e);
      let s = i.autoClear;
      if (n) {
        let t = e.texture,
          r = t.generateMipmaps;
        ((i.autoClear = !0), (t.generateMipmaps = !1));
        try {
          n.render(i);
        } finally {
          t.generateMipmaps = r;
        }
        i.autoClear = !1;
      }
      ((o.layers.mask = Fn(...t)),
        (a.overrideMaterial = r),
        i.render(a, o),
        (a.overrideMaterial = null),
        (i.autoClear = s),
        this.stats.passes++);
    }
    get keepsScene() {
      return this.sceneKept && !this.antialias;
    }
    render(e = !0, t = !1) {
      (e || !this.keepsScene ? this.renderScene(t) : this.renderUI(),
        this.postfx.update(),
        this.output.render(),
        this.overlay?.render(this.renderer),
        this.ui?.renderOverlay(this.renderer));
    }
    compileAsync() {
      let { renderer: e, scene: t, camera: n } = this,
        r = n.layers.mask,
        i = [];
      t.updateMatrixWorld();
      let a = (r, a, o = null) => {
        (e.setRenderTarget(r),
          (n.layers.mask = Fn(...a)),
          (t.overrideMaterial = o),
          i.push(e.compileAsync(t, n)),
          (t.overrideMaterial = null));
      };
      return (
        a(this.peelTarget, [q.glassNear], this.peelMaterial),
        this.liquid && a(this.liquidBackTarget, [q.liquidBack]),
        a(this.targetA, [q.opaque, q.sparkles, q.glassBehind]),
        this.liquid && a(this.targetB, [q.liquid, q.glassMiddle]),
        a(this.targetC, [q.glassNear]),
        this.ui && i.push(this.ui.compile(e)),
        this.overlay && i.push(this.overlay.compile(e)),
        (n.layers.mask = r),
        e.setRenderTarget(null),
        Promise.all(i)
      );
    }
    renderScene(e = !1) {
      Object.assign(this.transmissionPaintSettings, this.postfx.settings, {frame:false, speckle:this.postfx.settings.speckle * 0.35, smear:this.postfx.settings.smear * 0.6});
      this.transmissionPaint.update();
      this.transmissionTexture = this.transmissionPaint.getTransmissionTexture();
      this.transmissionBackdrop.value = this.transmissionTexture.value;
      let { renderer: t, camera: n } = this,
        r = n.layers.mask;
      ((this.stats.passes = 0),
        (this.guard.on.value = +!!this.ghosts.guard),
        this.pass(this.peelTarget, [q.glassNear], {
          override: this.peelMaterial,
        }),
        this.liquid && this.pass(this.liquidBackTarget, [q.liquidBack]),
        this.pass(this.targetA, [q.opaque, q.sparkles, q.glassBehind]),
        this.renderCleanBackdrop(),
        this.paintTransmissionEnabled && (this.transmissionTexture.textureNeedsUpdate = true, this.transmissionTexture.updateBefore({renderer:t})),
        this.liquid &&
          this.pass(this.targetB, [q.liquid, q.glassMiddle], {
            copy: this.copyA,
          }),
        this.pass(this.targetC, [q.glassNear], { copy: this.copyToC }),
        (this.sceneKept = e && !this.antialias),
        this.sceneKept &&
          (t.setRenderTarget(this.targetScene),
          this.keepScene.render(t),
          t.setRenderTarget(this.targetC),
          this.stats.passes++),
        this.drawUI(),
        (n.layers.mask = r),
        t.setRenderTarget(null));
    }
    renderCleanBackdrop() {
      const hidden=this.refractionExclude??[];
      const vis=hidden.map(o=>o.visible);
      try {hidden.forEach(o=>o.visible=false);this.pass(this.refractionTarget,[q.opaque,q.sparkles]);}
      finally {hidden.forEach((o,i)=>o.visible=vis[i]);}
    }
    renderUI() {
      let { renderer: e } = this;
      ((this.stats.passes = 0), e.setRenderTarget(this.targetC));
      let t = e.autoClear;
      e.autoClear = !0;
      try {
        (this.restoreScene.render(e), this.stats.passes++);
      } finally {
        e.autoClear = t;
      }
      (this.drawUI(), e.setRenderTarget(null));
    }
    drawUI() {
      if (!this.ui) return;
      let { renderer: e } = this,
        t = e.autoClear;
      e.autoClear = !1;
      try {
        (e.render(this.ui.scene, this.ui.camera), this.stats.passes++);
      } finally {
        e.autoClear = t;
      }
    }
    dispose() {
      (this.transmissionTexture?.dispose(), this.transmissionPaint.dispose(), this.postfx.dispose(),
        this.output.dispose(),
        this.copyA.material.dispose(),
        this.copyToC.material.dispose(),
        this.keepScene.material.dispose(),
        this.restoreScene.material.dispose(),
        this.peelMaterial.dispose());
      for (let e of [
        this.peelTarget,
        this.refractionTarget,
        this.liquidBackTarget,
        this.targetA,
        this.targetB,
        this.targetC,
        this.targetScene,
      ])
        e.dispose();
    }
  },
  Ln = (e, t) => {
    let n = U.degToRad(e),
      r = U.degToRad(t);
    return new B(
      Math.sin(n) * Math.cos(r),
      Math.sin(r),
      Math.cos(n) * Math.cos(r),
    );
  },
  Rn = {
    glass: {
      top: `#1d130f`,
      horizon: `#5e4a5e`,
      bottom: `#4b3d5c`,
      cards: [
        [`#fff4e6`, 9, [-112, -30], [0.32, 2.4]],
        [`#ffe9d6`, 5, [-128, -24], [0.14, 2]],
        [`#ffe6c8`, 6, [-138, 30], [0.9, 0.55]],
        [`#fff0e0`, 4, [-70, 8], [0.25, 1.2]],
        [`#cdb6ff`, 3.2, [78, -22], [0.55, 2.2]],
        [`#b9a4f0`, 1.6, [120, 25], [1.2, 0.6]],
      ],
    },
    scene: {
      top: `#3a2a24`,
      horizon: `#3b2c33`,
      bottom: `#2a2030`,
      cards: [
        [`#ffe3c2`, 2.2, [-140, 45], [2.6, 1.8]],
        [`#b8a2e6`, 0.9, [70, 10], [2, 1.6]],
      ],
    },
  };
function zn(
  e,
  { top: t, horizon: n, bottom: r, cards: i },
  a = `#ffffff`,
  o = null,
) {
  let s = new jt(),
    c = new Ue({ side: 1, depthWrite: !1 }),
    l = dt(ne).y,
    u = new G(a),
    d = (e) => new G(e).multiply(u).toArray();
  c.colorNode = V(
    V(W(...d(r)), W(...d(n)), z(-0.9, -0.05, l)),
    W(...d(t)),
    z(0, 0.6, l),
  );
  let f = new kt(new st(8, 48, 24), c);
  s.add(f);
  for (let [e, t, [n, r], a] of i) {
    let i = new kt(
      new Ve(...a),
      new Ue({ color: new G(e).multiply(u).multiplyScalar(t), side: 2 }),
    );
    (i.position.copy(Ln(n, r).multiplyScalar(3)), i.lookAt(0, 0, 0), s.add(i));
  }
  let p = new At(e),
    m = p.fromScene(s, 0.02, 0.1, 20, o ? { renderTarget: o } : {});
  return (
    p.dispose(),
    s.traverse((e) => {
      (e.geometry?.dispose(), e.material?.dispose());
    }),
    m
  );
}
function Bn(e, t, n) {
  e.background = null;
  let r = n.scene.envTint,
    i = zn(t, Rn.glass, n.scene.envTint),
    a = zn(t, Rn.scene, n.scene.envTint);
  e.environment = a.texture;
  let o = new C(`#ffffff`, 1, 0, 0.4, 0.85, 0);
  ((o.name = `Key`),
    (o.castShadow = !0),
    o.shadow.mapSize.set(256, 256),
    (o.shadow.camera.near = 0.3),
    (o.shadow.camera.far = 2.4),
    (o.shadow.autoUpdate = !1),
    o.shadow.camera.layers.set(q.opaque),
    o.layers.enableAll(),
    e.add(o, o.target));
  let s = new Ot(`#ffffff`, `#000000`, 1);
  s.layers.enableAll();
  let c = new Ie(`#ffffff`, 1);
  (c.layers.enableAll(), e.add(s, c, c.target));
  let l = () => {
    let { light: l } = n;
    (n.scene.envTint !== r &&
      ((r = n.scene.envTint),
      zn(t, Rn.glass, n.scene.envTint, i),
      zn(t, Rn.scene, n.scene.envTint, a)),
      t.setClearColor(n.scene.background, 1),
      (e.environmentIntensity = n.scene.environment),
      o.color.set(l.color),
      (o.intensity = l.intensity),
      (o.angle = U.degToRad(l.cone)),
      (o.penumbra = l.penumbra));
    let u = new B(l.targetX, 0, l.targetZ);
    (o.position
      .copy(Ln(l.azimuth, l.elevation).multiplyScalar(l.distance))
      .add(u)
      .add(new B(0, 0.04, 0)),
      o.target.position.copy(u),
      o.target.updateMatrixWorld(),
      (o.shadow.needsUpdate = !0),
      s.color.set(l.ambientSky),
      s.groundColor.set(l.ambientGround),
      (s.intensity = l.ambient),
      c.color.set(l.rimColor),
      (c.intensity = l.rim),
      c.position.copy(Ln(l.rimAzimuth, l.rimElevation)),
      c.target.position.set(0, 0, 0),
      c.target.updateMatrixWorld());
  };
  return (
    l(),
    {
      key: o,
      hemi: s,
      rim: c,
      update: l,
      keyDirection: () => Ln(n.light.azimuth, n.light.elevation),
      environment: i.texture,
      dispose: () => {
        (i.dispose(), a.dispose(), o.dispose(), s.dispose(), c.dispose());
      },
    }
  );
}
var Vn = {
  clearance: 4e-4,
  meniscusHeight: 0.0015,
  meniscusWidth: 0.003,
  lipRadius: 25e-5,
  meniscusSteps: 10,
  lipSteps: 6,
  topRings: 10,
  segments: 96,
};
function Hn(e, t) {
  let n = e.length,
    r = [];
  for (let t = 0; t < n - 1; t++) {
    let n = e[t + 1][0] - e[t][0],
      i = e[t + 1][1] - e[t][1],
      a = Math.hypot(n, i);
    r.push([-i / a, n / a]);
  }
  let i = [];
  for (let a = 0; a < n; a++) {
    let o, s;
    a === 0
      ? ([o, s] = r[0])
      : a === n - 1
        ? ([o, s] = r[n - 2])
        : ((o = r[a - 1][0] + r[a][0]), (s = r[a - 1][1] + r[a][1]));
    let c = Math.hypot(o, s);
    ((o /= c), (s /= c));
    let l = a < n - 1 ? Math.max(o * r[a][0] + s * r[a][1], 0.5) : 1;
    i.push([e[a][0] + (o * t) / l, e[a][1] + (s * t) / l]);
  }
  return ((i[0] = [0, e[0][1] + t]), i);
}
function Un(e, t) {
  return [
    Hn(e, t.clearance)[0][1] + 8e-4,
    e[e.length - 1][1] - 0.004 - t.meniscusHeight,
  ];
}
function Wn(e, t, n = t.fillY) {
  let { clearance: r, meniscusHeight: i, meniscusWidth: a, lipRadius: o } = t,
    s = Hn(e, r),
    c = n + i - o,
    l = 0;
  for (let e = 1; e < s.length; e++) s[e][1] < s[l][1] && (l = e);
  let u = -1;
  for (let e = l; e < s.length - 1; e++)
    if (s[e][1] < c && c <= s[e + 1][1]) {
      u = e;
      break;
    }
  if (u < 0 || s[0][1] >= n) throw Error(`fillY ${n} outside the cavity`);
  let d = (c - s[u][1]) / (s[u + 1][1] - s[u][1]),
    f = [s[u][0] + d * (s[u + 1][0] - s[u][0]), c],
    p = s.slice(0, u + 1),
    m = p[p.length - 1];
  Math.hypot(f[0] - m[0], f[1] - m[1]) < 2e-4 && p.pop();
  let h = p.length;
  p.push(f);
  let g = f[0] - o;
  for (let e = 1; e <= t.lipSteps; e++) {
    let n = (Math.PI * e) / t.lipSteps;
    p.push([g + o * Math.cos(n), c + o * Math.sin(n)]);
  }
  let _ = f[0] - a,
    v = a - 2 * o,
    y = c - n;
  for (let e = 1; e <= t.meniscusSteps; e++) {
    let n = (0.5 * Math.PI * e) / t.meniscusSteps;
    p.push([_ + v * Math.cos(n), c - y * Math.sin(n)]);
  }
  for (let e = 1; e < t.topRings; e++) p.push([_ * (1 - e / t.topRings), n]);
  p.push([0, n]);
  let b = [0];
  for (let e = 1; e < p.length; e++)
    b.push(b[e - 1] + Math.hypot(p[e][0] - p[e - 1][0], p[e][1] - p[e - 1][1]));
  let x = b[b.length - 1];
  return {
    points: p,
    v: b.map((e) => e / x),
    contact: f,
    offset: s,
    hit: u,
    contactIndex: h,
  };
}
function Gn(e, t = 96) {
  let n = 0;
  for (let t = 0; t < e.length - 1; t++) {
    let [r, i] = e[t],
      [a, o] = e[t + 1];
    n += (Math.PI / 3) * (r * r + r * a + a * a) * (o - i);
  }
  return (
    ((Math.abs(n) * t * Math.sin((2 * Math.PI) / t)) / (2 * Math.PI)) * 1e6
  );
}
function Kn(e, t) {
  let n = 0;
  for (let t = 1; t < e.length; t++) e[t][1] < e[n][1] && (n = t);
  for (let r = Math.max(1, n + 1); r < e.length; r++) {
    let [n, i] = e[r - 1],
      [a, o] = e[r];
    if (i < t && t <= o) return n + ((a - n) * (t - i)) / Math.max(1e-9, o - i);
  }
  return e[e.length - 1][0];
}
function qn(e, t, n = 96) {
  let r = e.length,
    i = e.map((t, n) => {
      if (n === 0) return [0, -1];
      if (n === r - 1) return [0, 1];
      let i = 0,
        a = 0;
      for (let [t, r] of [
        [n - 1, n],
        [n, n + 1],
      ]) {
        let n = e[r][0] - e[t][0],
          o = e[r][1] - e[t][1],
          s = Math.hypot(n, o) || 1;
        ((i += o / s), (a += -n / s));
      }
      let o = Math.hypot(i, a) || 1;
      return [i / o, a / o];
    }),
    a = n + 1,
    o = new Float32Array(r * a * 3),
    s = new Float32Array(r * a * 3),
    c = new Float32Array(r * a * 2),
    l = 0,
    u = 0;
  for (let a = 0; a < r; a++) {
    let [r, d] = e[a],
      [f, p] = i[a];
    for (let e = 0; e <= n; e++) {
      let i = Math.PI / 2 + (2 * Math.PI * (e % n)) / n,
        m = Math.cos(i),
        h = -Math.sin(i);
      (o.set([r * m, d, r * h], l),
        s.set([f * m, p, f * h], l),
        c.set([e / n, t[a]], u),
        (l += 3),
        (u += 2));
    }
  }
  let d = [];
  for (let t = 0; t < r - 1; t++) {
    let r = t * a,
      i = (t + 1) * a;
    for (let a = 0; a < n; a++) {
      let n = r + a,
        o = r + a + 1,
        s = i + a + 1,
        c = i + a;
      (e[t][0] > 0 && d.push(n, o, c), e[t + 1][0] > 0 && d.push(o, s, c));
    }
  }
  let f = new ht();
  return (
    f.setAttribute(`position`, new it(o, 3)),
    f.setAttribute(`normal`, new it(s, 3)),
    f.setAttribute(`uv`, new it(c, 2)),
    f.setIndex(d),
    f.computeBoundingBox(),
    f.computeBoundingSphere(),
    f
  );
}
function Jn(e, t, n) {
  let r = Hn(e, t.clearance);
  return {
    fillY: n,
    wallRadius: Kn(r, n),
    floorY: Math.min(...r.map((e) => e[1])),
  };
}
function Yn(e, t, n) {
  let r = { ...Vn, ...t };
  ((r.meniscusHeight = Math.max(r.meniscusHeight, r.lipRadius + 1e-4)),
    (r.meniscusWidth = Math.max(r.meniscusWidth, 2 * r.lipRadius + 2e-4)));
  let [i, a] = Un(e, r),
    o = Math.min(a, Math.max(i, n)),
    { points: s, v: c } = Wn(e, r, o),
    l = qn(s, c, r.segments);
  return (
    (l.name = `Liquid (rebuilt)`),
    { geometry: l, info: { ...Jn(e, r, o), volumeMl: Gn(s, r.segments) } }
  );
}
var Xn = 0.0022;
function Zn(e) {
  let t = [0];
  for (let n = 1; n < e.length; n++)
    t.push(t[n - 1] + Math.hypot(e[n][0] - e[n - 1][0], e[n][1] - e[n - 1][1]));
  let n = t[t.length - 1],
    r = (e) => {
      let n = 0,
        r = t.length - 1;
      for (; r - n > 1;) {
        let i = (n + r) >> 1;
        t[i] <= e ? (n = i) : (r = i);
      }
      return n;
    };
  function i(i, a = [0, 0]) {
    i = Math.min(n, Math.max(0, i));
    let o = r(i),
      s = (i - t[o]) / Math.max(1e-12, t[o + 1] - t[o]);
    return (
      (a[0] = e[o][0] + (e[o + 1][0] - e[o][0]) * s),
      (a[1] = e[o][1] + (e[o + 1][1] - e[o][1]) * s),
      a
    );
  }
  function a(t, i = [0, 0]) {
    let a = 0,
      o = 0;
    for (let i of [-3e-4, 3e-4]) {
      let s = r(Math.min(n - 1e-9, Math.max(0, t + i))),
        c = e[s + 1][0] - e[s][0],
        l = e[s + 1][1] - e[s][1],
        u = Math.hypot(c, l) || 1;
      ((a += l / u), (o += -c / u));
    }
    let s = Math.hypot(a, o) || 1;
    return ((i[0] = a / s), (i[1] = o / s), i);
  }
  return {
    points: e,
    acc: t,
    length: n,
    at: i,
    normalAt: a,
    along: (n, r) => t[n] + Math.hypot(r[0] - e[n][0], r[1] - e[n][1]),
  };
}
var Qn = (e, t) => {
  let n = Math.sin((e + 1) * 12.9898 + t * 78.233) * 43758.5453;
  return n - Math.floor(n);
};
function $n(e, t, n, r) {
  let i = Hn(e, { ...Vn, ...t }.clearance),
    a = 0;
  for (let e = 1; e < i.length; e++) i[e][1] < i[a][1] && (a = e);
  let o = i[a][1],
    s = -1 / 0;
  for (let e = 0; e <= a; e++) s = Math.max(s, i[e][1]);
  let c = Math.min(3, Math.max(0, Number(r.wave) || 0)) / 1e3,
    l = Math.min(4, Math.max(0, Number(r.meniscus) || 0)) / 1e3,
    u = Math.max(0.004, n - o),
    d = s + 1.4 * c + 0.0012,
    f = n - 1.4 * c - l - 0.004,
    p = Math.min(
      f,
      Math.max(
        d,
        o + Math.min(0.85, Math.max(0.03, Number(r.height) || 0)) * u,
      ),
    ),
    m = Math.max(0.002, Kn(i, p)),
    h = Number(r.seed) || 0,
    g = Math.min(4, Math.max(0.2, Number(r.waveScale) || 1)),
    _ = [0, 1, 2, 3].map((e) => Qn(h, e) * Math.PI * 2),
    v = Xn,
    y = (e) => e * e * (3 - 2 * e),
    b = (e) => l * Math.exp(-Math.max(0, m - e) / v);
  function x(e, t) {
    let n = Math.min(1.25, Math.max(0, e / m)),
      r = n >= 0.35 ? 1 : y(n / 0.35),
      i =
        0.55 * Math.sin(2 * t + _[0] + 3.1 * g * n) +
        0.3 * Math.sin(3 * t + _[1] - 2.3 * g * n) +
        0.2 * Math.sin(5 * t + _[2] + 5 * g * n),
      a = 0.3 * Math.cos(6 * g * n * n + _[3]);
    return p + b(e) + c * (i * r * (0.5 + 0.5 * Math.min(1, n)) + a);
  }
  function S(e, t) {
    let n = 1e-5;
    return [
      (x(e + n, t) - x(Math.max(0, e - n), t)) / (e + n - Math.max(0, e - n)),
      (x(e, t + 1e-4) - x(e, t - 1e-4)) / 2e-4,
    ];
  }
  let C = Zn(i),
    w = [0, 0];
  function T(e) {
    let t = (t) => (C.at(t, w), w[1] - x(w[0], e)),
      n = 0,
      r = t(0);
    for (let e = 0; e < i.length - 1; e++)
      for (let i = 1; i <= 6; i++) {
        let a = C.acc[e] + ((C.acc[e + 1] - C.acc[e]) * i) / 6,
          o = t(a);
        if (r < 0 && o >= 0) {
          let e = n,
            r = a;
          for (let n = 0; n < 30; n++) {
            let n = (e + r) / 2;
            t(n) < 0 ? (e = n) : (r = n);
          }
          return (C.at(r, w), { s: r, r: w[0], y: w[1] });
        }
        ((n = a), (r = o));
      }
    return (C.at(C.length, w), { s: C.length, r: w[0], y: w[1] });
  }
  return { baseY: p, lowY: o, poly: C, yAt: x, gradient: S, wallHit: T };
}
function er(e, t) {
  let n = e[0].length,
    r = t + 1,
    i = new Float32Array(n * r * 3),
    a = new Float32Array(n * r * 3),
    o = new Float32Array(n * r * 2);
  for (let s = 0; s < r; s++) {
    let c = Math.PI / 2 + (2 * Math.PI * (s % t)) / t,
      l = Math.cos(c),
      u = -Math.sin(c),
      d = e[s];
    for (let e = 0; e < n; e++) {
      let [c, f, p, m, h] = d[e],
        g = e * r + s;
      ((i[g * 3] = c * l),
        (i[g * 3 + 1] = f),
        (i[g * 3 + 2] = c * u),
        (a[g * 3] = p),
        (a[g * 3 + 1] = m),
        (a[g * 3 + 2] = h),
        (o[g * 2] = s / t),
        (o[g * 2 + 1] = e / (n - 1)));
    }
  }
  let s = [];
  for (let i = 0; i < n - 1; i++)
    for (let n = 0; n < t; n++) {
      let t = i * r + n,
        a = i * r + n + 1,
        o = (i + 1) * r + n + 1,
        c = (i + 1) * r + n;
      ((e[n][i][0] > 1e-7 || e[n + 1][i][0] > 1e-7) && s.push(t, a, c),
        (e[n][i + 1][0] > 1e-7 || e[n + 1][i + 1][0] > 1e-7) &&
          s.push(a, o, c));
    }
  let c = new ht();
  return (
    c.setAttribute(`position`, new it(i, 3)),
    c.setAttribute(`normal`, new it(a, 3)),
    c.setAttribute(`uv`, new it(o, 2)),
    c.setIndex(s),
    c.computeBoundingBox(),
    c.computeBoundingSphere(),
    c
  );
}
function tr(e, t, n, r = 1) {
  let [i, a] = e.gradient(t, n),
    o = Math.cos(n),
    s = -Math.sin(n),
    c = t > 1e-6 ? a / t : 0,
    l = -(i * o + c * -Math.sin(n)),
    u = -(i * s + c * -Math.cos(n)),
    d = Math.hypot(l, 1, u);
  return [(l / d) * r, (1 / d) * r, (u / d) * r];
}
function nr(e, t, n, r, i) {
  let a = [];
  for (let o = 0; o <= r; o++) {
    let s = (o / r) ** 1.7,
      c = o === r ? 0 : t.r * (1 - s),
      l = o === 0 ? t.y : e.yAt(c, n);
    a.push([c, l, ...tr(e, c, n, i)]);
  }
  return a;
}
function rr(e, { segments: t = 96, floorRows: n = 48, topRows: r = 28 } = {}) {
  let i = [],
    a = [0, 0],
    o = [0, 0],
    s = 0;
  for (let c = 0; c <= t; c++) {
    let l = Math.PI / 2 + (2 * Math.PI * (c % t)) / t,
      u = Math.cos(l),
      d = -Math.sin(l),
      f = e.wallHit(l),
      p = [];
    for (let t = 0; t <= n; t++) {
      let r = t / n;
      (e.poly.at(f.s * r, a),
        e.poly.normalAt(f.s * r, o),
        p.push(
          t === 0
            ? [0, a[1], 0, -1, 0]
            : [a[0], a[1], o[0] * u, o[1], o[0] * d],
        ));
    }
    let m = nr(e, f, l, r, 1);
    ((m[m.length - 1] = [0, m[m.length - 1][1], 0, 1, 0]),
      p.push(...m),
      c < t &&
        (s +=
          Gn(
            p.map((e) => [e[0], e[1]]),
            1e6,
          ) / t),
      i.push(p));
  }
  let c = er(i, t);
  return (
    (c.name = `Cream layer`),
    { geometry: c, info: { baseY: e.baseY, volumeMl: s } }
  );
}
function ir(e, t, n, r, { wallRows: i = 64, bottomRows: a = 28 } = {}) {
  let o = { ...Vn, ...t };
  ((o.meniscusHeight = Math.max(o.meniscusHeight, o.lipRadius + 1e-4)),
    (o.meniscusWidth = Math.max(o.meniscusWidth, 2 * o.lipRadius + 2e-4)));
  let [s, c] = Un(e, o),
    l = Math.min(c, Math.max(s, n)),
    u = Wn(e, o, l),
    d = u.points.slice(u.contactIndex),
    f = r.poly.along(u.hit, u.contact),
    p = o.segments,
    m = [],
    h = [0, 0],
    g = 0;
  for (let e = 0; e <= p; e++) {
    let t = Math.PI / 2 + (2 * Math.PI * (e % p)) / p,
      n = Math.cos(t),
      o = -Math.sin(t),
      s = r.wallHit(t),
      c = nr(r, s, t, a, -1).reverse();
    c[0] = [0, c[0][1], 0, -1, 0];
    let l = [],
      u = Math.min(s.s, f - 5e-4);
    for (let e = 1; e < i; e++)
      (r.poly.at(u + ((f - u) * e) / i, h), l.push([h[0], h[1]]));
    let _ = [...l, ...d.map((e) => [e[0], e[1]])],
      v = [[c[c.length - 1][0], c[c.length - 1][1]], ..._],
      y = [...c];
    for (let e = 1; e < v.length; e++) {
      let t = 0,
        r = 0;
      if (e === v.length - 1) ((t = 0), (r = 1));
      else {
        for (let [n, i] of [
          [e - 1, e],
          [e, e + 1],
        ]) {
          let e = v[i][0] - v[n][0],
            a = v[i][1] - v[n][1],
            o = Math.hypot(e, a) || 1;
          ((t += a / o), (r += -e / o));
        }
        let n = Math.hypot(t, r) || 1;
        ((t /= n), (r /= n));
      }
      y.push([v[e][0], v[e][1], t * n, r, t * o]);
    }
    (e < p &&
      (g +=
        Gn(
          y.map((e) => [e[0], e[1]]),
          1e6,
        ) / p),
      m.push(y));
  }
  let _ = er(m, p);
  return (
    (_.name = `Liquid (above the cream)`),
    { geometry: _, info: { ...Jn(e, o, l), volumeMl: g, creamY: r.baseY } }
  );
}
function ar(e, t) {
  let n = e?.cavity;
  if (!n || !Array.isArray(n.positions) || !Array.isArray(t) || t.length < 3)
    return null;
  let r = Float64Array.from(n.positions),
    i = Uint32Array.from(n.triangles),
    a = +(t[0][0] === 0),
    o = t.slice(a),
    s = (e) => {
      if (e <= o[0][1]) return o[0][0];
      for (let t = 1; t < o.length; t++)
        if (e <= o[t][1]) {
          let [n, r] = o[t - 1],
            [i, a] = o[t];
          return a > r ? n + ((i - n) * (e - r)) / (a - r) : i;
        }
      return o[o.length - 1][0];
    },
    c = Float64Array.from(
      new Set(Array.from({ length: r.length / 3 }, (e, t) => r[t * 3 + 1])),
    ).sort(),
    l = Array(Math.max(0, c.length - 1)).fill(null),
    u = (e) => {
      let t = 0,
        n = c.length - 1;
      for (; n - t > 1;) {
        let r = (t + n) >> 1;
        c[r] <= e ? (t = r) : (n = r);
      }
      return t;
    },
    d = !1,
    f = () => {
      d = !0;
      let e = Array.from({ length: l.length }, () => []);
      for (let t = 0; t < i.length; t += 3) {
        let n = r[i[t] * 3 + 1],
          a = r[i[t + 1] * 3 + 1],
          o = r[i[t + 2] * 3 + 1],
          s = Math.max(n, a, o),
          d = u(Math.min(n, a, o)),
          f = s >= c[c.length - 1] ? l.length : u(s);
        for (let n = d; n < f; n++) {
          let a = (c[n] + c[n + 1]) / 2,
            o = e[n],
            s = 0;
          for (let e = 0; e < 3; e++) {
            let n = i[t + e],
              o = i[t + ((e + 1) % 3)];
            r[n * 3 + 1] - a > 0 != r[o * 3 + 1] - a > 0 && s++;
          }
          if (s === 2)
            for (let e = 0; e < 3; e++) {
              let n = i[t + e],
                s = i[t + ((e + 1) % 3)];
              r[n * 3 + 1] - a > 0 != r[s * 3 + 1] - a > 0 && o.push(n, s);
            }
        }
      }
      for (let t = 0; t < l.length; t++) l[t] = Uint32Array.from(e[t]);
    },
    p = (e) => {
      let t = [];
      for (let n = 0; n < i.length; n += 3) {
        let a = [];
        for (let t = 0; t < 3; t++) {
          let o = i[n + t],
            s = i[n + ((t + 1) % 3)],
            c = r[o * 3 + 1] - e,
            l = r[s * 3 + 1] - e;
          if (
            (Math.abs(c) < 1e-12 && (c = 1e-12),
            Math.abs(l) < 1e-12 && (l = 1e-12),
            c > 0 != l > 0)
          ) {
            let e = c / (c - l);
            a.push(
              r[o * 3] + (r[s * 3] - r[o * 3]) * e,
              r[o * 3 + 2] + (r[s * 3 + 2] - r[o * 3 + 2]) * e,
            );
          }
        }
        a.length === 4 && t.push(...a);
      }
      return Float64Array.from(t);
    },
    m = new Map(),
    h = (e) => {
      let t = Math.round(e * 1e9),
        n = m.get(t);
      if (n) return n;
      let i = c.length - 1;
      if (i < 1 || e < c[0] - 1e-11 || e > c[i] + 1e-11) n = new Float64Array();
      else {
        let t = u(e);
        if (e - c[t] < 1e-11 || t >= i || c[t + 1] - e < 1e-11) n = p(e);
        else {
          d || f();
          let i = l[t];
          n = new Float64Array(i.length);
          for (let t = 0; t < i.length; t += 2) {
            let a = i[t],
              o = i[t + 1],
              s = r[a * 3 + 1] - e,
              c = s / (s - (r[o * 3 + 1] - e));
            ((n[t] = r[a * 3] + (r[o * 3] - r[a * 3]) * c),
              (n[t + 1] = r[a * 3 + 2] + (r[o * 3 + 2] - r[a * 3 + 2]) * c));
          }
        }
      }
      return (
        m.size > 4096 && m.clear(),
        m.set(t, (n = { s: n, sectors: null, queries: 0 })),
        n
      );
    },
    g = 2 * Math.PI,
    _ = 1e-4,
    v = (e) => {
      let t = (e + Math.PI) / g;
      return ((t -= Math.floor(t)), Math.min(63, Math.floor(t * 64)));
    },
    y = (e) => {
      let t = e.s,
        n = t.length / 4,
        r = Array.from({ length: 64 }, () => []);
      for (let e = 0; e < n; e++) {
        let n = t[4 * e],
          i = t[4 * e + 1],
          a = t[4 * e + 2],
          o = t[4 * e + 3],
          s = Math.atan2(-i, n),
          c = Math.atan2(-o, a) - s;
        if (
          ((c -= g * Math.round(c / g)),
          Math.min(Math.hypot(n, i), Math.hypot(a, o)) < 1e-6 ||
            Math.abs(c) > g / 3)
        ) {
          for (let t of r) t.push(e);
          continue;
        }
        let l = Math.min(s, s + c) - _,
          u = Math.abs(c) + 2 * _,
          d = v(l),
          f = Math.min(64, Math.floor(u / (g / 64)) + 2);
        for (let t = 0; t < f; t++) r[(d + t) % 64].push(e);
      }
      e.sectors = r.map((e) => Uint32Array.from(e));
    },
    b = (e, t) => {
      let n = h(t),
        r = n.s,
        i = Math.cos(e),
        a = -Math.sin(e);
      !n.sectors && ++n.queries > 8 && r.length >= 64 && y(n);
      let o = n.sectors,
        s = o ? o[v(e)] : null,
        c = s ? s.length : r.length / 4,
        l = 1 / 0;
      for (let e = 0; e < c; e++) {
        let t = s ? 4 * s[e] : 4 * e,
          n = r[t],
          o = r[t + 1],
          c = r[t + 2] - n,
          u = r[t + 3] - o,
          d = i * u - a * c;
        Math.abs(d) < 1e-18 && (d = 1e-18);
        let f = (n * a - o * i) / d,
          p = (n * u - o * c) / d;
        f >= -1e-9 && f <= 1 + 1e-9 && p > 0 && p < l && (l = p);
      }
      return l;
    },
    x = (e, t) => {
      let n = b(e, t);
      return Number.isFinite(n) ? n / Math.max(s(t), 1e-9) : 1;
    };
  return {
    point: (e, t, n, r = new Float64Array(3)) => {
      let i = e === 0 && n === 0 ? 1 : x(Math.atan2(-n, e), t);
      return ((r[0] = e * i), (r[1] = t), (r[2] = n * i), r);
    },
  };
}
function or(e, t, { eps: n = 2e-5 } = {}) {
  if (!t || !e?.attributes?.position) return e;
  let r = e.attributes.position,
    i = e.attributes.normal ?? null,
    a = new Float64Array(3),
    o = new Float64Array(3),
    s = new Float64Array(3),
    c = new Float64Array(9);
  for (let e = 0; e < r.count; e++) {
    let l = r.getX(e),
      u = r.getY(e),
      d = r.getZ(e);
    if (i) {
      for (let e = 0; e < 3; e++) {
        (t.point(
          l + (e === 0 ? n : 0),
          u + (e === 1 ? n : 0),
          d + (e === 2 ? n : 0),
          o,
        ),
          t.point(
            l - (e === 0 ? n : 0),
            u - (e === 1 ? n : 0),
            d - (e === 2 ? n : 0),
            s,
          ));
        for (let t = 0; t < 3; t++) c[t * 3 + e] = (o[t] - s[t]) / (2 * n);
      }
      let r = i.getX(e),
        a = i.getY(e),
        f = i.getZ(e),
        p = c[4] * c[8] - c[5] * c[7],
        m = c[5] * c[6] - c[3] * c[8],
        h = c[3] * c[7] - c[4] * c[6],
        g = c[2] * c[7] - c[1] * c[8],
        _ = c[0] * c[8] - c[2] * c[6],
        v = c[1] * c[6] - c[0] * c[7],
        y = c[1] * c[5] - c[2] * c[4],
        b = c[2] * c[3] - c[0] * c[5],
        x = c[0] * c[4] - c[1] * c[3],
        S = p * r + m * a + h * f,
        C = g * r + _ * a + v * f,
        w = y * r + b * a + x * f,
        T = Math.hypot(S, C, w) || 1;
      i.setXYZ(e, S / T, C / T, w / T);
    }
    (t.point(l, u, d, a), r.setXYZ(e, a[0], a[1], a[2]));
  }
  return (
    (r.needsUpdate = !0),
    i && (i.needsUpdate = !0),
    e.computeBoundingBox?.(),
    e.computeBoundingSphere?.(),
    e
  );
}
var sr = 8,
  cr = new WeakMap();
function lr(e = {}) {
  if (cr.has(e)) return cr.get(e);
  let t = e.cavityProfileBase,
    n = null;
  if (Array.isArray(t) && t.length > 2 && e.facetWarp) {
    let r = ar(e.facetWarp, t);
    n = r ? { cavity: t, warp: r } : null;
  }
  return (cr.set(e, n), n);
}
function ur(e, t = null) {
  return !e?.attributes?.position || e.getAttribute(`positionBase`)
    ? e
    : (e.setAttribute(ln, e.getAttribute(`position`).clone()),
      t?.warp && or(e, t.warp),
      e);
}
var dr = class {
    constructor({
      root: e,
      settings: t,
      pipeline: n,
      environment: r,
      liquidSettings: i = t.liquid,
      name: a = `Liquid`,
    }) {
      ((this.settings = t),
        (this.config = i),
        (this.name = a),
        (this.extras = {}),
        (this.cavity = null),
        (this.shape = null),
        (this.params = { ...Vn }),
        (this.source = `none`),
        (this.uniforms = $t(i)),
        (this.material = en({
          liquid: i,
          uniforms: this.uniforms,
          pipeline: n,
          environment: r,
        })),
        (this.material.name = `${a} · transmission`),
        (this.backMaterial = rn(this.uniforms)),
        (this.mesh = new kt(new ht(), this.material)),
        (this.mesh.name = a),
        this.mesh.layers.set(q.liquid),
        (this.mesh.renderOrder = 1),
        (this.mesh.castShadow = this.mesh.receiveShadow = !1),
        (this.mesh.frustumCulled = !1),
        (this.back = new kt(this.mesh.geometry, this.backMaterial)),
        (this.back.name = `${a} (back-face depth)`),
        this.back.layers.set(q.liquidBack),
        (this.back.frustumCulled = !1),
        this.mesh.add(this.back),
        e.add(this.mesh),
        (this.version = 0),
        (this.packageId = null),
        (this.cream = null),
        (this.creamInterface = null),
        (this.entry = null),
        (this.cache = new Map()));
    }
    setPackage(e = {}) {
      let t = e.extras ?? this.extras,
        n =
          Array.isArray(t.cavityProfile) && t.cavityProfile.length > 2
            ? t.cavityProfile
            : null;
      if (!n) {
        console.warn(
          `${this.name}: package ${e.id} has no cavityProfile; keeping the current one.`,
        );
        return;
      }
      ((this.extras = t),
        (this.cavity = n),
        (this.shape = lr(t)),
        (this.params = { ...Vn, ...(t.liquid ?? {}) }),
        (this.packageId = e.id ?? this.packageId),
        this.build());
    }
    setCream(e = null) {
      let t = fr(e);
      return (
        JSON.stringify(t) !== JSON.stringify(this.cream) &&
        ((this.cream = t), this.build(), !0)
      );
    }
    resolve(e = this.config, t = this.cream) {
      let n = e.fill * this.extras.height,
        r = e.meniscusHeight / 1e3,
        i = e.meniscusWidth / 1e3,
        a = fr(t),
        o = a ? JSON.stringify(a) : ``,
        s =
          [n, r, i].map((e) => e.toFixed(6)).join() + `|${this.packageId}|${o}`,
        c = this.cache.get(s);
      if (c) return c;
      let l = this.shape?.cavity ?? this.cavity,
        u = { ...this.params, meniscusHeight: r, meniscusWidth: i },
        d = null;
      if (a) {
        let [e, t] = Un(l, { ...Vn, ...u });
        d = $n(l, u, Math.min(t, Math.max(e, n)), a);
      }
      let f = { ...Vn, ...u };
      ((f.meniscusHeight = Math.max(f.meniscusHeight, f.lipRadius + 1e-4)),
        (f.meniscusWidth = Math.max(f.meniscusWidth, 2 * f.lipRadius + 2e-4)));
      let [p, m] = Un(l, f),
        h = Math.min(m, Math.max(p, n));
      return (
        (c = {
          key: s,
          cavity: l,
          shape: this.shape,
          params: u,
          fillY: n,
          y: h,
          info: Jn(l, f, h),
          creamInterface: d,
          geometry: null,
          cream: null,
          pinned: !1,
          source: ``,
        }),
        this.cache.set(s, c),
        c
      );
    }
    levelsFor(e, t = null) {
      let n = this.resolve(e, t);
      return {
        fillY: n.info.fillY,
        creamY: n.creamInterface?.baseY ?? null,
        floorY: n.info.floorY,
      };
    }
    prepare(e, t, n = null) {
      let r = {
        extras: this.extras,
        cavity: this.cavity,
        shape: this.shape,
        params: this.params,
        packageId: this.packageId,
      };
      try {
        ((this.extras = e.extras),
          (this.cavity = e.extras.cavityProfile),
          (this.shape = lr(e.extras)),
          (this.params = { ...Vn, ...(e.extras.liquid ?? {}) }),
          (this.packageId = e.id));
        let r = this.resolve(t, n);
        return ((r.pinned = !0), this.ensureGeometry(r));
      } finally {
        Object.assign(this, r);
      }
    }
    build() {
      if (!this.cavity) return;
      let e = this.ensureGeometry(this.resolve());
      (this.cache.delete(e.key),
        this.cache.set(e.key, e),
        e !== this.entry &&
          ((this.entry = e),
          this.version++,
          (this.mesh.geometry = this.back.geometry = e.geometry),
          (this.creamInterface = e.creamInterface),
          (this.info = e.info),
          (this.source = e.source),
          (this.uniforms.fillY.value = e.info.fillY),
          (this.uniforms.meniscus.value = e.params.meniscusHeight),
          this.trim()));
    }
    ensureGeometry(e) {
      if (!e.geometry) {
        let t = e.shape,
          n;
        (e.creamInterface
          ? ((n = ir(e.cavity, e.params, e.fillY, e.creamInterface)),
            (e.source = `built above the cream layer${t ? ` (warped)` : ``}`))
          : ((n = Yn(e.cavity, e.params, e.fillY)),
            (e.source = t
              ? `built from cavityProfileBase + facetWarp`
              : `built from cavityProfile`)),
          (e.geometry = ur(n.geometry, t)),
          (e.info = n.info),
          n.info.volumeMl &&
            (e.source += ` · ${Math.round(n.info.volumeMl)} ml`));
      }
      return e;
    }
    trim() {
      let e = this.cache.size - sr;
      for (let t of this.cache.values()) {
        if (e <= 0) break;
        t === this.entry ||
          t.pinned ||
          (t.geometry?.dispose(),
          t.cream?.dispose(),
          this.cache.delete(t.key),
          e--);
      }
    }
    configure(e = 1, t = null) {
      let n = this.config;
      (this.build(),
        t && this.uniforms.keyDirection.value.copy(t),
        Qt(this.material, this.uniforms, {
          ...n,
          envMapIntensity: n.envMapIntensity * e,
        }),
        (this.mesh.visible = n.visible),
        (this.uniforms.on.value = +!!n.visible));
    }
    get active() {
      return this.config.visible;
    }
    dispose() {
      (this.material.dispose(), this.backMaterial.dispose());
      for (let e of this.cache.values())
        (e.geometry?.dispose(), e.cream?.dispose());
      this.cache.clear();
    }
  },
  fr = (e) =>
    e
      ? {
          height: e.height,
          wave: e.wave,
          waveScale: e.waveScale,
          seed: e.seed,
          meniscus: e.meniscus,
        }
      : null,
  pr = new B(),
  mr = Object.freeze({
    rimRadius: 0.036056,
    lidRadius: 0.038903,
    lidTopY: 0.090475,
    height: 0.084825,
  });
function hr({
  mesh: e,
  map: t,
  glass: n,
  uniforms: r,
  surface: i,
  environment: a,
  name: o,
  pipeline: s,
}) {
  let c = dn({
    map: t,
    glass: n,
    uniforms: r,
    pipeline: s,
    liquid: i,
    environment: a,
    name: o,
  });
  ((e.material = c.near),
    e.layers.set(q.glassNear),
    (e.castShadow = e.receiveShadow = !1),
    (e.renderOrder = 3));
  let l = (t, n, r, i) => {
    let a = new kt(e.geometry, t);
    return (
      (a.name = `${e.name} (${i})`),
      a.layers.set(n),
      (a.castShadow = a.receiveShadow = !1),
      (a.renderOrder = r),
      e.add(a),
      a
    );
  };
  return (
    l(c.behind, q.glassBehind, 2, `behind the liquid`),
    l(c.middle, q.glassMiddle, 2, `far layer`),
    { mesh: e, materials: c }
  );
}
function gr(e, t) {
  for (let t of Object.keys(e)) delete e[t];
  return (Object.assign(e, structuredClone(t)), e);
}
var _r = class {
    constructor({ assets: e, settings: t, pipeline: n, environment: r }) {
      ((this.settings = t),
        (this.assets = e),
        (this.root = new We()),
        (this.root.name = `CupRoot`),
        (this.root.matrixAutoUpdate = !0),
        (this.extras = {}),
        (this.referenceExtras = { ...mr }),
        (this.pipeline = n),
        (this.environment = r),
        (this.liquid = new dr({
          root: this.root,
          settings: t,
          pipeline: n,
          environment: r,
        })),
        (this.surface = this.liquid.uniforms),
        (this.bodyUniforms = qt(t.glass, t.highlights)),
        (this.lidUniforms = qt(t.lid, t.highlights)),
        (this.lidParts = []),
        (this.bodies = []),
        (this.packages = {}),
        (this.packageId = null),
        (this.request = 0));
    }
    get package() {
      return this.packages[this.packageId];
    }
    get lid() {
      return this.package?.lid;
    }
    makeGlass(e, t, n, r, i, a) {
      let o = hr({
        mesh: e,
        map: t,
        glass: n,
        uniforms: r,
        surface: i,
        environment: this.environment,
        name: a,
        pipeline: this.pipeline,
      });
      return (
        r === this.lidUniforms ? this.lidParts.push(o) : this.bodies.push(o),
        o
      );
    }
    lidTop() {
      return Number(this.extras.lidTopY) || 0;
    }
    async setPackage(e) {
      let t = gn(e) ? e : `P4`,
        n = ++this.request,
        r = this.packages[t];
      if (!r)
        try {
          let e = await this.assets.loadPackage(t);
          r = this.packages[t] ?? this.buildPackage(t, e);
        } catch (e) {
          return (
            console.warn(
              `Cup: package ${t} could not be built; keeping ${this.packageId}.`,
              e,
            ),
            null
          );
        }
      return n === this.request
        ? ((this.packageId = t),
          gr(this.extras, r.extras),
          this.syncVisibility(),
          this.descriptor())
        : null;
    }
    show(e) {
      let t = this.packages[e];
      return t
        ? (this.request++,
          (this.packageId = e),
          gr(this.extras, t.extras),
          this.syncVisibility(),
          this.descriptor())
        : null;
    }
    async prepare(e) {
      if (!gn(e)) return null;
      if (!this.packages[e]) {
        try {
          let t = await this.assets.loadPackage(e);
          this.packages[e] || this.buildPackage(e, t);
        } catch (t) {
          return (
            console.warn(`Cup: package ${e} could not be built.`, t),
            null
          );
        }
        this.syncVisibility();
      }
      return this.descriptor(this.packages[e]);
    }
    warm(e) {
      let t = this.packageId;
      return !this.packages[e] || e === t
        ? () => {}
        : ((this.packageId = e),
          this.syncVisibility(),
          () => {
            ((this.packageId = t), this.syncVisibility());
          });
    }
    descriptor(e = this.package) {
      return {
        id: e.id,
        label: e.info?.label ?? e.id,
        extras: e.extras,
        source: e.source,
      };
    }
    buildPackage(e, t) {
      let n = this.settings,
        r = {
          id: e,
          info: hn[e],
          source: t.source,
          root: t.root,
          extras: t.extras,
        };
      return (
        t.root && t.root.parent !== this.root && this.root.add(t.root),
        (r.body = this.makeGlass(
          t.body,
          t.textures.cup,
          n.glass,
          this.bodyUniforms,
          this.surface,
          `body ${e}`,
        )),
        (r.lid = this.makeGlass(
          t.lid,
          t.textures.lid,
          n.lid,
          this.lidUniforms,
          null,
          `lid ${e}`,
        )),
        (this.packages[e] = r),
        this.keyDirection && this.configure(this.keyDirection, this.envScale),
        r
      );
    }
    syncVisibility() {
      let { lid: e } = this.settings;
      for (let t of Object.values(this.packages)) {
        let n = t.id === this.packageId;
        (t.root && (t.root.visible = n),
          (t.body.mesh.visible = n),
          (t.lid.mesh.visible = n && e.visible));
      }
    }
    place() {
      let e = this.settings.cup;
      (this.root.position.set(e.x, 0, e.z),
        this.root.rotation.set(0, U.degToRad(e.yaw), 0),
        this.root.scale.setScalar(e.scale),
        (this.root.visible = !0));
    }
    get occluder() {
      let e = this.extras;
      return {
        top: e.lidTopY ?? e.height,
        radius: Math.max(e.rimRadius ?? 0.04, e.lidRadius ?? 0),
      };
    }
    lidGlass() {
      let { glass: e, lid: t } = this.settings;
      return t.link ? { ...e, visible: t.visible } : t;
    }
    configure(e, t = 1) {
      let { settings: n } = this;
      ((this.keyDirection = (this.keyDirection ?? new B()).copy(e)),
        (this.envScale = t));
      let r = this.lidGlass();
      for (let e of this.bodies) Kt(e.materials.all, n.glass, t);
      for (let e of this.lidParts) Kt(e.materials.all, r, t);
      ((this.bodyUniforms.paintStrength.value = n.glass.paintStrength),
        (this.lidUniforms.paintStrength.value = r.paintStrength),
        pr.copy(e),
        Wt(this.bodyUniforms, n.highlights, pr),
        Wt(this.lidUniforms, n.highlights, pr),
        this.syncVisibility());
    }
    dispose() {
      for (let e of [...this.bodies, ...this.lidParts])
        for (let t of e.materials.all) t.dispose();
      this.liquid.dispose();
    }
  },
  vr = [
    `paintStrength`,
    `opacity`,
    `edgeOpacity`,
    `roughnessScale`,
    `specular`,
    `distortion`,
    `power`,
    `scale`,
    `ambient`,
    `attenuation`,
    `back`,
    `wrap`,
    `thinEdge`,
    `glow`,
    `rim`,
    `rimPower`,
    `rimTint`,
    `core`,
    `variation`,
    `level`,
    `glint`,
    `glintSize`,
    `facet`,
  ];
function yr(e) {
  let t = {};
  for (let n of vr) t[n] = I(e[n]);
  return ((t.jelly = I(new B(1, 1, 1))), t);
}
function br(e, t) {
  for (let n of vr) e[n].value = t[n];
}
function xr({
  color: e = `#ff7a4a`,
  color2: t = null,
  color3: n = null,
  color4: r = null,
  sss: i = `#ff4a2a`,
  roughness: a = 0.3,
  clarity: o = 0.2,
} = {}) {
  return {
    color: I(new G(e)),
    color2: I(new G(t ?? e)),
    color3: I(new G(n ?? e)),
    color4: I(new G(r ?? e)),
    sss: I(new G(i)),
    roughness: I(a),
    clarity: I(o),
  };
}
function Sr(
  e,
  {
    color: t,
    color2: n,
    color3: r,
    color4: i,
    sss: a,
    roughness: o,
    clarity: s,
  },
) {
  (t && e.color.value.set(t),
    n && e.color2 && e.color2.value.set(n),
    r && e.color3 && e.color3.value.set(r),
    i && e.color4 && e.color4.value.set(i),
    a && e.sss.value.set(a),
    typeof o == `number` && (e.roughness.value = o),
    typeof s == `number` && (e.clarity.value = s));
}
var Cr = class extends zt {
    constructor(e) {
      (super(
        e.useClearcoat,
        e.useSheen,
        e.useIridescence,
        e.useAnisotropy,
        e.useTransmission,
        e.useDispersion,
      ),
        (this.fruit = e));
    }
    direct(e, t) {
      let { lightDirection: n, lightColor: r, reflectedLight: i } = e,
        a = this.fruit,
        o = a.look,
        s = ae,
        c = s.dot(n),
        l = c.add(o.wrap).div(o.wrap.add(1)).clamp().sub(c.clamp()).max(0),
        u = V(ue.rgb, a.sssTint, 0.6);
      i.directDiffuse.addAssign(
        u
          .mul(l)
          .mul(r)
          .mul(1 / Math.PI),
      );
      let d = n.add(s.mul(a.thicknessDistortionNode)).normalize(),
        f = ke
          .dot(d.negate())
          .clamp()
          .pow(a.thicknessPowerNode)
          .mul(a.thicknessScaleNode),
        p = c.negate().add(o.wrap).div(o.wrap.add(1)).clamp().mul(o.back),
        m = f.add(p).add(a.thicknessAmbientNode);
      i.directDiffuse.addAssign(
        a.thicknessColorNode.mul(m).mul(a.thicknessAttenuationNode).mul(r),
      );
      let h = n.add(ke).normalize(),
        g = z(o.glintSize, 1, s.dot(h).clamp()).mul(o.glint);
      (i.directSpecular.addAssign(
        V(ue.rgb, W(1, 0.97, 0.92), 0.6)
          .mul(g)
          .mul(r)
          .mul(0.25),
      ),
        super.direct(e, t));
    }
  },
  wr = class extends rt {
    static get type() {
      return `FruitNodeMaterial`;
    }
    setupLightingModel() {
      return new Cr(this);
    }
    setupOutput(e, t) {
      return (
        this.look?.jelly && (t = L(t.rgb.mul(this.look.jelly), t.a)),
        super.setupOutput(e, t)
      );
    }
  };
function Tr({
  look: e,
  type: t,
  map: n = null,
  environment: r = null,
  envIntensity: i = 1,
  name: a = `fruit`,
  parts: o = !1,
}) {
  let s = new wr({
    transparent: !0,
    depthWrite: !0,
    side: 0,
    metalness: 0,
    roughness: 0.3,
    envMap: r ?? null,
  });
  ((s.name = `Fruit · ${a}`), (s.look = e));
  let c = I(0)
      .onObjectUpdate(({ object: e }) => e.userData.fruitSeed ?? 0)
      .sub(0.5)
      .mul(e.variation),
    l = t.color,
    u = t.sss;
  if (o && t.color2) {
    let n = pt(`color`, `vec4`),
      r = V(
        V(V(t.color, t.color2, n.x.clamp()), t.color3, n.y.clamp()),
        t.color4,
        n.z.clamp(),
      ),
      i = n.w.sub(0.5).mul(e.facet).mul(2).add(1);
    ((l = r.mul(i)), (u = V(t.sss, r, M(M(n.x, n.y), n.z).clamp().mul(0.75))));
  }
  let d = l.mul(c.mul(1.6).add(1)).mul(e.level),
    f = V(u, l, c.max(0).mul(1.5)).mul(e.level),
    p = null;
  n &&
    ((p = Gt({ map: n, strength: e.paintStrength })),
    (s.normalNode = p.normal));
  let m = Oe(() => ae.dot(ke).clamp())(),
    h = m.oneMinus();
  ((s.colorNode = V(d, d.mul(d).mul(1.15), m.mul(m).mul(e.core))),
    (s.opacityNode = e.opacity
      .mul(V(H(1), 0.55, t.clarity))
      .mul(V(e.edgeOpacity, H(1), z(0, 0.65, m)))),
    (s.roughnessNode = t.roughness.mul(e.roughnessScale).clamp(0.03, 1)),
    (s.specularIntensityNode = e.specular),
    (s.envMapIntensity = i),
    (s.sssTint = f),
    (s.thicknessColorNode = f.mul(V(H(1), e.thinEdge, h.pow(1.5)))),
    (s.thicknessDistortionNode = e.distortion),
    (s.thicknessAmbientNode = e.ambient),
    (s.thicknessAttenuationNode = e.attenuation),
    (s.thicknessPowerNode = e.power),
    (s.thicknessScaleNode = e.scale));
  let g = f.mul(e.glow).mul(V(0.55, 1, h)),
    _ = V(d, W(1, 0.96, 0.9), e.rimTint)
      .mul(h.pow(e.rimPower))
      .mul(e.rim)
      .mul(z(0.02, 0.2, m));
  return ((s.emissiveNode = g.add(_)), { material: s, painted: p });
}
function Er() {
  let e = new Ue({ colorWrite: !1, side: 0 });
  return ((e.name = `Fruit · depth (liquid thickness)`), e);
}
var Dr = {
    package: `P4`,
    source: {
      preset: `deliPinkShort`,
      layout: `pre-settled (P4 + cream, 5.5 s sim)`,
      signature: `5f1c7117`,
      base: `bubble tea/web (settings revision 18)`,
    },
    reference: {
      fillY: 0.0380046,
      liquid: { fill: 0.7836, meniscusHeight: 1.4, meniscusWidth: 2.5 },
      cream: {
        height: 0.31,
        wave: 1.1,
        waveScale: 1,
        seed: 3,
        meniscus: 1.4,
        fruitSink: 0.0025,
      },
    },
    pieces: [
      {
        type: `mandarinSegment`,
        index: 0,
        position: [
          0.029040664344243468, 0.023161043339286792, -0.00930576657768259,
        ],
        quaternion: [
          -0.9051380781768892, 0.2611400326246572, -0.019830929922144143,
          0.33486964182120693,
        ],
        scale: 0.9488507784867122,
        bound: 0.0175960109347802,
        fruitSeed: 0.20221452857367694,
      },
      {
        type: `mandarinSegment`,
        index: 1,
        position: [
          0.0003823816231335905, 0.029946742806962922, 0.01571277963315687,
        ],
        quaternion: [
          -0.41810828042175424, 0.3523669982084946, -0.5524663629007749,
          -0.629129463846264,
        ],
        scale: 1.0017304820319155,
        bound: 0.018576641254010488,
        fruitSeed: 0.53861153870821,
      },
      {
        type: `cherry`,
        index: 0,
        position: [
          0.016902380800522768, 0.020988689341851604, 0.0251266677691875,
        ],
        quaternion: [
          0.035011468695028754, -0.5823566981475158, 0.407737431751013,
          0.7024137384274516,
        ],
        scale: 0.9377314949942676,
        bound: 0.03246797955981524,
        fruitSeed: 0.04118190263397992,
      },
      {
        type: `cherry`,
        index: 1,
        position: [
          0.010708266794652583, 0.022540588861793515, -0.02713433642096996,
        ],
        quaternion: [
          0.3169398672903634, -0.4845906389871083, -0.7848518055049684,
          -0.22074572821149693,
        ],
        scale: 1.0572530904785609,
        bound: 0.03660629072869014,
        fruitSeed: 0.21687609772197902,
      },
      {
        type: `cherry`,
        index: 2,
        position: [
          -0.01054323869317102, 0.021507753752752202, -0.027546679471122652,
        ],
        quaternion: [
          0.3434417960283829, -0.14040156716672814, 0.14797958426965618,
          0.9167536066562844,
        ],
        scale: 0.9868261168538166,
        bound: 0.03416782987682143,
        fruitSeed: 0.6487868714611977,
      },
      {
        type: `shiratama`,
        index: 0,
        position: [
          -0.01566371787308603, 0.020345781275908387, -0.006419303629938056,
        ],
        quaternion: [
          0.7908650984889961, -0.12761660369302716, 0.5982307082350518,
          -0.019142052618139754,
        ],
        scale: 1.0725107185100304,
        bound: 0.012016550511302647,
        fruitSeed: 0.929003678727895,
      },
      {
        type: `shiratama`,
        index: 1,
        position: [
          -0.02561085851312035, 0.020456347849430557, 0.014967131353691722,
        ],
        quaternion: [
          -0.7164442359399191, -0.3681094584947838, -0.5912939711198696,
          0.03968026048852611,
        ],
        scale: 0.9668002038532434,
        bound: 0.010832156064677636,
        fruitSeed: 0.604404280660674,
      },
      {
        type: `pineappleChunk`,
        index: 0,
        position: [
          0.027457018050642146, 0.020880244116174385, 0.009928371039190927,
        ],
        quaternion: [
          -0.2684006946850583, 0.36022590968748297, -0.6388133940157529,
          0.6245925141309957,
        ],
        scale: 0.9856122692648943,
        bound: 0.014263402535932248,
        fruitSeed: 0.8175166910514235,
      },
      {
        type: `mangoCube`,
        index: 0,
        position: [
          0.0070009551978340665, 0.02275585385961931, -0.004681702394210392,
        ],
        quaternion: [
          0.24965947260659302, -0.7068019904272906, 0.34643953655541476,
          0.5639864728671135,
        ],
        scale: 1.1390762026774834,
        bound: 0.015049474130478269,
        fruitSeed: 0.25741233956068754,
      },
    ],
    types: JSON.parse(
      `{"mandarinSegment":{"nominal":0.03357,"bound":0.01854455024302498,"spheres":[[-0.005062,-0.016075,0.000646,0.001679],[-0.006416,0.014394,0.001323,0.001376],[0.001709,-0.01269,-0.001385,0.00256],[-0.003708,-0.007273,-0.002739,0.002685],[-0.000322,-0.003211,0.003355,0.003185],[0.006449,0.002206,-0.000031,0.003386],[-0.000322,0.014394,-0.002739,0.001729],[0.001032,-0.003211,-0.003416,0.003182],[-0.004385,-0.014044,0.002001,0.002045],[-0.004385,0.015071,0.000646,0.00167],[0.001709,-0.01269,0.002001,0.002323],[-0.003031,0.006269,0.003355,0.00297],[-0.003031,0.013716,0.003355,0.001526],[-0.002353,-0.014721,-0.002739,0.00186],[-0.005062,0.001529,-0.000708,0.002824],[-0.006416,0.013716,-0.001385,0.001122],[-0.000322,0.014394,0.000646,0.001735],[0.005094,-0.008627,0.001323,0.002662],[-0.005739,-0.013367,-0.002739,0.001728],[-0.000999,-0.015398,0.001323,0.0017],[0.004417,0.002206,0.002678,0.003239],[-0.003708,-0.007273,0.003355,0.00255],[0.005772,-0.003211,-0.002062,0.003],[0.001709,0.006946,-0.003416,0.003003],[-0.003708,0.013716,-0.003416,0.001327],[-0.006416,-0.016075,-0.000708,0.001053],[0.003063,0.011685,-0.001385,0.002677],[0.001709,0.011685,0.002678,0.002536],[0.005772,0.0083,0.000646,0.002734],[-0.005739,-0.010659,0.001323,0.002149],[-0.005739,0.009654,0.000646,0.002436],[-0.000322,-0.00795,-0.002739,0.002776],[-0.005739,-0.002534,0.000646,0.002377],[0.001709,-0.008627,0.003355,0.002503],[0.000355,0.001529,-0.004093,0.002888],[-0.003708,0.006269,-0.003416,0.002764],[-0.003708,0.001529,0.003355,0.0028],[-0.005062,0.011008,-0.003416,0.001587],[0.001709,0.006946,0.003355,0.003068],[-0.002353,-0.012013,0.003355,0.00183],[0.004417,-0.003888,0.002678,0.003012],[-0.005739,0.012362,0.003355,0.001501],[-0.002353,-0.003211,-0.003416,0.002837],[0.007126,-0.003888,-0.000708,0.002785],[0.00374,-0.009304,-0.002739,0.0023],[0.001032,0.001529,0.004032,0.002843],[0.004417,0.006946,-0.002062,0.003014],[-0.005739,-0.013367,0.000646,0.00188]],"points":[[-0.005232,-0.017143,0.000601],[0.000192,0.015956,-0.001107],[0.009738,-0.000946,0.002004],[-0.004416,-0.000564,-0.005606],[-0.000645,-0.005647,0.006246],[0.003755,-0.010812,-0.004481],[-0.005547,0.007817,0.004999],[0.005618,0.004799,-0.005467],[0.007381,0.010532,0.001857],[-0.007388,0.011391,-0.002925],[0.002827,-0.015149,0.001784],[0.000522,0.004321,0.006315],[-0.001643,0.008783,-0.00618],[0.008918,-0.006656,-0.00208],[-0.005861,0.015308,0.002718],[-0.005851,-0.012369,-0.004396],[-0.000271,-0.00559,-0.00603],[-0.003482,-0.012644,0.004931],[-0.004757,-0.000719,0.005473],[0.00664,0.00498,0.004965],[0.005359,-0.006385,0.004956],[0.000678,0.013656,0.004435],[0.006175,-0.000845,-0.005072],[0.003786,0.010085,-0.005102],[0.005464,-0.00061,0.005586],[-0.007915,-0.01159,0.000657],[-0.001894,-0.016324,-0.00333],[0.009366,0.004897,-0.001863],[0.00616,-0.011337,0.002003],[-0.000871,0.009158,0.006181],[-0.000095,0.004207,-0.006395],[0.000323,-0.000618,-0.006496],[-0.000121,-0.000694,0.006554],[-0.002034,-0.009782,-0.005615],[-0.004752,-0.005073,-0.005274],[-0.004052,0.013921,-0.004545],[-0.007566,0.011176,0.002515],[0.005476,-0.006236,-0.004825],[0.002958,-0.010743,0.004893],[-0.001771,-0.016112,0.002973],[0.001008,0.013512,-0.004557],[0.004334,0.010568,0.004862],[-0.005724,0.008092,-0.005063],[-0.004697,0.003759,0.00546],[0.006806,0.010481,-0.002261],[-0.005476,-0.009078,0.004747],[-0.003278,0.012281,0.005322],[-0.006642,-0.014593,0.003356],[-0.0044,0.016304,-0.00084],[0.003403,0.014304,0.001635],[0.009724,-0.000874,-0.001916],[0.009226,0.005058,0.00204],[0.006638,-0.01151,-0.001827],[0.00871,-0.006614,0.00175],[0.001327,-0.014381,-0.003905],[-0.007485,-0.014536,-0.001749],[0.003608,0.014391,-0.002033],[-0.001298,-0.009773,0.005569],[-0.007626,0.014723,-0.00043],[-0.002348,-0.01317,-0.004821],[0.000657,-0.014141,0.004095],[-0.001395,0.015499,-0.003796],[-0.004869,-0.015304,-0.003836],[0.003089,-0.015024,-0.00126],[-0.006968,-0.016255,0.002069],[-0.006251,0.015313,-0.002229],[-0.001341,0.015395,0.003809],[-0.00667,0.013097,-0.003765],[-0.000749,-0.016951,-0.001463],[-0.008237,0.010925,-0.000703],[-0.004658,-0.015202,0.004021],[-0.003213,0.012216,-0.005424]],"embedFrame":[[0.0006328924636941866,-0.00024355468470056168,0.000122979546551468,2],[0.0076873045279971216,-0.0006050296048391585,-0.00009832088991920633,1],[-0.006421519600608748,0.00011792023543803513,0.0003442799830221424,1],[0.0013163242793209698,0.013038067263615654,0.0002144227110121132,1],[-0.000050539351932596616,-0.013525176633016778,0.00003153638209082281,1],[0.0007898617980753864,-0.00028656588956630963,0.005196958865959841,1],[0.0004759231293129868,-0.0002005434798348137,-0.004950999772856905,1]]},"cherry":{"nominal":0.04018,"bound":0.034623961905016015,"spheres":[[-0.000272,-0.000161,0.000085,0.009989],[0.00202,0.000755,0.000085,0.008492],[-0.000272,-0.000161,-0.00129,0.009461],[0.000645,-0.00062,0.001002,0.009188]],"points":[[-0.00984,0.030207,0.013767],[0.002353,-0.009132,-0.00367],[0.007696,0.005545,0.004442],[-0.010391,0.001835,-0.000246],[0.001084,0.005482,-0.008796],[-0.000502,-0.002981,0.01042],[-0.004212,0.022973,0.006065],[-0.005249,-0.002913,-0.009064],[0.009407,0.00149,-0.004656],[-0.006911,-0.006781,0.003529],[0.007303,-0.006203,0.004465],[0.000284,-0.00918,0.004145],[0.004983,-0.003001,-0.008747],[0.004828,0.001456,0.009452],[-0.00682,-0.006821,-0.003458],[0.010303,-0.002553,0.000237],[-0.000137,-0.006129,-0.008469],[-0.007443,0.026812,0.009512],[0.007431,-0.006101,-0.003555],[-0.009094,0.001512,-0.005723],[-0.004381,0.005525,-0.00774],[-0.009025,-0.002134,0.005742],[0.005889,0.002323,-0.008799],[-0.003785,-0.00927,-0.000073],[-0.003802,-0.006088,0.007341],[0.003486,-0.006172,0.007468],[0.010387,0.002237,0.000978],[-0.009975,-0.002934,0.00036],[0.007437,0.005877,-0.004354],[0.004582,-0.008969,0.000505],[0.000454,-0.002124,-0.010656],[0.008631,-0.002075,0.005862],[-0.008932,-0.002992,-0.005148],[-0.005746,0.001473,-0.008844],[-0.003972,-0.006772,-0.006763],[-0.005642,-0.002503,0.00859],[-0.001763,-0.009177,-0.00374],[0.008838,-0.002559,-0.005058],[0.003911,-0.006798,-0.006652],[0.005418,-0.002546,0.008903],[0.008365,-0.006134,0.000495],[0.008798,0.005852,0.000257],[-0.000012,0.001856,-0.010614],[0.009165,0.001812,0.005173],[0.000087,-0.009974,0.000013],[0.004428,0.00586,-0.007145],[-0.000287,-0.006119,0.008493],[-0.00818,-0.006124,0.000014],[-0.002757,-0.008942,0.003646],[0.002823,-0.008915,0.003836],[0.004321,-0.008938,-0.001912],[-0.003821,-0.008983,-0.002474],[-0.010343,0.029185,0.014146],[-0.010357,0.03002,0.013527],[-0.009575,0.029883,0.014197],[-0.006647,0.026683,0.010213],[-0.006899,0.026991,0.009742],[0.005227,0.001495,-0.009439],[-0.008747,-0.002172,-0.006026],[0.000381,-0.002586,0.010605],[-0.010608,0.029509,0.013716],[-0.00936,-0.002558,0.004957],[0.005542,0.001883,0.009016],[0.008876,0.002338,-0.00535],[-0.009826,0.029372,0.014386],[0.009008,-0.002502,0.005078],[0.00472,-0.002134,0.009411],[0.005939,0.001499,-0.008989],[-0.009502,0.001509,-0.004987],[0.009257,-0.002553,-0.004287],[0.005847,-0.002177,-0.008489],[0.008704,0.00182,0.005918],[-0.000696,0.012243,0.001085],[-0.001431,0.015045,0.002092],[-0.002319,0.017696,0.00331],[-0.003362,0.020196,0.004738],[-0.004559,0.022544,0.006378],[-0.00591,0.024741,0.008229],[-0.007191,0.026504,0.009983],[-0.008585,0.028155,0.011892],[-0.010092,0.029696,0.013956]],"embedFrame":[[0.0003824343863087628,-0.00009758540300973533,-0.00005522921867776645,2],[0.0062931125992660725,0.0012181321700410642,0.004344963320149605,1],[-0.005528243826648547,-0.0014133029760605347,-0.004455421757505138,1],[-0.0027218871653853015,0.006064219319759737,0.002272271434029132,1],[0.003486755938002827,-0.006259390125779208,-0.0023827298713846646,1],[-0.0028778995257648715,-0.0038142054454187303,0.00543562299063227,1],[0.003642768298382397,0.00361903463939926,-0.005546081427987803,1]]},"shiratama":{"nominal":0.02131,"bound":0.011204130927471252,"spheres":[[-0.000044,0.000039,-0.002687,0.007785],[0.000414,0.000039,0.001896,0.008234],[-0.002336,-0.000419,0.000063,0.007983],[0.002248,0.000039,-0.00177,0.007608],[0.004081,0.000039,0.001896,0.006305],[-0.001419,0.000039,0.001896,0.008043],[-0.002336,0.000039,-0.00177,0.007505],[0.006831,0.002789,0.000063,0.003303],[-0.001419,0.000039,-0.006354,0.004593],[-0.004627,0.000039,0.004646,0.004647]],"points":[[-0.001486,0.000168,-0.010822],[0.000232,0.000843,0.010493],[0.009845,0.003097,-0.000996],[-0.009574,-0.004062,0.000831],[0.003008,-0.007887,0.000433],[-0.005095,0.006962,0.001686],[0.002128,0.007295,-0.004619],[0.006763,-0.00361,-0.007086],[0.00808,-0.002629,0.006204],[-0.004027,-0.006398,-0.005638],[-0.007812,0.002981,-0.00552],[-0.003174,-0.006203,0.00625],[0.004232,0.006545,0.00552],[-0.007951,0.001073,0.007421],[0.004194,0.00265,-0.009047],[-0.0021,0.005888,0.007443],[-0.009746,0.002112,0.001539],[0.002758,-0.004877,0.008312],[0.008349,-0.004971,0.000264],[-0.003158,-0.008047,0.000564],[0.001268,-0.005487,-0.008085],[-0.002273,0.005303,-0.007819],[-0.008332,-0.002699,-0.005066],[0.009118,0.002323,0.004697],[0.008719,0.001236,-0.005685],[0.004913,-0.006724,-0.003819],[-0.004482,-0.002618,0.008953],[-0.004106,-0.003009,-0.008854],[-0.007556,-0.004576,0.004731],[-0.00612,0.005113,0.006021],[-0.005169,0.001382,-0.008923],[0.006243,0.001085,0.00764],[-0.000135,0.007638,0.004081],[0.002868,0.004153,0.008663],[-0.009867,-0.001151,0.004083],[0.009998,-0.001427,0.00154],[0.003435,-0.002266,-0.009284],[0.007152,0.005729,0.002835],[-0.003466,0.00254,0.009239],[0.006764,-0.005671,0.003905],[0.008878,-0.003503,-0.003704],[-0.00986,0.001346,-0.002363],[0.00057,-0.007196,0.005628],[-0.007376,-0.005929,-0.001799],[0.007727,0.004954,-0.003623],[-0.00777,0.005354,-0.000434],[0.001471,-0.007748,-0.003165],[0.002916,-0.001236,0.009711],[0.000025,-0.00816,0.002171],[-0.00748,-0.00011,-0.007004],[-0.007213,-0.00611,0.001844],[0.006216,-0.000646,-0.008649],[-0.008334,0.003151,0.004729],[-0.005237,0.004413,-0.007073],[0.005725,-0.004503,0.007099],[-0.001524,-0.004782,-0.009226],[0.005953,-0.006858,0.000042],[-0.000257,0.003717,0.009573],[-0.00745,0.0053,0.002684],[0.001459,0.000649,-0.010267],[0.01044,0.001439,0.002178],[0.00124,0.006823,0.006572],[-0.002747,0.002765,-0.009772],[-0.006747,-0.005031,-0.004525],[0.007419,-0.002068,-0.007537],[-0.009677,-0.002503,0.003879],[-0.000097,-0.001601,0.010305],[0.004233,-0.004299,0.008302],[0.010512,0.000199,0.000224],[-0.000597,0.002003,0.010339],[-0.000595,-0.004266,-0.009694],[-0.009912,-0.001322,-0.003215]],"embedFrame":[[-0.00030729624763808027,-3.138505221239976e-7,-0.00011461187657599132,2],[0.0057364271652163385,0.00044602362490283026,0.0033651760377673826,1],[-0.0063510196604924995,-0.0004466513259470783,-0.003594399790919365,1],[-0.0007404241355257872,0.005886972589255813,-0.00011748889382341277,1],[0.00012583164024962656,-0.0058876002903000615,-0.00011173485932856987,1],[-0.003809261964211822,-0.00025496535122742096,0.006000293176257785,1],[0.003194669468935661,0.0002543376501831729,-0.006229516929409767,1]]},"pineappleChunk":{"nominal":0.01961,"bound":0.01447161625389507,"spheres":[[0.000118,0.000078,0.000249,0.008348],[-0.003257,-0.002922,-0.002751,0.005523],[-0.004007,0.003828,0.004374,0.004597],[-0.004757,0.003453,-0.003501,0.004663],[0.004993,-0.004422,0.003624,0.003905],[-0.002882,-0.002922,0.003249,0.005502],[0.003493,0.003828,0.003624,0.004644],[0.003118,-0.001797,-0.002376,0.006091],[0.006118,0.001578,-0.005376,0.003179],[0.000868,0.004578,-0.005001,0.003648],[0.007618,-0.005922,-0.005751,0.002434],[0.004243,0.003453,-0.003126,0.004826],[0.001243,-0.005922,-0.005751,0.002571],[0.002368,-0.002547,0.003249,0.005832],[-0.000632,0.004578,0.005124,0.00381],[-0.007757,0.004203,-0.006501,0.001894],[-0.005507,0.004203,0.000624,0.003682],[0.004993,-0.004422,0.005499,0.003679],[-0.005507,0.000453,0.005874,0.003085],[-0.005882,-0.005172,-0.000501,0.00279],[-0.006257,-0.005172,-0.005376,0.00275],[0.004993,0.000453,0.005874,0.003102],[-0.000257,-0.005172,0.005874,0.003171],[0.004993,0.005328,-0.006126,0.002569],[-0.004757,0.006078,-0.006126,0.002251],[-0.004382,-0.004047,0.005499,0.00355],[0.006868,-0.005547,-0.003501,0.002955],[0.007618,-0.001422,-0.006501,0.001887],[-0.006632,0.005703,-0.000876,0.002684],[0.007243,-0.005922,0.000624,0.002158],[-0.003257,0.001578,-0.002751,0.005832],[-0.004757,-0.007047,-0.006876,0.001318],[-0.008132,-0.000672,-0.007251,0.001168],[0.004993,0.004953,0.005124,0.002987],[0.005743,0.005703,0.000249,0.002614],[0.004243,-0.005922,-0.005751,0.00251],[-0.007007,0.006078,-0.006126,0.002275],[-0.006632,-0.007047,0.006999,0.001333],[-0.001757,-0.005922,-0.005376,0.002546],[0.007243,-0.006297,0.003249,0.001871],[0.007618,0.004203,-0.006501,0.00185],[-0.007382,0.006453,0.003999,0.001727],[0.001993,0.006828,0.006999,0.001664],[-0.002507,0.007203,0.007374,0.001245],[0.006493,-0.002547,-0.005001,0.003313],[-0.002507,0.005703,-0.006126,0.002499],[-0.007007,-0.004047,-0.006501,0.001998],[-0.006632,0.006828,0.007374,0.001423]],"points":[[0.009803,-0.007722,-0.007328],[-0.008163,0.00736,0.008242],[-0.008472,-0.006934,-0.003978],[0.007167,0.007845,-0.000065],[0.003084,-0.0076,0.008177],[-0.008728,0.007648,-0.007634],[-0.00757,-0.003972,0.008069],[0.0073,0.001485,0.008247],[0.009039,0.003011,-0.007964],[0.008334,-0.007872,0.000585],[0.002677,0.00772,-0.007114],[-0.009062,0.006983,0.000355],[-0.001802,0.001279,0.008594],[-0.008223,-0.001073,-0.008036],[-0.002648,-0.007233,-0.008],[0.00625,0.007966,0.007347],[0.003639,-0.008063,-0.003706],[-0.003252,0.008024,0.004302],[-0.004212,0.003268,-0.00817],[0.008228,-0.005289,0.007226],[-0.00763,-0.00756,0.003845],[-0.002184,-0.006952,0.008528],[0.002156,0.008035,0.004226],[0.009676,-0.001556,-0.007089],[0.008656,0.006715,-0.004119],[-0.007938,-0.005594,-0.008075],[-0.009343,0.003403,-0.007048],[-0.002474,-0.008052,-0.003783],[-0.003077,0.007208,0.008519],[-0.008359,0.003277,0.007151],[-0.003573,0.007441,-0.007989],[0.002339,0.007979,0.00015],[0.008204,0.00716,-0.00806],[-0.009347,0.007032,-0.003742],[0.004354,-0.007982,0.000409],[0.008854,-0.008044,-0.003557],[-0.006721,-0.007723,0.007625],[-0.008776,0.006926,0.004469],[-0.002416,-0.003259,0.008575],[0.00849,-0.007361,0.00424],[0.007619,0.007091,0.004151],[0.00342,0.007879,-0.003975],[0.003774,-0.007993,-0.006892],[0.006988,-0.003045,0.008545],[0.007311,-0.007264,0.00858],[-0.008325,-0.007347,-0.007713],[0.006201,0.007288,0.008265],[0.007229,0.007069,0.007365],[-0.009239,0.00746,-0.007387],[0.006734,0.007721,0.007859],[0.008724,0.006933,-0.007917],[0.007839,-0.006966,0.008358],[-0.00854,0.006726,0.007722],[0.00835,0.007372,-0.004204],[-0.007853,-0.006953,-0.008082],[0.009276,-0.007883,-0.007459],[0.009905,-0.007184,-0.007477],[-0.009126,0.007674,-0.003774],[-0.00824,0.006848,0.008349],[0.009472,-0.007774,-0.003545],[-0.007811,-0.007531,-0.007834],[-0.009526,0.006743,-0.006613],[-0.00848,-0.006824,-0.007832],[0.010084,-0.007065,-0.006847],[0.007309,0.007744,0.004088],[0.009087,0.00618,-0.007301],[0.006878,0.007228,0.007993],[0.009308,-0.007318,-0.007742],[0.006186,0.007863,0.00798],[-0.00871,-0.006676,-0.007201],[0.008271,0.006603,-0.008208],[0.008889,0.00637,-0.007953]],"embedFrame":[[0.000051438437459437386,-0.00010853632029960386,-0.000004604663954529101,2],[0.006810461689221064,-0.0036767586140738395,0.0018815579448438606,1],[-0.006707584814302189,0.0034596859734746317,-0.0018907672727529186,1],[0.0027747165137335635,0.005933773800433574,0.0016673645636389397,1],[-0.0026718396388146883,-0.006150846441032782,-0.0016765738915479977,1],[-0.0023552580506245946,-0.0009629914553142006,0.007003291473656224,1],[0.002458134925543469,0.0007459188147149928,-0.0070125008015652825,1]]},"mangoCube":{"nominal":0.01688,"bound":0.013211999421200583,"spheres":[[-0.000574,-0.000611,-0.000855,0.007351],[0.003926,0.003514,-0.003855,0.004471],[0.002426,0.001264,0.002145,0.006288],[-0.002449,0.001639,-0.00198,0.006234],[0.003551,-0.002861,0.002895,0.005178],[-0.004324,-0.002861,-0.003855,0.004448],[-0.002824,0.002764,0.002895,0.005214],[-0.003574,-0.002111,0.002895,0.005043],[0.003551,-0.000611,-0.003105,0.005147],[0.005801,-0.005486,0.00552,0.002592],[-0.001699,-0.004361,0.00477,0.003487],[0.004676,0.003889,0.00477,0.003696],[-0.005824,-0.005111,0.00027,0.002656],[-0.006199,0.004264,-0.00573,0.002405],[0.000176,-0.004361,-0.004605,0.003614],[-0.005074,0.002014,0.00477,0.003557],[0.003926,-0.003236,-0.00198,0.004794],[-0.005824,-0.004736,0.00552,0.002651],[-0.006574,-0.000236,-0.00573,0.002129],[-0.000574,0.005014,0.00552,0.002879],[-0.007324,-0.004736,-0.006855,0.001472],[0.006551,-0.000236,0.005895,0.0022],[0.005051,-0.005861,-0.006105,0.002133],[0.007301,-0.006611,-0.00573,0.001265],[-0.005074,0.005014,0.00552,0.002929],[0.005801,0.004639,-0.00498,0.002829],[0.006551,0.005764,0.003645,0.00207],[0.006926,-0.006611,-0.000855,0.001495],[0.000926,0.001264,-0.00198,0.006393],[0.001301,-0.003236,0.003645,0.004724],[-0.004324,0.003514,0.00252,0.004344],[0.006176,0.000139,-0.006105,0.002145],[-0.006199,0.006139,-0.00348,0.001871],[-0.005824,-0.004736,-0.004605,0.002971],[0.005801,0.005014,-0.000105,0.00287],[0.003551,0.005764,-0.00573,0.002212],[-0.001699,-0.005861,-0.006105,0.002074],[0.007301,-0.004736,-0.006855,0.001244],[0.000926,0.005389,0.00552,0.002487],[0.006551,0.002764,0.005895,0.002187],[-0.006574,0.006139,-0.005355,0.001883],[-0.006574,-0.005861,0.00402,0.001816],[-0.006949,-0.005861,-0.001605,0.001727],[-0.002824,0.006139,-0.00648,0.001711],[-0.006949,-0.001361,0.00702,0.001396],[0.007301,-0.006986,0.006645,0.001118],[0.007301,0.006889,-0.003105,0.001007],[-0.007699,0.006514,0.002895,0.000906]],"points":[[-0.007514,-0.006552,-0.007704],[0.007431,0.006472,0.007685],[0.008198,-0.005997,-0.006026],[-0.006236,-0.00548,0.008018],[-0.00639,0.007671,-0.005972],[0.007311,0.007309,-0.006098],[0.007485,-0.006815,0.007488],[-0.006452,0.007299,0.007283],[0.006289,-0.006016,-0.00787],[-0.008094,-0.005514,0.006167],[-0.006261,-0.007308,0.006192],[-0.008301,0.005856,0.006325],[0.006324,0.005895,-0.007948],[-0.008228,0.005943,-0.005945],[0.006392,-0.00776,-0.006056],[-0.006364,0.005971,-0.007825],[-0.008483,-0.005699,-0.006296],[0.007936,0.005806,-0.006991],[-0.007332,0.005779,0.007905],[0.006553,0.007437,0.006375],[0.00836,0.005618,0.006345],[0.006606,-0.007726,0.00615],[-0.006653,-0.007467,-0.00637],[0.008397,-0.005988,0.006172],[0.007204,-0.006851,-0.007377],[0.006629,-0.005923,0.007977],[-0.007732,0.006781,-0.006825],[-0.007586,-0.006336,0.007052],[-0.007804,0.006653,0.007228],[0.00724,0.006676,-0.007449],[0.006563,0.007186,0.007271],[0.007891,0.006473,0.007219],[-0.007313,0.006635,0.007718],[-0.007541,-0.007191,-0.006332],[-0.007353,0.007324,0.006379],[0.00774,0.006654,-0.006963],[-0.007242,0.006786,-0.007318],[-0.006641,-0.007222,-0.007256],[-0.007107,-0.006809,0.007053],[0.007259,0.007131,-0.006964],[0.006572,0.006517,0.007921],[-0.008005,-0.006536,-0.007205],[0.007424,0.006943,0.007227],[0.007475,0.005608,0.007906],[-0.007519,-0.00701,-0.007219],[-0.007099,-0.006335,0.007536],[-0.00732,0.007116,0.007242],[-0.006629,-0.006604,-0.007909],[0.006355,0.006729,-0.007657],[-0.006262,-0.007027,0.007079],[-0.008004,0.005814,0.007236],[0.008129,0.005609,0.007244],[0.00725,0.005851,-0.007658],[-0.006253,-0.006367,0.007738]],"embedFrame":[[0.00006402619105696207,0.0000786741691696864,0.00003645978639958683,2],[0.006588297909348243,-0.00018403915716137256,-0.002695353437002081,1],[-0.0064602455272343194,0.0003413874955007453,0.0027682730098012548,1],[-0.00012990131969363428,0.006333168859713692,-0.0010281718851756696,1],[0.0002579537018075584,-0.00617582052137432,0.0011010914579748434,1],[0.002689007756002744,0.0012086896317438896,0.006196918605497596,1],[-0.0025609553738888203,-0.0010513412934045167,-0.006123999032698422,1]]}}`,
    ),
  },
  Or = {
    package: `P7`,
    source: {
      preset: `bulkyLime`,
      layout: `pre-settled (P7 + cream, 4.6 s sim)`,
      signature: `73e9b0b5`,
      base: `bubble tea/web (settings revision 18)`,
    },
    reference: {
      fillY: 0.0649973901,
      liquid: { fill: 0.7681, meniscusHeight: 1.4, meniscusWidth: 2.5 },
      cream: {
        height: 0.31,
        wave: 1.1,
        waveScale: 1,
        seed: 3,
        meniscus: 1.4,
        fruitSink: 0.0025,
      },
    },
    pieces: [
      {
        type: `mandarinSegment`,
        index: 0,
        position: [
          -0.019280466354557595, 0.04507416980813374, -0.000981845729097917,
        ],
        quaternion: [
          -0.05372642229638729, -0.7844817878955, 0.17521458532573422,
          0.5924539181207606,
        ],
        scale: 1.000676372453031,
        bound: 0.01855709326596321,
        fruitSeed: 0.5509202417451888,
      },
      {
        type: `peachSlice`,
        index: 0,
        position: [
          0.01569686078367161, 0.038201031494527624, 0.006373838837139728,
        ],
        quaternion: [
          -0.26902261023362445, -0.04878417278021841, -0.0814729039729314,
          -0.9584409765799117,
        ],
        scale: 0.9550067587862252,
        bound: 0.022409965781938438,
        fruitSeed: 0.00972348963841796,
      },
      {
        type: `kiwiPiece`,
        index: 0,
        position: [
          -0.00310516239606608, 0.051648818958704705, 0.021314434066346304,
        ],
        quaternion: [
          -0.5694278497368818, 0.48006672648913096, 0.4686101587268018,
          -0.4750709222843288,
        ],
        scale: 0.9406581387821764,
        bound: 0.013030879954323787,
        fruitSeed: 0.04118190263397992,
      },
      {
        type: `kiwiPiece`,
        index: 1,
        position: [
          0.006000897771666531, 0.02987017245512877, -0.008321057787448547,
        ],
        quaternion: [
          -0.13333456666302057, -0.5149155936032502, -0.729447449676092,
          0.4301049208716891,
        ],
        scale: 1.0580981024238734,
        bound: 0.014657768624033663,
        fruitSeed: 0.21687609772197902,
      },
      {
        type: `kiwiPiece`,
        index: 2,
        position: [
          -0.004074908434539717, 0.05784525496247658, 0.0075795819692382775,
        ],
        quaternion: [
          0.7400644033818026, -0.03322645756835806, 0.6641054099093215,
          -0.10082006692006858,
        ],
        scale: 0.9726749846290353,
        bound: 0.013474407371507086,
        fruitSeed: 0.6487868714611977,
      },
      {
        type: `kiwiPiece`,
        index: 3,
        position: [
          -0.011990642091168364, 0.029520474503386733, -0.01240508088579947,
        ],
        quaternion: [
          -0.3878806137837685, -0.7490599150061109, -0.274090618655352,
          -0.461878994918465,
        ],
        scale: 1.0152862506250768,
        bound: 0.014064698646310754,
        fruitSeed: 0.4057431754190475,
      },
      {
        type: `pineappleChunk`,
        index: 0,
        position: [
          0.01344996520433613, 0.05072679294711147, -0.00143463039608291,
        ],
        quaternion: [
          0.232923662732157, -0.0632893725969445, 0.9122999219888902,
          0.330832094868056,
        ],
        scale: 0.8466349996997765,
        bound: 0.012252176822771733,
        fruitSeed: 0.604404280660674,
      },
      {
        type: `pineappleChunk`,
        index: 1,
        position: [
          -0.003170935700215848, 0.04289210607321054, 0.002276598628122352,
        ],
        quaternion: [
          0.4594302275563764, 0.06610170605259118, -0.022068138327815,
          -0.8854758199607585,
        ],
        scale: 0.9925930550790211,
        bound: 0.014364425789384926,
        fruitSeed: 0.8175166910514235,
      },
    ],
    types: JSON.parse(
      `{"mandarinSegment":{"nominal":0.03357,"bound":0.01854455024302498,"spheres":[[-0.005062,-0.016075,0.000646,0.001679],[-0.006416,0.014394,0.001323,0.001376],[0.001709,-0.01269,-0.001385,0.00256],[-0.003708,-0.007273,-0.002739,0.002685],[-0.000322,-0.003211,0.003355,0.003185],[0.006449,0.002206,-0.000031,0.003386],[-0.000322,0.014394,-0.002739,0.001729],[0.001032,-0.003211,-0.003416,0.003182],[-0.004385,-0.014044,0.002001,0.002045],[-0.004385,0.015071,0.000646,0.00167],[0.001709,-0.01269,0.002001,0.002323],[-0.003031,0.006269,0.003355,0.00297],[-0.003031,0.013716,0.003355,0.001526],[-0.002353,-0.014721,-0.002739,0.00186],[-0.005062,0.001529,-0.000708,0.002824],[-0.006416,0.013716,-0.001385,0.001122],[-0.000322,0.014394,0.000646,0.001735],[0.005094,-0.008627,0.001323,0.002662],[-0.005739,-0.013367,-0.002739,0.001728],[-0.000999,-0.015398,0.001323,0.0017],[0.004417,0.002206,0.002678,0.003239],[-0.003708,-0.007273,0.003355,0.00255],[0.005772,-0.003211,-0.002062,0.003],[0.001709,0.006946,-0.003416,0.003003],[-0.003708,0.013716,-0.003416,0.001327],[-0.006416,-0.016075,-0.000708,0.001053],[0.003063,0.011685,-0.001385,0.002677],[0.001709,0.011685,0.002678,0.002536],[0.005772,0.0083,0.000646,0.002734],[-0.005739,-0.010659,0.001323,0.002149],[-0.005739,0.009654,0.000646,0.002436],[-0.000322,-0.00795,-0.002739,0.002776],[-0.005739,-0.002534,0.000646,0.002377],[0.001709,-0.008627,0.003355,0.002503],[0.000355,0.001529,-0.004093,0.002888],[-0.003708,0.006269,-0.003416,0.002764],[-0.003708,0.001529,0.003355,0.0028],[-0.005062,0.011008,-0.003416,0.001587],[0.001709,0.006946,0.003355,0.003068],[-0.002353,-0.012013,0.003355,0.00183],[0.004417,-0.003888,0.002678,0.003012],[-0.005739,0.012362,0.003355,0.001501],[-0.002353,-0.003211,-0.003416,0.002837],[0.007126,-0.003888,-0.000708,0.002785],[0.00374,-0.009304,-0.002739,0.0023],[0.001032,0.001529,0.004032,0.002843],[0.004417,0.006946,-0.002062,0.003014],[-0.005739,-0.013367,0.000646,0.00188]],"points":[[-0.005232,-0.017143,0.000601],[0.000192,0.015956,-0.001107],[0.009738,-0.000946,0.002004],[-0.004416,-0.000564,-0.005606],[-0.000645,-0.005647,0.006246],[0.003755,-0.010812,-0.004481],[-0.005547,0.007817,0.004999],[0.005618,0.004799,-0.005467],[0.007381,0.010532,0.001857],[-0.007388,0.011391,-0.002925],[0.002827,-0.015149,0.001784],[0.000522,0.004321,0.006315],[-0.001643,0.008783,-0.00618],[0.008918,-0.006656,-0.00208],[-0.005861,0.015308,0.002718],[-0.005851,-0.012369,-0.004396],[-0.000271,-0.00559,-0.00603],[-0.003482,-0.012644,0.004931],[-0.004757,-0.000719,0.005473],[0.00664,0.00498,0.004965],[0.005359,-0.006385,0.004956],[0.000678,0.013656,0.004435],[0.006175,-0.000845,-0.005072],[0.003786,0.010085,-0.005102],[0.005464,-0.00061,0.005586],[-0.007915,-0.01159,0.000657],[-0.001894,-0.016324,-0.00333],[0.009366,0.004897,-0.001863],[0.00616,-0.011337,0.002003],[-0.000871,0.009158,0.006181],[-0.000095,0.004207,-0.006395],[0.000323,-0.000618,-0.006496],[-0.000121,-0.000694,0.006554],[-0.002034,-0.009782,-0.005615],[-0.004752,-0.005073,-0.005274],[-0.004052,0.013921,-0.004545],[-0.007566,0.011176,0.002515],[0.005476,-0.006236,-0.004825],[0.002958,-0.010743,0.004893],[-0.001771,-0.016112,0.002973],[0.001008,0.013512,-0.004557],[0.004334,0.010568,0.004862],[-0.005724,0.008092,-0.005063],[-0.004697,0.003759,0.00546],[0.006806,0.010481,-0.002261],[-0.005476,-0.009078,0.004747],[-0.003278,0.012281,0.005322],[-0.006642,-0.014593,0.003356],[-0.0044,0.016304,-0.00084],[0.003403,0.014304,0.001635],[0.009724,-0.000874,-0.001916],[0.009226,0.005058,0.00204],[0.006638,-0.01151,-0.001827],[0.00871,-0.006614,0.00175],[0.001327,-0.014381,-0.003905],[-0.007485,-0.014536,-0.001749],[0.003608,0.014391,-0.002033],[-0.001298,-0.009773,0.005569],[-0.007626,0.014723,-0.00043],[-0.002348,-0.01317,-0.004821],[0.000657,-0.014141,0.004095],[-0.001395,0.015499,-0.003796],[-0.004869,-0.015304,-0.003836],[0.003089,-0.015024,-0.00126],[-0.006968,-0.016255,0.002069],[-0.006251,0.015313,-0.002229],[-0.001341,0.015395,0.003809],[-0.00667,0.013097,-0.003765],[-0.000749,-0.016951,-0.001463],[-0.008237,0.010925,-0.000703],[-0.004658,-0.015202,0.004021],[-0.003213,0.012216,-0.005424]],"embedFrame":[[0.0006328924636941866,-0.00024355468470056168,0.000122979546551468,2],[0.0076873045279971216,-0.0006050296048391585,-0.00009832088991920633,1],[-0.006421519600608748,0.00011792023543803513,0.0003442799830221424,1],[0.0013163242793209698,0.013038067263615654,0.0002144227110121132,1],[-0.000050539351932596616,-0.013525176633016778,0.00003153638209082281,1],[0.0007898617980753864,-0.00028656588956630963,0.005196958865959841,1],[0.0004759231293129868,-0.0002005434798348137,-0.004950999772856905,1]]},"peachSlice":{"nominal":0.03939,"bound":0.02346576668255269,"spheres":[[-0.006372,-0.016474,0.000204,0.00228],[-0.006372,0.016859,0.000204,0.001839],[0.000295,0.012692,-0.001463,0.002872],[-0.003038,0.002692,-0.000629,0.003468],[-0.003872,-0.008141,-0.000629,0.003211],[0.002795,-0.008141,-0.002296,0.003236],[0.005295,0.002692,0.002704,0.003449],[0.002795,-0.008141,0.002704,0.003236],[-0.001372,0.012692,0.001871,0.002857],[0.005295,0.002692,-0.002296,0.003471],[-0.000538,-0.013141,0.001037,0.0025],[-0.008872,0.016859,-0.000629,0.001672],[-0.009705,-0.018974,-0.000629,0.001416],[-0.006372,0.012692,-0.000629,0.002442],[0.002795,0.008526,0.002704,0.002795],[-0.003872,-0.016474,0.000204,0.00228],[-0.003038,0.016026,-0.001463,0.001941],[0.002795,0.008526,-0.003129,0.002795],[0.000295,-0.013141,-0.002296,0.002472],[0.000295,0.002692,0.001871,0.00337],[-0.006372,-0.012308,0.000204,0.002431],[0.005295,-0.003141,0.002704,0.00315],[-0.012205,0.018526,0.000204,0.001108],[-0.003872,-0.003141,0.000204,0.00315],[-0.004705,0.007692,0.000204,0.002958],[0.004462,-0.003141,-0.003129,0.00315],[-0.003872,0.016859,0.001871,0.001799],[-0.011372,-0.017308,0.000204,0.001317],[0.001128,-0.003141,-0.002296,0.00315],[-0.008038,0.018526,0.000204,0.001328],[-0.003872,-0.016474,-0.002296,0.001626],[0.000295,-0.012308,0.002704,0.002431],[-0.001372,-0.003141,0.001871,0.002857],[-0.002205,-0.015641,0.002704,0.0015],[-0.007205,-0.016474,0.000204,0.00228],[-0.000538,0.007692,-0.002296,0.002652],[0.001128,0.012692,0.002704,0.00241]],"points":[[-0.012851,-0.019634,0.000007],[-0.009197,0.019642,-0.000459],[0.008361,-0.000332,0.002361],[0.001357,-0.014891,0.001627],[0.003597,0.01057,-0.005632],[0.000483,0.014835,0.004685],[0.006406,-0.005715,-0.006446],[-0.004261,-0.018004,-0.00309],[0.006431,0.005655,0.006513],[0.00804,0.00547,-0.002425],[0.006397,-0.005718,0.006502],[0.005267,0.01057,0.001733],[0.005416,-0.010609,-0.001836],[-0.003624,0.017786,-0.002972],[-0.003915,-0.017978,0.003167],[0.00163,0.014809,-0.001596],[-0.004285,0.018019,0.00305],[0.000554,-0.014891,-0.004325],[0.00708,-0.000028,-0.006435],[0.004255,-0.010849,0.005581],[0.007949,-0.005234,-0.001954],[0.006623,-0.000028,0.006671],[0.008077,0.005178,0.002329],[0.006233,0.005485,-0.006485],[0.008443,-0.000028,-0.002001],[0.003597,0.01057,0.005692],[0.00741,-0.005826,0.002261],[-0.008906,-0.019416,0.001647],[0.004006,-0.010626,-0.005765],[-0.012856,0.018107,0.000278],[0.005556,-0.010341,0.002067],[0.004783,0.01057,-0.001926],[0.002099,0.014604,0.001705],[0.000483,0.014835,-0.004625],[-0.008906,-0.019416,-0.001588],[0.000103,-0.014891,0.004562],[0.001157,-0.014891,-0.001547],[-0.002894,-0.017822,-0.001123],[-0.009323,0.019578,-0.001358],[0.00656,0.005755,-0.006267],[-0.009323,0.019578,0.001418],[0.004579,-0.010345,-0.005626],[0.007078,-0.000028,0.006494],[0.004032,0.01057,-0.00545],[-0.004354,0.017948,-0.00306],[-0.012654,-0.019634,0.00034],[0.001118,0.01459,-0.004507],[0.004345,-0.010504,0.005839],[0.003889,0.01057,0.005692],[0.000573,-0.014891,0.00439],[0.007719,-0.005818,-0.002538],[-0.012853,-0.019416,-0.000221],[-0.012848,0.019578,-0.00001],[0.006906,-0.000028,-0.006608],[0.000395,-0.014891,-0.004502],[0.006532,0.005322,-0.006486],[0.006677,-0.005233,-0.006305],[0.007905,0.005765,0.002311],[-0.012856,-0.019416,0.000277],[0.000811,0.014833,0.004654],[0.004322,-0.010626,-0.00573],[-0.012654,0.019578,-0.00028]],"embedFrame":[[-0.00010831651202811584,-0.0003760947436873706,0.0000518244447505562,2],[0.0070600368580531064,-0.0006229880786456105,0.00015093656429008746,1],[-0.007276669882109338,-0.00012920140872913063,-0.000047287674788975066,1],[0.0004362313044684283,0.015447076673043085,0.00008334818930996313,1],[-0.00065286432852466,-0.016199266160417825,0.00002030070019114926,1],[-0.00016642095104858323,-0.0003824359613134528,0.004238472342398871,1],[-0.00005021207300764846,-0.00036975352606128834,-0.004134823452897758,1]]},"kiwiPiece":{"nominal":0.01899,"bound":0.013852939146621559,"spheres":[[0.000411,0.000198,-0.004152,0.004458],[0.005161,0.000198,0.003369,0.004458],[0.003578,-0.000198,-0.000986,0.004408],[-0.003547,-0.000198,-0.005736,0.004322],[-0.004339,-0.000594,0.00416,0.004012],[-0.003547,-0.000198,-0.00059,0.004408],[0.000807,0.000198,0.003764,0.004408],[0.00714,-0.00099,0.004556,0.003476],[-0.004339,0.00099,0.004556,0.003617],[-0.004735,-0.002177,-0.008506,0.002429],[0.00714,0.002573,0.000202,0.002055],[-0.004339,0.00099,-0.004152,0.003633],[0.009119,0.002573,0.006139,0.001755],[-0.004735,0.002573,-0.008902,0.002083],[0.002786,0.002969,0.006535,0.001637],[-0.000381,-0.002177,-0.006527,0.002429],[0.003973,-0.002177,-0.003756,0.002419],[-0.006714,-0.002969,0.006139,0.001637],[-0.005527,0.002177,0.001785,0.002479],[0.006348,-0.002969,-0.001777,0.001637],[0.009515,-0.002969,0.006931,0.001242],[-0.005922,0.002177,0.005348,0.002479],[0.002786,-0.002177,0.005744,0.002429],[0.004765,0.002573,-0.002965,0.002083],[-0.000777,-0.002573,0.006139,0.002033],[-0.006318,-0.003365,-0.009694,0.001242],[-0.001172,0.002177,-0.007319,0.002479],[-0.005922,0.00099,-0.009694,0.001671],[-0.000777,0.000198,0.000202,0.004458],[-0.005922,-0.002177,0.001389,0.002408],[-0.005922,-0.002573,-0.004152,0.002033],[0.005953,0.002573,0.006139,0.002033],[-0.006318,0.003365,-0.007319,0.001292],[0.007536,0.001781,0.003369,0.002807],[0.006348,-0.00099,0.002181,0.003568],[-0.000777,0.001781,0.005348,0.002825],[0.003578,0.002573,-0.004944,0.001854],[0.001203,-0.002969,-0.006527,0.001637],[0.008723,0.001385,0.006139,0.002033],[-0.007506,-0.00099,0.006931,0.001183],[-0.00711,0.002969,-0.001381,0.001046],[0.006744,-0.002177,0.006139,0.002033],[-0.005922,-0.002573,-0.001381,0.002033],[-0.007506,0.002969,0.006931,0.001183],[-0.001964,0.00376,-0.009298,0.000896],[-0.001964,-0.00099,-0.006527,0.003617],[0.008723,-0.002177,0.005744,0.002104],[0.006348,0.003365,-0.002173,0.001292]],"points":[[-0.008355,-0.004134,0.007783],[0.010521,0.004266,0.006389],[-0.005755,0.004266,-0.010966],[0.005443,-0.004216,-0.005158],[-0.007908,0.0043,0.002096],[-0.007354,-0.00425,-0.006535],[0.010013,-0.00425,0.003585],[0.007166,0.0043,-0.002888],[0.000985,0.004184,-0.008709],[-0.000285,-0.004134,-0.009368],[-0.008275,0.004184,0.007816],[-0.005751,-0.004134,-0.010999],[-0.008077,-0.004216,0.003452],[0.009753,0.004184,0.002177],[0.008028,-0.004134,-0.001745],[0.00445,0.004184,-0.006187],[0.010493,-0.004134,0.007816],[-0.007642,0.0043,-0.002047],[-0.002956,-0.004134,-0.01039],[0.002202,-0.004134,-0.007956],[-0.001601,0.004184,-0.009929],[0.009277,-0.004134,0.000828],[0.008701,0.004184,-0.000482],[-0.008196,0.004184,0.004783],[-0.008259,0.004266,0.006295],[-0.008259,-0.004216,0.006294],[0.003288,-0.00425,-0.007023],[0.002138,0.0043,-0.00786],[-0.007129,0.004251,-0.011091],[0.010558,0.004251,0.007768],[-0.007129,-0.004201,-0.011091],[0.010521,-0.004216,0.006389],[0.006406,0.004184,-0.004101],[0.010489,-0.00425,0.007701],[-0.00835,0.004266,0.007701]],"embedFrame":[[0.00013284651547855702,-0.000011916026926132575,0.000031230205558171495,2],[0.004839242900759885,-0.0002352613162611168,-0.004642498856175475,1],[-0.00457354986980277,0.00021142926240885166,0.004704959267291818,1],[0.00019686508248597913,0.003627360733441862,-0.0000782152847352073,1],[0.00006882794847113492,-0.003651192787294127,0.0001406756958515503,1],[0.0065061052343220035,0.00006886113606409391,0.006445175088120164,1],[-0.006240412203364889,-0.00009269318991635906,-0.006382714677003821,1]]},"pineappleChunk":{"nominal":0.01961,"bound":0.01447161625389507,"spheres":[[0.000118,0.000078,0.000249,0.008348],[-0.003257,-0.002922,-0.002751,0.005523],[-0.004007,0.003828,0.004374,0.004597],[-0.004757,0.003453,-0.003501,0.004663],[0.004993,-0.004422,0.003624,0.003905],[-0.002882,-0.002922,0.003249,0.005502],[0.003493,0.003828,0.003624,0.004644],[0.003118,-0.001797,-0.002376,0.006091],[0.006118,0.001578,-0.005376,0.003179],[0.000868,0.004578,-0.005001,0.003648],[0.007618,-0.005922,-0.005751,0.002434],[0.004243,0.003453,-0.003126,0.004826],[0.001243,-0.005922,-0.005751,0.002571],[0.002368,-0.002547,0.003249,0.005832],[-0.000632,0.004578,0.005124,0.00381],[-0.007757,0.004203,-0.006501,0.001894],[-0.005507,0.004203,0.000624,0.003682],[0.004993,-0.004422,0.005499,0.003679],[-0.005507,0.000453,0.005874,0.003085],[-0.005882,-0.005172,-0.000501,0.00279],[-0.006257,-0.005172,-0.005376,0.00275],[0.004993,0.000453,0.005874,0.003102],[-0.000257,-0.005172,0.005874,0.003171],[0.004993,0.005328,-0.006126,0.002569],[-0.004757,0.006078,-0.006126,0.002251],[-0.004382,-0.004047,0.005499,0.00355],[0.006868,-0.005547,-0.003501,0.002955],[0.007618,-0.001422,-0.006501,0.001887],[-0.006632,0.005703,-0.000876,0.002684],[0.007243,-0.005922,0.000624,0.002158],[-0.003257,0.001578,-0.002751,0.005832],[-0.004757,-0.007047,-0.006876,0.001318],[-0.008132,-0.000672,-0.007251,0.001168],[0.004993,0.004953,0.005124,0.002987],[0.005743,0.005703,0.000249,0.002614],[0.004243,-0.005922,-0.005751,0.00251],[-0.007007,0.006078,-0.006126,0.002275],[-0.006632,-0.007047,0.006999,0.001333],[-0.001757,-0.005922,-0.005376,0.002546],[0.007243,-0.006297,0.003249,0.001871],[0.007618,0.004203,-0.006501,0.00185],[-0.007382,0.006453,0.003999,0.001727],[0.001993,0.006828,0.006999,0.001664],[-0.002507,0.007203,0.007374,0.001245],[0.006493,-0.002547,-0.005001,0.003313],[-0.002507,0.005703,-0.006126,0.002499],[-0.007007,-0.004047,-0.006501,0.001998],[-0.006632,0.006828,0.007374,0.001423]],"points":[[0.009803,-0.007722,-0.007328],[-0.008163,0.00736,0.008242],[-0.008472,-0.006934,-0.003978],[0.007167,0.007845,-0.000065],[0.003084,-0.0076,0.008177],[-0.008728,0.007648,-0.007634],[-0.00757,-0.003972,0.008069],[0.0073,0.001485,0.008247],[0.009039,0.003011,-0.007964],[0.008334,-0.007872,0.000585],[0.002677,0.00772,-0.007114],[-0.009062,0.006983,0.000355],[-0.001802,0.001279,0.008594],[-0.008223,-0.001073,-0.008036],[-0.002648,-0.007233,-0.008],[0.00625,0.007966,0.007347],[0.003639,-0.008063,-0.003706],[-0.003252,0.008024,0.004302],[-0.004212,0.003268,-0.00817],[0.008228,-0.005289,0.007226],[-0.00763,-0.00756,0.003845],[-0.002184,-0.006952,0.008528],[0.002156,0.008035,0.004226],[0.009676,-0.001556,-0.007089],[0.008656,0.006715,-0.004119],[-0.007938,-0.005594,-0.008075],[-0.009343,0.003403,-0.007048],[-0.002474,-0.008052,-0.003783],[-0.003077,0.007208,0.008519],[-0.008359,0.003277,0.007151],[-0.003573,0.007441,-0.007989],[0.002339,0.007979,0.00015],[0.008204,0.00716,-0.00806],[-0.009347,0.007032,-0.003742],[0.004354,-0.007982,0.000409],[0.008854,-0.008044,-0.003557],[-0.006721,-0.007723,0.007625],[-0.008776,0.006926,0.004469],[-0.002416,-0.003259,0.008575],[0.00849,-0.007361,0.00424],[0.007619,0.007091,0.004151],[0.00342,0.007879,-0.003975],[0.003774,-0.007993,-0.006892],[0.006988,-0.003045,0.008545],[0.007311,-0.007264,0.00858],[-0.008325,-0.007347,-0.007713],[0.006201,0.007288,0.008265],[0.007229,0.007069,0.007365],[-0.009239,0.00746,-0.007387],[0.006734,0.007721,0.007859],[0.008724,0.006933,-0.007917],[0.007839,-0.006966,0.008358],[-0.00854,0.006726,0.007722],[0.00835,0.007372,-0.004204],[-0.007853,-0.006953,-0.008082],[0.009276,-0.007883,-0.007459],[0.009905,-0.007184,-0.007477],[-0.009126,0.007674,-0.003774],[-0.00824,0.006848,0.008349],[0.009472,-0.007774,-0.003545],[-0.007811,-0.007531,-0.007834],[-0.009526,0.006743,-0.006613],[-0.00848,-0.006824,-0.007832],[0.010084,-0.007065,-0.006847],[0.007309,0.007744,0.004088],[0.009087,0.00618,-0.007301],[0.006878,0.007228,0.007993],[0.009308,-0.007318,-0.007742],[0.006186,0.007863,0.00798],[-0.00871,-0.006676,-0.007201],[0.008271,0.006603,-0.008208],[0.008889,0.00637,-0.007953]],"embedFrame":[[0.000051438437459437386,-0.00010853632029960386,-0.000004604663954529101,2],[0.006810461689221064,-0.0036767586140738395,0.0018815579448438606,1],[-0.006707584814302189,0.0034596859734746317,-0.0018907672727529186,1],[0.0027747165137335635,0.005933773800433574,0.0016673645636389397,1],[-0.0026718396388146883,-0.006150846441032782,-0.0016765738915479977,1],[-0.0023552580506245946,-0.0009629914553142006,0.007003291473656224,1],[0.002458134925543469,0.0007459188147149928,-0.0070125008015652825,1]]}}`,
    ),
  },
  kr = { P4: Dr, P7: Or },
  Ar = 4,
  jr = 64,
  Mr = 7,
  Nr = (e) =>
    String(e ?? ``)
      .toLowerCase()
      .replace(/[^a-z0-9]/g, ``),
  Pr = new ut(),
  Fr = new Lt(),
  Ir = new B();
function Lr(e, t, n = 12) {
  for (let r = 0; r < n; r++) {
    let n = Fr.makeRotationFromQuaternion(t).elements,
      r = 0,
      i = 0,
      a = 0,
      o = 0;
    for (let t = 0; t < 3; t++) {
      let s = n[4 * t],
        c = n[4 * t + 1],
        l = n[4 * t + 2],
        u = e[t],
        d = e[3 + t],
        f = e[6 + t];
      ((r += c * f - l * d),
        (i += l * u - s * f),
        (a += s * d - c * u),
        (o += s * u + c * d + l * f));
    }
    let s = 1 / (Math.abs(o) + 1e-12);
    ((r *= s), (i *= s), (a *= s));
    let c = Math.hypot(r, i, a);
    if (c < 1e-9) break;
    t.premultiply(
      Pr.setFromAxisAngle(Ir.set(r / c, i / c, a / c), c),
    ).normalize();
  }
  return t;
}
function Rr({
  cupRoot: e,
  model: t = null,
  normalMap: n = null,
  settings: r = {},
  environment: i = null,
  layers: a = {},
} = {}) {
  let o = r.fruits,
    s = o.physics,
    c = r.liquid,
    l = a.main ?? 0,
    u = a.depth ?? null,
    d = new We();
  ((d.name = `Fruits`), e?.add(d));
  let f = yr(o),
    p = new Map(),
    m = new Map(),
    h = new Map(),
    g = u === null ? null : Er(),
    _ = new Map(),
    v = {
      source: `loading`,
      disposed: !1,
      active: !0,
      liquidVisible: !0,
      envScale: 1,
      current: null,
      levels: null,
    },
    y = (e) => Object.keys(o.types).find((t) => Nr(t) === Nr(e)) ?? String(e),
    b = t?.scene ?? t?.scenes?.[0] ?? null,
    x = b?.getObjectByName(`FruitPrototypes`) ?? null;
  (x ||
    b?.traverse((e) => {
      !x && e.name.split(`.`)[0] === `FruitPrototypes` && (x = e);
    }),
    x?.traverse((e) => {
      if (!e.isMesh) return;
      let t = e.userData?.type ? e.userData : (e.parent?.userData ?? {}),
        n = e.geometry;
      (n.computeBoundingSphere(),
        h.set(y(t.type ?? e.name.replace(/^FruitProto_/, ``)), n));
    }),
    (v.source = t
      ? h.size
        ? `fruits.glb`
        : `fruits.glb (no FruitPrototypes)`
      : `missing fruits.glb`),
    h.size || console.warn(`Fruits: ${v.source}; no pieces.`));
  function S(e, t) {
    return (
      m.has(e) ||
        (p.has(e) || p.set(e, xr(o.types[e] ?? {})),
        m.set(
          e,
          Tr({
            look: f,
            type: p.get(e),
            map: n,
            environment: i,
            envIntensity: o.envIntensity,
            name: e,
            parts: t,
          }).material,
        )),
      m.get(e)
    );
  }
  function C(e) {
    let t = e?.id;
    if (_.has(t)) return _.get(t);
    let n = kr[t],
      r = e?.extras?.cavityProfile;
    if (!n || !(r?.length > 2)) return null;
    let i = Math.min(jr, n.pieces.length),
      a = {
        id: t,
        data: n,
        reference: null,
        fitKey: ``,
        n: i,
        pieces: [],
        group: new We(),
        P: new Float64Array(i * 3),
        Q: new Float64Array(i * 4),
        S: new Float64Array(i),
        B: new Float64Array(i),
        T: [],
        glass: Yt(r),
      };
    ((a.group.name = `Fruits ${t}`), (a.group.visible = !1));
    let s = new Map(),
      c = (e) => {
        if (s.has(e)) return s.get(e);
        let t = n.types[e],
          r = Float64Array.from(t.spheres.flat()),
          i = Float64Array.from(t.points.flat()),
          a = {
            type: e,
            spheres: r,
            sphereCount: t.spheres.length,
            points: i,
            pointCount: t.points.length,
            frame: Float64Array.from(t.embedFrame.flat()),
          };
        return (s.set(e, a), a);
      };
    for (let e = 0; e < i; e++) {
      let t = n.pieces[e],
        r = y(t.type);
      a.T.push(c(t.type));
      let i = h.get(r);
      if (!i) continue;
      let s = `Fruit_${r}_${String(t.index + 1).padStart(2, `0`)}`,
        d = new We();
      d.name = s;
      let f = new kt(i, S(r, !!i.attributes.color));
      ((f.name = `${s} (mesh)`),
        f.layers.set(l),
        (f.renderOrder = Ar),
        (f.castShadow = f.receiveShadow = !1),
        (f.userData.fruitSeed = t.fruitSeed),
        d.add(f));
      let p = null;
      (g &&
        ((p = new kt(i, g)),
        (p.name = `${s} (liquid depth)`),
        p.layers.set(u),
        (p.castShadow = p.receiveShadow = !1),
        (p.visible = !!o.depthInLiquid),
        f.add(p)),
        a.group.add(d),
        a.pieces.push({
          pivot: d,
          mesh: f,
          twin: p,
          type: r,
          name: s,
          index: e,
        }));
    }
    return (w(a), T(a), d.add(a.group), _.set(t, a), a);
  }
  function w(e) {
    let t = v.levels,
      n = e.reference,
      r =
        t && n
          ? Math.min(
              1,
              (t.fillY - t.floorY) / Math.max(1e-6, n.fillY - n.floorY),
            )
          : 1,
      i = t && n ? t.floorY - n.floorY : 0,
      a = Math.abs(i) < 1e-9 && r > 1 - 1e-9,
      o = a ? `baked` : `${i}|${r}`;
    if (o === e.fitKey) return !1;
    e.fitKey = o;
    let { P: s, Q: c, S: l, B: u, data: d } = e;
    for (let i = 0; i < e.n; i++) {
      let o = d.pieces[i],
        f = i * 3;
      if (
        (s.set(o.position, f),
        c.set(o.quaternion, i * 4),
        (l[i] = o.scale),
        (u[i] = o.bound),
        !a)
      ) {
        ((s[f + 1] = t.floorY + (s[f + 1] - n.floorY) * r),
          (l[i] *= r),
          (u[i] *= r),
          ne.set(c[i * 4], c[i * 4 + 1], c[i * 4 + 2], c[i * 4 + 3]));
        for (let t = 0; t < 3; t++) {
          let t = pe(e, i, s[f], s[f + 1], s[f + 2], ne);
          if (t <= 0) break;
          ((s[f] += ie[0] * t),
            (s[f + 1] += ie[1] * t),
            (s[f + 2] += ie[2] * t));
        }
      }
    }
    return !0;
  }
  function T(e = v.current) {
    if (!e) return;
    let { P: t, Q: n, S: r } = e;
    for (let i of e.pieces) {
      let e = i.index;
      (i.pivot.position.set(t[e * 3], t[e * 3 + 1], t[e * 3 + 2]),
        i.pivot.quaternion.set(
          n[e * 4],
          n[e * 4 + 1],
          n[e * 4 + 2],
          n[e * 4 + 3],
        ),
        i.pivot.scale.setScalar(r[e]));
    }
  }
  function E(e) {
    return !!C(e);
  }
  function D(e = {}) {
    let t = C(e);
    t !== v.current &&
      (N.on && F(),
      v.current && (v.current.group.visible = !1),
      (v.current = t),
      t && (t.group.visible = !0));
  }
  function O(e = null, t = null) {
    v.levels = e;
    let n = v.current;
    n && ((n.reference = t), w(n) && !N.on && T(n));
  }
  function k({ envScale: e } = {}) {
    (Number.isFinite(e) && (v.envScale = e), br(f, o), ee(f.jelly.value));
    for (let [e, t] of p) o.types[e] && Sr(t, o.types[e]);
    for (let e of m.values())
      e.envMapIntensity = o.envIntensity * (v.envScale ?? 1);
    d.visible =
      v.active && !!o.visible && !(o.hideWithLiquid && !v.liquidVisible);
    for (let e of _.values())
      for (let t of e.pieces) t.twin && (t.twin.visible = !!o.depthInLiquid);
  }
  let A = new G(),
    j = new G();
  function ee(e) {
    e.set(1, 1, 1);
    let t = c,
      n = Math.min(Math.max(Number(o.jellyCompensation) || 0, 0), 1);
    if (!t || !v.liquidVisible || t.visible === !1 || n <= 0) return e;
    (A.set(t.color ?? `#ffffff`), j.set(t.attenuationColor ?? `#ffffff`));
    let r =
        Math.max(Number(o.jellyDepth) || 0, 0) /
        Math.max(Number(t.attenuationDistance) || 1, 1e-4),
      i = (e, t) =>
        Math.min(Math.max(e * Math.max(t, 1e-4) ** +r, 0.2), 1) ** +-n;
    return e.set(i(A.r, j.r), i(A.g, j.g), i(A.b, j.b));
  }
  function te(e) {
    ((v.liquidVisible = !!e), k());
  }
  function M(e = 0) {
    !v.disposed &&
      v.active &&
      d.visible &&
      v.current?.pieces.length &&
      le(Math.min(Math.max(e, 0), 0.05), N.field?.active ? N.field : null);
  }
  let N = {
    field: null,
    on: !1,
    held: -1,
    u: new Float64Array(192),
    uv: new Float64Array(192),
    w: new Float64Array(192),
    wv: new Float64Array(192),
    sample: { u: [0, 0, 0], grad: Array(9).fill(0), w: [0, 0, 0] },
  };
  function P(e = null) {
    ((N.field = e), !e && N.on && F());
  }
  function F() {
    ((N.on = !1), N.u.fill(0), N.uv.fill(0), N.w.fill(0), N.wv.fill(0), T());
  }
  let ne = new ut(),
    re = new ut(),
    ie = new Float64Array(3),
    ae = new B(),
    oe = new ut(),
    I = new B(),
    se = { tu: [0, 0, 0], tw: [0, 0, 0] },
    L = new Float64Array(21),
    ce = new Float64Array(21),
    R = new Float64Array(9);
  function le(e, t) {
    let n = v.current;
    if (!t || !n) {
      N.on && F();
      return;
    }
    let r = t.coupling;
    if ((!t.moving && !N.on) || (!t.moving && N.held === t.version)) return;
    ((N.held = -1), (N.on = !0));
    let i = t.lag,
      a = t.rotation,
      { P: o, Q: s, S: c, B: l } = n,
      u = e > 0 ? Math.max(1, Math.ceil(e * 120)) : 0,
      d = u ? e / u : 0,
      f = 0,
      p = 0;
    for (let e of n.pieces) {
      let m = e.index,
        h = m * 3,
        g = ue(n, m, t),
        _ = g.tu[0] * r,
        v = g.tu[1] * r,
        y = g.tu[2] * r,
        b = r * a,
        x = g.tw[0] * b,
        S = g.tw[1] * b,
        C = g.tw[2] * b,
        w = N.u,
        T = N.uv,
        E = N.w,
        D = N.wv;
      if (i <= 1e-4 || !u)
        ((w[h] = _),
          (w[h + 1] = v),
          (w[h + 2] = y),
          (E[h] = x),
          (E[h + 1] = S),
          (E[h + 2] = C),
          T.fill(0, h, h + 3),
          D.fill(0, h, h + 3));
      else {
        let e = Math.min(1.6, Math.max(0.6, l[m] / 0.0075)),
          t = 1 / (i * Math.sqrt(e)),
          n = t * t,
          r = 1.2 * t;
        for (let e = 0; e < u; e++)
          ((T[h] += (n * (_ - w[h]) - r * T[h]) * d),
            (w[h] += T[h] * d),
            (T[h + 1] += (n * (v - w[h + 1]) - r * T[h + 1]) * d),
            (w[h + 1] += T[h + 1] * d),
            (T[h + 2] += (n * (y - w[h + 2]) - r * T[h + 2]) * d),
            (w[h + 2] += T[h + 2] * d),
            (D[h] += (n * (x - E[h]) - r * D[h]) * d),
            (E[h] += D[h] * d),
            (D[h + 1] += (n * (S - E[h + 1]) - r * D[h + 1]) * d),
            (E[h + 1] += D[h + 1] * d),
            (D[h + 2] += (n * (C - E[h + 2]) - r * D[h + 2]) * d),
            (E[h + 2] += D[h + 2] * d));
      }
      ((f +=
        w[h] ** 2 +
        w[h + 1] ** 2 +
        w[h + 2] ** 2 +
        E[h] ** 2 * 1e-4 +
        E[h + 1] ** 2 * 1e-4 +
        E[h + 2] ** 2 * 1e-4 +
        (T[h] ** 2 + T[h + 1] ** 2 + T[h + 2] ** 2) * 0.001),
        (p = Math.max(
          p,
          Math.abs(w[h] - _),
          Math.abs(w[h + 1] - v),
          Math.abs(w[h + 2] - y),
          Math.abs(T[h]) * 0.01,
          Math.abs(T[h + 1]) * 0.01,
          Math.abs(T[h + 2]) * 0.01,
        )));
      let O = Math.hypot(E[h], E[h + 1], E[h + 2]);
      (O > 1e-9
        ? re.setFromAxisAngle(
            ae.set(E[h] / O, E[h + 1] / O, E[h + 2] / O),
            Math.min(O, 0.6),
          )
        : re.identity(),
        ne
          .set(s[m * 4], s[m * 4 + 1], s[m * 4 + 2], s[m * 4 + 3])
          .premultiply(re));
      let k = o[h] + w[h],
        A = o[h + 1] + w[h + 1],
        j = o[h + 2] + w[h + 2],
        ee = fe(n, m, k, A, j, ne, t);
      ee > 0 && (A -= ee);
      for (let e = 0; e < 3; e++) {
        let e = pe(n, m, k, A, j, ne);
        if (e <= 0) break;
        ((k += ie[0] * e), (A += ie[1] * e), (j += ie[2] * e));
      }
      (e.pivot.position.set(k, A, j),
        e.pivot.quaternion.copy(ne),
        e.pivot.scale.setScalar(c[m]));
    }
    !t.moving && f < 1e-10
      ? F()
      : !t.moving && p < 1e-6 && (N.held = t.version);
  }
  function ue(e, t, n) {
    let r = e.T[t].frame,
      i = e.S[t],
      a = e.P,
      o = e.Q,
      s = t * 3;
    oe.set(o[t * 4], o[t * 4 + 1], o[t * 4 + 2], o[t * 4 + 3]);
    let c = 0,
      l = 0,
      u = 0,
      d = 0,
      f = 0,
      p = 0,
      m = 0,
      h = N.sample;
    for (let e = 0; e < Mr; e++) {
      I.set(r[e * 4] * i, r[e * 4 + 1] * i, r[e * 4 + 2] * i).applyQuaternion(
        oe,
      );
      let t = a[s] + I.x,
        o = a[s + 1] + I.y,
        g = a[s + 2] + I.z,
        _ = r[e * 4 + 3];
      (n.sample(t, o, g, h),
        (L[e * 3] = t),
        (L[e * 3 + 1] = o),
        (L[e * 3 + 2] = g),
        (ce[e * 3] = t + h.u[0]),
        (ce[e * 3 + 1] = o + h.u[1]),
        (ce[e * 3 + 2] = g + h.u[2]),
        (c += _),
        (l += _ * t),
        (u += _ * o),
        (d += _ * g),
        (f += _ * ce[e * 3]),
        (p += _ * ce[e * 3 + 1]),
        (m += _ * ce[e * 3 + 2]));
    }
    ((l /= c), (u /= c), (d /= c), (f /= c), (p /= c), (m /= c), R.fill(0));
    for (let e = 0; e < Mr; e++) {
      let t = r[e * 4 + 3],
        n = ce[e * 3] - f,
        i = ce[e * 3 + 1] - p,
        a = ce[e * 3 + 2] - m,
        o = L[e * 3] - l,
        s = L[e * 3 + 1] - u,
        c = L[e * 3 + 2] - d;
      ((R[0] += t * n * o),
        (R[1] += t * n * s),
        (R[2] += t * n * c),
        (R[3] += t * i * o),
        (R[4] += t * i * s),
        (R[5] += t * i * c),
        (R[6] += t * a * o),
        (R[7] += t * a * s),
        (R[8] += t * a * c));
    }
    let g = Lr(R, re.identity());
    (I.set(a[s] - l, a[s + 1] - u, a[s + 2] - d).applyQuaternion(g),
      (se.tu[0] = f + I.x - a[s]),
      (se.tu[1] = p + I.y - a[s + 1]),
      (se.tu[2] = m + I.z - a[s + 2]));
    let _ = Math.min(1, Math.max(-1, g.w)),
      v = Math.acos(Math.abs(_)),
      y = Math.sin(v),
      b = _ < 0 ? -1 : 1,
      x = y > 1e-9 ? ((2 * v) / y) * b : 2 * b;
    return (
      (se.tw[0] = g.x * x),
      (se.tw[1] = g.y * x),
      (se.tw[2] = g.z * x),
      se
    );
  }
  let de = new B();
  function fe(e, t, n, r, i, a, o) {
    let c = o.fillY;
    if (!(c > 0)) return 0;
    let l = s.surfaceClearance;
    if (r + e.B[t] < c - 0.012) return 0;
    let u = e.T[t],
      d = e.S[t],
      f = u.points,
      p = N.sample,
      m = 0;
    for (let e = 0; e < u.pointCount; e++) {
      de.set(f[e * 3] * d, f[e * 3 + 1] * d, f[e * 3 + 2] * d).applyQuaternion(
        a,
      );
      let t = de.y + r;
      if (t < c - 0.012) continue;
      let s = de.x + n,
        u = de.z + i;
      (o.sample(s, c, u, p), (m = Math.max(m, t + l - (c + p.u[1]))));
    }
    return m;
  }
  function pe(e, t, n, r, i, a) {
    let o = e.glass,
      c = s.wallClearance;
    if (o.eval(Math.hypot(n, i), r).d > e.B[t] + c + 0.001) return 0;
    let l = e.T[t],
      u = e.S[t],
      d = l.spheres,
      f = l.points,
      p = 0,
      m = l.sphereCount + l.pointCount;
    for (let e = 0; e < m; e++) {
      let t = e >= l.sphereCount,
        s = t ? (e - l.sphereCount) * 3 : e * 4,
        m = t ? f : d;
      de.set(m[s] * u, m[s + 1] * u, m[s + 2] * u).applyQuaternion(a);
      let h = de.x + n,
        g = de.y + r,
        _ = de.z + i,
        v = Math.hypot(h, _),
        y = o.eval(v, g),
        b = (t ? 0 : d[s + 3] * u) + c - y.d;
      if (b > p) {
        p = b;
        let e = v > 1e-9 ? h / v : 0,
          t = v > 1e-9 ? _ / v : 0;
        ((ie[0] = y.nr * e), (ie[1] = y.ny), (ie[2] = y.nr * t));
      }
    }
    return p;
  }
  function me() {
    let e = v.current,
      t = {};
    for (let n of e?.pieces ?? []) t[n.type] = (t[n.type] ?? 0) + 1;
    return {
      source: v.source,
      layout: e
        ? `${e.id} (${e.fitKey === `baked` ? `baked poses` : `re-fitted to the jelly levels`})`
        : `none`,
      pieces: e?.pieces.length ?? 0,
      types: t,
    };
  }
  function z(e) {
    ((v.active = !!e), !v.active && N.on && F(), k());
  }
  function he() {
    ((v.disposed = !0), d.removeFromParent());
    for (let e of m.values()) e.dispose();
    g?.dispose();
    for (let e of h.values()) e.dispose();
  }
  return {
    group: d,
    settings: o,
    layouts: _,
    update: M,
    setActive: z,
    setLiquidVisible: te,
    configure: k,
    setPackage: D,
    prepare: E,
    setLevels: O,
    setJelly: P,
    describe: me,
    dispose: he,
    get pieces() {
      return v.current?.pieces ?? [];
    },
    get layout() {
      return v.current;
    },
    get carrying() {
      return N.on;
    },
  };
}
function zr(e) {
  return {
    color: I(new G(e.color)),
    shade: I(new G(e.shade)),
    glowColor: I(new G(e.glowColor)),
    roughness: I(e.roughness),
    sheen: I(e.sheen),
    translucency: I(e.translucency),
    glow: I(e.glow),
    softness: I(e.softness),
    grain: I(e.grain),
    grainScale: I(e.grainScale),
    top: I(0.02),
    low: I(0.001),
  };
}
function Br(e, t) {
  (e.color.value.set(t.color),
    e.shade.value.set(t.shade),
    e.glowColor.value.set(t.glowColor));
  for (let n of [
    `roughness`,
    `sheen`,
    `translucency`,
    `glow`,
    `softness`,
    `grain`,
    `grainScale`,
  ])
    e[n].value = t[n];
}
var Vr = class extends zt {
    constructor(e) {
      (super(!1, !1, !1, !1, !1, !1), (this.cream = e));
    }
    direct(e, t) {
      let { lightDirection: n, lightColor: r, reflectedLight: i } = e,
        a = this.cream.creamUniforms,
        o = ae,
        s = o.dot(n),
        c = s
          .add(a.softness)
          .div(a.softness.add(1))
          .clamp()
          .sub(s.clamp())
          .max(0);
      i.directDiffuse.addAssign(
        V(ue.rgb, a.shade, 0.5)
          .mul(c)
          .mul(r)
          .mul(1 / Math.PI),
      );
      let l = n.add(o.mul(0.35)).normalize(),
        u = ke.dot(l.negate()).clamp().pow(2.5).mul(1.2),
        d = s.negate().add(a.softness).div(a.softness.add(1)).clamp().mul(0.6);
      i.directDiffuse.addAssign(
        a.glowColor.mul(u.add(d).add(0.08)).mul(a.glow).mul(0.5).mul(r),
      );
      let f = n.add(ke).normalize(),
        p = z(0.6, 1, o.dot(f).clamp()).mul(a.sheen);
      (i.directSpecular.addAssign(W(1, 0.98, 0.95).mul(p).mul(r).mul(0.12)),
        super.direct(e, t));
    }
  },
  Hr = class extends rt {
    static get type() {
      return `CreamNodeMaterial`;
    }
    setupLightingModel() {
      return new Vr(this);
    }
  };
function Ur({ uniforms: e, liquid: t, environment: n = null }) {
  let r = new Hr({
    transparent: !0,
    depthWrite: !0,
    side: 0,
    metalness: 0,
    roughness: 0.45,
    envMap: n,
  });
  ((r.name = `Cream jelly layer`), (r.creamUniforms = e));
  let i = Jt(t),
    a = t.deform.on;
  r.positionNode = V(Ee, i.position, a);
  let o = V(ge, i.normal.normalize(), a).normalize(),
    s = Oe(() => Ke(Ee.mul(W(70, 210, 70).mul(e.grainScale))))(),
    c = s.mul(e.grain).mul(0.22);
  r.normalNode = E(o.add(W(c.x, c.y.mul(0.3), c.z))).normalize();
  let l = Oe(() => ae.dot(ke).clamp())(),
    u = l.oneMinus(),
    d = s.x.mul(e.grain).mul(0.5).add(0.5).clamp(),
    f = Ee.y.sub(e.low).div(e.top.sub(e.low).max(1e-4)).clamp();
  return (
    (r.colorNode = V(
      e.shade,
      e.color,
      V(H(0.78), H(1), d)
        .mul(z(0, 0.6, l).mul(0.3).add(0.7))
        .mul(f.mul(0.25).add(0.75)),
    )),
    (r.roughnessNode = e.roughness),
    (r.specularIntensityNode = e.sheen.mul(0.5).add(0.15)),
    (r.opacityNode = H(1).sub(e.translucency.mul(u.mul(0.65).add(0.35)))),
    (r.thicknessColorNode = e.glowColor.mul(e.glow).mul(0.25)),
    (r.thicknessDistortionNode = H(0.3)),
    (r.thicknessAmbientNode = H(0.04)),
    (r.thicknessAttenuationNode = H(0.5)),
    (r.thicknessPowerNode = H(2)),
    (r.thicknessScaleNode = H(1)),
    (r.emissiveNode = V(e.color, e.glowColor, u.mul(0.7).add(0.3))
      .mul(e.glow)
      .mul(V(0.12, 0.3, u.pow(1.5)))
      .mul(f.mul(0.5).add(0.6))),
    r
  );
}
function Wr(e) {
  let t = new Ue({ colorWrite: !1, side: 0 });
  return (
    (t.name = `Cream jelly layer · depth (liquid thickness)`),
    (t.positionNode = V(Ee, Jt(e).position, e.deform.on)),
    t
  );
}
function Gr({ cupRoot: e, liquid: t, settings: n }) {
  let r = n.cream,
    i = zr(r),
    a = Ur({
      uniforms: i,
      liquid: t.uniforms,
      environment: t.material?.envMap ?? null,
    }),
    o = Wr(t.uniforms),
    s = new kt(new ht(), a);
  ((s.name = `CreamLayer`),
    s.layers.set(q.opaque),
    (s.renderOrder = 3),
    (s.castShadow = s.receiveShadow = !1),
    (s.frustumCulled = !1),
    (s.visible = !1));
  let c = new kt(s.geometry, o);
  ((c.name = `CreamLayer (liquid depth)`),
    c.layers.set(q.liquidBack),
    (c.frustumCulled = !1),
    s.add(c),
    e?.add(s));
  let l = { active: !1, entry: null, info: null, disposed: !1 };
  function u() {
    if (l.disposed) return;
    Br(i, r);
    let e = t.entry,
      n = l.active ? t.creamInterface : null;
    ((s.visible = !!n),
      n &&
        e !== l.entry &&
        ((l.entry = e),
        d(e),
        (s.geometry = c.geometry = e.cream),
        (l.info = e.creamInfo),
        (i.top.value = n.baseY),
        (i.low.value = n.lowY)));
  }
  function d(e) {
    let t = e?.creamInterface;
    if (!t || e.cream) return;
    let n = rr(t, { segments: e.params?.segments ?? 96 });
    ((e.cream = ur(n.geometry, e.shape)),
      (e.creamInfo = { ...n.info, heightMm: (t.baseY - t.lowY) * 1e3 }));
  }
  function f(e) {
    ((l.active = !!e), u());
  }
  return {
    mesh: s,
    twin: c,
    material: a,
    uniforms: i,
    settings: r,
    get visible() {
      return s.visible;
    },
    setActive: f,
    sync: u,
    prepare: d,
    info: () => ({
      enabled: !!r.enabled,
      height: r.height,
      heightMm: l.info?.heightMm ?? null,
      volumeMl: l.info?.volumeMl ?? null,
      shown: s.visible,
    }),
    describe: () =>
      `cream ${l.info ? `${l.info.heightMm.toFixed(0)} mm · ${Math.round(l.info.volumeMl)} ml` : ``}`,
    dispose() {
      ((l.disposed = !0), s.removeFromParent(), a.dispose(), o.dispose());
    },
  };
}
var Kr = [
    `enabled`,
    `frequency`,
    `damping`,
    `stiffness`,
    `volume`,
    `adhesion`,
    `rimPin`,
    `glueFalloff`,
    `wallGrip`,
    `response`,
    `maxDisplacement`,
    `cells`,
    `surfaceWobble`,
  ],
  qr = 5e-4,
  Jr = 4,
  Yr = new B(),
  Xr = new ut(),
  Zr = new B(),
  Qr = new ut(),
  $r = new B(),
  ei = new B(),
  ti = new B(),
  ni = new B(),
  ri = (e, t) =>
    e?.isVector3
      ? t.copy(e)
      : Array.isArray(e)
        ? t.fromArray(e)
        : t.set(0, 0, 0),
  ii = (e) => e * e * (3 - 2 * e);
function ai({
  cupRoot: e,
  liquid: t,
  fruits: n = null,
  extras: r = {},
  settings: i = {},
} = {}) {
  let a = i.jelly,
    o = t?.uniforms?.deform;
  if (!o)
    throw Error(
      `JellyDeform: the liquid has no deform uniforms (materials/LiquidMaterial.js)`,
    );
  if (!(r.cavityProfile?.length > 2) && !(t.cavity?.length > 2))
    throw Error(`JellyDeform: the cup has no extras.cavityProfile`);
  let s = {
      active: !1,
      body: null,
      key: ``,
      written: -1,
      previousOmega: new B(),
      omegaValid: !1,
      disposed: !1,
      ms: 0,
      frames: 0,
      profile: t.cavity ?? r.cavityProfile,
      packageId: t.packageId ?? r.package ?? null,
      sdf: null,
      creamWanted: !1,
      bodies: new Map(),
      sdfs: new Map(),
      visualSdfs: new WeakMap(),
    },
    c = o.map,
    l = c.image.data,
    u = tt.toHalfFloat,
    d = u(0),
    p = {
      acceleration: [0, 0, 0],
      gravity: [0, -9.81, 0],
      angularVelocity: [0, 0, 0],
      angularAcceleration: [0, 0, 0],
    },
    m = { u: [0, 0, 0], grad: Array(9).fill(0), w: [0, 0, 0] },
    h = Gr({ cupRoot: e, liquid: t, settings: i }),
    g = h.settings,
    _ = (e) =>
      `${Number(a.volume)}|${Number(a.wallGrip)}|${Number(a.adhesion)}|${Number(a.rimPin)}|${e.fillY}|${e.dims.join()}|${JSON.stringify(e.layer)}`,
    v = { y: 0, firmness: 1 },
    y = () =>
      !s.creamWanted || !t.creamInterface
        ? null
        : ((v.y = t.creamInterface.baseY),
          (v.firmness = Math.max(0.2, Number(g.firmness) || 1)),
          v),
    b = { packageId: null, fillY: NaN, cells: NaN, key: `` };
  function x(e) {
    let t = Math.round(a.cells);
    return (
      (b.packageId !== s.packageId || b.fillY !== e || b.cells !== t) &&
        Object.assign(b, {
          packageId: s.packageId,
          fillY: e,
          cells: t,
          key: `${s.packageId}|${e.toFixed(6)}|${t}`,
        }),
      b.key
    );
  }
  function S() {
    let e = t.info;
    if (!e || !s.profile) return null;
    let n = x(e.fillY),
      r = y();
    if (s.body && n === s.key)
      return (
        s.body.setLayer(r) &&
          ((s.calibration = s.body.calibration = _(s.body)), C(s.body)),
        s.body
      );
    s.key = n;
    let i = s.bodies.get(n);
    return (
      i
        ? ((i.settings = a),
          !i.setLayer(r) && i.calibration !== _(i) && i.calibrate(),
          (i.calibration = _(i)))
        : ((i = new un({
            cavityProfile: s.profile,
            fillY: e.fillY,
            settings: a,
            layer: r,
          })),
          (i.calibration = _(i)),
          oi(s.bodies, n, i)),
      (s.body = i),
      (s.calibration = i.calibration),
      C(i),
      i
    );
  }
  function C(e) {
    let [n, r, i] = e.dims,
      [a, c, u] = e.h,
      [d, f, p] = e.origin;
    (o.scale.value.set(1 / (a * 12), 1 / (c * 12), 1 / (u * 12)),
      o.offset.value.set(
        (-d / a + 0.5) / 12,
        (-f / c + 0.5) / 12,
        (-p / u + 0.5) / 12,
      ),
      o.lo.value.set(0.5 / 12, 0.5 / 12, 0.5 / 12),
      o.hi.value.set((n - 0.5) / 12, (r - 0.5) / 12, (i - 0.5) / 12),
      o.grad.value.set(5e-4 / a, 5e-4 / c, 5e-4 / u),
      o.texel.value.set(1 / 12, 1 / 12, 1 / 12),
      (o.band.value = c),
      T(w(s.packageId, e, s.profile, t.cavity ? t.shape : null)),
      l.fill(0),
      (s.written = -1),
      A(e, !0));
  }
  function w(e, t, n, r = null) {
    let i = `${e}|${t.fillY.toFixed(6)}|${n.length}|${r ? r.cavity.length : 0}`,
      a = s.sdfs.get(i);
    if (a) return a;
    let o = t.cavity,
      c = r
        ? (s.visualSdfs.get(r.cavity) ??
          s.visualSdfs
            .set(r.cavity, new fn(r.cavity, { grid: !1 }))
            .get(r.cavity))
        : o,
      [l, f] = Zt,
      p = Math.max(o.maxRadius, c.maxRadius) + 0.003,
      m = t.lowY - 0.003,
      h = t.fillY + 0.018,
      g = new Float32Array(l * f * 3),
      _ = new Uint16Array(l * f * 4);
    for (let e = 0; e < f; e++)
      for (let t = 0; t < l; t++) {
        let n = ((t + 0.5) / l) * p,
          r = m + ((e + 0.5) / f) * (h - m),
          i = o.exact(n, r),
          a = e * l + t;
        ((g[a * 3] = i.d * 1e3), (g[a * 3 + 1] = i.nr), (g[a * 3 + 2] = i.ny));
        let s = c === o ? i : c.exact(n, r);
        ((_[a * 4] = u(s.d * 1e3)),
          (_[a * 4 + 1] = u(s.nr)),
          (_[a * 4 + 2] = u(s.ny)),
          (_[a * 4 + 3] = d));
      }
    let v = { key: i, values: g, W: l, H: f, r1: p, ya: m, yb: h, texels: _ };
    return (oi(s.sdfs, i, v), v);
  }
  function T(e) {
    s.sdf !== e &&
      (o.sdfMap.image.data.set(e.texels),
      (o.sdfMap.needsUpdate = !0),
      o.sdfScale.value.set(1 / e.r1, 1 / (e.yb - e.ya)),
      o.sdfOffset.value.set(0, -e.ya / (e.yb - e.ya)),
      (s.sdf = e));
  }
  function E(e, t, n = [0, 0, 0]) {
    let r = s.sdf;
    if (!r) return ((n[0] = 1), (n[1] = 0), (n[2] = 1), n);
    let i = Math.min(r.W - 1, Math.max(0, (e / r.r1) * r.W - 0.5)),
      a = Math.min(
        r.H - 1,
        Math.max(0, ((t - r.ya) / (r.yb - r.ya)) * r.H - 0.5),
      ),
      o = Math.min(r.W - 2, Math.floor(i)),
      c = Math.min(r.H - 2, Math.floor(a)),
      l = i - o,
      u = a - c,
      d = r.values;
    for (let e = 0; e < 3; e++) {
      let t = d[(c * r.W + o) * 3 + e],
        i = d[(c * r.W + o + 1) * 3 + e],
        a = d[((c + 1) * r.W + o) * 3 + e],
        s = d[((c + 1) * r.W + o + 1) * 3 + e];
      n[e] = (t * (1 - l) + i * l) * (1 - u) + (a * (1 - l) + s * l) * u;
    }
    return ((n[0] *= 0.001), n);
  }
  let D = { adhesion: 1, rimPin: 1, falloff: 0.008 },
    O = [0, 0, 0];
  function k(e, n, r, i = null) {
    if (!s.body || !s.sdf || D.adhesion + D.rimPin <= 0)
      return (i && (i[0] = i[1] = i[2] = 0), 1);
    let a = Math.max(1e-6, Math.hypot(e, r)),
      c = E(a, n, O),
      l = Math.max(1e-5, D.falloff),
      u = Math.min(1, Math.max(0, (c[0] - qr) / l)),
      d = o.band.value,
      f = t.uniforms.fillY.value,
      p = ii(Math.min(1, Math.max(0, (n - (f - d)) / d))),
      m = D.adhesion + (D.rimPin - D.adhesion) * p;
    if (i) {
      let t = (m * 6 * u * (1 - u)) / l;
      ((i[0] = (e / a) * c[1] * t),
        (i[1] = c[2] * t),
        (i[2] = (r / a) * c[1] * t));
    }
    return 1 - m * (1 - ii(u));
  }
  function A(e, t = !1) {
    if (!t && s.written === e.version) return;
    let [n, r, i] = e.dims,
      a = e.U;
    for (let e = 0; e < i; e++)
      for (let t = 0; t < r; t++)
        for (let i = 0; i < n; i++) {
          let o = i + n * (t + r * e),
            s = (i + 12 * (t + 12 * e)) * 4,
            c = a[o * 3],
            f = a[o * 3 + 1],
            p = a[o * 3 + 2];
          ((l[s] = c === 0 ? d : u(c * 1e3)),
            (l[s + 1] = f === 0 ? d : u(f * 1e3)),
            (l[s + 2] = p === 0 ? d : u(p * 1e3)));
        }
    ((c.needsUpdate = !0), (s.written = e.version));
  }
  function j(t, n) {
    if (n?.cup?.acceleration) {
      let e = n.cup;
      return (
        ri(e.acceleration, $r).toArray(p.acceleration),
        ri(e.angularVelocity, ei).toArray(p.angularVelocity),
        ri(e.angularAcceleration, ti).toArray(p.angularAcceleration),
        e.gravity
          ? ri(e.gravity, ni).toArray(p.gravity)
          : ((p.gravity[0] = 0), (p.gravity[1] = -9.81), (p.gravity[2] = 0)),
        p
      );
    }
    (e.updateWorldMatrix(!0, !1), e.matrixWorld.decompose(Yr, Xr, Zr));
    let r = Math.max(
      1e-4,
      (Math.abs(Zr.x) + Math.abs(Zr.y) + Math.abs(Zr.z)) / 3,
    );
    return (
      Qr.copy(Xr).invert(),
      ri(n?.acceleration, $r)
        .applyQuaternion(Qr)
        .divideScalar(r)
        .toArray(p.acceleration),
      ri(n?.angularVelocity, ei).applyQuaternion(Qr),
      ei.toArray(p.angularVelocity),
      n?.angularAcceleration
        ? ri(n.angularAcceleration, ti).applyQuaternion(Qr)
        : s.omegaValid && t > 0
          ? ti.copy(ei).sub(s.previousOmega).divideScalar(t).clampLength(0, 200)
          : ti.set(0, 0, 0),
      s.previousOmega.copy(ei),
      (s.omegaValid = t > 0),
      ti.toArray(p.angularAcceleration),
      ni
        .set(0, -9.81, 0)
        .applyQuaternion(Qr)
        .divideScalar(r)
        .toArray(p.gravity),
      p
    );
  }
  function ee(e) {
    let n = t.info,
      r = n.wallRadius,
      i = n.fillY,
      o = 0,
      s = 0;
    for (let t = 0; t < 12; t++) {
      let n = (t / 12) * Math.PI * 2,
        c = r * Math.cos(n),
        l = r * Math.sin(n);
      e.sample(c, i, l, m);
      let u = m.u[1] * a.surfaceWobble;
      ((o += u * c), (s += u * l));
    }
    let c = 2 / (12 * r * r);
    t.uniforms.slope.value.set(o * c, s * c);
  }
  function te() {
    let e = !!(s.active && g.enabled && t.cavity);
    ((s.creamWanted = e), t.setCream(e ? g : null), h.setActive(e), h.sync());
  }
  let M = Object.keys(g),
    N = { jelly: [], cream: [] },
    P = () => {
      let e = f(a, Kr, N.jelly),
        t = f(g, M, N.cream);
      return e || t;
    };
  function F() {
    te();
    let e = S();
    if (e) {
      e.settings = a;
      let t = _(e);
      (s.calibration !== t &&
        (e.calibrate(), (s.calibration = e.calibration = t)),
        e.configure());
    }
    (P(),
      (o.surface.value = Math.max(0, Number(a.surfaceWobble) || 0)),
      (D.adhesion = o.adhesion.value =
        Math.min(1, Math.max(0, Number(a.adhesion ?? 1)))),
      (D.rimPin = o.rimPin.value =
        Math.min(1, Math.max(0, Number(a.rimPin ?? 1)))),
      (D.falloff = o.falloff.value =
        Math.min(0.03, Math.max(5e-4, Number(a.glueFalloff) || 0.008))),
      (o.clearance.value = qr),
      (o.on.value = s.active && a.enabled && e ? 1 : 0),
      n?.setJelly?.(o.on.value ? I : null));
  }
  function ne(e) {
    ((s.active = !!e),
      (s.omegaValid = !1),
      !s.active && s.body && (s.body.reset(), A(s.body, !0)),
      F());
  }
  function re(e = {}) {
    let n = e.extras?.cavityProfile ?? t.cavity;
    n?.length > 2 &&
      (s.body?.reset(),
      (s.profile = n),
      (s.packageId = e.id ?? t.packageId ?? s.packageId),
      (s.body = null),
      (s.key = ``),
      (s.sdf = null),
      (s.omegaValid = !1),
      F());
  }
  function ie(e, t) {
    let n = e?.extras?.cavityProfile;
    if (!(n?.length > 2) || !t) return;
    h.prepare(t);
    let r = t.info.fillY,
      i = `${e.id}|${r.toFixed(6)}|${Math.round(a.cells)}`,
      o = s.bodies.get(i);
    if (!o) {
      let e = t.creamInterface
        ? {
            y: t.creamInterface.baseY,
            firmness: Math.max(0.2, Number(g.firmness) || 1),
          }
        : null;
      ((o = new un({ cavityProfile: n, fillY: r, settings: a, layer: e })),
        (o.calibration = _(o)),
        oi(s.bodies, i, o));
    }
    w(e.id, o, n, lr(e.extras));
  }
  function ae(e = 0, n = 0, r = null) {
    if (
      s.disposed ||
      !s.active ||
      (P() && (!a.enabled && s.body && (s.body.reset(), A(s.body, !0)), F()),
      t.version !== s.liquidVersion && ((s.liquidVersion = t.version), te()),
      !a.enabled)
    )
      return;
    let i = performance.now(),
      c = S();
    c &&
      (o.on.value || F(),
      c.setMotion(j(e, r)),
      c.update(e)
        ? (A(c), ee(c))
        : c.asleep && t.uniforms.slope.value.set(0, 0),
      s.frames++,
      (s.ms = s.ms * 0.9 + (performance.now() - i) * 0.1));
  }
  let oe = [0, 0, 0],
    I = {
      get active() {
        return !!(s.active && a.enabled && s.body);
      },
      get moving() {
        return !(!s.body || s.body.asleep);
      },
      get version() {
        return s.body?.version ?? 0;
      },
      get coupling() {
        return Math.max(0, Number(a.fruitCoupling) || 0);
      },
      get lag() {
        return Math.max(0, Number(a.fruitLag) || 0);
      },
      get rotation() {
        return Math.max(0, Number(a.fruitRotation) || 0);
      },
      get fillY() {
        return s.body?.fillY ?? 0;
      },
      sample(e, t, n, r = m) {
        let i = s.body;
        if (!i)
          return ((r.u[0] = r.u[1] = r.u[2] = r.w[0] = r.w[1] = r.w[2] = 0), r);
        i.sample(e, t, n, r);
        let o = i.h[1],
          c = i.fillY,
          l = Math.min(1, Math.max(0, (t - (c - o)) / o));
        r.u[1] *= 1 + (a.surfaceWobble - 1) * ii(l);
        let u = k(e, t, n, oe),
          d = r.u,
          f = r.w;
        return (
          (f[0] = u * f[0] + 0.5 * (oe[1] * d[2] - oe[2] * d[1])),
          (f[1] = u * f[1] + 0.5 * (oe[2] * d[0] - oe[0] * d[2])),
          (f[2] = u * f[2] + 0.5 * (oe[0] * d[1] - oe[1] * d[0])),
          (d[0] *= u),
          (d[1] *= u),
          (d[2] *= u),
          r
        );
      },
    };
  function se(e = 1, t = null) {
    if (!s.active || !s.body) return;
    let n = t ?? [Math.cos(s.frames * 2.4), 0, Math.sin(s.frames * 2.4)];
    s.body.kick(n[0] * 0.05 * e, (n[1] ?? 0) * 0.05 * e, n[2] * 0.05 * e);
  }
  function L() {
    let e = s.body;
    if (!e) return `soft jelly (waiting for the liquid)`;
    let t = e.describe(),
      n = h.visible ? ` · ${h.describe()}` : ``;
    return `soft jelly ${t.dims} (${t.active} nodes) · ${t.asleep ? `resting` : `${t.substeps} steps · ${(Math.max(...t.probe.map(Math.abs)) * 1e3).toFixed(1)} mm`}${n}`;
  }
  function ce() {
    ((s.disposed = !0),
      (o.on.value = 0),
      n?.setJelly?.(null),
      t.setCream?.(null),
      h.dispose());
  }
  return {
    settings: a,
    field: I,
    cream: h,
    get body() {
      return s.body;
    },
    get stats() {
      return { ...(s.body?.stats ?? {}), ms: s.ms };
    },
    setActive: ne,
    update: ae,
    configure: F,
    setPackage: re,
    prepare: ie,
    kick: se,
    nudge: (e) => se(e),
    describe: L,
    dispose: ce,
  };
}
function oi(e, t, n) {
  for (e.delete(t), e.set(t, n); e.size > Jr;) e.delete(e.keys().next().value);
}
var si = class {
  constructor({ cup: e, assets: t, settings: n, environment: r }) {
    ((this.cup = e),
      (this.root = e.root),
      (this.liquid = e.liquid),
      (this.assets = t),
      (this.settings = n),
      (this.environment = r),
      (this.fruits = null),
      (this.jelly = null),
      (this.state = { fruits: null, jelly: null, levels: [] }),
      (this.references = new Map()),
      (this.prepared = new Map()));
  }
  init({ reducedMotion: e = !1 } = {}) {
    this.reducedMotion = e;
    let t = { main: q.opaque, depth: q.liquidBack };
    try {
      this.fruits = Rr({
        cupRoot: this.root,
        model: this.assets.fruitModel,
        normalMap: this.assets.textures.fruit,
        settings: this.settings,
        environment: this.environment.environment,
        layers: t,
      });
    } catch (e) {
      this.fail(`fruits`, e);
    }
    try {
      this.jelly = ai({
        cupRoot: this.root,
        liquid: this.liquid,
        fruits: this.fruits,
        extras: this.cup.extras,
        settings: this.settings,
      });
    } catch (e) {
      this.fail(`jelly`, e);
    }
    return (
      this.fruits?.setActive(!1),
      this.jelly?.setActive(!1),
      this.packageId && this.fruits?.setPackage(this.cup.descriptor()),
      this
    );
  }
  fail(e, t) {
    console.warn(`Contents: the ${e} failed.`, t);
    try {
      this[e]?.dispose?.();
    } catch (t) {
      console.warn(`Contents: disposing the ${e} failed too.`, t);
    }
    ((this[e] = null), (this.state[e] = null));
  }
  apply() {
    let e = !!(this.settings.contents.fruits && this.fruits);
    this.state.fruits !== e &&
      (this.fruits?.setActive(e), (this.state.fruits = e));
    let t = !!(this.jelly && this.liquid.active);
    this.state.jelly !== t &&
      (this.jelly?.setActive(t), (this.state.jelly = t));
  }
  setPackage(e) {
    if (!e?.extras) return;
    let t = (t, n) => {
      try {
        n();
      } catch (n) {
        console.warn(`Contents: the ${t} could not take package ${e.id}.`, n);
      }
    };
    ((this.packageId = e.id),
      t(`liquid`, () => this.liquid.setPackage(e)),
      t(`jelly`, () => this.jelly?.setPackage(e)),
      t(`fruits`, () => this.fruits?.setPackage(e)),
      this.syncLevels(!0));
  }
  *prepare(e, t) {
    if (!e?.extras || e.id === this.packageId) return;
    let n = t.cream.enabled && t.liquid.visible ? t.cream : null,
      r = this.liquid.prepare(e, t.liquid, n);
    (yield,
      this.jelly?.prepare(e, r),
      yield,
      this.fruits?.prepare(e),
      this.prepared.set(e.id, r));
  }
  warm(e) {
    let t = this.prepared.get(e),
      n = this.fruits?.layouts.get(e),
      r = this.fruits?.layout;
    if (!t?.geometry || e === this.packageId) return () => {};
    let { mesh: i, back: a } = this.liquid,
      o = this.jelly?.cream.mesh,
      s = this.jelly?.cream.twin,
      c = {
        geometry: i.geometry,
        cream: o?.geometry,
        creamVisible: o?.visible,
      };
    return (
      (i.geometry = a.geometry = t.geometry),
      o && t.cream && ((o.geometry = s.geometry = t.cream), (o.visible = !0)),
      n && r && ((r.group.visible = !1), (n.group.visible = !0)),
      () => {
        ((i.geometry = a.geometry = c.geometry),
          o &&
            ((o.geometry = s.geometry = c.cream), (o.visible = c.creamVisible)),
          n && r && ((n.group.visible = !1), (r.group.visible = !0)));
      }
    );
  }
  configure(e) {
    (this.fruits?.configure({ envScale: e }), this.apply());
  }
  applyLiquid(e = null, t = this.settings.scene.environment) {
    let n = this.liquid;
    (n.configure(t, e),
      this.fruits?.setLiquidVisible(n.active),
      this.syncLevels(),
      this.apply());
  }
  syncLevels(e = !1) {
    let t = this.liquid,
      n = t.info,
      r = this.settings.cream;
    if (!this.fruits || !n) return;
    let i = this.state.levels;
    if (
      !e &&
      i[0] === t.version &&
      i[1] === t.packageId &&
      i[2] === r.fruitSink
    )
      return;
    ((i[0] = t.version), (i[1] = t.packageId), (i[2] = r.fruitSink));
    let a = t.creamInterface,
      o = {
        fillY: n.fillY,
        floorY: a ? a.baseY - Math.max(0, r.fruitSink) : n.floorY,
      },
      s = this.references.get(t.packageId),
      c = kr[t.packageId];
    if (!s && c) {
      let e = c.reference,
        n = t.levelsFor(e.liquid, e.cream);
      ((s = {
        fillY: n.fillY,
        floorY:
          n.creamY === null
            ? n.floorY
            : n.creamY - Math.max(0, e.cream.fruitSink),
      }),
        this.references.set(t.packageId, s));
    }
    this.fruits.setLevels(o, s ?? null);
  }
  get liquidActive() {
    return this.liquid.active;
  }
  update(e, t, { cupState: n = null } = {}) {
    (this.liquid.active && this.liquid.uniforms.slope.value.set(0, 0),
      this.state.jelly && this.jelly.update(e, this.reducedMotion ? 0 : t, n),
      this.syncLevels(),
      this.state.fruits && this.fruits.update(e));
  }
  nudge(e = 1.5) {
    this.state.jelly && this.jelly.nudge(e);
  }
  get moving() {
    return !!(
      (this.state.jelly && this.jelly.body && !this.jelly.body.asleep) ||
      this.fruits?.carrying
    );
  }
  describe() {
    let e = [];
    this.state.fruits && e.push(`${this.fruits.pieces.length} fruits`);
    let t = this.liquid.info?.volumeMl;
    return (
      this.liquid.active && e.push(`jelly${t ? ` ${Math.round(t)} ml` : ``}`),
      this.state.jelly && e.push(this.jelly.describe()),
      e.push(this.cup.packageId ?? ``),
      e.filter(Boolean).join(`, `) || `empty`
    );
  }
  dispose() {
    (this.jelly?.dispose(), this.fruits?.dispose());
  }
};
function ci(e, t, n) {
  let r = (e) => I(new G(e)),
    i = {
      inverse: I(new Lt()),
      apple: I(new Pt(0,.103,.86,.004)),
      bowInverse: I(new Lt()),
      bowSize: I(new B(.024,.022,.011)),
      bowOffset: I(new w(.022,.008)),
      bowOpacity: I(0),
      shape: I(new Pt(0.03, 0.046, 0.085, 0.091)),
      cap: I(new B(0.047, 1, 1)),
      span: I(new w(5, 5.1)),
      bound: I(new Pt()),
      boundRadius: I(0),
      active: I(0),
    };
  return {
    edgeFade: I(e.edgeFade),
    fogStart: I(e.fogStart),
    fogEnd: I(e.fogEnd),
    bounds: I(new Pt(0, 0, 0.8, 0.5)),
    centre: I(new w(0, 0)),
    caster: i,
    lightPosition: I(new B(-0.6, 1, -0.7)),
    shadowColor: r(t.color),
    shadowOpacity: I(t.opacity),
    shadowSoftness: I(t.softness),
    caustic: I(t.caustic),
    causticColor: r(t.causticColor),
    painterly: I(+!!n.painterly),
    edgeSoftness: I(n.edgeSoftness),
    strokeInfluence: I(n.strokeInfluence),
    strokeShift: I(n.strokeShift / 1e3),
    breakup: I(n.breakup),
    breakupScale: I(n.breakupScale),
    streak: I(n.streak),
    colorVariation: I(n.colorVariation),
    color1: r(n.color),
    glaze: r(n.glaze),
    glazeAmount: I(n.glazeAmount),
    color2: r(n.color2),
    density: I(n.density),
    contact: I(n.contact),
    contactWidth: I(n.contactWidth / 1e3),
    contactColor: r(n.contactColor),
  };
}
var li = 10;
function ui({ uniforms: e, backdrop: t, surface: n }) {
  let r = n(e),
    i = r.top,
    a = e.painterly,
    o = Ut(`vec4`, `tablePaintFields`),
    s = Ut(`float`, `tableStrokeB`),
    c = Ut(`vec3`, `tableShadowPoint`),
    l = Ut(`vec4`, `tablePaintedShadow`),
    u = Ut(`float`, `tableContact`),
    d = () => {
      let t = r.strokeValue.sub(0.5).mul(2),
        n = r.streak,
        d = r.tilt
          .mul(5)
          .mul(R(1, 0.55))
          .clamp(-1, 1)
          .mul(e.strokeInfluence)
          .add(R(n.mul(e.breakup), 0))
          .mul(e.strokeShift)
          .mul(a)
          .mul(i);
      c.assign(F.add(W(d.x, 0, d.y)));
      let f = t
        .mul(e.strokeInfluence)
        .mul(0.3)
        .add(n.mul(e.breakup).mul(0.45))
        .mul(a)
        .mul(i);
      (o.assign(L(t, n, f, i)),
        s.assign(r.tilt.y.mul(6).add(r.tilt.x.mul(2.5)).clamp(-1, 1)),
        l.assign(L(0)),
        u.assign(0));
    },
    f = new Le({ roughness: 0.6, metalness: 0 });
  ((f.name = `Table`),
    (f.colorNode = Oe(() => (d(), r.albedo))()),
    (f.roughnessNode = r.roughness),
    (f.normalNode = r.normal));
  let p = e.edgeSoftness.clamp(0.02, 1),
    m = (e) => {
      let t = o.z.negate().add(0.5).clamp(0.08, 0.92);
      return z(t.sub(p.mul(0.5)), t.add(p.mul(0.5)), e)
        .mul(e.greaterThan(0.001).select(1, 0))
        .max(e.greaterThan(0.999).select(1, 0));
    },
    h = Oe(() => {
      let t = c,
        n = e.lightPosition.sub(t).normalize(),
        r = H(0).toVar(),
        i = H(0).toVar(),
        s = H(0).toVar(),
        l = H(0).toVar(),
        u = e.caster;
      {
        let c = R(u.bound.x, u.bound.y),
          d = R(u.bound.z, u.bound.w).sub(c),
          f = R(t.x, t.z).sub(c),
          p = f
            .sub(d.mul(f.dot(d).div(d.dot(d).max(1e-8)).clamp(0, 1)))
            .length();
        ie(u.active.greaterThan(0.5).and(p.lessThan(u.boundRadius)), () => {
          let c = u.shape,
            d = H(1e3).toVar(),
            bowDistance = H(1e3).toVar(),
            f = H(2).toVar();
          for (let r = 0; r < li; r++) {
            let i = V(u.span.x, u.span.y, (r + 0.5) / li)
                .sub(t.y)
                .div(M(n.y, 0.05)),
              a = t.add(n.mul(i)),
              o = u.inverse.mul(L(a, 1)).xyz.toVar(),
              s = o.y.div(c.z).clamp(0, 1),
              appleY = o.y.sub(u.apple.w).div(u.apple.y).mul(2).sub(1).clamp(-1,1),
              appleRadius = H(1).sub(appleY.mul(appleY)).max(0).sqrt().mul(appleY.mul(.14).add(.91)).mul(u.apple.x),
              l = gt(u.apple.x.greaterThan(0),appleRadius,gt(o.y.greaterThan(c.z), u.cap.x, V(c.x, c.y, s))),
              radial = R(o.x,o.z.div(gt(u.apple.x.greaterThan(0),u.apple.z,H(1)))).length(),
              p = o.y.greaterThanEqual(0).and(o.y.lessThanEqual(c.w)),
              m = gt(p, radial.sub(l), H(1)),
              h = e.shadowSoftness.mul(i.mul(0.35).add(0.004));
            const bowPoint=u.bowInverse.mul(L(a,1)).xyz,
              bowLocal=W(at(bowPoint.x).sub(u.bowOffset.x),bowPoint.y.sub(u.bowOffset.y),bowPoint.z),
              bowSdf=bowLocal.div(u.bowSize).length().sub(1).mul(u.bowSize.z);
            bowDistance.assign(ee(bowDistance,bowSdf.div(h)));
            (d.assign(ee(d, m.div(h))),
              r === Math.floor(li * 0.35) &&
                f.assign(gt(p, R(o.x, o.z).length().div(l.max(1e-4)), H(2))));
          }
          let p = u.inverse.mul(L(t, 1)).xyz.toVar(),
            h = R(p.x, p.z),
            g = z(c.x.mul(1.05), c.x.mul(0.8), h.length()).oneMinus(),
            _ = z(1, -1, d).max(z(1,-1,bowDistance).mul(u.bowOpacity));
          r.assign(M(r, _.mul(g).mul(u.cap.y)));
          let v = m(_).mul(g);
          (i.assign(M(i, v.mul(u.cap.y))),
            s.addAssign(
              z(0.75, 0, f)
                .mul(V(_, v, a))
                .mul(g)
                .mul(u.cap.z),
            ));
          let y = R(n.x, n.z).normalize().mul(e.contactWidth.mul(0.45)),
            b = h.add(y).length().sub(c.x),
            x = z(e.contactWidth, 0, b.add(o.z.mul(e.contactWidth).mul(0.6))),
            S = z(0.012, 0.002, at(p.y));
          l.assign(M(l, x.mul(V(H(0.55), H(1), z(-0.004, 0, b))).mul(S)));
        });
      }
      return L(r, i, s, l);
    });
  ((f.receivedShadowPositionNode = c),
    (f.receivedShadowNode = Oe(() => {
      let t = h().toVar(),
        n = V(W(1), e.shadowColor, t.x.mul(e.shadowOpacity)),
        r = t.y.mul(e.shadowOpacity),
        i = o.x.mul(0.5).add(0.5).mul(e.colorVariation),
        c = o.x.mul(e.density).mul(0.5).add(1),
        d = r.mul(c).clamp(0, 1).mul(a),
        f = V(H(1), s.mul(0.8).add(0.55).clamp(0, 1.4), e.colorVariation);
      (l.assign(L(V(e.glaze, e.color2, i).mul(f), d).max(0)), u.assign(t.w));
      let p = V(W(1), e.color1, d);
      return V(n, p, a).add(e.causticColor.mul(t.z).mul(e.caustic));
    })));
  let g = M(
      at(F.x.sub(e.bounds.x)).div(e.bounds.z),
      at(F.z.sub(e.bounds.y)).div(e.bounds.w),
    ),
    _ = z(H(1).sub(e.edgeFade.max(0.001)), 1, g).mul(
      e.edgeFade.greaterThan(5e-4).select(1, 0),
    ),
    v = z(
      e.fogStart,
      e.fogEnd.max(e.fogStart.add(0.01)),
      Ft(F.xz.sub(e.centre)),
    ),
    y = M(_, v),
    b = t(dt(F.sub(je))),
    x = u.mul(e.contact).mul(a).mul(o.w).clamp(0, 1),
    S = xe.rgb
      .add(l.rgb.mul(l.a).mul(e.glazeAmount))
      .mul(V(W(1), e.contactColor, x));
  return ((f.outputNode = Oe(() => L(V(S, b, y), xe.a))()), f);
}
function di(e, t, n, r) {
  ((e.edgeFade.value = t.edgeFade),
    (e.fogStart.value = t.fogStart),
    (e.fogEnd.value = t.fogEnd),
    e.shadowColor.value.set(n.color),
    (e.shadowOpacity.value = n.opacity),
    (e.shadowSoftness.value = n.softness),
    (e.caustic.value = n.caustic),
    e.causticColor.value.set(n.causticColor),
    fi(e, r));
}
function fi(e, t) {
  ((e.painterly.value = +!!t.painterly),
    (e.edgeSoftness.value = t.edgeSoftness),
    (e.strokeInfluence.value = t.strokeInfluence),
    (e.strokeShift.value = t.strokeShift / 1e3),
    (e.breakup.value = t.breakup),
    (e.breakupScale.value = Math.max(0.05, t.breakupScale)),
    (e.streak.value = t.streak),
    (e.colorVariation.value = t.colorVariation),
    pi(e.color1, t.color),
    pi(e.glaze, t.glaze),
    (e.glazeAmount.value = t.glazeAmount),
    pi(e.color2, t.color2),
    (e.density.value = t.density),
    (e.contact.value = t.contact),
    (e.contactWidth.value = Math.max(0.5, t.contactWidth) / 1e3),
    pi(e.contactColor, t.contactColor));
}
function pi(e, t) {
  e.userData?.hex !== t && (e.value.set(t), (e.userData = { hex: t }));
}
function mi() {
  let e = () => I(new G());
  return {
    base: e(),
    dark: e(),
    light: e(),
    streakColor: e(),
    poolColor: e(),
    variation: I(0),
    variationScale: I(1),
    warmth: I(0),
    streaks: I(0),
    streakLength: I(1),
    streakWidth: I(0.02),
    streakCoverage: I(0),
    rotation: I(new w(1, 0)),
    grain: I(0),
    pool: I(0),
    poolRadius: I(0.3),
    poolCentre: I(new w()),
    relief: I(0),
    roughness: I(1),
    seed: I(0),
    centre: I(new w()),
  };
}
function hi(e, t, n) {
  for (let n of [`base`, `dark`, `light`, `streakColor`, `poolColor`])
    e[n].value.set(t[n]);
  for (let n of [
    `variation`,
    `variationScale`,
    `warmth`,
    `streaks`,
    `streakLength`,
    `streakWidth`,
    `streakCoverage`,
    `grain`,
    `pool`,
    `poolRadius`,
    `relief`,
    `roughness`,
    `seed`,
  ])
    e[n].value = Number(t[n]) || 0;
  ((e.variationScale.value = Math.max(0.02, e.variationScale.value)),
    (e.streakLength.value = Math.max(0.02, e.streakLength.value)),
    (e.streakWidth.value = Math.max(0.002, e.streakWidth.value)),
    (e.poolRadius.value = Math.max(0.02, e.poolRadius.value)));
  let r = U.degToRad(t.angle);
  (e.rotation.value.set(Math.cos(r), Math.sin(r)),
    e.centre.value.set(n.x, n.z),
    e.poolCentre.value.set(t.poolX, t.poolZ));
}
var gi = 1e-6;
function _i(e) {
  return (
    (Number(e.streakCoverage) || 0) <= gi &&
    Math.abs(Number(e.grain) || 0) <= gi
  );
}
function vi(e, { lean: t = !1 } = {}) {
  return (n) => {
    let r = Vt.normalize().toVar(),
      i = z(0.9, 0.995, r.y),
      a = F.xz.sub(e.centre),
      o = e.rotation.x,
      s = e.rotation.y,
      c = R(a.x.mul(o).add(a.y.mul(s)), a.y.mul(o).sub(a.x.mul(s))).toVar(),
      l = e.seed.mul(7.31),
      u = R(Tt(c.mul(2.2).add(R(l, 1.7))), Tt(c.mul(2.2).add(R(4.1, l)))).mul(
        0.035,
      ),
      d = c.add(u).toVar(),
      f = Tt(d.div(e.variationScale).add(R(l.mul(0.37), 0.5)))
        .add(
          Tt(d.div(e.variationScale.mul(0.45)).add(R(2.3, l.mul(0.21)))).mul(
            0.35,
          ),
        )
        .toVar(),
      p = Tt(d.div(e.variationScale.mul(1.8)).add(R(11.7, l.mul(0.13)))),
      m = R(d.x.div(e.streakLength), d.y.div(e.streakWidth)),
      h = Tt(m.add(R(l.mul(0.9), 3.3))).toVar(),
      g = t
        ? null
        : z(0.55, -0.35, Tt(d.mul(1.6).add(R(7.7, l.mul(0.5)))))
            .mul(e.streakCoverage.mul(1.6))
            .clamp(0, 1),
      _ = t ? null : z(0.28, 0.62, h).mul(g),
      v = t ? null : z(0.3, 0.66, h.negate()).mul(g).mul(0.6),
      y = t ? null : Tt(R(d.x.div(0.09), d.y.div(0.0016)).add(R(l, 9.1))),
      b = F.xz.sub(e.centre.add(e.poolCentre)).div(e.poolRadius),
      x = Ge(Bt(b, b).mul(-1.1)).mul(e.pool),
      C = Oe(() => {
        let n = W(e.base).toVar();
        (n.assign(V(n, e.dark, f.negate().max(0).mul(e.variation).clamp(0, 1))),
          n.assign(
            V(n, e.light, f.max(0).mul(e.variation).mul(0.85).clamp(0, 1)),
          ));
        let r = p.mul(e.warmth);
        return (
          n.assign(
            n.mul(
              W(
                H(1).add(r.mul(0.22)),
                H(1).add(r.mul(0.02)),
                H(1).sub(r.mul(0.2)),
              ),
            ),
          ),
          t ||
            (n.assign(V(n, e.streakColor, _.mul(e.streaks))),
            n.assign(n.mul(H(1).sub(v.mul(e.streaks).mul(0.35)))),
            n.assign(n.mul(y.mul(e.grain).mul(0.5).add(1)))),
          n.assign(V(n, e.poolColor, x.clamp(0, 1))),
          n.max(0)
        );
      })(),
      w = (t) =>
        z(
          0.2,
          0.7,
          Tt(
            R(t.x.div(e.streakLength), t.y.div(e.streakWidth)).add(
              R(l.mul(0.9), 3.3),
            ),
          ),
        ),
      T = 0.004,
      E = t ? null : w(d),
      D = t
        ? R(0, 0)
        : R(w(d.add(R(T, 0))).sub(E), w(d.add(R(0, T))).sub(E))
            .mul(g)
            .mul(e.relief)
            .mul(1.2),
      O = D.x.mul(o).sub(D.y.mul(s)),
      k = D.x.mul(s).add(D.y.mul(o)),
      A = dt(V(r, dt(W(O.negate(), 1, k.negate())), i)),
      j = R(O, k),
      ee = S.mul(L(A, 0)).xyz.normalize(),
      te = f.mul(0.35).add(h.mul(0.45)).add(0.5).clamp(0, 1),
      M = n.streak.max(0.5),
      N = Tt(
        R(
          c.x.mul(n.breakupScale).mul(9).div(M),
          c.y.mul(n.breakupScale).mul(160),
        ).add(R(1.3, l)),
      )
        .mul(1.6)
        .clamp(-1.2, 1.2);
    return {
      albedo: C,
      roughness: t
        ? e.roughness.clamp(0.05, 1)
        : e.roughness.sub(_.mul(0.06)).clamp(0.05, 1),
      normal: ee,
      strokeValue: te,
      streak: N,
      tilt: j.mul(3),
      top: i,
    };
  };
}
var yi = new B(),
  bi = new B(),
  xi = new B(),
  Si = class {
    constructor({ assets: e, settings: t, backdrop: n }) {
      ((this.settings = t),
        (this.backdrop = n),
        (this.mesh = e.table),
        (this.mesh.name = `Table`),
        this.mesh.layers.set(q.opaque),
        (this.mesh.receiveShadow = !0),
        (this.mesh.castShadow = !1),
        (this.uniforms = ci(t.table, t.cupShadow, t.shadowPaint)),
        (this.conceptUniforms = mi()),
        (this.caster = null),
        this.mesh.updateWorldMatrix(!0, !1));
      let r = new Re().setFromObject(this.mesh),
        i = r.getCenter(new B()),
        a = r.getSize(new B());
      (this.uniforms.bounds.value.set(
        i.x,
        i.z,
        Math.max(0.05, a.x / 2),
        Math.max(0.05, a.z / 2),
      ),
        (this.material = null),
        this.configureStyle());
    }
    buildMaterial(e) {
      (this.material?.dispose(),
        (this.lean = e),
        (this.material = ui({
          uniforms: this.uniforms,
          backdrop: (e) => this.backdrop.colorAt(e),
          surface: vi(this.conceptUniforms, { lean: e }),
        })),
        (this.material.name = `Table concept`),
        (this.mesh.material = this.material));
    }
    configureStyle() {
      let { table: e, cup: t } = this.settings,
        n = _i(e.concept);
      (n !== this.lean && this.buildMaterial(n),
        hi(this.conceptUniforms, e.concept, t),
        (this.uniforms.edgeFade.value = e.edgeFade));
    }
    setCaster({ root: e = null, extras: t = {}, lid: n = null } = {}) {
      this.caster = { root: e, lid: n, shape: Ei(t) };
    }
    update(e, t) {
      let n = this.uniforms,
        r = this.caster;
      r && e && ((r.root = e.root), (r.lid = e.lid?.mesh ?? e.lid ?? null));
      let i = n.caster,
        a = r?.root;
      if (!a || !Ti(a)) i.active.value = 0;
      else {
        (a.updateWorldMatrix(!0, !1),
          (i.active.value = 1),
          i.inverse.value.copy(a.matrixWorld).invert());
        let e = r.shape,
          n = !r.lid || Ti(r.lid),
          o = n ? e.top : e.bodyTop;
        (i.shape.value.set(e.base, e.rim, e.rimHeight, o),
          i.cap.value.set(n ? e.capRadius : e.rim + 0.0015, 1, 1));
        let s = 1 / 0,
          c = -1 / 0,
          l = Math.max(e.rim, e.capRadius);
        for (let [e, t, n] of Ci)
          (yi.set(e * l, t * o, n * l).applyMatrix4(a.matrixWorld),
            (s = Math.min(s, yi.y)),
            (c = Math.max(c, yi.y)));
        i.span.value.set(Math.max(0, s), Math.max(s, c) + 0.002);
        let u = t.position;
        bi.setFromMatrixPosition(a.matrixWorld);
        let d = wi;
        for (let e = 0; e < Ci.length; e++) {
          let [t, n, r] = Ci[e],
            i = xi.set(t * l, n * o, r * l).applyMatrix4(a.matrixWorld),
            s = u.y > i.y + 0.001 ? Math.min(u.y / (u.y - i.y), 50) : 50;
          (i.sub(u).multiplyScalar(s).add(u),
            (d[2 * e] = i.x),
            (d[2 * e + 1] = i.z));
        }
        let f = 0,
          p = -1;
        for (let e = 0; e < Ci.length; e++) {
          let t = Math.hypot(d[2 * e] - bi.x, d[2 * e + 1] - bi.z);
          t > p && ((p = t), (f = e));
        }
        let m = d[2 * f],
          h = d[2 * f + 1],
          g = m - bi.x,
          _ = h - bi.z,
          v = Math.max(g * g + _ * _, 1e-8),
          y = l * a.matrixWorld.getMaxScaleOnAxis();
        for (let e = 0; e < Ci.length; e++) {
          let t = d[2 * e],
            n = d[2 * e + 1],
            r = U.clamp(((t - bi.x) * g + (n - bi.z) * _) / v, 0, 1);
          y = Math.max(y, Math.hypot(t - bi.x - g * r, n - bi.z - _ * r));
        }
        let b = this.settings.shadowPaint;
        (i.bound.value.set(bi.x, bi.z, m, h),
          (i.boundRadius.value =
            y +
            this.settings.cupShadow.softness * (p * 0.35 + 0.004) * 1.25 +
            (b.strokeShift * Math.max(1, b.strokeInfluence + b.breakup)) / 1e3 +
            b.contactWidth / 1e3 +
            0.01));
      }
      (n.lightPosition.value.copy(t.position),
        fi(n, this.settings.shadowPaint));
    }
    configure() {
      let { table: e, cupShadow: t, cup: n, shadowPaint: r } = this.settings;
      (di(this.uniforms, e, t, r),
        this.uniforms.centre.value.set(n.x, n.z),
        this.configureStyle());
    }
    describe() {
      return `table: concept (procedural)`;
    }
    dispose() {
      this.material.dispose();
    }
  },
  Ci = [
    [-1, 0, -1],
    [1, 0, -1],
    [-1, 0, 1],
    [1, 0, 1],
    [-1, 1, -1],
    [1, 1, -1],
    [-1, 1, 1],
    [1, 1, 1],
  ],
  wi = new Float64Array(Ci.length * 2),
  Ti = (e) => {
    for (let t = e; t; t = t.parent) if (!t.visible) return !1;
    return !0;
  };
function Ei(e = {}) {
  let t = Array.isArray(e.outerProfile)
      ? e.outerProfile.filter((e) => Array.isArray(e) && e.length >= 2)
      : [],
    n = Number(e.baseRadius) || 0,
    r = Number(e.rimRadius) || 0,
    i = Number(e.height) || 0;
  if (t.length) {
    let e = t.reduce((e, t) => (t[0] > e[0] + 1e-6 ? t : e));
    ((r ||= e[0]),
      (i ||= e[1]),
      (n ||=
        Math.max(...t.filter((e) => e[1] <= 0.0025).map((e) => e[0]), 0) ||
        e[0] * 0.65));
  }
  ((r ||= 0.046), (n ||= r * 0.65), (i ||= 0.085));
  let a = e.lid ?? {},
    o = Number(e.lidTopY ?? e.topY ?? a.topY ?? a.y) || 0,
    s = Number(e.lidRadius ?? a.outerRadius) || r + 0.0015,
    c = Math.max(i, o || i + 0.006);
  return { base: n, rim: r, rimHeight: i, bodyTop: i, top: c, capRadius: s };
}
var Di = 1,
  Oi = {
    x: 0.18,
    zNear: 0.1,
    zFar: -0.26,
    height: 0.16,
    clearance: 1.3,
    stars: 0.4,
  };
function ki(e) {
  let t = e >>> 0;
  return () => {
    t = (t + 1831565813) >>> 0;
    let e = t;
    return (
      (e = Math.imul(e ^ (e >>> 15), e | 1)),
      (e ^= e + Math.imul(e ^ (e >>> 7), e | 61)),
      ((e ^ (e >>> 14)) >>> 0) / 4294967296
    );
  };
}
var Ai = [`size`, `seed`],
  ji = class {
    constructor(e, { seed: t = 5, cup: n = null } = {}) {
      ((this.settings = e),
        (this.clearance = {
          radius:
            Oi.clearance * Math.max(n?.rimRadius ?? 0.046, n?.lidRadius ?? 0),
          height: 1.5 * (n?.lidTopY ?? 0.091),
        }),
        (this.uniforms = {
          time: I(0),
          brightness: I(e.brightness),
          twinkle: I(e.twinkle),
          color: I(new G(e.color)),
          occluderA: He(
            Array.from({ length: Di }, () => new Pt()),
            `vec4`,
          ),
          occluderB: He(
            Array.from({ length: Di }, () => new Pt()),
            `vec4`,
          ),
          nearFade: I(0.12),
          bulk: I(e.bulk),
          irregularity: I(e.irregularity),
          relief: I(e.relief),
          highlight: I(e.highlight),
          edge: I(e.edge),
          streaks: I(e.streaks),
          shade: I(new G(e.shade)),
          light: I(new w(-0.7071, 0.7071)),
        }),
        this.build(e.count, t));
    }
    build(e, t = this.seed ?? 5) {
      let n = this.sprite?.parent ?? null;
      (this.dispose(), (this.seed = t));
      let r = this.settings;
      this.structure = Ai.map((e) => r[e]).join(`|`);
      let i = Math.max(1, e);
      this.requested = e;
      let a = ki(t),
        o = ki(((r.seed ?? 5) * 7919 + 17) >>> 0),
        s = Math.max(0.1, r.size ?? 1),
        c = new Float32Array(i * 4),
        l = new Float32Array(i * 4),
        u = new Float32Array(i * 3),
        d = 0,
        f = 0;
      for (; d < i && f++ < i * 40;) {
        let e = a(),
          t = e < Oi.stars,
          n = !t && e < Oi.stars + 0.12,
          r = (a() * 2 - 1) * Oi.x,
          i = Oi.zFar + a() * (Oi.zNear - Oi.zFar),
          f = 0.004 + a() ** 1.6 * Oi.height;
        if (
          Math.hypot(r, i) < this.clearance.radius &&
          f < this.clearance.height
        )
          continue;
        let p = t
          ? 0.0036 + a() * 0.0034
          : n
            ? 0.0016 + a() * 0.0012
            : 7e-4 + a() * 9e-4;
        o();
        let m = o(),
          h = o(),
          g = o() * 2 - 1;
        ((p *= (t ? 1.45 : n ? 1.7 : 2.1) * s * (0.85 + 0.3 * m)),
          u.set([g, m, h], d * 3),
          c.set([r, f, i, p], d * 4),
          l.set(
            [t ? 1 : n ? 2 : 0, a() * Math.PI * 2, 0.5 + a() * 1.4, a()],
            d * 4,
          ),
          d++);
      }
      let p = this.uniforms,
        m = Xe(new qe(c, 4)),
        h = Xe(new qe(l, 4)),
        g = new mt({ transparent: !0, depthWrite: !1 });
      ((g.name = `Sparkles`), (g.positionNode = m.xyz));
      let _ = h.x.equal(1),
        v = fe(p.time.mul(h.z).add(h.y)).mul(0.5).add(0.5),
        y = V(H(1), T(v, 2).mul(0.7).add(0.3), p.twinkle),
        b = Je().sub(0.5).mul(2),
        x = A(b.x).mul(1.2),
        S = V(p.color, p.color.mul(W(1, 0.95, 0.8)), h.w),
        C = Xe(new qe(u, 3));
      g.scaleNode = m.w.mul(gt(_, y.mul(0.12).add(0.88), H(1)));
      let w = this.bulkyMark(b, h, C, x);
      ((g.colorNode = L(
        this.bulkyColor(w, b, h, C, S)
          .mul(p.brightness)
          .mul(V(H(0.92), H(1.06), y)),
        1,
      )),
        (g.opacityNode = w.w.mul(this.occlusion(m.xyz, m.w))),
        (this.sprite = new $e(g)),
        (this.sprite.name = `Sparkles`),
        (this.sprite.count = d),
        (this.sprite.frustumCulled = !1),
        this.sprite.layers.set(q.sparkles),
        (this.sprite.renderOrder = 3),
        (this.material = g),
        (this.count = d),
        (this.sprite.visible = this.settings.enabled !== !1 && e > 0),
        n?.add(this.sprite));
    }
    bulkyMark(e, t, n, r) {
      let i = this.uniforms,
        a = i.irregularity,
        o = n.x,
        s = n.y,
        c = n.z,
        l = t.x.equal(1),
        u = t.x.equal(2),
        d = i.bulk.clamp(0, 1),
        f = V(H(0.17), H(0.36), d),
        p = V(H(0.07), H(0.15), d),
        m = V(H(0.12), H(0.28), d),
        h = s.mul(6.283),
        g = c.mul(6.283),
        _ = (e, t, n) => {
          let r = M(n.sub(e.sub(t).abs()), 0).div(n);
          return ee(e, t).sub(r.mul(r).mul(n).mul(0.25));
        },
        v = (e, t, n, r, i) => {
          let a = e.abs(),
            o = n.sub(r).div(i),
            s = H(1).sub(o.mul(o)).max(0).sqrt(),
            c = a.mul(o.negate()).add(t.mul(s)),
            l = R(a, t).length().sub(n),
            u = R(a, t.sub(i)).length().sub(r),
            d = a.mul(s).add(t.mul(o)).sub(n);
          return gt(c.lessThan(0), l, gt(c.greaterThan(s.mul(i)), u, d));
        },
        y = (e, t, n, r, i) => {
          let s = H((t * Math.PI) / 2)
              .add(o.mul(0.18).mul(a))
              .add(n.mul(a)),
            c = Mt(s),
            l = fe(s),
            u = e.x.mul(c).add(e.y.mul(l)),
            d = e.y.mul(c).sub(e.x.mul(l)).add(u.mul(u).mul(i).mul(a));
          return v(d, u, f, p, r.sub(p));
        },
        b = (e) => {
          let t = H(0.93).sub(a.mul(s).mul(0.24)),
            n = H(0.9).sub(a.mul(c).mul(0.28)),
            r = H(0.94).sub(a.mul(s.oneMinus()).mul(0.22)),
            i = H(0.9).sub(a.mul(c.oneMinus()).mul(0.26)),
            o = (e) => fe(h.mul(e + 1).add(e * 1.7)).mul(0.13),
            l = (e) => fe(g.mul(e + 1).add(e)).mul(0.35),
            u = y(e, 0, o(0), t, l(0));
          ((u = _(u, y(e, 1, o(1), n, l(1)), m)),
            (u = _(u, y(e, 2, o(2), r, l(2)), m)),
            (u = _(u, y(e, 3, o(3), i, l(3)), m)));
          let d = nt(e.y, e.x);
          return u.add(
            a.mul(
              fe(d.mul(7).add(g))
                .mul(0.012)
                .add(fe(d.mul(11).add(h)).mul(0.008)),
            ),
          );
        },
        x = (e) => {
          let t = nt(e.y, e.x),
            n = H(0.68).mul(
              H(1).add(
                a.mul(
                  fe(t.mul(2).add(h))
                    .mul(0.1)
                    .add(fe(t.mul(3).add(g)).mul(0.07))
                    .add(fe(t.mul(5).add(h.mul(1.7))).mul(0.04)),
                ),
              ),
            );
          return e.length().sub(n);
        },
        S = (e) => {
          let n = t.w.mul(1.2).add(0.5),
            r = Mt(n),
            i = fe(n),
            s = e.x.mul(r).add(e.y.mul(i)),
            c = e.y
              .mul(r)
              .sub(e.x.mul(i))
              .add(s.mul(s).mul(a).mul(0.3).mul(o.sign()));
          return v(c, s.add(0.62), H(0.3), H(0.17), H(1.1));
        },
        C = gt(l, f.mul(0.8), gt(u, H(0.22), H(0.45))),
        w = (e) => {
          let t = gt(l, b(e), gt(u, S(e), x(e)));
          return R(t, z(0, C, t.negate()));
        };
      return Oe(() => {
        let t = H(0.015),
          n = w(e).toVar(),
          i = w(e.add(R(t, 0))),
          a = w(e.add(R(0, t))),
          o = i.y.sub(n.y).div(t),
          s = a.y.sub(n.y).div(t),
          c = z(r, r.negate(), n.x);
        return L(o, s, n.y, c);
      })();
    }
    bulkyColor(e, t, n, r, i) {
      let a = this.uniforms;
      return Oe(() => {
        let n = R(e.x, e.y).clamp(-6, 6),
          o = dt(
            W(
              n.x.negate().mul(a.relief).mul(0.22),
              n.y.negate().mul(a.relief).mul(0.22),
              1,
            ),
          ).toVar(),
          s = dt(W(a.light.x, a.light.y, 0.9)),
          c = Bt(o, s).sub(s.z).mul(2.4).clamp(-1, 1).toVar(),
          l = V(i, W(1, 0.98, 0.9), 0.55),
          u = V(i, l, c.max(0).mul(0.8)).toVar();
        u.assign(V(u, a.shade, c.negate().max(0).mul(0.75)));
        let d = dt(s.add(W(0, 0, 1))),
          f = T(Bt(o, d).max(0), 28)
            .mul(a.highlight)
            .mul(a.relief.min(1).mul(0.7).add(0.3));
        u.addAssign(W(1, 0.97, 0.88).mul(f).mul(0.9));
        let p = z(0.32, 0, e.z).mul(a.edge);
        u.assign(V(u, a.shade.mul(0.85), p.mul(0.6)));
        let m = at(t.x).greaterThan(at(t.y)),
          h = gt(m, t.y, t.x),
          g = fe(
            h
              .mul(34)
              .add(r.y.mul(40))
              .add(fe(gt(m, t.x, t.y).mul(5).add(r.z.mul(9))).mul(1.5)),
          );
        return (
          u.mulAssign(
            H(1).add(
              g
                .mul(0.07)
                .mul(a.streaks)
                .mul(z(0.1, 0.5, e.z).oneMinus().mul(0.5).add(0.5)),
            ),
          ),
          u.max(0)
        );
      })();
    }
    occlusion(e, t) {
      let n = this.uniforms;
      return Oe(() => {
        let r = S.mul(L(e, 1)).xyz.toVar(),
          i = r.length().toVar(),
          a = r.div(i.max(1e-5)).toVar(),
          o = H(1).toVar();
        for (let e = 0; e < Di; e++) {
          let r = n.occluderA.element(e),
            i = n.occluderB.element(e),
            s = S.mul(L(r.xyz, 1)).xyz,
            c = S.mul(L(i.xyz, 1)).xyz.sub(s),
            l = a.dot(c),
            u = c.dot(c).max(1e-8),
            d = a.dot(s.negate()),
            f = c.dot(s.negate()),
            p = u.sub(l.mul(l)).max(1e-8),
            m = l.mul(d).negate().add(f).div(p).clamp(0, 1),
            h = gt(u.sub(l.mul(l)).lessThan(1e-7), H(0), m),
            g = s.add(c.mul(h)),
            _ = a.dot(g).max(0),
            v = a.mul(_).sub(g).length(),
            y = r.w,
            b = z(y.add(t).mul(1.25), y.add(t.mul(0.5)), v);
          o.assign(ee(o, H(1).sub(b.mul(y.greaterThan(0).select(1, 0)))));
        }
        let s = z(n.nearFade.mul(0.6), n.nearFade, i);
        return o.mul(s);
      })();
    }
    setOccluders(e, t = null) {
      let n = this.uniforms;
      for (let t = 0; t < Di; t++) {
        let r = e[t],
          i = n.occluderA.array[t],
          a = n.occluderB.array[t];
        r
          ? (i.set(r.a.x, r.a.y, r.a.z, r.radius),
            a.set(r.b.x, r.b.y, r.b.z, r.radius))
          : (i.set(0, -10, 0, 0), a.set(0, -10, 0, 0));
      }
      t != null && (n.nearFade.value = t);
    }
    configure() {
      let e = this.settings,
        t = this.uniforms;
      (Ai.map((t) => e[t]).join(`|`) !== this.structure &&
        this.build(e.count, this.seed),
        this.sprite && (this.sprite.visible = e.enabled && this.requested > 0),
        (t.brightness.value = e.brightness),
        (t.twinkle.value = e.twinkle),
        t.color.value.set(e.color),
        (t.bulk.value = e.bulk),
        (t.irregularity.value = e.irregularity),
        (t.relief.value = e.relief),
        (t.highlight.value = e.highlight),
        (t.edge.value = e.edge),
        (t.streaks.value = e.streaks),
        t.shade.value.set(e.shade));
      let n = U.degToRad(e.lightAngle);
      t.light.value.set(Math.cos(n), Math.sin(n));
    }
    update(e) {
      this.uniforms.time.value = e;
    }
    dispose() {
      (this.sprite?.removeFromParent(),
        this.material?.dispose(),
        (this.sprite = null));
    }
  },
  Mi = [
    [0.59719, 0.35458, 0.04823],
    [0.076, 0.90834, 0.01566],
    [0.0284, 0.13383, 0.83777],
  ],
  Ni = [
    [1.60475, -0.53108, -0.07367],
    [-0.10208, 1.10813, -0.00605],
    [-0.00327, -0.07276, 1.07602],
  ],
  Pi = 0.0245786,
  Fi = 90537e-9,
  Ii = 0.983729,
  Li = 0.432951,
  Ri = 0.238081,
  zi = (e) => (e * (e + Pi) - Fi) / (e * (Ii * e + Li) + Ri);
function Bi(e) {
  e = Math.min(Math.max(e, 0), 1 / Ii - 1e-4);
  let t = 1 - Ii * e,
    n = Pi - Ii * Li * e,
    r = -(Fi + Ri * e);
  return (-n + Math.sqrt(Math.max(n * n - 4 * t * r, 0))) / (2 * t);
}
var Vi = class {
    constructor(e) {
      this.settings = e;
      let t = e.scene;
      this.uniforms = {
        top: I(new G(t.background)),
        horizon: I(new G(t.horizon)),
        glow: I(t.backdropGlow),
        glowColor: I(new G(t.backdropGlowColor)),
        keyDirection: I(new B(-0.5, 0.6, -0.6)),
        fadeColor: I(new G()),
        tableFade: I(0),
        roomFade: I(0),
      };
      let n = new Ue({ side: 1, depthWrite: !1, depthTest: !1 });
      ((n.name = `Backdrop (room gradient)`),
        (n.colorNode = this.colorAt(dt(F.sub(je)), this.uniforms.roomFade)),
        (n.fog = !1),
        (this.mesh = new kt(new st(1, 48, 24), n)),
        (this.mesh.name = `Backdrop`),
        this.mesh.layers.set(q.opaque),
        (this.mesh.renderOrder = -100),
        (this.mesh.frustumCulled = !1),
        (this.mesh.castShadow = this.mesh.receiveShadow = !1));
    }
    colorAt(e, t = this.uniforms.tableFade) {
      let n = this.uniforms;
      return Oe(() => {
        let r = e.toVar(),
          i = z(-0.05, 0.75, r.y),
          a = V(n.horizon, n.top, T(i, H(0.8))),
          o = M(
            r.x
              .mul(n.keyDirection.x)
              .add(r.z.mul(n.keyDirection.z))
              .div(M(n.keyDirection.xz.length(), 0.001)),
            0,
          ),
          s = z(-0.25, 0.08, r.y).mul(z(0.6, 0.02, r.y)),
          c = n.glowColor.mul(T(o, H(3)).mul(s).mul(n.glow));
        return V(a.add(c), n.fadeColor, t);
      })();
    }
    configure(e = null) {
      let { scene: t, table: n } = this.settings,
        r = this.uniforms;
      (r.top.value.set(t.background),
        r.horizon.value.set(t.horizon),
        (r.glow.value = t.backdropGlow),
        r.glowColor.value.set(t.backdropGlowColor),
        e && r.keyDirection.value.copy(e));
      let i = n.fadeTo === `color`;
      ((r.tableFade.value = +!!i),
        (r.roomFade.value = i && n.fadeBackdrop ? 1 : 0),
        Ki(n.fadeColor, t.exposure, r.fadeColor.value));
    }
    update(e) {
      (this.mesh.position.copy(e.position),
        this.mesh.scale.setScalar(Math.max(0.05, e.far * 0.8)),
        this.mesh.updateMatrixWorld());
    }
    dispose() {
      (this.mesh.geometry.dispose(), this.mesh.material.dispose());
    }
  },
  Hi = new j().set(...Mi.flat()).invert(),
  Ui = new j().set(...Ni.flat()).invert(),
  Wi = new B(),
  Gi = new G();
function Ki(e, t, n = new G()) {
  return (
    Gi.set(e),
    Wi.set(
      Math.min(Gi.r, 0.995),
      Math.min(Gi.g, 0.995),
      Math.min(Gi.b, 0.995),
    ).applyMatrix3(Ui),
    Wi.set(Bi(Wi.x), Bi(Wi.y), Bi(Wi.z))
      .applyMatrix3(Hi)
      .multiplyScalar(0.6 / Math.max(t, 0.001)),
    n.setRGB(Math.max(Wi.x, 0), Math.max(Wi.y, 0), Math.max(Wi.z, 0))
  );
}
function qi(e, t, n, r = new B()) {
  let i = e.fov * (n < 0.8 ? 1.12 : 1),
    a = Math.tan(U.degToRad(i / 2)),
    o = a * n,
    s = U.degToRad(e.elevation),
    c = U.degToRad(e.azimuth),
    l = 2 * Math.max(t.rimRadius ?? 0.04, t.lidRadius ?? 0) * 1.04,
    u = (t.lidTopY ?? t.height ?? 0.09) * Math.cos(s) + l * Math.sin(s),
    d = Math.max(u / (e.fill * 2 * a), l / (e.fillWidth * 2 * o)),
    f = d * e.zoom,
    p = new B(r.x + e.offsetX, e.targetY, r.z + e.targetZ);
  return {
    fov: i,
    base: d,
    distance: f,
    target: p,
    position: new B(
      Math.sin(c) * Math.cos(s),
      Math.sin(s),
      Math.cos(c) * Math.cos(s),
    )
      .multiplyScalar(f)
      .add(p),
  };
}
var Ji = new B(),
  Yi = new B(),
  Xi = new B(),
  Zi = new Re(new B(-0.35, 0, -0.35), new B(0.35, 0.25, 0.35)),
  Qi = class {
    constructor({ camera: e, canvas: t, settings: n, extras: r }) {
      ((this.camera = e),
        (this.canvas = t),
        (this.settings = n),
        (this.extras = r),
        (this.base = 0.4),
        (this.subjectTop = null),
        (this.subjectRadius = null),
        (this.userMoved = !1));
      let i = (this.controls = new Dt(e, t));
      ((i.enableDamping = !0),
        (i.screenSpacePanning = !0),
        t.style.removeProperty(`cursor`),
        (this.onStart = () => {
          ((this.userMoved = !0), t.classList.add(`dragging`));
        }),
        (this.onEnd = () => t.classList.remove(`dragging`)),
        (this.bounds = Zi.clone()),
        (this.onChange = () => {
          this.bounds.containsPoint(i.target) ||
            (this.bounds.clampPoint(i.target, Xi),
            Ji.subVectors(Xi, i.target),
            i.target.add(Ji),
            e.position.add(Ji),
            e.updateMatrixWorld());
        }),
        (this.anchor = this.origin().clone()),
        i.addEventListener(`start`, this.onStart),
        i.addEventListener(`end`, this.onEnd),
        i.addEventListener(`change`, this.onChange));
    }
    origin() {
      let e = this.settings.cup;
      return Yi.set(e.x, 0, e.z);
    }
    follow() {
      let e = this.origin();
      (Ji.subVectors(e, this.anchor),
        this.recentre(),
        Ji.lengthSq() !== 0 &&
          (this.controls.target.add(Ji),
          this.camera.position.add(Ji),
          this.controls.update(),
          this.updateClipping()));
    }
    recentre() {
      let e = this.origin();
      (this.anchor.copy(e),
        this.bounds.copy(Zi).translate(Xi.set(e.x, 0, e.z)));
    }
    setSubject({ top: e = null, radius: t = null } = {}) {
      let n = Number.isFinite(e) ? e : null,
        r = Number.isFinite(t) && t > 0 ? t : null,
        i =
          (n ?? -1) !== (this.subjectTop ?? -1) ||
          (r ?? -1) !== (this.subjectRadius ?? -1);
      return ((this.subjectTop = n), (this.subjectRadius = r), i);
    }
    subject(e = this.settings.camera) {
      let t = this.extras.lidTopY ?? this.extras.height,
        n = this.subjectTop ?? t,
        r = this.subjectRadius;
      if ((this.subjectTop === null && r === null) || !Number.isFinite(t))
        return { view: e, extras: this.extras, lift: 0 };
      let i = (n - t) * 0.5,
        a = { ...this.extras, lidTopY: n };
      return (
        r !== null && ((a.rimRadius = r), (a.lidRadius = r)),
        { view: { ...e, targetY: e.targetY + i }, extras: a, lift: i }
      );
    }
    framing() {
      let { view: e, extras: t } = this.subject();
      return qi(e, t, this.camera.aspect, this.origin());
    }
    frame() {
      let { camera: e, controls: t } = this,
        n = this.framing();
      ((this.base = n.base),
        this.recentre(),
        (e.fov = n.fov),
        e.position.copy(n.position),
        t.target.copy(n.target),
        t._sphericalDelta?.set(0, 0, 0),
        t._panOffset?.set(0, 0, 0),
        typeof t._scale == `number` && (t._scale = 1),
        (this.userMoved = !1),
        this.configure(),
        t.update(),
        this.updateClipping());
    }
    configure() {
      let { controls: e } = this,
        t = this.settings.orbit;
      ((e.enableDamping = t.damping > 0),
        (e.dampingFactor = Math.max(0.01, t.damping)),
        (e.rotateSpeed = t.rotateSpeed),
        (e.zoomSpeed = t.zoomSpeed),
        (e.panSpeed = t.panSpeed),
        (e.enablePan = t.pan),
        (e.zoomToCursor = t.zoomToCursor),
        (e.autoRotate = t.autoRotate),
        (e.autoRotateSpeed = t.autoRotateSpeed),
        (e.minDistance = this.base * Math.min(t.minDistance, t.maxDistance)),
        (e.maxDistance = this.base * Math.max(t.minDistance, t.maxDistance)));
      let n = Math.min(t.minElevation, t.maxElevation),
        r = Math.max(t.minElevation, t.maxElevation);
      ((e.minPolarAngle = U.degToRad(90 - Math.min(89.9, r))),
        (e.maxPolarAngle = U.degToRad(90 - Math.max(0.5, n))));
    }
    resize(e, t) {
      if (((this.camera.aspect = e / t), !this.userMoved)) {
        this.frame();
        return;
      }
      let n = this.framing(),
        r = n.base / this.base;
      ((this.base = n.base),
        (this.camera.fov = n.fov),
        r !== 1 &&
          (Ji.subVectors(
            this.camera.position,
            this.controls.target,
          ).multiplyScalar(r),
          this.camera.position.copy(this.controls.target).add(Ji)),
        this.configure(),
        this.updateClipping());
    }
    updateClipping() {
      let { camera: e } = this,
        t = e.position.distanceTo(this.controls.target);
      ((e.near = Math.max(0.004, t * 0.05)),
        (e.far = Math.max(t * 12, t + 3)),
        e.updateProjectionMatrix());
    }
    update(e) {
      let t = this.controls.update(e);
      return (this.updateClipping(), this.camera.updateMatrixWorld(), t);
    }
    get live() {
      let e = this.controls.target;
      Ji.copy(this.camera.position).sub(e);
      let t = Ji.length();
      return {
        distance: t,
        elevation: U.radToDeg(Math.asin(U.clamp(Ji.y / t, -1, 1))),
        azimuth: U.radToDeg(Math.atan2(Ji.x, Ji.z)),
        zoom: t / Math.max(1e-6, this.base),
        target: e,
      };
    }
    saveView() {
      let e = this.live,
        t = this.settings.camera,
        n = this.origin(),
        r = (e, t) => Number(e.toFixed(t));
      ((t.elevation = r(e.elevation, 1)), (t.azimuth = r(e.azimuth, 1)));
      let { lift: i, extras: a } = this.subject();
      ((t.offsetX = r(e.target.x - n.x, 4)),
        (t.targetY = r(e.target.y - i, 4)),
        (t.targetZ = r(e.target.z - n.z, 4)));
      let o = qi(
        { ...this.subject(t).view, zoom: 1 },
        a,
        this.camera.aspect,
        n,
      );
      ((t.zoom = r(e.distance / o.base, 3)),
        (this.base = o.base),
        this.configure(),
        (this.userMoved = !0));
    }
    dispose() {
      (this.controls.removeEventListener(`start`, this.onStart),
        this.controls.removeEventListener(`end`, this.onEnd),
        this.controls.removeEventListener(`change`, this.onChange),
        this.controls.dispose());
    }
  },
  $i = new B(0, 1, 0),
  ea = new B(),
  ta = new B(),
  na = new B(),
  ra = new B(),
  ia = new B(),
  aa = new Lt(),
  oa = new Ye(),
  sa = new w(),
  ca = new ut(),
  la = new B(),
  ua = new ut(),
  da = new ut(),
  fa = new St(),
  pa = new B();
function ma({
  canvas: e,
  camera: t,
  controls: n = null,
  cup: r,
  settings: i,
  reducedMotion: a = !1,
  onHover: o = null,
} = {}) {
  let s = i.interaction,
    c = r.root,
    l = r.extras ?? {},
    u = new Pe(),
    d = new B(),
    f = new B(),
    p = new B(),
    m = new w(),
    h = new w(),
    g = new B(),
    _ = new B(),
    v = new B(),
    y = new B();
  new B();
  let b = new B(),
    x = {
      active: !1,
      pointerId: null,
      y: 0,
      grab: new B(),
      target: new B(),
      controlsWere: !0,
      hover: !1,
    },
    S = {
      active: !1,
      t: 0,
      duration: 1,
      amplitude: 0,
      frequency: 3,
      dir: new B(1, 0, 0),
      count: 0,
    },
    C = {
      mobile: i.mobile,
      velocity: new B(),
      acceleration: new B(),
      angularVelocity: new B(),
      angularAcceleration: new B(),
      offset: d,
      cup: {
        acceleration: new B(),
        angularVelocity: new B(),
        angularAcceleration: new B(),
        gravity: new B(0, -9.81, 0),
      },
      dragging: !1,
      shaking: !1,
      moving: !1,
      speed: 0,
    },
    T = !1,
    E = !1,
    D = (t) => {
      x.hover = t;
      let n = x.active ? `held` : t ? `hover` : ``;
      (n !== (e.dataset.cup ?? ``) &&
        (n ? (e.dataset.cup = n) : delete e.dataset.cup),
        o?.());
    },
    O = { source: null, length: 0, table: null, y0: 0, y1: 0, max: 0 },
    k = () => {
      let e = r.extras?.outerProfile ?? l.outerProfile;
      if (!Array.isArray(e) || e.length < 3) return null;
      if (O.source === e && O.length === e.length) return O;
      let t = Math.min(...e.map((e) => e[1])),
        n = Math.max(...e.map((e) => e[1])),
        i = new Float64Array(97);
      for (let r = 0; r <= 96; r++) {
        let a = t + ((n - t) * r) / 96,
          o = 0;
        for (let t = 0; t < e.length - 1; t++) {
          let [n, r] = e[t],
            [i, s] = e[t + 1];
          if ((a - r) * (a - s) > 0) continue;
          let c = Math.abs(s - r) < 1e-12 ? 1 : (a - r) / (s - r);
          o = Math.max(o, n + (i - n) * Math.min(1, Math.max(0, c)));
        }
        i[r] = o;
      }
      return (
        Object.assign(O, {
          source: e,
          length: e.length,
          table: i,
          y0: t,
          y1: n,
          max: Math.max(...i),
        }),
        O
      );
    },
    A = () => {
      let e = r.extras ?? l,
        t = Math.max(
          Number(r.lidTop?.()) || 0,
          Number(e.lidTopY) || 0,
          Number(e.height) || 0.085,
        ),
        n = Number(e.baseRadius) || 0.023,
        i = Number(e.rimRadius) || 0.036,
        a = Number(e.lidRadius) || i + 0.002,
        o = Number(e.height) || 0.085,
        s = Number(e.lidSkirtBottomY) || o - 0.008,
        c = k();
      if (c) {
        let e = c.table.length - 1,
          n = (t) => {
            let n = Math.min(
                e,
                Math.max(0, ((t - c.y0) / Math.max(1e-6, c.y1 - c.y0)) * e),
              ),
              r = Math.min(e - 1, Math.floor(n)),
              i = n - r;
            return c.table[r] * (1 - i) + c.table[r + 1] * i;
          };
        return {
          top: t,
          radius: (e) => (e >= s ? Math.max(a, n(Math.min(e, c.y1))) : n(e)),
          bound: Math.max(a, c.max),
        };
      }
      return {
        top: t,
        radius: (e) =>
          e >= s ? a : n + (i - n) * Math.min(1, Math.max(0, e / o)),
        bound: Math.max(a, i),
      };
    };
  function j(n, r) {
    let i = e.getBoundingClientRect();
    (sa.set(
      ((n - i.left) / i.width) * 2 - 1,
      (-(r - i.top) / i.height) * 2 + 1,
    ),
      u.setFromCamera(sa, t),
      c.updateWorldMatrix(!0, !1),
      aa.copy(c.matrixWorld).invert(),
      oa.copy(u.ray).applyMatrix4(aa));
    if(C.mobile){
      const mesh=c.getObjectByName("Touch apple surface");
      if(mesh){ u.layers.enableAll(); const hit=u.intersectObject(mesh,false)[0]; return hit?.point?.clone() ?? null; }
    }
    let a = oa.origin,
      o = oa.direction,
      { top: s, radius: l, bound: d } = A(),
      f = d + 0.002,
      p = o.x * o.x + o.z * o.z,
      m = 2 * (a.x * o.x + a.z * o.z),
      h = a.x * a.x + a.z * a.z - f * f,
      g = -1 / 0,
      _ = 1 / 0;
    if (p > 1e-12) {
      let e = m * m - 4 * p * h;
      if (e < 0) return null;
      let t = Math.sqrt(e);
      ((g = (-m - t) / (2 * p)), (_ = (-m + t) / (2 * p)));
    } else if (h > 0) return null;
    if (Math.abs(o.y) > 1e-9) {
      let e = (0 - a.y) / o.y,
        t = (s - a.y) / o.y;
      (e > t && ([e, t] = [t, e]), (g = Math.max(g, e)), (_ = Math.min(_, t)));
    } else if (a.y < 0 || a.y > s) return null;
    if (((g = Math.max(g, 0)), !(_ > g))) return null;
    for (let e = 0; e <= 40; e++) {
      let t = g + ((_ - g) * e) / 40,
        n = a.x + o.x * t,
        r = a.y + o.y * t,
        i = a.z + o.z * t;
      if (Math.hypot(n, i) <= l(r) + 0.002)
        return la.set(n, r, i).applyMatrix4(c.matrixWorld).clone();
    }
    return null;
  }
  function ee(n, r) {
    let i = e.getBoundingClientRect();
    (sa.set(
      ((n - i.left) / i.width) * 2 - 1,
      (-(r - i.top) / i.height) * 2 + 1,
    ),
      u.setFromCamera(sa, t),
      C.mobile ? fa.setFromNormalAndCoplanarPoint(t.getWorldDirection(ra), x.worldPoint) : fa.set($i, -x.y));
    let a = u.ray.intersectPlane(fa, la);
    if (!a) return;
    x.target.set(a.x - x.grab.x - g.x, C.mobile ? a.y - x.grab.y : 0, a.z - x.grab.z - g.z);
    if(C.mobile) x.target.multiplyScalar(C.mobile.touchGain);
    let o = x.target.length(),
      c = Math.max(0.005, s.maxOffset);
    o > 1e-9 && x.target.multiplyScalar((c * Math.tanh(o / c)) / o);
  }
  function te(t) {
    if (!s.enabled || x.active || t.button > 0 || i.mobile?.gestureLock) return;
    let r = j(t.clientX, t.clientY);
    if (r) {
      (t.preventDefault(),
        t.stopImmediatePropagation(),
        (x.active = !0),
        (x.pointerId = t.pointerId),
        (x.y = r.y),
        x.grab.set(r.x - c.position.x, i.mobile ? r.y - c.position.y : 0, r.z - c.position.z),
        (x.worldPoint=r.clone()), (C.grabLocal=c.worldToLocal(r.clone())),
        x.target.copy(d),
        (x.controlsWere = !n || n.enabled !== !1),
        n && (n.enabled = !1),
        (S.active = !1));
      try {
        e.setPointerCapture(t.pointerId);
      } catch {}
      D(!0);
      e.dispatchEvent(new CustomEvent('jelly-press',{detail:{pointerId:t.pointerId,x:t.clientX,y:t.clientY}}));
    }
  }
  function M(e) {
    if (x.active) {
      if (e.pointerId !== x.pointerId) return;
      (ee(e.clientX, e.clientY), D(!0));
      return;
    }
    if (e.pointerType === `touch` || e.buttons) return;
    let t = s.enabled && !!j(e.clientX, e.clientY);
    (t || t !== x.hover) && D(t);
  }
  function N() {
    !x.active && x.hover && D(!1);
  }
  function P(t) {
    if (!x.active || (t && t.pointerId !== x.pointerId)) return;
    x.active = !1;
    e.dispatchEvent(new CustomEvent('jelly-release',{detail:{cancelled:!t || t.type!=='pointerup'}}));
    try {
      t && e.releasePointerCapture(t.pointerId);
    } catch {}
    n && (n.enabled = x.controlsWere);
    let r = !!(
      s.enabled &&
      t &&
      t.pointerType !== `touch` &&
      j(t.clientX, t.clientY)
    );
    D(r);
  }
  function F(e) {
    if (
      !s.enabled ||
      e.metaKey ||
      e.ctrlKey ||
      e.altKey ||
      e.target?.closest?.(`input, textarea, select, [contenteditable]`)
    )
      return;
    let n = e.key;
    if (n === `s` || n === `S`) {
      ne();
      return;
    }
    let r = {
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
      ArrowUp: [0, 1],
      ArrowDown: [0, -1],
    };
    if (!r[n]) return;
    (e.preventDefault(),
      t.getWorldDirection(ra).setY(0),
      ra.lengthSq() < 1e-8 && ra.set(0, 0, -1),
      ra.normalize(),
      ia.crossVectors(ra, $i).normalize());
    let [i, a] = r[n];
    (ea.copy(ia).multiplyScalar(i).addScaledVector(ra, a),
      re(ea, e.shiftKey ? 2 : 1));
  }
  (e.addEventListener(`pointerdown`, te, { capture: !0 }),
    e.addEventListener(`pointermove`, M),
    e.addEventListener(`pointerleave`, N),
    e.addEventListener(`pointerup`, P),
    e.addEventListener(`pointercancel`, P),
    e.addEventListener(`lostpointercapture`, P),
    window.addEventListener(`keydown`, F));
  function ne(e = s.shakeStrength) {
    s.enabled &&
      (t.getWorldDirection(ra).setY(0),
      ra.lengthSq() < 1e-8 && ra.set(0, 0, -1),
      ra.normalize(),
      S.dir
        .crossVectors(ra, $i)
        .normalize()
        .applyAxisAngle($i, (S.count % 2 ? -1 : 1) * 0.26),
      S.count++,
      (S.t = 0),
      (S.duration = Math.max(0.2, Number(s.shakeDuration) || 1.3)),
      (S.frequency = Math.max(0.5, Number(s.shakeFrequency) || 3.4)),
      (S.amplitude =
        Math.max(0, Number(s.shakeAmplitude) || 0.012) *
        Math.max(0, Number(e) || 0) *
        (a ? 0.5 : 1)),
      (S.active = S.amplitude > 0));
  }
  function re(e, t = 1) {
    s.enabled &&
      (ta.set(e.x ?? e[0] ?? 0, 0, e.z ?? e[2] ?? 0),
      !(ta.lengthSq() < 1e-12) &&
        (ta.normalize().multiplyScalar((Number(s.nudgeSpeed) || 0) * t),
        f.add(ta).clampLength(0, s.maxSpeed)));
  }
  function ie() {
    let e = i.cup ?? {};
    return (
      g.set(Number(e.x) || 0, 0, Number(e.z) || 0),
      ua.setFromAxisAngle($i, U.degToRad(Number(e.yaw) || 0)),
      Math.max(0.2, Number(e.scale) || 1)
    );
  }
  function ae(e, t, n, r) {
    r.copy(g).add(e);
    let i = t.length();
    if (i < 1e-9) return r;
    let a = (Number(l.baseRadius) || 0.023) * n;
    return (
      ra.set(t.x / i, 0, t.y / i),
      ia.set(ra.z, 0, -ra.x),
      na.copy(ra).multiplyScalar(-a).applyAxisAngle(ia, i),
      r.addScaledVector(ra, a).add(na)
    );
  }
  function oe() {
    let e = ie();
    ae(d, m, e, _);
    let t = m.length();
    return (
      t > 1e-9
        ? da.setFromAxisAngle(ia.set(m.y / t, 0, -m.x / t), t)
        : da.identity(),
      c.position.copy(_),
      c.quaternion.copy(da).multiply(ua),
      e
    );
  }
  function I(e = 0) {
    if (E) return;
    ((e = Math.min(Math.max(Number(e) || 0, 0), 0.05)),
      !s.enabled && x.active && P());
    let t = ie();
    if (e <= 0) {
      oe();
      return;
    }
    let n = Math.max(1, Math.min(32, Math.round(Number(s.substeps) || 8))),
      r = e / n,
      i = Math.max(0.5, Number(s.maxAcceleration) || 28),
      o = Math.max(0.05, Number(s.maxSpeed) || 1.2),
      l = x.active || S.active,
      u =
        2 *
        Math.PI *
        Math.max(
          0.1,
          l ? Number(s.followFrequency) || 7 : Number(s.dragSpring) || 2.2,
        ),
      g = l ? 0.9 : Math.max(0.05, Number(s.returnDamping) || 0.55),
      w = 2 * Math.PI * Math.max(0.2, Number(s.tiltFrequency) || 3),
      D = Math.max(0.02, Number(s.tiltDamping) || 0.35),
      O = U.degToRad(Math.max(0, Number(s.tiltMax) || 0)) * (a ? 0.5 : 1),
      k = (O * Math.max(0, Number(s.tilt) || 0)) / 10,
      A = T ? pa.copy(y) : null;
    (b.copy(C.angularVelocity), T || ae(d, m, t, v));
    for (let e = 0; e < n; e++) {
      if (x.active) p.copy(x.target);
      else if (S.active) {
        S.t += r;
        let e = S.t,
          t = S.duration;
        if (e >= t) ((S.active = !1), p.set(0, 0, 0));
        else {
          let n =
            ha(Math.min(1, e / 0.12)) * ha(Math.min(1, (t - e) / (0.4 * t)));
          p.copy(S.dir).multiplyScalar(
            S.amplitude * n * Math.sin(2 * Math.PI * S.frequency * e),
          );
        }
      } else p.set(0, 0, 0);
      (ea
        .copy(p)
        .sub(d)
        .multiplyScalar(u * u)
        .addScaledVector(f, -2 * g * u),
        (C.mobile || (ea.y = 0)),
        ea.clampLength(0, i),
        f.addScaledVector(ea, r).clampLength(0, o),
        d.addScaledVector(f, r));
      let a = _a(ea.x * k, ea.z * k, O),
        s = w * w * (a[0] - m.x) - 2 * D * w * h.x,
        c = w * w * (a[1] - m.y) - 2 * D * w * h.y;
      ((h.x += s * r), (h.y += c * r), (m.x += h.x * r), (m.y += h.y * r));
      let l = m.length();
      (l > O * 1.5 && l > 0 && m.multiplyScalar((O * 1.5) / l),
        e === n - 1
          ? (ae(d, m, t, _), y.copy(_).sub(v).divideScalar(r))
          : ae(d, m, t, v));
    }
    let j =
      x.active ||
      S.active ||
      d.lengthSq() > 1e-12 ||
      f.lengthSq() > 1e-10 ||
      m.lengthSq() > 1e-12 ||
      h.lengthSq() > 1e-10;
    (j ||
      (d.set(0, 0, 0),
      f.set(0, 0, 0),
      m.set(0, 0),
      h.set(0, 0),
      y.set(0, 0, 0)),
      oe(),
      v.copy(_),
      C.velocity.copy(y).clampLength(0, o),
      A
        ? C.acceleration.copy(y).sub(A).divideScalar(e).clampLength(0, i)
        : C.acceleration.set(0, 0, 0),
      C.angularVelocity.set(h.y, 0, -h.x),
      C.angularAcceleration
        .copy(C.angularVelocity)
        .sub(b)
        .divideScalar(e)
        .clampLength(0, 400),
      j ||
        (C.velocity.set(0, 0, 0),
        C.acceleration.set(0, 0, 0),
        C.angularVelocity.set(0, 0, 0),
        C.angularAcceleration.set(0, 0, 0)),
      (T = !0),
      ca.copy(c.quaternion).invert());
    let ee = C.cup;
    (ee.acceleration.copy(C.acceleration).applyQuaternion(ca).divideScalar(t),
      ee.angularVelocity.copy(C.angularVelocity).applyQuaternion(ca),
      ee.angularAcceleration.copy(C.angularAcceleration).applyQuaternion(ca),
      ee.gravity.set(0, -9.81, 0).applyQuaternion(ca).divideScalar(t),
      (C.dragging = x.active),
      (C.pull = x.active ? x.target.clone().sub(d).addScaledVector(x.target,.18).applyQuaternion(ca).divideScalar(t) : null),
      (C.shaking = S.active),
      (C.moving = j),
      (C.speed = C.velocity.length()));
  }
  function se() {
    E ||
      ((E = !0),
      P(),
      e.removeEventListener(`pointerdown`, te, { capture: !0 }),
      e.removeEventListener(`pointermove`, M),
      e.removeEventListener(`pointerleave`, N),
      e.removeEventListener(`pointerup`, P),
      e.removeEventListener(`pointercancel`, P),
      e.removeEventListener(`lostpointercapture`, P),
      window.removeEventListener(`keydown`, F),
      delete e.dataset.cup,
      d.set(0, 0, 0),
      m.set(0, 0),
      oe());
  }
  return { settings: s, state: C, update: I, shake: ne, cancel: () => {P(); S.active=false;}, dispose: se };
}
function ha(e) {
  return e * e * (3 - 2 * e);
}
var ga = [0, 0];
function _a(e, t, n) {
  let r = Math.hypot(e, t),
    i = r > n && r > 0 ? n / r : 1;
  return ((ga[0] = e * i), (ga[1] = t * i), ga);
}
function va(e, t) {
  let n = e.toneMapping,
    r = e.outputColorSpace,
    i = e.autoClear,
    a = e.getRenderTarget();
  try {
    return (
      (e.toneMapping = 0),
      (e.outputColorSpace = te.workingColorSpace),
      (e.autoClear = !1),
      e.setRenderTarget(null),
      t()
    );
  } finally {
    ((e.toneMapping = n),
      (e.outputColorSpace = r),
      (e.autoClear = i),
      e.setRenderTarget(a));
  }
}
function ya() {
  let e = new ye(-1, 1, 1, -1, 0.1, 10);
  return ((e.position.z = 1), e);
}
function ba(e, t, n) {
  ((e.left = -t / 2),
    (e.right = t / 2),
    (e.top = n / 2),
    (e.bottom = -n / 2),
    e.updateProjectionMatrix());
}
var xa = {
  "mesq-main.png": {
    width: 1416,
    height: 1392,
    left: 245,
    top: 600,
    right: 1169,
    bottom: 794,
  },
};
async function Sa(e) {
  let t = await new vt().loadAsync(`/star-knot-jelly/mr/jelly-painting/ui/${e}`);
  try {
    let n = t.image,
      r = xa[e],
      {
        left: i,
        top: a,
        right: o,
        bottom: s,
      } = r?.width === n.width && r.height === n.height ? r : Ca(n, e),
      c = o - i + 1,
      l = s - a + 1;
    return (
      t.repeat.set(c / n.width, l / n.height),
      t.offset.set(i / n.width, 1 - (s + 1) / n.height),
      { map: t, aspect: c / l }
    );
  } catch (e) {
    throw (t.dispose(), e);
  }
}
function Ca(e, t) {
  let n = document.createElement(`canvas`);
  ((n.width = e.width), (n.height = e.height));
  let r = n.getContext(`2d`, { willReadFrequently: !0 });
  r.drawImage(e, 0, 0);
  let i = r.getImageData(0, 0, n.width, n.height).data,
    a = n.width,
    o = 0,
    s = n.height,
    c = 0;
  for (let e = 0; e < n.height; e++)
    for (let t = 0; t < n.width; t++) {
      let r = (e * n.width + t) * 4;
      i[r + 3] * Math.max(i[r], i[r + 1], i[r + 2]) < 1024 ||
        ((a = Math.min(a, t)),
        (o = Math.max(o, t)),
        (s = Math.min(s, e)),
        (c = Math.max(c, e)));
    }
  if (o <= a || c <= s) throw Error(`No visible ink in ${t}.`);
  return {
    left: Math.max(0, a - 3),
    right: Math.min(n.width - 1, o + 3),
    top: Math.max(0, s - 3),
    bottom: Math.min(n.height - 1, c + 3),
  };
}
var wa = (e) => e.a.mul(e.r.max(e.g).max(e.b));
function Ta(e, t) {
  let n = t.uniforms.seed,
    r = R(K(e.mul(0.3), n.add(1.7)), K(e.mul(0.3), n.add(5.9))),
    i = R(K(e.mul(0.9), n.add(2.3)), K(e.mul(0.9), n.add(7.1)));
  return r.mul(0.55).add(i.mul(0.3));
}
function Ea({ colour: e, mark: t, markAt: n, px: r, post: i }) {
  let a = i.uniforms,
    o = a.speckleSize.mul(2.1),
    s = r.div(o),
    c = Rt(s),
    l = sn(c.add(a.seed.mul(3.3)).add(19.1)).toVar(),
    u = sn(c.add(a.seed.mul(1.7)).add(71.1)),
    d = tn(c.add(5.5)).toVar(),
    f = nn(r, a.seed).mul(0.6).add(0.4),
    p = Xt(s, u, d),
    m = a.speckle.mul(a.styleStrength).mul(0.35).clamp(0, 0.8).mul(f),
    h = P(l, m).mul(p),
    g = d.x.mul(Math.PI * 2),
    _ = o.mul(l.mul(3).add(1.2)),
    v = R(Mt(g), fe(g)).mul(_).toVar(),
    y = V(t.w, n(v), h),
    b = K(R(r.x.mul(0.07), r.y.mul(0.85)), a.seed.add(41.7))
      .mul(0.65)
      .add(K(r.mul(0.55), a.seed.mul(1.3).add(9.2)).mul(0.35)),
    x = z(0.7, 0.05, t.z),
    S = b.mul(0.5).add(0.5).clamp(0, 1).mul(x).mul(0.9),
    C = z(S.sub(0.12), S.add(0.12), t.z.add(0.1)).mul(H(1).sub(S.mul(0.35))),
    w = H(1).sub(z(0.3, 0.85, K(r.mul(0.7), a.seed.add(27.3))).mul(0.3)),
    T = K(r.mul(0.3), a.seed.add(3.1))
      .mul(0.6)
      .add(K(r.mul(0.9), a.seed.add(8.3)).mul(0.4))
      .mul(0.1)
      .add(1),
    E = e.mul(T),
    D = on(r, a.speckleSize, a.seed, a.dpr),
    O = cn(E, D),
    k = a.speckle.mul(a.styleStrength).mul(0.7).clamp(0, 1);
  return { colour: V(E, O, k), alpha: y.mul(M(C, 0)).mul(w) };
}
var Da = document.documentElement,
  Oa = !1,
  ka = (e) => {
    e !== Oa && ((Oa = e), Da.classList.toggle(`keyboard-nav`, e));
  };
(addEventListener(
  `keydown`,
  (e) => {
    e.key === `Tab` && ka(!0);
  },
  !0,
),
  addEventListener(`pointerdown`, () => ka(!1), !0));
var Aa = (e) => Oa && document.activeElement === e,
  ja = {
    tilt: 0.21,
    step: 0.035,
    hop: 0.06,
    squash: 0.07,
    in: 0.35,
    out: 0.25,
    press: 0.1,
  },
  Ma = 3,
  Na = [0.12, 0.3],
  Pa = [0.35, 0.65],
  Fa = [
    [0, 0],
    ...Array.from({ length: 8 }, (e, t) => [
      Math.cos((t * Math.PI) / 4) * Ma,
      Math.sin((t * Math.PI) / 4) * Ma,
    ]),
  ],
  Ia = 2,
  La = new G(),
  Ra = { r: 0, g: 0, b: 0 },
  za = { x: 0, y: 0, size: 0, visible: !1 },
  Ba = [],
  Va = class {
    constructor({
      canvas: e,
      settings: t,
      sparkles: n,
      postfx: r,
      onChange: i,
      reducedMotion: a = !1,
    }) {
      (Object.assign(this, {
        canvas: e,
        settings: t,
        sparkles: n,
        postfx: r,
        onChange: i,
        reducedMotion: a,
      }),
        (this.themes = null),
        (this.studyQuads = []),
        (this.scene = new jt()),
        (this.camera = ya()),
        (this.geometry = new Ve(1, 1)),
        (this.viewport = I(new w(1, 1))),
        (this.signatureStrength = I(t.ui.signaturePostStrength)),
        (this.cursorPaint = {
          color: I(new G(t.ui.cursorColor)),
          follow: I(1),
          brightness: I(1),
          lift: I(1),
          opacity: I(1),
          pointer: I(new w(-100, -100)),
          framed: I(1),
          exposure: I(t.scene.exposure),
          size: I(t.ui.cursorSize),
          dotRadius: I(3.5),
          dotQuad: I(11),
          dotColor: I(new B(0.067, 0.067, 0.067)),
          dotOpacity: I(1),
        }),
        (this.width = this.height = 1),
        (this.rect = { x: 0, y: 0, width: 1, height: 1 }),
        (this.framed = !1),
        (this.disposed = !1),
        (this.pointer = {
          x: -100,
          y: -100,
          surface: !1,
          visible: !1,
          theme: !1,
          snap: !0,
          size: t.ui.cursorSize,
          engaged: 0,
          press: 0,
          tilt: 0.08,
          down: !1,
        }),
        (this.dance = { ramp: 0, phase: 0, time: 0 }),
        (this._box = { x: 0, y: 0, width: 1, height: 1 }),
        (this.cleanups = []),
        (this.artwork = []),
        (this.signatureFocus = this.canvasMesh(`Signature keyboard focus`, 2)),
        (this.signatureFocus.mesh.visible = !1),
        (this.cursor = this.starMesh(
          `Star cursor`,
          4,
          this.cursorPaint.opacity,
        )),
        (this.cursor.visible = !1),
        (this.overlayScene = new jt()),
        (this.studyStar = this.overlayMesh(`Star cursor · theme canvases`, 0)),
        (this.dot = this.overlayMesh(`Cursor dot · paper`, 1)),
        (this.signatureLink = document.createElement(`a`)),
        Object.assign(this.signatureLink, {
          className: `signature-link`,
          href: `https://x.com/mesqme`,
          target: `_blank`,
          rel: `noopener noreferrer`,
          textContent: `Mesq on X`,
          hidden: !0,
        }),
        this.signatureLink.setAttribute(
          `aria-label`,
          `Mesq on X (opens in a new tab)`,
        ),
        document.body.append(this.signatureLink),
        this.listen(this.signatureLink, `pointerenter`, () => {
          ((this.signatureHovered = !0), this.onChange());
        }),
        this.listen(this.signatureLink, `pointerleave`, () => {
          ((this.signatureHovered = !1), this.onChange());
        }),
        this.listen(this.signatureLink, `focus`, () => this.onChange()),
        this.listen(this.signatureLink, `blur`, () => this.onChange()),
        this.listen(window, `pointermove`, (e) => this.trackPointer(e), {
          passive: !0,
        }),
        this.listen(
          window,
          `pointerdown`,
          (e) => {
            ((this.pointer.down = !0), this.trackPointer(e));
          },
          { passive: !0, capture: !0 },
        ),
        this.listen(
          window,
          `pointerup`,
          () => {
            ((this.pointer.down = !1), this.onChange());
          },
          { passive: !0 },
        ),
        this.listen(window, `pointercancel`, () => this.clearPointer()),
        this.listen(window, `blur`, () => this.clearPointer()),
        this.listen(document, `pointerout`, (e) => {
          e.relatedTarget || this.clearPointer();
        }),
        this.listen(document, `visibilitychange`, () => {
          document.hidden && this.clearPointer();
        }),
        (this.ready = this.loadArtwork()));
    }
    listen(e, t, n, r) {
      (e.addEventListener(t, n, r),
        this.cleanups.push(() => e.removeEventListener(t, n, r)));
    }
    mesh(e, t, n) {
      let r = new kt(this.geometry, e);
      return (
        (r.name = t),
        (r.renderOrder = n),
        (r.frustumCulled = !1),
        this.scene.add(r),
        r
      );
    }
    overlayMesh(e, t) {
      let n = new kt(this.geometry);
      return (
        (n.name = e),
        (n.renderOrder = t),
        (n.frustumCulled = !1),
        (n.visible = !1),
        this.overlayScene.add(n),
        n
      );
    }
    starPaint(e = null) {
      let { sparkles: t, cursorPaint: n } = this,
        r = e
          ? Je().sub(0.5).mul(2).add(e.mul(2).div(n.size)).toVar()
          : Je().sub(0.5).mul(2),
        i = L(1, 0, 1, 0.35),
        a = W(0.22, 0.47, 0.71),
        o = A(r.x).mul(1.2),
        s = t.bulkyMark(r, i, a, o),
        c = V(n.color, t.uniforms.color, n.follow);
      return {
        mark: s,
        markAt: (e) => t.bulkyMark(r.add(e.mul(2).div(n.size)), i, a, o).w,
        normal: t
          .bulkyColor(s, r, i, a, c)
          .mul(t.uniforms.brightness)
          .mul(n.brightness)
          .mul(n.lift),
      };
    }
    frameCoverage() {
      return V(
        H(1),
        xt(this.postfx.frameTexture, wt).x,
        this.cursorPaint.framed,
      );
    }
    frameAt(e) {
      return V(
        H(1),
        xt(this.postfx.frameTexture, e.div(this.viewport)).level(0).x,
        this.cursorPaint.framed,
      );
    }
    studyAt(e) {
      let t = H(0);
      return (
        this.themes?.studies.forEach((n, r) => {
          let i = this.studyQuads[r],
            a = e.sub(i.xy).div(i.z),
            o = P(0, a.x).mul(P(a.x, 1)).mul(P(0, a.y)).mul(P(a.y, 1)),
            s = xt(n.target.texture, R(a.x, a.y.oneMinus())).level(0).a;
          t = M(t, s.mul(o).mul(i.w));
        }),
        t
      );
    }
    handoff(e) {
      let t = this.cursorPaint.pointer,
        n = H(0);
      for (let [r, i] of Fa) n = n.add(z(Na[0], Na[1], e(t.add(R(r, i)))));
      return z(Pa[0], Pa[1], n.div(Fa.length));
    }
    starMesh(e, t, n) {
      let { mark: r, normal: i } = this.starPaint(),
        a = new Ue({ transparent: !0, depthTest: !1, depthWrite: !1 });
      ((a.name = e),
        (a.colorNode = i),
        (a.opacityNode = r.w
          .mul(n)
          .mul(this.frameCoverage())
          .mul(this.handoff((e) => this.frameAt(e)))));
      let o = this.mesh(a, e, t);
      return ((o.rotation.z = 0.08), o);
    }
    setThemes(e) {
      ((this.themes = e),
        (this.studyQuads = e.studies.map(() => I(new Pt(0, 0, 1, 0)))));
      for (let e of [this.studyStar, this.dot]) {
        let t = e.material;
        ((e.material =
          e === this.dot ? this.dotMaterial() : this.studyStarMaterial()),
          t.dispose());
      }
    }
    studyStarMaterial() {
      let e = this.cursorPaint,
        t = new It();
      return (
        (t.name = `Star cursor · theme canvases`),
        (t.fragmentNode = Oe(() => {
          let t = wt.mul(this.viewport).toVar(),
            n = this.handoff((e) => this.studyAt(e)).toVar(),
            r = this.studyAt(t).toVar(),
            {
              mark: i,
              markAt: a,
              normal: o,
            } = this.starPaint(Ta(Je().sub(0.5).mul(24), this.postfx)),
            s = Ea({
              colour: et(ft(o, e.exposure)),
              mark: i,
              markAt: a,
              px: t,
              post: this.postfx,
            });
          return L(s.colour.clamp(0, 1), s.alpha.mul(e.opacity).mul(r).mul(n));
        })()),
        (t.transparent = !0),
        (t.depthTest = t.depthWrite = !1),
        t
      );
    }
    dotMaterial() {
      let e = this.cursorPaint,
        t = new It();
      return (
        (t.name = `Cursor dot · paper`),
        (t.fragmentNode = Oe(() => {
          let t = H(1)
              .sub(this.handoff((e) => M(this.frameAt(e), this.studyAt(e))))
              .toVar(),
            n = Je().sub(0.5).mul(e.dotQuad).toVar(),
            r = A(n.x),
            i = e.dotRadius.sub(Ft(n)).div(r).add(0.5).clamp(0, 1);
          return L(e.dotColor, i.mul(e.dotOpacity).mul(t));
        })()),
        (t.transparent = !0),
        (t.depthTest = t.depthWrite = !1),
        t
      );
    }
    canvasMesh(e, t) {
      let n = document.createElement(`canvas`),
        r = new Et(n);
      ((r.colorSpace = D), (r.generateMipmaps = !1), (r.minFilter = _e));
      let i = new Ue({
        map: r,
        transparent: !0,
        depthTest: !1,
        depthWrite: !1,
      });
      return { canvas: n, map: r, mesh: this.mesh(i, e, t) };
    }
    imageMesh(e, t, n) {
      let r = I(new G()),
        i = I(1),
        a = new Ue({ transparent: !0, depthTest: !1, depthWrite: !1 });
      ((a.colorNode = r), (a.opacityNode = wa(xt(e.map)).mul(i)));
      let o = this.mesh(a, t, n),
        s = { ...e, mesh: o, color: r, opacity: i, ...this.coverage(o, e.map) };
      return (this.artwork.push(s), s);
    }
    coverage(e, t) {
      let n = I(new Pt(0, 0, 1, 1)),
        r = I(0);
      e.userData.uiBounds = n;
      let i = wt.mul(this.viewport).sub(n.xy).div(n.zw),
        a = i.x
          .greaterThanEqual(0)
          .and(i.x.lessThanEqual(1))
          .and(i.y.greaterThanEqual(0))
          .and(i.y.lessThanEqual(1)),
        o = wa(xt(t, R(i.x, i.y.oneMinus())).setUpdateMatrix(!0));
      return { visibility: r, coverage: gt(a, o, 0).mul(r) };
    }
    configure() {
      let e = this.settings.ui,
        t = this.cursorPaint;
      ((this.signatureStrength.value = U.clamp(e.signaturePostStrength, 0, 1)),
        t.color.value.set(e.cursorColor),
        (t.follow.value = +!!e.cursorFollowSparkles),
        (t.brightness.value = e.cursorBrightness));
      let n = Math.max(0.5, e.cursorDotSize / 2);
      ((t.dotRadius.value = n),
        (t.dotQuad.value = 2 * (n + Ia)),
        La.set(e.cursorDotColor).getRGB(Ra, D),
        t.dotColor.value.set(Ra.r, Ra.g, Ra.b),
        (t.dotOpacity.value = U.clamp(e.cursorDotOpacity, 0, 1)),
        (this.signature.mesh.visible = e.signatureVisible),
        (this.signature.opacity.value = e.signatureOpacity),
        (this.signatureLink.hidden =
          !e.signatureVisible || e.signatureOpacity <= 0),
        this.updatePointerVisibility(),
        this.onChange());
    }
    async loadArtwork() {
      let e = await Sa(`mesq-main.png`);
      if (this.disposed) {
        e.map.dispose();
        return;
      }
      ((this.signature = this.imageMesh(e, `Mesq signature`, 2)),
        (this.postProtection = this.signature.coverage.mul(
          this.signatureStrength.oneMinus(),
        )));
    }
    place(e, t, n) {
      ((this.width = t),
        (this.height = n),
        (this.framed = !!e),
        (this.cursorPaint.framed.value = +!!e),
        this.viewport.value.set(t, n));
      let r = (this.rect = e ?? { x: 0, y: 0, width: t, height: n });
      ba(this.camera, t, n);
      let i = this.settings.ui,
        a = Math.min(r.width, r.height),
        o = Math.max(8, i.margin * Math.min(1, a / 576)),
        s = Math.min(i.signatureSize * Math.min(1, a / 500), r.width * 0.45),
        c = Math.min(n - 12, r.y + r.height - o);
      if (this.signature) {
        let e = s,
          a = e / this.signature.aspect,
          l = U.clamp(
            r.x + r.width - o - e - i.signatureX,
            Math.max(8, r.x + 8),
            Math.max(8, Math.min(t - 8, r.x + r.width - 8) - e),
          ),
          u = U.clamp(
            c - a - i.signatureY,
            Math.max(8, r.y + 8),
            Math.max(8, Math.min(n - 8, r.y + r.height - 8) - a),
          );
        ((this.signature.rect = { x: l, y: u, width: e, height: a }),
          this.position(this.signature.mesh, this.signature.rect));
        let d = Math.max(44, e + 16),
          f = Math.max(44, a + 16),
          p = {
            x: U.clamp(
              l + (e - d) / 2,
              Math.max(0, r.x),
              Math.min(t, r.x + r.width) - d,
            ),
            y: U.clamp(
              u + (a - f) / 2,
              Math.max(0, r.y),
              Math.min(n, r.y + r.height) - f,
            ),
            width: d,
            height: f,
          };
        Object.assign(this.signatureLink.style, {
          left: `${p.x}px`,
          top: `${p.y}px`,
          width: `${p.width}px`,
          height: `${p.height}px`,
        });
        let m = this.context(this.signatureFocus, d, f);
        ((m.strokeStyle = i.signatureColor),
          (m.lineWidth = 1.2),
          m.setLineDash([3, 4]),
          m.strokeRect(2, 2, d - 4, f - 4),
          (this.signatureFocus.map.needsUpdate = !0),
          this.position(this.signatureFocus.mesh, p));
      }
      (this.updatePointerVisibility(), this.onChange());
    }
    position(e, t) {
      (e.position.set(
        t.x + t.width / 2 - this.width / 2,
        this.height / 2 - t.y - t.height / 2,
        0,
      ),
        e.scale.set(t.width, t.height, 1),
        e.userData.uiBounds?.value.set(t.x, t.y, t.width, t.height));
    }
    context(e, t, n) {
      ((e.canvas.width !== Math.ceil(t * 2) ||
        e.canvas.height !== Math.ceil(n * 2)) &&
        e.map.dispose(),
        (e.canvas.width = Math.ceil(t * 2)),
        (e.canvas.height = Math.ceil(n * 2)));
      let r = e.canvas.getContext(`2d`);
      return (r.scale(2, 2), r);
    }
    hover() {
      this.onChange();
    }
    trackPointer(e) {
      let t = this.pointer,
        n = e.target,
        r = t.visible;
      ((t.x = e.clientX),
        (t.y = e.clientY),
        (t.surface =
          e.pointerType !== `touch` && !n?.closest?.(`.cup-controls`)),
        (t.theme = !!n?.closest?.(`.theme-canvas`)),
        this.updatePointerVisibility(),
        t.visible && !r && (t.snap = !0),
        this.onChange());
    }
    updatePointerVisibility() {
      let e = this.settings.ui.cursorEnabled;
      ((this.pointer.visible = this.pointer.surface && e),
        document.documentElement.classList.contains(`painted-cursor`) !== e &&
          document.documentElement.classList.toggle(`painted-cursor`, e));
    }
    clearPointer() {
      this.pointer.surface =
        this.pointer.visible =
        this.pointer.down =
        this.pointer.theme =
          !1;
    }
    studyQuad(e) {
      let t = e.mesh,
        n = t.scale.x;
      return (
        (za.x = t.position.x - n / 2 + this.width / 2),
        (za.y = this.height / 2 - t.position.y - n / 2),
        (za.size = n),
        (za.visible = t.visible && this.themes.visible),
        za
      );
    }
    nearStudy(e, t) {
      let n = this.themes?.visible ? this.themes.studies : Ba;
      for (let r = 0; r < n.length; r++) {
        let i = this.studyQuad(n[r]);
        if (
          i.visible &&
          e + 7 > i.x &&
          e - 7 < i.x + i.size &&
          t + 7 > i.y &&
          t - 7 < i.y + i.size
        )
          return !0;
      }
      return !1;
    }
    update(e, t) {
      let n = this.settings.ui;
      this.signatureFocus.mesh.visible =
        !this.signatureLink.hidden && Aa(this.signatureLink);
      let r =
        !this.signatureLink.hidden &&
        (this.signatureHovered || this.signatureFocus.mesh.visible);
      (this.exposure !== this.settings.scene.exposure ||
        this.signatureInk !== n.signatureColor ||
        this.signatureHighlight !== r ||
        this.signatureHoverBrightness !== n.textHoverBrightness) &&
        ((this.exposure = this.settings.scene.exposure),
        (this.signatureInk = n.signatureColor),
        (this.signatureHighlight = r),
        (this.signatureHoverBrightness = n.textHoverBrightness),
        Ki(
          n.signatureColor,
          this.exposure,
          this.signature.color.value,
        ).multiplyScalar(r ? n.textHoverBrightness : 1));
      let i = this.pointer,
        a = this.canvas.dataset.cup,
        o = a === `held` || i.down,
        s = a === `hover` || a === `held` || i.theme,
        c =
          n.cursorSize *
          (o ? n.cursorPressedScale : s ? n.cursorHoverScale : 1),
        l = o ? -0.3 : this.canvas.classList.contains(`dragging`) ? 0.35 : 0.08,
        u = this.reducedMotion || i.snap,
        d = u ? 1 : 1 - Math.exp(-n.cursorResponse * e);
      (i.visible && (i.snap = !1),
        (i.size += (c - i.size) * d),
        (i.engaged += (+!!s - i.engaged) * d),
        (i.press += (+!!o - i.press) * d),
        (i.tilt += (l - i.tilt) * d));
      let f = this.cursorPaint;
      ((f.opacity.value = U.lerp(
        U.clamp(n.cursorIdleOpacity, 0, 1),
        1,
        i.engaged,
      )),
        (f.lift.value = 1 + Math.max(0, n.cursorHoverLightness) * i.engaged),
        (f.exposure.value = this.settings.scene.exposure),
        f.pointer.value.set(i.x, i.y));
      let p = this.dance,
        m = t - p.time;
      p.time = t;
      let h = s && !o && !this.reducedMotion && n.cursorDance > 0 && i.visible;
      ((p.ramp = u
        ? +!!h
        : U.clamp(
            p.ramp + (h ? e / ja.in : -e / (o ? ja.press : ja.out)),
            0,
            1,
          )),
        (p.phase =
          p.ramp === 0
            ? 0
            : (p.phase + (m * Math.max(0, n.cursorDanceSpeed)) / 2) % 1),
        (p.ramp > 0 || h) && this.onChange());
      let g = this.reducedMotion ? 1 : 1 + Math.sin(t * 2.4) * n.cursorPulse,
        _ = i.size * g,
        v = p.ramp * p.ramp * (3 - 2 * p.ramp),
        y = v * Math.max(0, n.cursorDance),
        b = p.phase * Math.PI * 2,
        x = Math.sin(b),
        S = Math.cos(2 * b),
        C = this._box;
      ((C.width = C.height = _),
        (C.x = i.x - _ / 2 + x * ja.step * y * _),
        (C.y = i.y - _ / 2 - S * ja.hop * y * _),
        (f.size.value = _),
        this.position(this.cursor, C),
        (this.cursor.rotation.z = i.tilt * (1 - v) + x * ja.tilt * y));
      let w = S * ja.squash * y;
      ((this.cursor.scale.x *= 1 - w),
        (this.cursor.scale.y *= (1 + w) * (1 - 0.2 * i.press)),
        this.studyStar.position.copy(this.cursor.position),
        this.studyStar.scale.copy(this.cursor.scale),
        (this.studyStar.rotation.z = this.cursor.rotation.z));
      let T = f.dotQuad.value;
      ((C.x = i.x - T / 2),
        (C.y = i.y - T / 2),
        (C.width = C.height = T),
        this.position(this.dot, C));
      let E = this.rect,
        D =
          !this.framed ||
          (i.x + 35 > E.x &&
            i.x - 35 < E.x + E.width &&
            i.y + 35 > E.y &&
            i.y - 35 < E.y + E.height),
        O =
          !this.framed ||
          (i.x - 35 > E.x &&
            i.x + 35 < E.x + E.width &&
            i.y - 35 > E.y &&
            i.y + 35 < E.y + E.height);
      ((this.cursor.visible = i.visible && D),
        (this.studyStar.visible = i.visible && this.nearStudy(i.x, i.y)),
        (this.dot.visible = i.visible && !O));
      for (let e of this.artwork)
        e.visibility.value = e.mesh.visible ? e.opacity.value : 0;
    }
    renderOverlay(e) {
      if (!this.dot.visible && !this.studyStar.visible) return;
      let t = this.themes?.studies ?? Ba;
      for (let e = 0; e < t.length; e++) {
        let n = this.studyQuad(t[e]);
        this.studyQuads[e].value.set(n.x, n.y, n.size, +!!n.visible);
      }
      va(e, () => e.render(this.overlayScene, this.camera));
    }
    compile(e) {
      let t = this.scene.children,
        n = this.overlayScene.children,
        r = t.map((e) => e.visible),
        i = n.map((e) => e.visible);
      (t.forEach((e) => {
        e.visible = !0;
      }),
        n.forEach((e) => {
          e.visible = !0;
        }));
      try {
        return Promise.all([
          e.compileAsync(this.scene, this.camera),
          va(e, () => e.compileAsync(this.overlayScene, this.camera)),
        ]);
      } finally {
        (t.forEach((e, t) => {
          e.visible = r[t];
        }),
          n.forEach((e, t) => {
            e.visible = i[t];
          }));
      }
    }
    dispose() {
      ((this.disposed = !0), this.clearPointer());
      for (let e of this.cleanups) e();
      this.signatureLink.remove();
      for (let e of this.scene.children) e.material.dispose();
      for (let e of this.overlayScene.children) e.material.dispose();
      (document.documentElement.classList.remove(`painted-cursor`),
        this.signatureFocus.map.dispose());
      for (let e of this.artwork) e.map.dispose();
      this.geometry.dispose();
    }
  },
  Ha = new G(),
  Ua = { r: 0, g: 0, b: 0 };
function Wa(e, t, n, r) {
  Ha.set(e);
  let i = (n * t) / 0.6,
    a = [Ha.r * i, Ha.g * i, Ha.b * i],
    o = Mi.map((e) => zi(e[0] * a[0] + e[1] * a[1] + e[2] * a[2])),
    s = Ni.map((e) => U.clamp(e[0] * o[0] + e[1] * o[1] + e[2] * o[2], 0, 1));
  return (
    Ha.setRGB(s[0], s[1], s[2], oe).getRGB(Ua, D),
    r.set(Ua.r, Ua.g, Ua.b)
  );
}
var Ga = [
    [`base`, `table.concept.base`, 1.15],
    [`dark`, `table.concept.dark`, 0.95],
    [`light`, `table.concept.light`, 1.15],
    [`shadow`, `shadowPaint.color`, 1.1],
    [`jelly`, `liquid.attenuationColor`, 1.1],
    [`cream`, `cream.color`, 1.05],
    [`creamShade`, `cream.shade`, 1],
    [`creamGlow`, `cream.glowColor`, 1.05],
  ],
  Ka = (e, t) => t.split(`.`).reduce((e, t) => e?.[t], e),
  qa = {
    P4: { rim: 0.4, foot: 0.74, top: 0.29, bottom: 0.215, cream: 0.63 },
    P7: { rim: 0.27, foot: 0.77, top: 0.215, bottom: 0.16, cream: 0.6 },
  },
  Ja = (e) => {
    let t = new Map();
    for (let n of e.pieces) t.set(n.type, (t.get(n.type) ?? 0) + 1);
    return [...t.entries()]
      .sort((e, t) => t[1] - e[1])
      .map(([e]) => e)
      .slice(0, 3);
  },
  Ya = { P4: Ja(Dr), P7: Ja(Or) },
  Xa = (e) => Ya[e.contents.package] ?? Ya.P4,
  Za = (e) => qa[e.contents.package] ?? qa.P4,
  Qa =
    `seed.edgeRoughness.bristles.flecks.edgeDarken.corner.edgeNoiseScale.edgeOctaves.edgeLacunarity.edgeGain.edgeDisplacement.edgeTilt.edgeOverlap.deckle.deckleScale.edgeWidth.bristleReach.bristleLength.bristleDensity.bristleScale.bristleAngleJitter.fleckSize.fleckSpread.cornerRandom.cornerTL.cornerTR.cornerBL.cornerBR.edgeDarkenWidth.paperColor.styleStrength.strokeLength.strokeWidth.strokeDensity.strokeAngle.smear.speckle.speckleSize`.split(
      `.`,
    ),
  $a = Ga.map(([, e]) => e.split(`.`));
function eo(e, t) {
  let n = 0,
    r = !1,
    i = (e) => {
      (Object.is(e, t[n]) || ((t[n] = e), (r = !0)), n++);
    };
  (i(e.scene.exposure), i(e.contents.package));
  for (let t = 0; t < $a.length; t++) {
    let n = e;
    for (let e of $a[t]) n = n?.[e];
    i(n);
  }
  let a = Xa(e);
  for (let t = 0; t < a.length; t++) i(e.fruits.types[a[t]]?.color);
  i(e.table.concept.variation);
  for (let t = 0; t < Qa.length; t++) i(e.post[Qa[t]]);
  return r;
}
var to = 0.16,
  no = 5,
  ro = 44,
  io = 56,
  ao = 24,
  oo = 14;
function so(e) {
  let t = {
    rt: I(new w(1, 1)),
    side: I(64),
    half: I(32),
    margin: I(10),
    dpr: I(1),
    edgeScale: I(0.25),
    cornerRadius: I(4),
    corners: I(new Pt(1, 1, 1, 1)),
    variation: I(1),
    paper: I(new B(0.97, 0.96, 0.94)),
    strokeLength: I(12),
    strokeWidth: I(4),
    drag: I(0.3),
    strokeAngle: I(0),
    speckle: I(1),
    speckleSize: I(1),
    seed: I(e * 7.7),
    shape: I(new Pt(0.3, 0.75, 0.25, 0.2)),
    creamTop: I(0.62),
  };
  for (let e of [
    ...Ga.map(([e]) => e),
    `fruit1`,
    `fruit2`,
    `fruit3`,
    `upper`,
    `lower`,
  ])
    t[e] = I(new B());
  for (let e of [
    `roughness`,
    `bristles`,
    `flecks`,
    `edgeDarken`,
    `edgeNoiseScale`,
    `edgeOctaves`,
    `edgeLacunarity`,
    `edgeGain`,
    `edgeDisplacement`,
    `edgeTilt`,
    `edgeOverlap`,
    `deckle`,
    `deckleScale`,
    `edgeWidth`,
    `bristleReach`,
    `bristleLength`,
    `bristleDensity`,
    `bristleScale`,
    `bristleAngle`,
    `fleckSize`,
    `fleckSpread`,
    `cornerRandom`,
    `edgeDarkenWidth`,
  ])
    t[e] = I(1);
  return t;
}
function co(e) {
  let t = (t) => {
    let n = e.seed,
      r = K(t.mul(1.7), R(n.mul(0.37), 0.5)).add(
        K(t.mul(3.9), R(2.3, n.mul(0.21))).mul(0.35),
      ),
      i = t.x.sub(t.y).mul(0.7).add(r.mul(0.6)),
      a = W(e.base).toVar();
    (a.assign(
      V(a, e.upper, z(-0.15, 0.6, i).mul(e.variation.mul(0.55).clamp(0, 0.65))),
    ),
      a.assign(
        V(
          a,
          e.lower,
          z(-0.15, -0.75, i).mul(e.variation.mul(0.38).clamp(0, 0.45)),
        ),
      ));
    let o = e.shape.y,
      s = t.sub(R(0.36, o.add(0.02))).mul(R(1 / 0.32, 10)),
      c = z(1, 0.3, Ft(s).add(K(t.mul(9), 4.1).mul(0.2)));
    a.assign(V(a, e.shadow, c.mul(0.42)));
    let l = e.shape.x,
      u = e.shape.z,
      d = e.shape.w,
      f = t.y.sub(l).div(o.sub(l)),
      p = V(u, d, f.clamp(0, 1)),
      m = at(t.x.sub(0.5)).sub(p),
      h = H(0.075),
      g = Ft(M(R(m, t.y.sub(o)).add(h), 0)).sub(h),
      _ = M(M(m, l.sub(t.y)), gt(t.y.greaterThan(o.sub(h)), g, t.y.sub(o))).add(
        K(t.mul(11), n.add(7.3)).mul(0.012),
      ),
      v = z(0.014, -0.01, _),
      y = V(V(a, e.paper, 0.2), e.jelly, 0.38).toVar(),
      b = l.add(e.creamTop).mul(0.5),
      x = e.creamTop.sub(l),
      S = (e, n, r, i) =>
        z(
          r,
          r.mul(0.5),
          Ft(t.sub(R(e, n)).mul(R(1, 1.1))).add(
            K(t.mul(15), i).mul(r.mul(0.4)),
          ),
        );
    (y.assign(
      V(
        y,
        V(e.fruit2, e.jelly, 0.22),
        S(H(0.5).add(u.mul(0.4)), b.add(x.mul(0.12)), u.mul(0.42), 23.4).mul(
          0.85,
        ),
      ),
    ),
      y.assign(
        V(
          y,
          V(e.fruit1, e.jelly, 0.34),
          S(H(0.5).sub(u.mul(0.38)), b.sub(x.mul(0.05)), u.mul(0.44), 11.1).mul(
            0.9,
          ),
        ),
      ),
      y.assign(
        V(
          y,
          V(e.fruit3, e.jelly, 0.22),
          S(H(0.5).add(u.mul(0.05)), b.add(x.mul(0.28)), u.mul(0.36), 31.7).mul(
            0.8,
          ),
        ),
      ),
      y.assign(
        V(
          y,
          V(e.fruit1, e.jelly, 0.38),
          S(H(0.5).add(u.mul(0.12)), b.sub(x.mul(0.3)), u.mul(0.3), 41.9).mul(
            0.75,
          ),
        ),
      ));
    let C = e.creamTop.add(K(R(t.x.mul(7), 2.9), n).mul(0.015)),
      w = z(C.sub(0.006), C.add(0.012), t.y),
      T = V(e.cream, e.creamGlow, 0.3);
    y.assign(
      V(y, V(T, e.creamShade, z(C.add(0.02), o.add(0.02), t.y).mul(0.45)), w),
    );
    let E = at(
      Ft(t.sub(R(0.5, l.add(0.005))).mul(R(H(1).div(u), 1 / 0.045))).sub(1),
    );
    return (
      y.assign(V(y, e.paper, z(0.24, 0.06, E).mul(0.5))),
      a.assign(V(a, y, v)),
      a
    );
  };
  return Oe(() => {
    let n = Je(),
      r = R(n.x, n.y.oneMinus()).mul(e.rt).sub(e.margin).toVar(),
      i = r.sub(e.half).toVar(),
      a = H(0.75).div(e.dpr),
      o = Mt(e.strokeAngle),
      s = fe(e.strokeAngle),
      c = i.x.mul(o).add(i.y.mul(s)),
      l = i.y.mul(o).sub(i.x.mul(s)),
      u = Rt(
        l
          .add(K(R(c.mul(0.06), 1.3), e.seed).mul(e.strokeWidth.mul(0.5)))
          .div(e.strokeWidth),
      ),
      d = K(R(c.div(e.strokeLength), u.mul(1.71)), e.seed.mul(3.1))
        .mul(e.strokeLength)
        .mul(e.drag),
      f = r.add(R(o, s).mul(d)),
      p = f.div(e.side),
      m = p.add(
        R(K(p.mul(3.1), e.seed.add(5.2)), K(p.mul(3.1), e.seed.add(9.4))).mul(
          0.018,
        ),
      ),
      h = t(m).toVar();
    {
      let n = e.speckleSize.mul(2.1),
        i = r.div(n),
        a = Rt(i),
        o = sn(a.add(e.seed.mul(3.3))),
        s = sn(a.add(e.seed.mul(1.7)).add(71.1)),
        c = tn(a.add(5.5)),
        l = nn(r, e.seed),
        u = Xt(i, s, c),
        d = P(o, e.speckle.mul(l).mul(0.55)).mul(u),
        p = c.x.mul(Math.PI * 2),
        m = n.mul(o.mul(3).add(1.2)),
        g = t(f.add(R(Mt(p), fe(p)).mul(m)).div(e.side));
      h.assign(V(h, g, d));
    }
    {
      let t = on(r, e.speckleSize, e.seed, e.dpr);
      h.assign(V(h, cn(h, t), ze(e.speckle.mul(0.7), 0, 1)));
    }
    let g = P(0, i.x),
      _ = P(0, i.y),
      v = sn(R(g, _).add(e.seed.mul(1.37))),
      y = V(V(e.corners.x, e.corners.y, g), V(e.corners.z, e.corners.w, g), _),
      b = e.cornerRadius
        .mul(y)
        .mul(v.sub(0.5).mul(0.9).mul(e.cornerRandom).add(1.05))
        .clamp(0, e.half.mul(0.4)),
      x = at(i).sub(e.half).add(b),
      S = Ft(M(x, 0))
        .add(ee(M(x.x, x.y), 0))
        .sub(b),
      C = (t, n) => {
        let r = n.add(e.seed.mul(7.31)),
          i = t.mul(e.edgeNoiseScale).div(e.edgeScale),
          a = H(0).toVar(),
          o = H(0.004),
          s = e.edgeDisplacement;
        for (let t = 0; t < no; t++) {
          let n = e.edgeOctaves.sub(t).clamp(0, 1);
          (a.addAssign(
            K(W(i.mul(o), r.add(3.3 * t), 0))
              .mul(s)
              .mul(n),
          ),
            (o = o.mul(e.edgeLacunarity)),
            (s = s.mul(e.edgeGain)));
        }
        let c = sn(R(r, 5.1))
            .sub(0.5)
            .mul(e.edgeTilt)
            .mul(t.div(M(e.half, 1))),
          l = z(0.3, 0.62, K(W(i.mul(0.0065), r.add(21.7), 0))).mul(
            e.edgeOverlap,
          ),
          u = z(-0.25, 0.45, K(W(i.mul(0.0085), r.add(13.1), 0)));
        return { shift: a.add(c).add(l).mul(e.edgeScale), dry: u };
      },
      w = C(i.x, P(0, i.y).add(1)),
      T = C(i.y, P(0, i.x).add(3)),
      E = z(-3, 3, x.x.sub(x.y)),
      D = V(w.shift, T.shift, E),
      O = V(w.dry, T.dry, E),
      k = i.mul(e.deckleScale),
      A = K(W(k.mul(0.3), 31.1))
        .mul(2.4)
        .add(K(W(k.mul(0.85), 47.3)).mul(1))
        .mul(e.deckle),
      j = S.sub(D.add(A.mul(0.75)).mul(e.roughness)).toVar(),
      te = K(i.mul(0.003), e.seed.mul(2.9).add(17.7)).mul(e.bristleAngle),
      N = Mt(te),
      F = fe(te),
      ne = i.x.mul(N).sub(i.y.mul(F)).div(e.bristleLength),
      re = i.x.mul(F).add(i.y.mul(N)).div(e.bristleScale),
      ie = K(R(i.x.mul(0.016), i.y.mul(0.29)), 11.3)
        .mul(0.5)
        .add(K(i.mul(0.45), 51.7).mul(0.15)),
      ae = K(R(ne.mul(0.045), re.mul(0.8)), R(83.1, 0)),
      oe = K(R(ne.mul(0.016), re.mul(0.36)), R(71.3, 0))
        .mul(0.55)
        .add(ae.mul(0.3))
        .add(ie.mul(0.25))
        .add(e.bristleDensity.sub(0.5).mul(1.6)),
      I = e.bristles
        .mul(e.bristleReach)
        .mul(V(1.5, 10, O))
        .mul(V(0.45, 1, E))
        .mul(e.edgeScale),
      se = j.negate().add(oe.mul(I)).toVar(),
      ce = z(a.negate(), a, se),
      le = ze(se.div(M(I.mul(0.8).mul(e.edgeWidth), 1)), 0, 1),
      ue = V(z(-0.7, 0.5, ae).mul(0.5).add(0.5), H(1), le),
      de = ce.mul(V(H(1), ue, ze(e.bristles, 0, 1).mul(O))),
      pe = Ge(M(se, 0).div(e.edgeDarkenWidth.max(0.05).negate())).mul(ce),
      me = M(e.fleckSize.mul(0.8), 1).mul(9),
      he = r.div(me),
      B = Rt(he),
      ge = tn(B.add(e.seed.mul(17.1)))
        .mul(0.4)
        .add(0.3),
      _e = sn(B.add(91.7)).mul(0.1).add(0.05).mul(me).mul(e.fleckSize).min(1.6),
      ve = Ft(Ce(he).sub(ge).mul(R(0.65, 1))).mul(me),
      ye = z(1.5, 3, j).mul(
        H(1).sub(
          z(
            e.edgeScale.mul(10).mul(e.fleckSpread),
            e.edgeScale.mul(26).mul(e.fleckSpread),
            j,
          ),
        ),
      ),
      be = e.flecks
        .mul(ye)
        .mul(z(0.05, 0.55, K(r.mul(0.02), e.seed.mul(5.3).add(61.3))))
        .mul(0.45),
      xe = H(1)
        .sub(P(be, sn(B.add(e.seed.mul(3.1)).add(7.3))))
        .mul(H(1).sub(z(_e.sub(a), _e.add(a), ve)));
    return (
      h.assign(h.mul(H(1).sub(pe.mul(e.edgeDarken)))),
      L(ze(h, 0, 1), M(de, xe))
    );
  })();
}
var lo = class {
    constructor({
      renderer: e,
      settings: t,
      presets: n,
      valuesOf: r,
      onChoose: i,
      onChange: a,
      reducedMotion: o = !1,
    }) {
      (Object.assign(this, {
        renderer: e,
        settings: t,
        valuesOf: r,
        onChange: a,
        reducedMotion: o,
      }),
        (this.ids = Object.keys(n)),
        (this.scene = new jt()),
        (this.camera = ya()),
        (this.geometry = new Ve(1, 1)),
        (this.width = this.height = 1),
        (this.ratio = 1),
        (this.visible = !1),
        (this.active = this.chosen = this.ids[0]),
        (this.cleanups = []),
        (this.group = document.createElement(`div`)),
        (this.group.className = `theme-canvases`),
        this.group.setAttribute(`role`, `group`),
        this.group.setAttribute(`aria-label`, `Theme`),
        (this.group.hidden = !0),
        (this.studies = this.ids.map((e, t) => {
          let r = document.createElement(`button`);
          ((r.type = `button`),
            (r.className = `theme-canvas`),
            (r.dataset.preset = e),
            (r.textContent = n[e].label),
            r.setAttribute(`aria-label`, n[e].label),
            r.setAttribute(`aria-pressed`, `false`),
            this.group.append(r));
          let a = {
            id: e,
            index: t,
            button: r,
            hovered: !1,
            focused: !1,
            lift: 0,
            rect: null,
            signature: [],
            size: ``,
            dirty: !0,
          };
          (this.listen(r, `click`, () => i(e)),
            this.listen(r, `pointerenter`, (e) => {
              e.pointerType !== `touch` && ((a.hovered = !0), this.onChange());
            }),
            this.listen(r, `pointerleave`, () => {
              ((a.hovered = !1), this.onChange());
            }),
            this.listen(r, `focus`, () => this.onChange()),
            this.listen(r, `blur`, () => this.onChange()),
            (a.u = so(t)),
            (a.target = new k(1, 1, {
              type: De,
              depthBuffer: !1,
              generateMipmaps: !1,
              minFilter: _e,
              magFilter: _e,
            })),
            (a.target.texture.name = `Theme canvas · ${n[e].label}`));
          let o = new It();
          ((o.name = `Theme canvas paint · ${n[e].label}`),
            (o.fragmentNode = co(a.u)),
            (o.blending = 0),
            (o.depthTest = o.depthWrite = !1),
            (a.quad = new Qe(o)),
            (a.opacity = I(1)),
            (a.brightness = I(1)));
          let s = new It();
          s.name = `Theme canvas · ${n[e].label}`;
          let c = xt(a.target.texture, Je());
          return (
            (s.fragmentNode = L(
              c.rgb.mul(a.brightness).clamp(0, 1),
              c.a.mul(a.opacity),
            )),
            (s.transparent = !0),
            (s.depthTest = s.depthWrite = !1),
            (a.mesh = new kt(this.geometry, s)),
            (a.mesh.name = s.name),
            (a.mesh.frustumCulled = !1),
            (a.mesh.visible = !1),
            this.scene.add(a.mesh),
            a
          );
        })),
        document.body.append(this.group));
    }
    listen(e, t, n, r) {
      (e.addEventListener(t, n, r),
        this.cleanups.push(() => e.removeEventListener(t, n, r)));
    }
    sync({ active: e, chosen: t = e }) {
      ((this.active = e),
        (this.chosen = t),
        t === e
          ? this.group.removeAttribute(`aria-busy`)
          : this.group.setAttribute(`aria-busy`, `true`));
      for (let e of this.studies)
        e.button.setAttribute(`aria-pressed`, String(e.id === t));
      this.onChange();
    }
    place(e, t, n, r) {
      ((this.width = t),
        (this.height = n),
        (this.ratio = r),
        ba(this.camera, t, n));
      let i = this.settings.ui,
        a = e && i.miniVisible ? this.layout(e, t, n) : null;
      ((this.visible = !!a), (this.group.hidden = !a));
      for (let [e, t] of this.studies.entries()) {
        if (((t.rect = a?.[e] ?? null), (t.mesh.visible = !!t.rect), !t.rect))
          continue;
        let n = t.rect;
        Object.assign(t.button.style, {
          left: `${n.x}px`,
          top: `${n.y}px`,
          width: `${n.width}px`,
          height: `${n.height}px`,
        });
        let i = `${n.width}@${r}`;
        i !== t.size && ((t.size = i), (t.dirty = !0));
      }
      this.configure();
    }
    layout(e, t, n) {
      let r = this.settings.ui,
        i = this.studies.length,
        a = Math.min(e.width, e.height),
        o = Math.max(io, r.miniSize * a),
        s = Math.max(ao, r.miniGap * a),
        c = (e) => Math.round(Math.max(10, e * 0.28)),
        l = (e) => i * e + (i - 1) * c(e),
        u = (e, t) => Math.min(o, e - ao, (t - 28) / (i + (i - 1) * 0.28)),
        d = U.clamp,
        f = u(e.x - oo, n);
      if (f >= ro) {
        let t = d(Math.min(s, e.x - oo - f) + r.miniX, ao, e.x - oo - f),
          i = l(f),
          o = d(e.y + e.height - i - a * 0.06 - r.miniY, oo, n - oo - i);
        return this.studies.map((n, r) =>
          this.snap({
            x: e.x - t - f,
            y: o + r * (f + c(f)),
            width: f,
            height: f,
          }),
        );
      }
      let p = n - oo - (e.y + e.height);
      if (((f = u(p, t)), f >= ro)) {
        let n = d(Math.min(s, p - f) - r.miniY, ao, p - f),
          i = l(f),
          a = d(e.x + e.width / 2 - i / 2 - r.miniX, oo, t - oo - i);
        return this.studies.map((t, r) =>
          this.snap({
            x: a + r * (f + c(f)),
            y: e.y + e.height + n,
            width: f,
            height: f,
          }),
        );
      }
      return null;
    }
    snap(e) {
      let t = this.ratio,
        n = (e) => Math.round(e * t) / t,
        r = n(e.width);
      return { x: n(e.x), y: n(e.y), width: r, height: r };
    }
    configure() {
      for (let e of this.studies) {
        let t = this.valuesOf(e.id);
        (eo(t, e.signature) && (e.dirty = !0), (e.values = t));
      }
      this.onChange();
    }
    update(e) {
      if (!this.visible) return;
      let t = this.studies.find((e) => e.id === this.active);
      t &&
        eo(this.settings, t.signature) &&
        ((t.values = this.settings), (t.dirty = !0), this.onChange());
      let n = this.settings.ui,
        r = this.reducedMotion ? 1 : 1 - Math.exp(-24 * e);
      for (let e of this.studies) {
        if (!e.rect) continue;
        e.focused = Aa(e.button);
        let t = e.hovered || e.focused ? 1 : 0,
          i = e.lift;
        ((e.lift += (t - e.lift) * r),
          Math.abs(t - e.lift) < 0.002 && (e.lift = t),
          e.lift !== i && this.onChange());
        let a = e.id === this.chosen ? 1 : U.clamp(n.miniInactiveOpacity, 0, 1);
        ((e.opacity.value = U.lerp(
          a,
          Math.max(a, Math.min(1, a + 0.25)),
          e.lift,
        )),
          (e.brightness.value = U.lerp(
            1,
            Math.max(0, n.miniHoverBrightness),
            e.lift,
          )));
        let o = e.rect,
          s = Math.round(o.width * to * this.ratio) / this.ratio,
          c = Math.round(2 * e.lift * this.ratio) / this.ratio,
          l = o.x - s,
          u = o.y - s - c,
          d = o.width + 2 * s;
        (e.mesh.position.set(
          l + d / 2 - this.width / 2,
          this.height / 2 - u - d / 2,
          0,
        ),
          e.mesh.scale.set(d, d, 1));
      }
    }
    setUniforms(e) {
      let { u: t, values: n } = e,
        r = n.post,
        i = e.rect.width,
        a = Math.round(i * to * this.ratio) / this.ratio;
      ((t.side.value = i),
        (t.half.value = i / 2),
        (t.margin.value = a),
        (t.dpr.value = this.ratio),
        t.rt.value.set(i + 2 * a, i + 2 * a));
      for (let [e, r, i] of Ga) Wa(Ka(n, r), n.scene.exposure, i, t[e].value);
      Xa(n).forEach((e, r) =>
        Wa(
          n.fruits.types[e]?.color ?? `#ffffff`,
          n.scene.exposure,
          1.05,
          t[`fruit${r + 1}`].value,
        ),
      );
      let o = (e) => 0.2126 * e.x + 0.7152 * e.y + 0.0722 * e.z,
        s = o(t.light.value) >= o(t.dark.value);
      (t.upper.value.copy(s ? t.light.value : t.dark.value),
        t.lower.value.copy(s ? t.dark.value : t.light.value));
      let c = Za(n);
      (t.shape.value.set(c.rim, c.foot, c.top, c.bottom),
        (t.creamTop.value = c.cream),
        Ha.set(r.paperColor).getRGB(Ua, D),
        t.paper.value.set(Ua.r, Ua.g, Ua.b),
        (t.variation.value = n.table.concept.variation),
        (t.edgeScale.value = U.clamp(i / 2 / 420, 0.3, 1.3)),
        (t.cornerRadius.value = (2 + 10 * r.corner) * Math.max(0.2, i / 700)),
        t.corners.value.set(r.cornerTL, r.cornerTR, r.cornerBL, r.cornerBR),
        (t.seed.value = r.seed + 13.37 * (e.index + 1)));
      for (let [e, n] of Object.entries({
        roughness: `edgeRoughness`,
        bristles: `bristles`,
        flecks: `flecks`,
        edgeDarken: `edgeDarken`,
        edgeNoiseScale: `edgeNoiseScale`,
        edgeOctaves: `edgeOctaves`,
        edgeLacunarity: `edgeLacunarity`,
        edgeGain: `edgeGain`,
        edgeDisplacement: `edgeDisplacement`,
        edgeTilt: `edgeTilt`,
        edgeOverlap: `edgeOverlap`,
        deckle: `deckle`,
        deckleScale: `deckleScale`,
        edgeWidth: `edgeWidth`,
        bristleReach: `bristleReach`,
        bristleLength: `bristleLength`,
        bristleDensity: `bristleDensity`,
        bristleScale: `bristleScale`,
        fleckSize: `fleckSize`,
        fleckSpread: `fleckSpread`,
        cornerRandom: `cornerRandom`,
        edgeDarkenWidth: `edgeDarkenWidth`,
      }))
        t[e].value = r[n];
      ((t.edgeOctaves.value = U.clamp(r.edgeOctaves, 0, no)),
        (t.edgeNoiseScale.value = Math.max(0.05, r.edgeNoiseScale)),
        (t.edgeLacunarity.value = Math.max(1, r.edgeLacunarity)));
      for (let e of [
        `deckleScale`,
        `edgeWidth`,
        `bristleLength`,
        `bristleScale`,
        `fleckSize`,
        `fleckSpread`,
      ])
        t[e].value = Math.max(0.05, t[e].value);
      ((t.bristleAngle.value = U.degToRad(r.bristleAngleJitter)),
        (t.edgeDarken.value = r.frame ? r.edgeDarken : 0));
      let l = i / 520;
      ((t.strokeWidth.value = U.clamp(r.strokeWidth * l, 2.5, 9)),
        (t.strokeLength.value = U.clamp(r.strokeLength * 0.8 * l, 6, 40)),
        (t.drag.value =
          0.08 +
          0.45 * U.clamp(r.strokeDensity, 0, 1) +
          0.2 * U.clamp(r.smear, 0, 1)),
        (t.strokeAngle.value = U.degToRad(r.strokeAngle)),
        (t.speckle.value = Math.max(
          0,
          r.speckle * U.clamp(r.styleStrength, 0, 4),
        )),
        (t.speckleSize.value = U.clamp(r.speckleSize, 0.3, 6)));
    }
    render(e) {
      if (!this.visible) return;
      let t = e.getRenderTarget();
      try {
        for (let t of this.studies) {
          if (!t.dirty || !t.rect || !t.values) continue;
          ((t.dirty = !1), this.setUniforms(t));
          let n = Math.max(1, Math.round(t.u.rt.value.x * this.ratio));
          (t.target.setSize(n, n),
            e.setRenderTarget(t.target),
            t.quad.render(e));
        }
      } finally {
        e.setRenderTarget(t);
      }
      va(e, () => e.render(this.scene, this.camera));
    }
    compile(e) {
      let t = this.studies.map((e) => e.mesh.visible),
        n = e.getRenderTarget(),
        r = [];
      try {
        for (let t of this.studies)
          (e.setRenderTarget(t.target),
            r.push(e.compileAsync(t.quad, t.quad.camera)));
        for (let e of this.studies) e.mesh.visible = !0;
        r.push(va(e, () => e.compileAsync(this.scene, this.camera)));
      } finally {
        (e.setRenderTarget(n),
          this.studies.forEach((e, n) => {
            e.mesh.visible = t[n];
          }));
      }
      return Promise.all(r);
    }
    dispose() {
      for (let e of this.cleanups) e();
      this.group.remove();
      for (let e of this.studies)
        (e.quad.material.dispose(),
          e.mesh.material.dispose(),
          e.target.dispose());
      this.geometry.dispose();
    }
  },
  uo = document.querySelector(`canvas.threejs`),
  fo = new URLSearchParams(location.search),
  po = `star-apple-runtime-v1`,
  J = l(),
  mo = null,
  ho =
    mo?.revision === 2 && mo.tweaks && typeof mo.tweaks == `object`
      ? mo
      : { revision: 2, preset: null, device: null, tweaks: {} },
  Y = { id: n(fo.get(`preset`)) ?? (m(ho.preset) ? ho.preset : `pink`) },
  go = !(fo.has(`set`) || fo.has(`post`) || fo.has(`dpr`)),
  _o = null,
  vo = null,
  yo = null,
  bo = !1,
  xo = 0,
  So = 0,
  Co = null;
function wo() {
  let e = fo.get(`post`);
  ((e === `0` || e === `off`) && (J.post.enabled = !1),
    e === `noframe` && (J.post.frame = !1),
    fo.has(`dpr`) &&
      ((J.scene.pixelRatio = Math.min(
        3,
        Math.max(0.5, Number(fo.get(`dpr`)) || 1),
      )),
      (J.scene.autoQuality = !1)),
    r(J, fo.get(`set`)));
}
function To(e, n = J) {
  return (
    t(n, e),
    ho.tweaks[e] && a(n, ho.tweaks[e]),
    ho.device && a(n, ho.device),
    n
  );
}
(To(Y.id), wo(), configureAppleDefaults(J));
var Eo = 0,
  Do = () => ({ ...J, revision: 2, presets: { content: Y.id, look: Y.id } });
function Oo(e, t) {
  let n = null;
  for (let [r, i] of Object.entries(e)) {
    let e = t?.[r];
    if (typeof i == `object` && i && !Array.isArray(i)) {
      let t = Oo(i, e);
      t && ((n ??= {})[r] = t);
    } else
      JSON.stringify(i) !== JSON.stringify(e) &&
        ((n ??= {})[r] = structuredClone(i));
  }
  return n;
}
function ko() {
  ((ho.preset = Y.id),
    (ho.device = {
      scene: Object.fromEntries(u.scene.map((e) => [e, J.scene[e]])),
    }));
  let t = Oo(J, o(p[Y.id].file));
  if (t) for (let e of Object.keys(u)) for (let n of u[e]) delete t[e]?.[n];
  ((ho.tweaks[Y.id] =
    t && Object.values(t).some((e) => Object.keys(e).length) ? t : null),
    e.write(po, ho));
}
var Ao = () => {
    go && (clearTimeout(Eo), (Eo = setTimeout(ko, 250)));
  },
  jo =
    matchMedia(`(prefers-reduced-motion: reduce)`).matches ||
    fo.get(`motion`) === `reduce`,
  Mo = fo.has(`still`),
  No = { width: Math.max(1,innerWidth), height: Math.max(1,innerHeight) },
  Po = {
    fps: 60,
    frameMs: 0,
    drawCalls: 0,
    triangles: 0,
    passes: 0,
    pixelRatio: 1,
    msaa: ``,
    renderer: ``,
    assets: ``,
    liquid: ``,
    package: ``,
    switchMs: 0,
    firstFrame: 0,
    ready: {},
  };
_(`renderer`);
var X = new Be({
  canvas: uo,
  antialias: !1,
  powerPreference: `high-performance`,
  forceWebGL: fo.has('vr') || fo.get(`renderer`) === `webgl` || !navigator.gpu || (fo.get(`renderer`) !== `webgpu` && /iPhone|iPad|iPod/.test(navigator.userAgent)),
});
((X.shadowMap.enabled = !0), (X.shadowMap.type = 1), (X.toneMapping = 4));
var Fo =
    matchMedia(`(pointer: coarse)`).matches ||
    Math.min(screen.width, screen.height) < 600,
  Io = Fo && !fo.has(`dpr`) ? 1.5 : 1 / 0,
  Lo = Fo ? 0.75 : 1,
  Ro = 1 / 0,
  zo = () => Math.min(devicePixelRatio || 1, J.scene.pixelRatio, Io),
  Bo = () => Math.min(zo(), J.scene.autoQuality ? Ro : 1 / 0);
(X.setPixelRatio(Bo()),
  X.setSize(No.width, No.height),
  await X.init(),
  (Po.renderer = X.backend.isWebGPUBackend ? `WebGPU` : `WebGL 2`));
var Vo = new jt();
Vo.matrixWorldAutoUpdate = !1;
var Ho = new Ze(J.camera.fov, No.width / No.height, 0.02, 10),
  Uo = Bn(Vo, X, J),
  Z = new In(X, Vo, Ho, J.post);
(_(`assets`), (Ct.onProgress = (e, t, n) => v(t / n)));
var Wo = await new Mn({ mapVariant: Cn(fo.get(`maps`)) }).load(
  J.contents.package,
);
_(`scene`);
var Q = new _r({
    assets: Wo,
    settings: J,
    pipeline: Z,
    environment: Uo.environment,
  }),
  $ = new si({ cup: Q, assets: Wo, settings: J, environment: Uo }),
  Go = new Vi(J),
  Ko = new Si({ assets: Wo, settings: J, backdrop: Go }),
  qo = new ji(J.sparkles, { cup: Q.referenceExtras });
Vo.add(Go.mesh, Q.root, Ko.mesh, qo.sprite);
var Jo = Promise.resolve(!1);
function Yo(e, t) {
  ($.setPackage(e),
    Ko.setCaster({ root: Q.root, extras: Q.extras, lid: Q.lid?.mesh ?? null }),
    (Po.package = `${e.id} ${hn[e.id]?.label ?? ``} · ${e.source ?? ``} · ${(performance.now() - t).toFixed(1)} ms`));
}
function Xo() {
  let e = J.contents.package;
  if (e === Q.packageId && $.packageId === e) return !0;
  let t = performance.now(),
    n = Q.show(e);
  return n
    ? (Yo(n, t), !0)
    : ((Jo = Jo.then(async () => {
        let e = J.contents.package;
        if (bo || (e === Q.packageId && $.packageId === e)) return !1;
        let n = await Q.setPackage(e);
        return !n || bo ? !1 : (Yo(n, t), ds(), Ao(), !0);
      }).catch(
        (e) => (console.warn(`The cup package could not be switched.`, e), !1),
      )),
      !1);
}
{
  let e = performance.now(),
    t = await Q.setPackage(J.contents.package);
  if (!t)
    throw Error(`The cup package ${J.contents.package} could not be built.`);
  Yo(t, e);
}
$.init({ reducedMotion: jo });
var Zo = new Qi({
  camera: Ho,
  canvas: uo,
  settings: J,
  extras: Q.referenceExtras,
});
Po.assets = [Wo.describe(), Ko.describe()].join(`, `).replaceAll(
  `, `,
  `
`,
);
var Qo = fo.has(`nointeraction`)
  ? null
  : ma({
      canvas: uo,
      camera: Ho,
      controls: Zo.controls,
      cup: Q,
      settings: J,
      reducedMotion: jo,
      onHover: () => vo?.hover(),
    });
function $o() {
  (Uo.update(),
    (X.toneMappingExposure = J.scene.exposure),
    (Vo.environmentIntensity = J.scene.environment),
    Q.configure(Uo.keyDirection(), J.scene.environment),
    $.configure(J.scene.environment),
    Go.configure(Uo.keyDirection()),
    Ko.configure(),
    qo.configure(),
    es(),
    (Uo.key.shadow.needsUpdate = !0));
}
function es() {
  J.contents.package === $.packageId &&
    ($.applyLiquid(Uo.keyDirection(), J.scene.environment),
    (Po.liquid = Q.liquid.source),
    $.liquidActive !== Z.liquid && os());
}
function ts() {
  (Xo(), $.apply(), es(), Zo.setSubject(ns()) && Zo.frame());
}
function ns() {
  let e = Q.extras,
    t = Q.lidTop();
  return {
    top:
      Number.isFinite(t) && Math.abs(t - Q.referenceExtras.lidTopY) > 0.002
        ? t
        : null,
    radius:
      Math.max(Number(e.rimRadius) || 0, Number(e.lidRadius) || 0) || null,
  };
}
var rs = Fo && !fo.has(`dpr`) ? 1 : 1 / 0,
  is = () =>
    J.scene.antialias && zo() <= Math.min(J.scene.msaaMaxRatio, rs) + 1e-6;
function as() {
  (Z.configure({ antialias: is(), liquid: $.liquidActive }),
    (Po.msaa = Z.antialias ? `4×` : `off`));
}
function os() {
  (as(), fs());
}
function ss() {
  ((J.cup.scale = Math.min(1.15, Math.max(0.9, J.cup.scale))),
    Q.place(),
    (Uo.key.shadow.needsUpdate = !0));
}
var cs = ``;
function ls(e = !1) {
  let t = JSON.stringify(J.sparkles);
  (e || t !== cs) &&
    ((cs = t),
    qo.build(J.sparkles.count, 5),
    Vo.add(qo.sprite),
    qo.configure());
}
var us = ``;
function ds() {
  (ss(), Xo(), $o(), ts(), as(), X.getPixelRatio() !== Bo() && fs(), ls());
  let e = JSON.stringify(J.camera);
  (e === us ? Zo.configure() : ((us = e), (Ho.fov = J.camera.fov), Zo.frame()),
    gs(),
    _o?.refreshQuietly(),
    sc());
}
function fs() {
  if(window.questJelly?.active)return;
  // Embedded comparison frames can briefly report zero size while navigating.
  if(innerWidth<1 || innerHeight<1)return;
  ((No.width = innerWidth), (No.height = innerHeight));
  let e = Bo();
  (X.getPixelRatio() !== e && X.setPixelRatio(e),
    (Po.pixelRatio = e),
    is() !== Z.antialias && as(),
    X.setSize(No.width, No.height),
    Z.resize(),
    Zo.resize(No.width, No.height),
    gs(),
    xs.hold(),
    sc());
}
((vo = new Va({
  canvas: uo,
  settings: J,
  sparkles: qo,
  postfx: Z.postfx,
  onChange: cc,
  reducedMotion: jo,
})),
  (Z.ui = vo),
  await vo.ready,
  Z.postfx.setUIProtection(vo.postProtection));
var ps = new Map();
function ms(e) {
  if (e === Y.id) return J;
  let t =
      JSON.stringify(ho.tweaks[e] ?? null) + JSON.stringify(ho.device ?? null),
    n = ps.get(e);
  return (
    n?.key !== t && ps.set(e, (n = { key: t, values: To(e, l()) })),
    n.values
  );
}
((yo = new lo({
  renderer: X,
  settings: J,
  presets: p,
  valuesOf: ms,
  onChoose: (e) => {
    (e !== Y.id || Co) && Ss(e);
  },
  onChange: cc,
  reducedMotion: jo,
})),
  (Z.overlay = yo),
  vo.setThemes(yo));
var hs = document.querySelector(`.social-links`);
hs && document.body.append(hs);
function gs() {
  let e = J.post,
    t = e.enabled && e.frame ? Z.postfx.frameRect() : null;
  (vo.place(t, No.width, No.height),
    vo.configure(),
    yo.place(t, No.width, No.height, X.getPixelRatio()),
    _s());
}
var _s = () => yo.sync({ active: Y.id, chosen: Co?.id ?? Y.id }),
  vs = null;
function ys() {
  (bs(), fs());
}
function bs() {
  (vs?.removeEventListener(`change`, ys),
    (vs = matchMedia(`(resolution: ${devicePixelRatio || 1}dppx)`)),
    vs.addEventListener(`change`, ys));
}
var xs = {
  until: 0,
  slow: 0,
  hold(e = 2e3) {
    ((this.until = performance.now() + e), (this.slow = 0));
  },
  sample(e) {
    !J.scene.autoQuality ||
      performance.now() < this.until ||
      ((this.slow = e < 45 ? this.slow + 1 : 0),
      !(this.slow < 2 || Bo() <= Lo) &&
        ((Ro = Math.max(Lo, Bo() - 0.25)), (this.slow = 0), os()));
  },
};
(bs(),
  (us = JSON.stringify(J.camera)),
  ss(),
  $o(),
  ts(),
  os(),
  ls(),
  Zo.frame());
function Ss(e, t = {}) {
  if (!m(e)) return Promise.resolve(!1);
  let n = Vs(e, !0);
  if (!n.done) {
    let r = (Co = { id: e });
    return (
      _s(),
      n.promise.then(() => (Co !== r || bo ? !1 : ((Co = null), Cs(e, t), !0)))
    );
  }
  return ((Co = null), Cs(e, t), Promise.resolve(!0));
}
function Cs(e, { tweaks: n = !0 } = {}) {
  let r = performance.now();
  (e !== Y.id && go && Eo && (clearTimeout(Eo), ko()),
    (Y.id = e),
    n ? To(e) : t(J, e),
    wo(),
    ds(),
    (go = !0),
    g(e),
    Ao(),
    xs.hold(),
    sc(),
    (Po.switchMs = Number((performance.now() - r).toFixed(2))));
}
window.addEventListener(`resize`, fs);
var ws = () => location.hash === `#debug`,
  Ts = 0,
  Es = ws(),
  Ds = (e, t) => {
    let n = Object.assign(document.createElement(`a`), {
      href: URL.createObjectURL(new Blob([t], { type: `application/json` })),
      download: e,
    });
    (n.click(), setTimeout(() => URL.revokeObjectURL(n.href), 1e3));
  },
  Os = async (e, t) => {
    try {
      return (await navigator.clipboard.writeText(e), !0);
    } catch {
      return (Ds(t, e), !1);
    }
  },
  ks = () => JSON.stringify(Do(), null, 2),
  As = (e) => structuredClone(o(p[Y.id].file)[e] ?? null);
async function js(e) {
  let t = o(e);
  if (!Object.keys(t).length) return !1;
  let n = c(e) ?? d(t, Y.id).id;
  return (
    await Vs(n, !0).promise,
    !bo &&
      ((Co = null), Cs(n, { tweaks: !1 }), a(J, t), ds(), Ao(), p[Y.id].label)
  );
}
var Ms = {
  visual: () => {
    ($o(), Ao());
  },
  liquid: () => {
    (es(), Ao());
  },
  rendering: () => {
    ((Ro = 1 / 0), os(), Ao());
  },
  cup: () => {
    (ss(), Zo.follow(), Ko.configure(), Ao());
  },
  camera: () => {
    (Zo.setSubject(ns()), Zo.frame(), (us = JSON.stringify(J.camera)), Ao());
  },
  orbit: () => {
    (Zo.configure(), Ao());
  },
  save: Ao,
  post: () => {
    (gs(), Ao());
  },
  ui: () => {
    (gs(), Ao(), sc());
  },
  contents: () => {
    (ts(), Ao());
  },
  shake: () => Qo?.shake?.(),
  nudge: () => $.nudge(1.5),
  sparkles: (e) => {
    e?.last !== !1 && (ls(!0), Ao());
  },
  resetView: () => Zo.frame(),
  saveView: () => {
    (Zo.saveView(), (us = JSON.stringify(J.camera)), Ao());
  },
  preset: (e) => Ss(e),
  resetPreset: () => {
    ((ho.tweaks[Y.id] = null), Cs(Y.id, { tweaks: !1 }));
  },
  defaults: () => {
    ((ho.tweaks = {}), (ho.device = null));
    for (let [e, t] of Object.entries(u)) {
      let n = i(e);
      for (let r of t) J[e][r] = n[r];
    }
    ((Ro = 1 / 0), Ss(h, { tweaks: !1 }));
  },
  copy: () => Os(ks(), `jelly-painting-settings.json`),
  download: () => Ds(`jelly-painting-settings.json`, ks()),
  paste: async () => {
    let e = null;
    try {
      e = await navigator.clipboard.readText();
    } catch {
      e = prompt(
        `Paste a settings JSON (the panel's "Copy settings JSON" or a preset file):`,
      );
    }
    try {
      return e ? await js(JSON.parse(e)) : !1;
    } catch (e) {
      return (console.warn(`Paste settings JSON: not a settings JSON.`, e), !1);
    }
  },
};
async function Ns() {
  let e = ++Ts;
  if (!Es) {
    _o && (_o.hidden = _o.disabled = !0);
    return;
  }
  if (_o) {
    _o.hidden = _o.disabled = !1;
    return;
  }
  let [{ createControls: t }, n] = await Promise.all([
    x(() => import(`./Controls-CCUdmDEh.js`), __vite__mapDeps([0, 1, 2, 3])),
    Is(),
  ]);
  if (bo || e !== Ts) return;
  let r = {
    lab: n,
    get variant() {
      return Wo.mapVariant;
    },
    apply: (e) => Fs.then(() => Wo.setMapVariant(e)).then(sc),
  };
  ((_o = await t({
    settings: J,
    stats: Po,
    actions: Ms,
    view: Zo,
    contents: $,
    table: Ko,
    preset: Y,
    postfx: Z.postfx,
    interaction: Qo,
    ghosts: Z.ghosts,
    presetValues: As,
    maps: r,
  })),
    bo && _o.dispose());
}
var Ps,
  Fs = new Promise((e) => {
    Ps = e;
  });
async function Is() {
  if (!Wo.available(`textures/lab/lab.json`)) return null;
  try {
    return await (await fetch(`/star-knot-jelly/mr/jelly-painting/textures/lab/lab.json`)).json();
  } catch {
    return null;
  }
}
function Ls() {
  ws() !== Es && ((Es = !Es), Ns());
}
(window.addEventListener(`hashchange`, Ls), Ns());
var Rs = new Map();
Rs.set(J.contents.package, {
  promise: Promise.resolve(),
  done: !0,
  urgent: !1,
});
var zs = () =>
    new Promise((e) =>
      (window.requestIdleCallback ?? ((e) => setTimeout(e, 40)))(() => e(), {
        timeout: 400,
      }),
    ),
  Bs = () => new Promise((e) => requestAnimationFrame(() => e()));
function Vs(e, t = !1) {
  let n = To(e, l()),
    r = n.contents.package,
    i = Rs.get(r);
  return i
    ? ((i.urgent ||= t), i)
    : ((i = { done: !1, urgent: t }),
      (i.promise = Hs(r, n, i)
        .catch((t) =>
          console.warn(
            `The ${p[e].label} preset could not be prepared ahead.`,
            t,
          ),
        )
        .finally(() => {
          ((i.done = !0), (Po.ready[r] = Math.round(performance.now())));
        })),
      Rs.set(r, i),
      i);
}
async function Hs(e, t, n) {
  let r = () => (n.urgent ? Bs() : zs());
  if ((await Wo.packageModel(e), bo)) return;
  let i = Wo.packageInfo(e),
    a = Q.prepare(e);
  for (let n of $.prepare(i, t))
    if ((await r(), bo || e === $.packageId)) return;
  let o = await a;
  o && !bo && (await Ws(o.id));
}
function Us() {
  return Promise.resolve(); // Independent apple scene: no unrelated theme prewarming.

  for (let e of s) e !== Y.id && Vs(e);
}
function Ws(e) {
  if (bo || e === Q.packageId) return Promise.resolve();
  let t = [Q.warm(e), $.warm(e)],
    n;
  try {
    n = Z.compileAsync();
  } finally {
    for (let e of t.reverse()) e();
  }
  return n.catch((e) =>
    console.warn(`The other preset could not be compiled ahead.`, e),
  );
}
var Gs = { a: new B(), b: new B(), radius: 0.05 },
  Ks = [Gs];
function qs() {
  if(window.questJelly?.active && J.jelly.freeBody)return [];
  let { top: e, radius: t } = Q.occluder;
  return (
    Gs.a.setFromMatrixPosition(Q.root.matrixWorld),
    Gs.b.set(0, e, 0).applyMatrix4(Q.root.matrixWorld),
    (Gs.radius = t * Q.root.scale.x * 1.08 + 0.004),
    Ks
  );
}
var Js = performance.now(),
  Ys = 0,
  Xs = 0,
  Zs = 0,
  Qs = 0,
  $s = 0,
  ec = 0,
  tc = 0,
  nc = 90,
  rc = 45,
  ic = () => (vo.cursor.visible || vo.studyStar.visible ? rc : nc),
  ac = () => Mo || (!jo && J.sparkles.enabled && J.sparkles.twinkle > 0),
  oc = !0;
function sc() {
  So = xo = performance.now();
}
function cc() {
  xo = performance.now();
}
var lc = !1,
  uc = (e) => {
    ((xo = performance.now()),
      e.pointerType && (lc = e.pointerType !== `touch`),
      (e.type !== `pointermove` ||
        e.buttons ||
        e.target?.closest?.(`.cup-controls`)) &&
        (So = xo));
  };
for (let e of [`pointerdown`, `pointermove`, `wheel`, `keydown`])
  window.addEventListener(e, uc, { passive: !0 });
((true) &&
  (window.jellyCup = {
    settings: J,
    assets: Wo,
    actions: Ms,
    stats: Po,
    cup: Q,
    contents: $,
    renderer: X,
    view: Zo,
    camera: Ho,
    scene: Vo,
    pipeline: Z,
    table: Ko,
    backdrop: Go,
    sparkles: qo,
    sceneUI: vo,
    themeCanvases: yo,
    presets: p,
    selectPreset: Ss,
    prepareOthers: Us,
    applySettingsJson: js,
    settingsJson: Do,
    baseSettings: () => l(),
    get preset() {
      return Y.id;
    },
    get fruits() {
      return $.fruits;
    },
    get jelly() {
      return $.jelly;
    },
    get interaction() {
      return Qo;
    },
    get pane() {
      return _o;
    },
    get frames() {
      return Qs;
    },
  }),
  window.appleStudy = await installApple(window.jellyCup, {
    Mesh: kt, Geometry: ht, Attribute: it, Vector3: B, Vector2: w, Color: G, Group: We,
    StandardMaterial: Le, BasicMaterial: Ue, uniform: I, vec3: W, vec4: L, uv: Je, mix: V,
    texture: xt, normalView: ae, normalLocal: le, transformNormal: E,
    environment: Uo, makeGlass: hr, glassUniforms: qt, configureGlass: Wt,
    fruitMaterial: Tr, fruitLook: yr, fruitType: xr, normalFactory: Gt,
    notify: sc, refresh: $o, save: Ao
  }),
  vo.update(0, 0),
  _(`compile`),
  await Z.compileAsync().catch((e) =>
    console.warn(`The scene could not be compiled ahead.`, e),
  ),
  _(`frames`),
  X.setAnimationLoop(window.__desktopLoop = () => {
    if (bo || window.questJelly?.active) return;
    let e = performance.now(),
      t = (e - Js) / 1e3;
    if (((Js = e), !document.hidden))
      try {
        let n = Math.min(t, 1 / 20);
        Mo || (Ys += n);
        let r = Zo.update(n);
        (Qo?.update?.(n),
          Go.update(Ho),
          Vo.updateMatrixWorld(),
          window.appleStudy?.beforeUpdate?.(n),
          $.update(n, Ys, { cupState: Qo?.state ?? null }),
          window.appleStudy?.update(n, Ys),
          vo.update(n, Ys),
          yo.update(n));
        let i = r || Qo?.state.moving || $.moving || window.appleStudy?.moving || e - So < 500 || Qs < 3,
          a = e - xo < 500;
        oc &&= i;
        let o = !0;
        if (i) tc = 3;
        else if (tc > 0) tc--;
        else if (!(ac() && e - ec >= ic())) {
          if (a) o = !Z.keepsScene;
          else return;
        }
        (o &&
          ((ec = e),
          Ko.update(Q, Uo.key),
          qo.update(jo ? 0 : Ys),
          qo.setOccluders(
            qs(),
            0.3 * Ho.position.distanceTo(Zo.controls.target),
          ),
          Vo.updateMatrixWorld()),
          Z.render(o, a && lc),
          Qs++,
          Qs === 2 &&
            ((Po.firstFrame = Math.round(performance.now())),
            b(),
            xs.hold(),
            zs()
              .then(() => {
                if (!bo) return Us();
              })
              .catch((e) =>
                console.warn(`The other preset could not be pre-built.`, e),
              )
              .finally(Ps)),
          ($s += performance.now() - e),
          Xs++,
          (Zs += t),
          Zs >= 0.5 &&
            ((Po.fps = Math.round(Xs / Zs)),
            (Po.frameMs = Number(($s / Xs).toFixed(2))),
            (Po.drawCalls = X.info.render.drawCalls),
            (Po.triangles = X.info.render.triangles),
            (Po.passes = Z.stats.passes),
            oc && xs.sample(Po.fps),
            (Xs = 0),
            (Zs = 0),
            ($s = 0),
            (oc = !0)));
      } catch (e) {
        (console.error(`The cup scene failed to render.`, e),
          X.setAnimationLoop(null),
          y());
      }
  }));
if (fo.has('vr')) {
  import('/star-knot-jelly/mr/src/vr/main.js').then(async ({installQuestVR}) => {
    // The desktop's second frame completes the shared loading overlay. Do
    // not let an immediate VR/preview start skip that ready transition.
    while(Qs<2)await new Promise(requestAnimationFrame);
    window.questJelly=installQuestVR(window.jellyCup,window.appleStudy,{
      advance(dt,time){
        Vo.updateMatrixWorld(true);
        window.appleStudy.beforeUpdate?.(dt);
        $.update(dt,time,{cupState:null});
        window.appleStudy.update(dt,time);
        Ko.update(Q,Uo.key);qo.update(time);qo.setOccluders([],.008);
        Vo.updateMatrixWorld(true);
      },
      renderEye(target){
        // RTT and blur nodes cache by frameId. Each eye needs its own update,
        // even when both views are submitted inside the same XR callback.
        X._nodes.nodeFrame.frameId++;
        Go.update(Ho);Vo.updateMatrixWorld(true);
        Z.renderScene(false);Z.postfx.update();X.setRenderTarget(target);
        Z.output.render();
        const framebuffer=X.backend.state.currentBoundFramebuffers[X.getContext().DRAW_FRAMEBUFFER];
        X.setRenderTarget(null);Qs++;return framebuffer;
      },
      resume(){Js=performance.now();X.setAnimationLoop(window.__desktopLoop);fs();sc();},
    });
  }).catch(error=>{console.error('Quest VR adapter failed',error);document.body.insertAdjacentHTML('beforeend','<p role="alert">VR 模块未加载，请刷新重试。</p>');});
}
function dc() {
  if (!bo) {
    ((bo = !0),
      X.setAnimationLoop(null),
      clearTimeout(Eo),
      vo.dispose(),
      yo.dispose());
    for (let e of [`pointerdown`, `pointermove`, `wheel`, `keydown`])
      window.removeEventListener(e, uc);
    (window.removeEventListener(`resize`, fs),
      window.removeEventListener(`hashchange`, Ls),
      vs?.removeEventListener(`change`, ys),
      window.removeEventListener(`pagehide`, dc),
      Qo?.dispose?.(),
      Zo.dispose(),
      _o?.dispose(),
      qo.dispose(),
      $.dispose(),
      Q.dispose(),
      Ko.dispose(),
      Go.dispose(),
      Wo.dispose(),
      Z.dispose(),
      Uo.dispose(),
      X.dispose());
  }
}
(window.addEventListener(`pagehide`, dc, { once: !0 }),
  window.addEventListener(`pageshow`, (e) => {
    e.persisted && bo && location.reload();
  }));
