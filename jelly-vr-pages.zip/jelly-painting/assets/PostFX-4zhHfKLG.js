import { p as e } from "./presets-Dsv3aenh.js";
import {
  $ as t,
  A as n,
  An as r,
  At as i,
  B as a,
  Bn as o,
  Bt as s,
  C as c,
  Ct as l,
  D as u,
  Dt as d,
  E as f,
  Et as p,
  F as m,
  Ft as h,
  G as g,
  Gt as _,
  H as v,
  Ht as y,
  I as b,
  It as x,
  J as S,
  Jt as C,
  Kt as w,
  L as T,
  Ln as E,
  Lt as D,
  M as O,
  Mn as k,
  Mt as A,
  N as j,
  Nn as M,
  Nt as N,
  O as P,
  On as F,
  Ot as I,
  P as L,
  Pn as ee,
  Pt as R,
  R as te,
  S as ne,
  Sn as re,
  St as z,
  T as ie,
  Tt as ae,
  U as B,
  Ut as V,
  V as oe,
  Vt as H,
  W as se,
  X as ce,
  Y as le,
  Z as ue,
  _t as de,
  b as fe,
  bt as pe,
  c as me,
  ct as he,
  d as ge,
  et as _e,
  g as ve,
  gt as ye,
  ht as be,
  it as xe,
  j as Se,
  jn as U,
  jt as Ce,
  k as we,
  ln as Te,
  lt as Ee,
  mt as W,
  nt as De,
  o as Oe,
  ot as ke,
  p as Ae,
  pt as je,
  q as Me,
  qt as G,
  r as Ne,
  rt as K,
  s as Pe,
  st as Fe,
  tt as Ie,
  u as Le,
  ut as Re,
  vt as ze,
  w as Be,
  wn as Ve,
  wt as He,
  xt as Ue,
  yn as We,
  yt as Ge,
} from "./three-CU5tkW7F.js";
var Ke = Object.defineProperty,
  qe = (e, t, n) =>
    t in e
      ? Ke(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n })
      : (e[t] = n),
  q = (e, t) => Ke(e, `name`, { value: t, configurable: !0 }),
  Je = (e, t, n) => qe(e, typeof t == `symbol` ? t : t + ``, n);
function J(e, t) {
  return (
    e &&
    (typeof e.onChange == `function`
      ? e.onChange(t)
      : typeof e.addEventListener == `function` &&
        e.addEventListener(`change`, (e) => t(e.value)),
    e)
  );
}
q(J, `bindChange`);
function Ye(e) {
  return (e && typeof e.disable == `function` && e.disable(), e);
}
q(Ye, `safeDisable`);
function Xe(e) {
  return (e && typeof e.listen == `function` && e.listen(), e);
}
q(Xe, `safeListen`);
function Ze(e) {
  return (e && typeof e.updateDisplay == `function` && e.updateDisplay(), e);
}
q(Ze, `safeUpdateDisplay`);
function Qe(e) {
  return (
    e &&
      (typeof e.destroy == `function`
        ? e.destroy()
        : e.parent &&
          typeof e.parent.remove == `function` &&
          e.parent.remove(e.paramList || e)),
    null
  );
}
q(Qe, `disposeFolder`);
function $e(e) {
  return (
    typeof e == `object` &&
    !!e &&
    Reflect.get(e, `isNode`) === !0 &&
    typeof Reflect.get(e, `sample`) == `function`
  );
}
q($e, `isViewportBufferNode`);
function et(e) {
  if (!$e(e))
    throw TypeError(
      `Transmission viewport buffers must be sampleable vec4 nodes.`,
    );
  return e;
}
q(et, `requireViewportBufferNode`);
function tt(e) {
  return typeof e == `object` && !!e && Reflect.get(e, `isNode`) === !0;
}
q(tt, `isVec4Node`);
function Y(e, t) {
  if (typeof e != `object` || !e || Reflect.get(e, `isNode`) !== !0)
    throw TypeError(`${t} must be a TSL node.`);
  return e;
}
q(Y, `requireNode`);
function nt(e, t) {
  let n = Reflect.get(e, t);
  if (!tt(n))
    throw TypeError(`Transmission model-matrix column ${t} is unavailable.`);
  return n;
}
q(nt, `matrixColumn`);
function X(e) {
  return Y(j(e, `float`), `Material reference ${e}`);
}
q(X, `materialFloat`);
var rt = X(`chromaticAberration`),
  it = X(`anisotropicBlur`),
  at = X(`distortion`),
  ot = X(`surfaceDistortion`),
  st = X(`distortionScale`),
  ct = X(`temporalDistortion`),
  lt = X(`time`),
  ut = X(`ditherStrength`),
  dt = X(`ditherScale`),
  ft = X(`edgeFade`),
  pt = X(`blurScale`),
  mt = X(`backdropDistance`),
  ht = 1,
  gt = 2.5;
function _t() {
  let e = v.mul(st).toVar(),
    t = e.fwidth().toVar(),
    n = G(0).toVar();
  return (
    y(ot.abs().greaterThan(1e-5), () => {
      let r = Ae.add(lt).mul(ct),
        i = G(r, r.negate(), r.negate()),
        o = t.x.max(t.y).max(t.z).smoothstep(0.25, 0.75).oneMinus(),
        s = Y(me(e.add(i), gt), `Transmission surface noise`);
      n.assign(
        Y(a(s), `Transmission surface noise view transform`).mul(ot.mul(o)),
      );
    }),
    n
  );
}
q(_t, `surfaceDistortionOffsetView`);
var vt = null;
function yt() {
  return (vt === null && (vt = et(c())), vt);
}
q(yt, `getSharedViewportBuffer`);
var bt = H(([e]) => {
    let t = q(
      (e) => e.dot(w(0.06711056, 0.00583715)).fract().mul(52.9829189).fract(),
      `ign`,
    );
    return C(
      t(e),
      t(e.add(w(17, 59))),
      t(e.add(w(43, 23))),
      t(e.add(w(71, 97))),
    );
  }).setLayout({
    name: `ignVec4`,
    type: `vec4`,
    inputs: [{ name: `p`, type: `vec2` }],
  }),
  xt = H(([e, t, n]) => {
    let r = t.abs().toVar(),
      i = e.mul(n).toVar(),
      a = w(i.y, i.z).floor(),
      o = w(i.z, i.x).floor(),
      s = w(i.x, i.y).floor(),
      c = r.x.greaterThanEqual(r.y),
      l = W(c, r.x, r.y),
      u = W(c, r.y, r.x),
      d = W(c, a, o),
      f = W(c, o, a),
      p = l.greaterThanEqual(r.z),
      m = u.greaterThanEqual(r.z),
      h = W(p, d, s),
      g = W(p, W(m, f, s), d),
      _ = W(p, l, r.z),
      v = W(p, W(m, u, r.z), l),
      y = V(0.5773),
      b = V(1).sub(y),
      x = _.sub(y).div(b).clamp(0, 1),
      S = v.sub(y).div(b).clamp(0, 1),
      C = x.add(S).add(1e-5),
      T = bt(h),
      E = bt(g);
    return T.mul(x.div(C)).add(E.mul(S.div(C)));
  }).setLayout({
    name: `biplanarIGNVec4`,
    type: `vec4`,
    inputs: [
      { name: `posWS`, type: `vec3` },
      { name: `n`, type: `vec3` },
      { name: `scale`, type: `float` },
    ],
  }),
  St = H(([e, t, n, r]) => {
    let i = r.greaterThan(0).and(r.lessThan(0x8ac7230489e80000)),
      a = n
        .clamp(1e-4, 1)
        .log()
        .negate()
        .div(r.max(1e-6))
        .mul(t)
        .negate()
        .exp(),
      o = e.mul(a);
    return i.select(o, e);
  }).setLayout({
    name: `applyVolumeAttenuation`,
    type: `vec3`,
    inputs: [
      { name: `radiance`, type: `vec3` },
      { name: `transmissionDistance`, type: `float` },
      { name: `attenuationColor`, type: `vec3` },
      { name: `attenuationDistance`, type: `float` },
    ],
  }),
  Ct = H(([e, t, n]) => {
    let r = n.mul(t.mul(C(e, 1))),
      i = r.w.max(1e-6),
      a = r.xy.div(i).mul(0.5).add(0.5);
    return C(a, 0, r.w);
  }).setLayout({
    name: `worldToScreenPoint`,
    type: `vec4`,
    inputs: [
      { name: `worldPos`, type: `vec3` },
      { name: `view`, type: `mat4` },
      { name: `proj`, type: `mat4` },
    ],
  }),
  wt = H(([e, t, n]) => {
    let r = e.x.mul(t.z.div(n.x)).add(t.x.div(n.x)),
      i = e.y.mul(t.w.div(n.y)).add(t.y.div(n.y));
    return w(r, i);
  }).setLayout({
    name: `remapUVToViewport`,
    type: `vec2`,
    inputs: [
      { name: `uvIn`, type: `vec2` },
      { name: `vp`, type: `vec4` },
      { name: `screenSize`, type: `vec2` },
    ],
  }),
  Tt = q(
    (e) =>
      e
        .mul(e.mul(e.negate().add(3)).sub(3))
        .add(1)
        .mul(1 / 6),
    `bicubicW0`,
  ),
  Et = q(
    (e) =>
      e
        .mul(e.mul(e.mul(3).sub(6)))
        .add(4)
        .mul(1 / 6),
    `bicubicW1`,
  ),
  Dt = q(
    (e) =>
      e
        .mul(e.mul(e.mul(-3).add(3)).add(3))
        .add(1)
        .mul(1 / 6),
    `bicubicW2`,
  ),
  Ot = q((e) => e.pow(3).mul(1 / 6), `bicubicW3`),
  kt = q((e) => Tt(e).add(Et(e)), `bicubicG0`),
  At = q((e) => Dt(e).add(Ot(e)), `bicubicG1`),
  jt = q(
    (e) =>
      Et(e)
        .div(Tt(e).add(Et(e)))
        .sub(1),
    `bicubicH0`,
  ),
  Mt = q(
    (e) =>
      Ot(e)
        .div(Dt(e).add(Ot(e)))
        .add(1),
    `bicubicH1`,
  );
function Nt(e, t) {
  return w(Y(e.size(t), `Transmission buffer size`));
}
q(Nt, `bufferLevelSize`);
function Pt(e, t, n, r, i) {
  let a = t.mul(r).add(0.5).toVar(),
    o = a.floor().toVar(),
    s = a.fract().toVar(),
    c = kt(s.x).toVar(),
    l = At(s.x).toVar(),
    u = jt(s.x).toVar(),
    d = Mt(s.x).toVar(),
    f = jt(s.y).toVar(),
    p = Mt(s.y).toVar(),
    m = w(o.x.add(u), o.y.add(f)).sub(0.5).mul(i),
    h = w(o.x.add(d), o.y.add(f)).sub(0.5).mul(i),
    g = w(o.x.add(u), o.y.add(p)).sub(0.5).mul(i),
    _ = w(o.x.add(d), o.y.add(p)).sub(0.5).mul(i),
    v = e
      .sample(m)
      .level(n)
      .mul(c)
      .add(e.sample(h).level(n).mul(l))
      .mul(kt(s.y)),
    y = e
      .sample(g)
      .level(n)
      .mul(c)
      .add(e.sample(_).level(n).mul(l))
      .mul(At(s.y));
  return v.add(y);
}
q(Pt, `bicubicSampleLevel`);
function Ft(e) {
  let { buffer: r, samples: i, refractionMode: a, ditherAnchor: o } = e;
  return H(() => {
    let e = g.toVar(),
      c = ce.sub(e).normalize().toVar(),
      l = te.normalize().toVar(),
      d = l.dot(c).lessThan(0).select(l.negate(), l).toVar(),
      p = (o === `screen` ? bt(w(Ie.x, Ie.y)) : xt(e, d, dt)).toVar(),
      m = G(
        nt(Me, 0).xyz.length(),
        nt(Me, 1).xyz.length(),
        nt(Me, 2).xyz.length(),
      ).toVar(),
      h = m.mul(e.opticalThickness ?? Se).toVar(),
      b = _(
        nt(Me, 0).xyz.div(m.x),
        nt(Me, 1).xyz.div(m.y),
        nt(Me, 2).xyz.div(m.z),
      ).toVar(),
      x = v.mul(st).toVar(),
      S = x.fwidth().toVar(),
      T = G(0).toVar();
    y(at.abs().greaterThan(1e-5), () => {
      let e = Ae.add(lt).mul(ct),
        t = G(e, e.negate(), e.negate()),
        n = S.x.max(S.y).max(S.z).smoothstep(0.25, 0.75).oneMinus(),
        r = Y(me(x.add(t), gt), `Transmission distortion noise`);
      T.assign(b.mul(r).mul(at.mul(n)));
    });
    let E = n.clamp(0, 1).toVar(),
      O = E.mul(E).toVar(),
      k = G(p.x.sub(0.5), p.y.sub(0.5), p.w.sub(0.5)).mul(2),
      A = d
        .add(k.mul(O.mul(ut).mul(0.35)).add(T))
        .normalize()
        .toVar(),
      j = w(xe.x, xe.y.oneMinus()).toVar(),
      M = j.x
        .min(j.x.oneMinus())
        .min(j.y.min(j.y.oneMinus()))
        .div(ft.max(1e-4))
        .clamp(0, 1)
        .toVar(),
      N = M.mul(M)
        .mul(V(3).sub(M.mul(2)))
        .toVar(),
      F = De.y.mul(nt(ue, 1).y).mul(0.5).toVar(),
      I = C(_e).toVar(),
      L = w(De).toVar(),
      ee = Y(r, `Transmission mip buffer`),
      R = Y(Fe(ee), `Transmission maximum mip level`),
      ne = q((n) => {
        let o = Ce(c.negate(), A, V(1).div(n)).normalize(),
          s = o.mul(h).toVar(),
          l = s.length().toVar(),
          u = e.add(s),
          m = mt.max(0);
        if (a === `slab`) {
          let e = Ce(o, d, n),
            t = e.dot(e).lessThan(1e-6).select(o, e.normalize());
          u = u.add(t.mul(m));
        } else u = u.add(o.mul(m));
        let g = Ct(u, t, ue).toVar(),
          _ = j.add(g.xy.sub(j).mul(N)).clamp(0.001, 0.999).toVar(),
          v = l.add(m).mul(O).div(n).mul(F).div(g.w.max(1e-4)).mul(pt).toVar(),
          b = v.max(1).log2().clamp(0, R).toVar(),
          x = G(0).toVar();
        if (i > 1) {
          let e = b
              .sub(Math.log2(i) * 0.5)
              .max(0)
              .add(p.w)
              .clamp(0, R)
              .floor()
              .toVar(),
            t = w(v).div(L).toVar(),
            n = G(0).toVar();
          for (let a = 0; a < i; a++) {
            let o = p.x.mul(6.2831853).add(a * 2.3999632),
              s = V((a + 0.5) / i).sqrt(),
              c = wt(
                _.add(w(o.cos(), o.sin()).mul(s).mul(t)).clamp(0.001, 0.999),
                I,
                L,
              ).flipY();
            n.addAssign(r.sample(c).level(e).rgb);
          }
          x.assign(n.div(i));
        } else {
          let e = Y(
              Y(b.add(p.w).clamp(0, R), `Transmission dithered mip level`)
                .floor()
                .toInt(),
              `Transmission integer mip level`,
            ).toVar(),
            t = V(e).toVar(),
            n = Nt(r, e).toVar(),
            i = w(1).div(n).toVar(),
            a = wt(_.add(w(p.y, p.z).sub(0.5).mul(i).mul(ut)), I, L)
              .flipY()
              .toVar();
          (x.assign(Pt(r, a, t, n, i).rgb),
            y(it.greaterThan(1e-4), () => {
              let e = g.xy.sub(j),
                n = e.dot(e),
                i = n
                  .greaterThan(1e-12)
                  .select(e.div(n.sqrt()), w(0))
                  .mul(v.max(1))
                  .div(L)
                  .mul(it),
                a = wt(_.add(i).clamp(0.001, 0.999), I, L).flipY(),
                o = wt(_.sub(i).clamp(0.001, 0.999), I, L).flipY();
              x.assign(
                x
                  .mul(2)
                  .add(r.sample(a).level(t).rgb)
                  .add(r.sample(o).level(t).rgb)
                  .mul(0.25),
              );
            }));
        }
        return St(x, l, ie, f);
      }, `sampleChannel`),
      re = P.sub(1)
        .max(0)
        .mul(u.mul(0.025).add(rt.mul(ht)))
        .toVar(),
      z = G(0).toVar();
    y(re.greaterThan(1e-4), () => {
      let e = P.sub(re).max(1),
        t = P.add(re);
      z.assign(G(ne(e).r, ne(P).g, ne(t).b));
    }).Else(() => {
      z.assign(ne(P));
    });
    let ae = d.dot(c).clamp(0, 1).oneMinus().pow(5),
      B = Y(s, `Transmission specular color`),
      oe = B.add(G(E.oneMinus()).max(B).sub(B).mul(ae)),
      H = Y(D.rgb, `Transmission diffuse color`).mul(we.oneMinus());
    return z.mul(H).mul(oe.oneMinus().clamp(0, 1));
  })();
}
q(Ft, `buildTransmissionBackdrop`);
var It = class extends ve {
  constructor(e = {}) {
    (super(),
      Je(this, `_samples`),
      Je(this, `_refractionMode`),
      Je(this, `_ditherAnchor`),
      Je(this, `_viewportBuffer`),
      Je(this, `_backdropBuilt`),
      (this._samples = 1),
      (this._refractionMode = `volume`),
      (this._ditherAnchor = `world`),
      (this._viewportBuffer = null),
      (this._backdropBuilt = !1),
      (this.roughness = 0.42),
      (this.thickness = 0.5),
      (this.transmission = 1),
      (this.isMeshTransmissionNodeMaterial = !0),
      (this.forceSinglePass = !0),
      (this.chromaticAberration = 0.4),
      (this.attenuationDistance = 1 / 0),
      (this.anisotropicBlur = 0),
      (this.time = 0),
      (this.distortion = 0),
      (this.surfaceDistortion = 0),
      (this.distortionScale = 0),
      (this.temporalDistortion = 0),
      (this.ditherStrength = 0.5),
      (this.ditherScale = 128),
      (this.edgeFade = 0.1),
      (this.blurScale = 1),
      (this.backdropDistance = 0),
      this.setValues(e),
      this._viewportBuffer === null && (this._viewportBuffer = yt()),
      (this._backdropBuilt = !0),
      this._rebuildBackdrop(),
      (this.userData.set = {
        chromaticAberration: q(
          (e) => (this.chromaticAberration = e),
          `chromaticAberration`,
        ),
        anisotropicBlur: q(
          (e) => (this.anisotropicBlur = e),
          `anisotropicBlur`,
        ),
        time: q((e) => (this.time = e), `time`),
        distortion: q((e) => (this.distortion = e), `distortion`),
        surfaceDistortion: q(
          (e) => (this.surfaceDistortion = e),
          `surfaceDistortion`,
        ),
        distortionScale: q(
          (e) => (this.distortionScale = e),
          `distortionScale`,
        ),
        temporalDistortion: q(
          (e) => (this.temporalDistortion = e),
          `temporalDistortion`,
        ),
        ditherStrength: q((e) => (this.ditherStrength = e), `ditherStrength`),
        ditherScale: q((e) => (this.ditherScale = e), `ditherScale`),
        edgeFade: q((e) => (this.edgeFade = e), `edgeFade`),
        blurScale: q((e) => (this.blurScale = e), `blurScale`),
        backdropDistance: q(
          (e) => (this.backdropDistance = e),
          `backdropDistance`,
        ),
      }));
  }
  static get type() {
    return `MeshTransmissionNodeMaterial`;
  }
  get useTransmission() {
    return !1;
  }
  setupNormal() {
    return Y(super.setupNormal(), `Transmission shading normal`)
      .add(_t())
      .normalize();
  }
  get samples() {
    return this._samples;
  }
  set samples(e) {
    let t = Math.max(1, Math.floor(e));
    t !== this._samples && ((this._samples = t), this._rebuildBackdrop());
  }
  get refractionMode() {
    return this._refractionMode;
  }
  set refractionMode(e) {
    e !== this._refractionMode &&
      ((this._refractionMode = e), this._rebuildBackdrop());
  }
  get ditherAnchor() {
    return this._ditherAnchor;
  }
  set ditherAnchor(e) {
    e !== this._ditherAnchor &&
      ((this._ditherAnchor = e), this._rebuildBackdrop());
  }
  get viewportBuffer() {
    return this._viewportBuffer;
  }
  set viewportBuffer(e) {
    let t = e == null ? null : et(e);
    t !== this._viewportBuffer &&
      ((this._viewportBuffer = t),
      this._backdropBuilt &&
        this._viewportBuffer === null &&
        (this._viewportBuffer = yt()),
      this._rebuildBackdrop());
  }
  _rebuildBackdrop() {
    this._backdropBuilt === !0 &&
      ((this.backdropNode = Ft({
        buffer: this._viewportBuffer ?? yt(),
        samples: this._samples,
        refractionMode: this._refractionMode,
        ditherAnchor: this._ditherAnchor,
        opticalThickness:this.opticalThicknessNode,
      })),
      (this.backdropAlphaNode = O),
      (this.needsUpdate = !0));
  }
  copy(e) {
    super.copy(e);
    let t = e;
    return (
      t.isMeshTransmissionNodeMaterial === !0 &&
        ((this.chromaticAberration = t.chromaticAberration),
        (this.anisotropicBlur = t.anisotropicBlur),
        (this.time = t.time),
        (this.distortion = t.distortion),
        (this.surfaceDistortion = t.surfaceDistortion),
        (this.distortionScale = t.distortionScale),
        (this.temporalDistortion = t.temporalDistortion),
        (this.ditherStrength = t.ditherStrength),
        (this.ditherScale = t.ditherScale),
        (this.edgeFade = t.edgeFade),
        (this.blurScale = t.blurScale),
        (this.backdropDistance = t.backdropDistance),
        (this._samples = t._samples),
        (this._refractionMode = t._refractionMode),
        (this._ditherAnchor = t._ditherAnchor),
        (this._viewportBuffer = t._viewportBuffer)),
      this
    );
  }
  attachGUI(e) {
    e &&
      ((this._debug = e.addFolder(`Three.js Blocks - Transmission`)),
      J(
        this._debug
          .add(
            { chromaticAberration: this.chromaticAberration },
            `chromaticAberration`,
            0,
            2,
            0.001,
          )
          .name(`Chromatic Aberration`),
        (e) => (this.chromaticAberration = e),
      ),
      J(
        this._debug
          .add(
            { anisotropicBlur: this.anisotropicBlur },
            `anisotropicBlur`,
            0,
            1,
            0.001,
          )
          .name(`Anisotropic Blur`),
        (e) => (this.anisotropicBlur = e),
      ),
      J(
        this._debug
          .add({ blurScale: this.blurScale }, `blurScale`, 0, 4, 0.001)
          .name(`Blur Scale`),
        (e) => (this.blurScale = e),
      ),
      J(
        this._debug
          .add({ edgeFade: this.edgeFade }, `edgeFade`, 0, 0.5, 0.001)
          .name(`Edge Fade`),
        (e) => (this.edgeFade = e),
      ),
      J(
        this._debug
          .add(
            { backdropDistance: this.backdropDistance },
            `backdropDistance`,
            0,
            10,
            0.01,
          )
          .name(`Backdrop Distance`),
        (e) => (this.backdropDistance = e),
      ),
      J(
        this._debug
          .add({ samples: this.samples }, `samples`, 1, 8, 1)
          .name(`Samples`),
        (e) => (this.samples = e),
      ),
      J(
        this._debug
          .add(
            { ditherStrength: this.ditherStrength },
            `ditherStrength`,
            0,
            1,
            0.001,
          )
          .name(`Dither Strength`),
        (e) => (this.ditherStrength = e),
      ),
      J(
        this._debug
          .add({ ditherScale: this.ditherScale }, `ditherScale`, 1, 512, 1)
          .name(`Dither Scale`),
        (e) => (this.ditherScale = e),
      ),
      J(
        this._debug
          .add({ distortion: this.distortion }, `distortion`, 0, 5, 0.001)
          .name(`Distortion`),
        (e) => (this.distortion = e),
      ),
      J(
        this._debug
          .add(
            { surfaceDistortion: this.surfaceDistortion },
            `surfaceDistortion`,
            0,
            2,
            0.001,
          )
          .name(`Surface Distortion`),
        (e) => (this.surfaceDistortion = e),
      ),
      J(
        this._debug
          .add(
            { distortionScale: this.distortionScale },
            `distortionScale`,
            0,
            10,
            0.001,
          )
          .name(`Distortion Scale`),
        (e) => (this.distortionScale = e),
      ),
      J(
        this._debug
          .add(
            { temporalDistortion: this.temporalDistortion },
            `temporalDistortion`,
            0,
            1,
            0.001,
          )
          .name(`Temporal Distortion`),
        (e) => (this.temporalDistortion = e),
      ),
      this._debug.close());
  }
  disposeGUI() {
    return ((this._debug = Qe(this._debug)), this);
  }
  dispose() {
    (super.dispose(), this.disposeGUI());
  }
};
q(It, `MeshTransmissionNodeMaterial`);
var Lt = It;
function Rt({ map: e, strength: t, uvNode: n = he() }) {
  let r = (e) => e.xyz.mul(2).sub(1),
    i = { mapNode: ke(e, n) };
  return {
    normal: H(() => {
      let e = r(i.mapNode),
        n = a(e.normalize()).normalize();
      return I(b, n, t).normalize();
    })(),
    ...i,
  };
}
function zt(e, t) {
  return {
    paintStrength: x(e.paintStrength),
    edge: x(t.edge),
    edgeColor: x(new We(t.edgeColor)),
    streaks: x(t.streaks),
    streakColor: x(new We(t.streakColor)),
    streakStart: x(0.62),
    streakEnd: x(0.9),
    streakPaint: x(t.streakPaint),
    streakSide: x(-1),
    specularAA: x(t.specularAA),
    rimPower: x(t.edgePower),
    haze: x(t.haze),
    hazeColor: x(new We(t.hazeColor)),
    glint: x(t.glint),
    iridescence: x(t.iridescence),
    keyDirection: x(new F(-0.4, 0.8, -0.45)),
  };
}
var Bt = [
  `color`,
  `transmission`,
  `ior`,
  `roughness`,
  `thickness`,
  `chromaticAberration`,
  `dispersion`,
  `anisotropicBlur`,
  `attenuationColor`,
  `attenuationDistance`,
  `envMapIntensity`,
  `specularIntensity`,
];
function Vt(e, t) {
  return {
    transmission: e.transmission,
    color: new We(e.color),
    ior: e.ior,
    thickness: e.thickness,
    roughness: e.roughness,
    chromaticAberration: e.chromaticAberration,
    dispersion: e.dispersion,
    anisotropicBlur: e.anisotropicBlur,
    attenuationColor: new We(e.attenuationColor),
    attenuationDistance: e.attenuationDistance,
    specularIntensity: e.specularIntensity,
    envMap: t,
    envMapIntensity: e.envMapIntensity,
    ditherStrength: 0,
    transparent: !0,
    depthWrite: !0,
    side: 0,
  };
}
function Ht({
  map: e,
  glass: r,
  uniforms: a,
  pipeline: o,
  liquid: s,
  environment: c,
  name: u,
}) {
  let d = Rt({ map: e, strength: a.paintStrength }),
    f = Vt(r, c),
    h = H(() => {
      let e = b,
        n = se,
        r = e.dot(n).abs().oneMinus(),
        o = i(r, a.rimPower).mul(a.edge),
        s = I(
          I(G(1, 0.86, 0.5), a.edgeColor, N(0.62, 0.78, r)),
          G(0.42, 0.45, 1),
          N(0.82, 0.96, r),
        ),
        c = I(a.edgeColor, s, a.iridescence),
        u = I(T, e, a.streakPaint).normalize(),
        d = u.x.mul(a.streakSide),
        f = l(d).mul(1.5),
        m = a.streakStart,
        h = a.streakEnd,
        g = N(m.sub(f), m.add(p(f, 0.1)), d)
          .mul(N(h.sub(p(f, 0.08)), h.add(f), d).oneMinus())
          .mul(N(-0.35, 0.2, u.y.add(0.15)))
          .mul(N(0.08, 0.3, u.dot(n).abs())),
        _ = t.mul(C(a.keyDirection, 0)).xyz.normalize().add(n).normalize(),
        v = p(e.dot(_), 0),
        y = l(v),
        x = N(V(0.93).sub(y), V(0.985).add(y), v).mul(a.glint),
        S = a.haze.mul(I(0.6, 1, r));
      return c
        .mul(o)
        .add(a.edgeColor.mul(x))
        .add(a.streakColor.mul(g.mul(a.streaks)))
        .add(a.hazeColor.mul(S));
    })(),
    g = (e) => ne(ke(e, K).x, le, S),
    _ = g(o.textures.peelDepth),
    y = g(o.textures.opaqueDepth),
    x = B.z.lessThan(_.sub(3e-4)),
    w = B.z.greaterThan(y.sub(4e-5)),
    E = s
      ? H(() => {
          let e = v,
            t = m,
            n = s.fillY
              .add(e.x.mul(s.slope.x))
              .add(e.z.mul(s.slope.y))
              .add(s.meniscus.mul(0.5)),
            r = t.x
              .mul(e.x)
              .add(t.z.mul(e.z))
              .lessThan(0)
              .or(t.y.greaterThan(0.6));
          return s.on.greaterThan(0.5).and(e.y.lessThan(n)).and(r);
        })()
      : V(0).greaterThan(1),
    D = H(() => {
      let e = d.normal,
        t = e.dFdx(),
        r = e.dFdy(),
        i = t.dot(t).add(r.dot(r)).mul(0.5).min(0.18).mul(a.specularAA);
      return n.mul(n).add(i).sqrt().clamp(0, 1);
    })(),
    O = (e, t = {}) => {
      let n = new Lt({ ...f, ...t });
      return (
        (n.name = `Glass · ${u} · ${e}`),
        (n.normalNode = d.normal),
        (n.roughnessNode = D),
        n
      );
    },
    k = O(`behind the liquid`, { viewportBuffer: o.viewports.behind });
  ((k.emissiveNode = h.mul(0.6)), (k.maskNode = x.and(E)));
  let A = O(`far`, { viewportBuffer: o.viewports.middle });
  ((A.emissiveNode = h.mul(0.6)), (A.maskNode = x.and(E.not()).and(w)));
  let j = O(`near`, { viewportBuffer: o.glassBackdrop });
  return (
    (j.emissiveNode = h),
    (j.maskNode = B.z.greaterThan(_.sub(3e-4)).and(w)),
    o.guard?.attach(A, { far: !0, points: 1 }),
    o.guard?.attach(j, { mode: `ray`, contact: !s }),
    { behind: k, middle: A, near: j, painted: d, all: [k, A, j] }
  );
}
function Ut(e, t, n = 1) {
  for (let r of e)
    for (let e of Bt) {
      let i = e === `envMapIntensity` ? t[e] * n : t[e];
      if (r[e]?.isColor) {
        r[e].set(i);
        continue;
      }
      (e === `dispersion` && !!r.dispersion != !!i && (r.needsUpdate = !0),
        (r[e] = i));
    }
}
function Wt(e, t, n) {
  ((e.edge.value = t.edge),
    e.edgeColor.value.set(t.edgeColor),
    (e.streaks.value = t.streaks),
    e.streakColor.value.set(t.streakColor),
    (e.streakPaint.value = t.streakPaint),
    (e.specularAA.value = t.specularAA),
    (e.rimPower.value = t.edgePower),
    (e.haze.value = t.haze),
    e.hazeColor.value.set(t.hazeColor),
    (e.glint.value = t.glint),
    (e.iridescence.value = t.iridescence),
    e.keyDirection.value.copy(n));
}
var Gt = new WeakMap(),
  Kt = 5;
function qt(e) {
  let t = Gt.get(e);
  return (t || Gt.set(e, (t = new Jt(e))), t);
}
var Jt = class {
    constructor(e, { grid: t = !0 } = {}) {
      let n = (e ?? [])
        .map(([e, t]) => [Math.max(0, Number(e)), Number(t)])
        .filter(([e, t]) => Number.isFinite(e) && Number.isFinite(t));
      if (n.length < 2)
        throw Error(`CavitySDF: cavityProfile needs ≥ 2 points [[r, y], …]`);
      (n[0][0] > 1e-6 && n.unshift([0, n[0][1]]),
        (n = n.filter(
          (e, t) =>
            t === 0 ||
            Math.hypot(e[0] - n[t - 1][0], e[1] - n[t - 1][1]) > 1e-7,
        )));
      let r = n[n.length - 1];
      ((this.floorY = n[0][1]),
        (this.topY = Math.max(...n.map((e) => e[1]))),
        (this.maxRadius = Math.max(...n.map((e) => e[0]))));
      let i = [...n, [r[0], r[1] + 1]],
        a = i.length - 1;
      this.seg = new Float64Array(a * Kt);
      for (let e = 0; e < a; e++) {
        let [t, n] = i[e],
          [r, a] = i[e + 1],
          o = r - t,
          s = a - n;
        this.seg.set([t, n, r, a, 1 / Math.max(o * o + s * s, 1e-18)], e * Kt);
      }
      ((this.segCount = a),
        (this.poly = [...i, [0, r[1] + 1]]),
        (this.polyX = Float64Array.from(this.poly.map((e) => e[0]))),
        (this.polyY = Float64Array.from(this.poly.map((e) => e[1]))),
        (this.radiusSamples = 128),
        (this.radiusTable = new Float64Array(this.radiusSamples)));
      for (let e = 0; e < this.radiusSamples; e++) {
        let t =
            this.floorY +
            ((this.topY - this.floorY) * e) / (this.radiusSamples - 1),
          n = 0;
        for (let e = 0; e < a; e++) {
          let r = e * Kt,
            i = this.seg[r + 1],
            a = this.seg[r + 3];
          if ((t - i) * (t - a) > 0) continue;
          let o = Math.abs(a - i) < 1e-12 ? 1 : (t - i) / (a - i);
          n = Math.max(
            n,
            this.seg[r] +
              (this.seg[r + 2] - this.seg[r]) * Math.min(1, Math.max(0, o)),
          );
        }
        this.radiusTable[e] = n || this.maxRadius;
      }
      ((this.out = { d: 0, nr: 0, ny: 0 }),
        (this.grid = null),
        t && this.buildGrid());
    }
    buildGrid(e = 3e-4) {
      let t = 0.004;
      ((this.gCell = e),
        (this.gR = Math.ceil((this.maxRadius + t) / e) + 2),
        (this.gY0 = this.floorY - t),
        (this.gY = Math.ceil((this.topY + t - this.gY0) / e) + 2),
        (this.grid = new Float32Array(this.gR * this.gY)));
      for (let t = 0; t < this.gY; t++)
        for (let n = 0; n < this.gR; n++)
          this.grid[t * this.gR + n] = this.exact(n * e, this.gY0 + t * e).d;
    }
    radiusAt(e) {
      let t =
        ((e - this.floorY) / Math.max(this.topY - this.floorY, 1e-9)) *
        (this.radiusSamples - 1);
      if (t <= 0) return this.radiusTable[0];
      if (t >= this.radiusSamples - 1)
        return this.radiusTable[this.radiusSamples - 1];
      let n = Math.floor(t),
        r = t - n;
      return this.radiusTable[n] * (1 - r) + this.radiusTable[n + 1] * r;
    }
    inside(e, t) {
      let n = this.polyX,
        r = this.polyY,
        i = n.length,
        a = !1;
      for (let o = 0, s = i - 1; o < i; s = o++)
        r[o] > t != r[s] > t &&
          e < ((n[s] - n[o]) * (t - r[o])) / (r[s] - r[o]) + n[o] &&
          (a = !a);
      return a;
    }
    eval(e, t) {
      let n = e / this.gCell,
        r = (t - this.gY0) / this.gCell,
        i = Math.floor(n),
        a = Math.floor(r);
      if (this.grid && i >= 0 && a >= 0 && i < this.gR - 1 && a < this.gY - 1) {
        let e = this.grid,
          t = this.gR,
          o = n - i,
          s = r - a,
          c = a * t + i,
          l = e[c],
          u = e[c + 1],
          d = e[c + t],
          f = e[c + t + 1],
          p = this.out;
        p.d = (l * (1 - o) + u * o) * (1 - s) + (d * (1 - o) + f * o) * s;
        let m = (u - l) * (1 - s) + (f - d) * s,
          h = (d - l) * (1 - o) + (f - u) * o,
          g = Math.hypot(m, h);
        if (g > 1e-12) return ((p.nr = m / g), (p.ny = h / g), p);
      }
      return this.exact(e, t);
    }
    exact(e, t) {
      let n = this.seg,
        r = 1 / 0,
        i = 0,
        a = 0,
        o = 0;
      for (let s = 0; s < this.segCount; s++) {
        let c = s * Kt,
          l = n[c],
          u = n[c + 1],
          d = n[c + 2] - l,
          f = n[c + 3] - u,
          p = ((e - l) * d + (t - u) * f) * n[c + 4];
        p = p < 0 ? 0 : p > 1 ? 1 : p;
        let m = l + d * p,
          h = u + f * p,
          g = (e - m) * (e - m) + (t - h) * (t - h);
        g < r && ((r = g), (i = m), (a = h), (o = s));
      }
      let s = Math.sqrt(r),
        c = this.inside(e, t) ? 1 : -1,
        l = this.out;
      if (((l.d = s * c), s > 1e-9))
        ((l.nr = ((e - i) / s) * c), (l.ny = ((t - a) / s) * c));
      else {
        let e = o * Kt,
          t = n[e + 2] - n[e],
          r = n[e + 3] - n[e + 1],
          i = Math.hypot(t, r) || 1;
        ((l.nr = -r / i), (l.ny = t / i));
      }
      return l;
    }
  },
  Yt = 9.81,
  Xt = 1e3,
  Zt = 4e-4,
  Qt = 0.3,
  $t = 0.15,
  en = 4,
  tn = 10,
  nn = 30,
  rn = 30,
  an = 0.995,
  Z = (e, t, n) => (e < t ? t : e > n ? n : e),
  on = [0, 0, 0, 0, 0, 0, 0, 0, 0],
  sn = class {
    constructor({
      cavityProfile: e,
      fillY: t,
      settings: n,
      layer: r = null,
    } = {}) {
      ((this.settings = n),
        (this.cavity = qt(e)),
        (this.lowY =
          Array.isArray(e) && e.length
            ? Math.min(...e.map((e) => e[1]))
            : this.cavity.floorY),
        (this.layer = r ? { y: r.y, firmness: r.firmness } : null),
        (this.fillY = t),
        (this.motion = {
          ax: 0,
          ay: 0,
          az: 0,
          gx: 0,
          gy: -9.81,
          gz: 0,
          wx: 0,
          wy: 0,
          wz: 0,
          bx: 0,
          by: 0,
          bz: 0,
        }),
        (this._forcing = Array(9).fill(0)),
        (this._sleepForcing = Array(9).fill(0)),
        (this.stats = { active: 0, substeps: 0, maxU: 0, maxV: 0 }),
        (this.asleep = !0),
        (this.sleepTime = 0),
        (this.version = 0),
        this.build());
    }
    build() {
      let e = this.cavity,
        t = this.settings,
        n = Z(Math.round(t.cells) || 7, 4, 11),
        r = this.fillY,
        i = Math.min(e.floorY, this.lowY ?? e.floorY),
        a = 0;
      for (let t = 0; t <= 48; t++)
        a = Math.max(a, e.radiusAt(i + ((r - i) * t) / 48));
      a += 5e-4;
      const appleDepth = t.freeBody ? Z(Number(t.bodyDepth) || 1, .6, 1.4) : 1;
      let o = n + 1,
        s = o,
        c = (2 * a) / n,
        l = c * appleDepth,
        u = Z(Math.round((r - i) / c), 2, 11),
        d = u + 1,
        f = (r - i) / u;
      ((this.dims = [o, d, s]),
        (this.h = [c, f, l]),
        (this.origin = [-a, i, -a * appleDepth]),
        (this.cellSize = Math.cbrt(c * f * l)));
      let p = o * d * s;
      this.N = p;
      let m = (this.X = new Float64Array(p * 3));
      for (let e = 0; e < s; e++)
        for (let t = 0; t < d; t++)
          for (let n = 0; n < o; n++) {
            let r = n + o * (t + d * e);
            ((m[r * 3] = -a + n * c),
              (m[r * 3 + 1] = i + t * f),
              (m[r * 3 + 2] = -a * appleDepth + e * l));
          }
      let h = (t, n, i) =>
          n <= r + 1e-9 && e.exact(Math.hypot(t, i / appleDepth), n).d > Zt * 0.5,
        g = c * f * l,
        _ = [],
        v = [],
        y = new Float64Array(p),
        b = new Map(),
        x = (e, t) => e * 3 + t,
        S = [(f * l) / c, (c * l) / f, (c * f) / l];
      for (let e = 0; e < s - 1; e++)
        for (let t = 0; t < d - 1; t++)
          for (let n = 0; n < o - 1; n++) {
            let r = 0;
            for (let o = 0; o < 4; o++)
              for (let s = 0; s < 4; s++)
                for (let u = 0; u < 4; u++)
                  h(
                    -a + (n + (u + 0.5) / 4) * c,
                    i + (t + (s + 0.5) / 4) * f,
                    -a * appleDepth + (e + (o + 0.5) / 4) * l,
                  ) && r++;
            if (!r) continue;
            let s = r / 64,
              u = Math.max(s, Qt),
              p = this.layer,
              m =
                p && p.firmness !== 1
                  ? 1 + (p.firmness - 1) * Z((p.y - (i + t * f)) / f, 0, 1)
                  : 1,
              C = n + o * (t + d * e),
              w = [];
            for (let e = 0; e < 2; e++)
              for (let t = 0; t < 2; t++)
                for (let n = 0; n < 2; n++) w.push(C + n + o * (t + d * e));
            (_.push(w), v.push(u * m * g));
            for (let e of w) y[e] += (Xt * g * u) / 8;
            let T = (e, t) =>
              b.set(x(e, t), (b.get(x(e, t)) ?? 0) + ((u * m) / 4) * S[t]);
            for (let e = 0; e < 2; e++)
              for (let t = 0; t < 2; t++) T(C + o * (t + d * e), 0);
            for (let e = 0; e < 2; e++)
              for (let t = 0; t < 2; t++) T(C + t + o * d * e, 1);
            for (let e = 0; e < 2; e++)
              for (let t = 0; t < 2; t++) T(C + t + o * e, 2);
          }
      let C = [1, o, o * d];
      ((this.edgeA = new Int32Array(b.size)),
        (this.edgeB = new Int32Array(b.size)),
        (this.edgeK = new Float64Array(b.size)),
        (this.edgeL = new Float64Array(b.size)));
      let w = 0;
      for (let [e, t] of b) {
        let n = Math.floor(e / 3),
          r = e % 3;
        ((this.edgeA[w] = n),
          (this.edgeB[w] = n + C[r]),
          (this.edgeK[w] = t),
          (this.edgeL[w] = this.h[r]),
          w++);
      }
      ((this.cellCorners = Int32Array.from(_.flat())),
        (this.cellVW = Float64Array.from(v)),
        (this.cellCount = _.length));
      let T = [];
      for (let e = 0; e < p; e++) y[e] > 0 && T.push(e);
      ((this.active = Int32Array.from(T)),
        (this.mass = y),
        (this.invMass = new Float64Array(p)));
      for (let e of T) this.invMass[e] = 1 / y[e];
      ((this.sdf0 = new Float64Array(p)),
        (this.nrm = new Float64Array(p * 3)),
        (this.bond = new Float64Array(p)),
        (this.limit = new Float64Array(p)));
      let E = 0.5 * Math.min(c, f);
      for (let t of T) {
        let n = m[t * 3],
          r = m[t * 3 + 1],
          i = m[t * 3 + 2],
          a = Math.hypot(n, i / appleDepth),
          o = e.exact(a, r);
        this.sdf0[t] = o.d;
        let s = a > 1e-9 ? n / a : 0,
          c = a > 1e-9 ? i / a : 0;
        ((this.nrm[t * 3] = o.nr * s),
          (this.nrm[t * 3 + 1] = o.ny),
          (this.nrm[t * 3 + 2] = o.nr * c));
        let l =
          Math.hypot(
            this.nrm[t * 3],
            this.nrm[t * 3 + 1],
            this.nrm[t * 3 + 2],
          ) || 1;
        ((this.nrm[t * 3] /= l),
          (this.nrm[t * 3 + 1] /= l),
          (this.nrm[t * 3 + 2] /= l),
          (this.bond[t] = Z(1 - (o.d - Zt) / E, 0, 1)),
          (this.limit[t] = Math.min(o.d, Zt)));
      }
      // A freestanding apple has a contact patch, not a cup wall or pinned rim.
      if (this.settings.freeBody) for (const node of T) {
        const y = this.X[node*3+1] - this.origin[1];
        this.bond[node] = Math.max(0, 1-y/(this.h[1]*.8));
        this.nrm[node*3] = 0; this.nrm[node*3+1] = 1; this.nrm[node*3+2] = 0;
      }
      this.bonded = Int32Array.from(T.filter((e) => this.bond[e] > 0));
      let D = Xt * c * f * l;
      this.grip = new Float64Array(p);
      for (let e of this.bonded)
        this.grip[e] = this.bond[e] * Math.min(1, y[e] / D);
      ((this.free = Int32Array.from(T.filter((e) => this.bond[e] < 1))),
        (this.near = this.settings.freeBody ? new Int32Array() : this.free),
        (this.glueW2 = new Float64Array(p)),
        (this.glueC = new Float64Array(p)),
        (this.pin = new Float64Array(p)),
        (this.U = new Float64Array(p * 3)),
        (this.V = new Float64Array(p * 3)),
        (this.F = new Float64Array(p * 3)),
        (this.W = new Float64Array(p * 3)),
        (this.probe = Math.round(n / 2) + o * (d - 1 + d * Math.round(n / 2))),
        (this.stats.active = T.length),
        this.calibrate(),
        this.configure(),
        this.reset());
    }
    setLayer(e = null) {
      let t = !!(e && e.firmness > 0 && Math.abs(e.firmness - 1) > 0.001),
        n = this.layer;
      return (
        !(t
          ? n !== null && n.y === e.y && n.firmness === e.firmness
          : n === null) &&
        ((this.layer = t ? { y: e.y, firmness: e.firmness } : null),
        this.build(),
        !0)
      );
    }
    coefficients(e, t) {
      let n = this.settings,
        r = 14 * Z(Number(n.volume) || 0, 0, 1.25) * e + e,
        i = Z(Number(n.wallGrip) || 0, 0, 1),
        a = i * i * nn * e * this.cellSize;
      (!this._row || this._row.length !== this.N) &&
        (this._row = new Float64Array(this.N));
      let o = this._row;
      o.fill(0);
      let [s, c, l] = this.h,
        u = 1 + Math.max(0, t) * en;
      for (let t = 0; t < this.edgeA.length; t++) {
        let n = 2 * this.edgeK[t] * e * u;
        ((o[this.edgeA[t]] += n), (o[this.edgeB[t]] += n));
      }
      let d = 8 / (4 * s) + 8 / (4 * c) + 8 / (4 * l),
        f = 1 / (4 * Math.min(s, c, l));
      for (let e = 0; e < this.cellCount; e++) {
        let t = r * this.cellVW[e] * f * d;
        for (let n = 0; n < 8; n++) o[this.cellCorners[e * 8 + n]] += t;
      }
      let p = 0;
      for (let e of this.active)
        p = Math.max(p, (o[e] + this.grip[e] * a) * this.invMass[e]);
      return {
        mu: e,
        kappa: r,
        kGrip: a,
        glue2: (rn * e * this.cellSize) / (Xt * s * c * l),
        omegaMax: Math.sqrt(p),
      };
    }
    calibrate() {
      let e = { ...this.coefficients(40, 0), alpha: 0, beta: 0, stiff: 0 };
      this.setGlue(e);
      let t = this.N * 3,
        n = this.active,
        r = this.mass,
        i = this.nrm,
        a = (e) => this.glueW2[e] === 1 / 0,
        o = (e) => this.bond[e] >= 0.5,
        s = (e) => {
          for (let t of n) {
            let n = t * 3;
            if (a(t)) {
              e[n] = e[n + 1] = e[n + 2] = 0;
              continue;
            }
            if (o(t)) {
              let t = e[n] * i[n] + e[n + 1] * i[n + 1] + e[n + 2] * i[n + 2];
              ((e[n] -= t * i[n]),
                (e[n + 1] -= t * i[n + 1]),
                (e[n + 2] -= t * i[n + 2]));
            }
          }
          return e;
        },
        c = new Float64Array(t),
        l = new Float64Array(t),
        u = new Float64Array(t),
        d = (n, r) => {
          (r.fill(0), s(n), c.set(n), l.set(c));
          let i = 0;
          for (let e = 0; e < t; e++) i += c[e] * c[e];
          let a = i;
          for (let n = 0; n < 600 && i > a * 1e-14; n++) {
            (this.stiffness(l, u, e), s(u));
            let n = 0;
            for (let e = 0; e < t; e++) n += l[e] * u[e];
            if (!(n > 0)) break;
            let a = i / n,
              o = 0;
            for (let e = 0; e < t; e++)
              ((r[e] += a * l[e]), (c[e] -= a * u[e]), (o += c[e] * c[e]));
            let d = o / i;
            i = o;
            for (let e = 0; e < t; e++) l[e] = c[e] + d * l[e];
          }
          return r;
        },
        f = new Float64Array(t),
        p = new Float64Array(t),
        m = new Float64Array(t);
      for (let e of n) f[e * 3] = r[e];
      d(f, p);
      for (let e of n)
        for (let t = 0; t < 3; t++) f[e * 3 + t] = r[e] * p[e * 3 + t];
      d(f, m);
      let h = 0,
        g = 0;
      for (let e of n) {
        let t = e * 3;
        ((h +=
          r[e] * (m[t] * p[t] + m[t + 1] * p[t + 1] + m[t + 2] * p[t + 2])),
          (g +=
            r[e] * (m[t] * m[t] + m[t + 1] * m[t + 1] + m[t + 2] * m[t + 2])));
      }
      let _ = g > 0 && h > 0 ? Math.sqrt(h / g) : 2 * Math.PI * 0.5;
      ((this.f0 = _ / (2 * Math.PI)),
        (this.mu0 = 40),
        this.U.fill(0),
        this.V.fill(0),
        this.k && this.setGlue(this.k));
    }
    stiffness(e, t, n) {
      t.fill(0);
      let r = n.mu,
        i = this.edgeA,
        a = this.edgeB,
        o = this.edgeK;
      for (let n = 0; n < i.length; n++) {
        let s = i[n] * 3,
          c = a[n] * 3,
          l = o[n] * r;
        for (let n = 0; n < 3; n++) {
          let r = l * (e[c + n] - e[s + n]);
          ((t[s + n] -= r), (t[c + n] += r));
        }
      }
      let [s, c, l] = this.h,
        u = 1 / (4 * s),
        d = 1 / (4 * c),
        f = 1 / (4 * l),
        p = this.cellCorners,
        m = this.cellVW;
      for (let r = 0; r < this.cellCount; r++) {
        let i = r * 8,
          a = 0;
        for (let t = 0; t < 8; t++) {
          let n = p[i + t] * 3;
          a +=
            (t & 1 ? u : -u) * e[n] +
            (t & 2 ? d : -d) * e[n + 1] +
            (t & 4 ? f : -f) * e[n + 2];
        }
        let o = n.kappa * m[r] * a;
        for (let e = 0; e < 8; e++) {
          let n = p[i + e] * 3;
          ((t[n] += o * (e & 1 ? u : -u)),
            (t[n + 1] += o * (e & 2 ? d : -d)),
            (t[n + 2] += o * (e & 4 ? f : -f)));
        }
      }
      let h = this.nrm;
      for (let r of this.bonded) {
        let i = r * 3,
          a = this.glueW2[r];
        if (a > 0 && a < 1 / 0) {
          let n = a * this.mass[r];
          ((t[i] += n * e[i]),
            (t[i + 1] += n * e[i + 1]),
            (t[i + 2] += n * e[i + 2]));
        }
        if (n.kGrip > 0) {
          let a = e[i] * h[i] + e[i + 1] * h[i + 1] + e[i + 2] * h[i + 2],
            o = this.grip[r] * n.kGrip;
          ((t[i] += o * (e[i] - a * h[i])),
            (t[i + 1] += o * (e[i + 1] - a * h[i + 1])),
            (t[i + 2] += o * (e[i + 2] - a * h[i + 2])));
        }
      }
      return t;
    }
    configure() {
      let e = this.settings,
        t = Z(Number(e.frequency) || 3, 0.3, 12),
        n = this.mu0 * (t / this.f0) ** 2,
        r = Z(Number(e.stiffness) || 0, 0, 3),
        i = this.coefficients(n, r),
        a = 2 * Math.PI * t;
      return (
        (i.alpha = 2 * Z(Number(e.damping) || 0, 0, 2) * a),
        (i.beta = 0.35 / i.omegaMax),
        (i.stiff = r),
        (i.hMax =
          1.25 / (i.omegaMax * (1 + i.beta * i.omegaMax) + 0.5 * i.alpha)),
        (this.k = i),
        this.setGlue(i),
        (this.response = Math.max(0, Number(e.response) || 0)),
        (this.maxU = Math.max(5e-4, Number(e.maxDisplacement) || 0.008)),
        (this.near = this.settings.freeBody ? new Int32Array() : Int32Array.from(
          this.free.filter((e) => this.sdf0[e] < this.maxU + 0.001),
        )),
        this
      );
    }
    setGlue(e = this.k) {
      let t = this.settings,
        n = this.X,
        r = Z(Number(t.adhesion ?? 1), 0, 1),
        i = Z(Number(t.rimPin ?? 1), 0, 1),
        a = this.fillY,
        o = this.h[1];
      (this.glueW2.fill(0), this.glueC.fill(0), this.pin.fill(0));
      for (let t of this.bonded) {
        let s = n[t * 3 + 1],
          c = Z((s - (a - o)) / o, 0, 1),
          l = c * c * (3 - 2 * c),
          u = this.bond[t] * (this.settings.freeBody ? 1 : r + (i - r) * l);
        if (u <= 1e-4) continue;
        if (((this.pin[t] = u), u >= an)) {
          this.glueW2[t] = 1 / 0;
          continue;
        }
        let d = (e.glue2 * u) / (1 - u);
        ((this.glueW2[t] = d), (this.glueC[t] = 1.2 * Math.sqrt(d)));
      }
    }
    reset() {
      return (
        this.U.fill(0),
        this.V.fill(0),
        (this.asleep = !0),
        (this.sleepTime = 0),
        (this.sleepForcing = null),
        this.version++,
        this
      );
    }
    wake() {
      ((this.asleep = !1), (this.sleepTime = 0));
    }
    setMotion({
      acceleration: e,
      gravity: t,
      angularVelocity: n,
      angularAcceleration: r,
    } = {}) {
      let i = this.motion,
        a = (e) => (Number.isFinite(e) ? e : 0);
      (e && ((i.ax = a(e[0])), (i.ay = a(e[1])), (i.az = a(e[2]))),
        t && ((i.gx = a(t[0])), (i.gy = a(t[1]) || -9.81), (i.gz = a(t[2]))),
        n && ((i.wx = a(n[0])), (i.wy = a(n[1])), (i.wz = a(n[2]))),
        r && ((i.bx = a(r[0])), (i.by = a(r[1])), (i.bz = a(r[2]))));
    }
    forcing() {
      let e = this.motion,
        t = this.response,
        n = this._forcing;
      return (
        (n[0] = t * (-e.ax + e.gx)),
        (n[1] = t * (-e.ay + e.gy + Yt)),
        (n[2] = t * (-e.az + e.gz)),
        (n[3] = e.wx),
        (n[4] = e.wy),
        (n[5] = e.wz),
        (n[6] = e.bx),
        (n[7] = e.by),
        (n[8] = e.bz),
        n
      );
    }
    kick(e, t, n) {
      let r = this.X,
        i = this.V,
        a = this.fillY,
        o = this.origin[1];
      for (let s of this.free) {
        let c =
          Z((r[s * 3 + 1] - o) / Math.max(1e-4, a - o), 0, 1) *
          (1 - Math.max(this.bond[s], this.pin[s]));
        ((i[s * 3] += e * c), (i[s * 3 + 1] += t * c), (i[s * 3 + 2] += n * c));
      }
      this.wake();
    }
    update(e) {
      e = Z(Number(e) || 0, 0, 0.05);
      let t = this.forcing();
      if (this.asleep) {
        let n = this.sleepForcing ?? on,
          r = 0;
        for (let e = 0; e < 3; e++) r = Math.max(r, Math.abs(t[e] - n[e]));
        for (let e = 3; e < 9; e++)
          r = Math.max(r, Math.abs(t[e] - n[e]) * (e < 6 ? 0.05 : 0.01));
        if (r < 0.03 || e <= 0) return ((this.stats.substeps = 0), !1);
        this.wake();
      }
      if (e <= 0) return !1;
      let n = Math.min(this.settings.freeBody ? 256 : tn, Math.max(1, Math.ceil(e / this.k.hMax - 1e-6))),
        r = Math.min(e / n, this.k.hMax);
      for (let e = 0; e < n; e++) this.step(r, this.response, e === n - 1);
      if (
        ((this.stats.substeps = n),
        !Number.isFinite(this.stats.maxU) || !Number.isFinite(this.stats.maxV))
      )
        return (this.reset(), !0);
      if (this.stats.maxV < 2e-4 && this.stats.kinetic < 1e-9) {
        if (((this.sleepTime += e), this.sleepTime > 0.4)) {
          this.asleep = !0;
          for (let e = 0; e < 9; e++) this._sleepForcing[e] = t[e];
          ((this.sleepForcing = this._sleepForcing),
            this.V.fill(0),
            this.stats.maxU < 5e-5 &&
              Math.abs(t[0]) + Math.abs(t[1]) + Math.abs(t[2]) < 0.05 &&
              this.U.fill(0));
        }
      } else this.sleepTime = 0;
      return (this.version++, !0);
    }
    step(e, t = this.response, n = !0) {
      let { U: r, V: i, F: a, W: o, X: s, mass: c, invMass: l } = this,
        u = this.k,
        d = this.motion,
        f = this.active,
        p = u.beta,
        m = u.mu,
        h = u.stiff,
        g = t * (-d.ax + d.gx),
        _ = t * (-d.ay + d.gy + Yt),
        v = t * (-d.az + d.gz),
        y = d.wx,
        b = d.wy,
        x = d.wz,
        S = d.bx,
        C = d.by,
        w = d.bz,
        T = y !== 0 || b !== 0 || x !== 0 || S !== 0 || C !== 0 || w !== 0;
      for (let e = 0; e < f.length; e++) {
        let t = f[e],
          n = t * 3,
          // Optional per-node VR contact acceleration. Evaluated at every
          // elastic solver substep; desktop behaviour is unchanged when absent.
          l = g + (this.externalAcceleration?.[n] ?? 0),
          u = _ + (this.externalAcceleration?.[n + 1] ?? 0),
          d = v + (this.externalAcceleration?.[n + 2] ?? 0);
        if (T) {
          let e = s[n] + r[n],
            t = s[n + 1] + r[n + 1],
            a = s[n + 2] + r[n + 2],
            o = b * a - x * t,
            c = x * e - y * a,
            f = y * t - b * e;
          ((l -=
            C * a -
            w * t +
            (b * f - x * c) +
            2 * (b * i[n + 2] - x * i[n + 1])),
            (u -=
              w * e - S * a + (x * o - y * f) + 2 * (x * i[n] - y * i[n + 2])),
            (d -=
              S * t - C * e + (y * c - b * o) + 2 * (y * i[n + 1] - b * i[n])));
        }
        let m = c[t];
        ((a[n] = l * m),
          (a[n + 1] = u * m),
          (a[n + 2] = d * m),
          (o[n] = r[n] + p * i[n]),
          (o[n + 1] = r[n + 1] + p * i[n + 1]),
          (o[n + 2] = r[n + 2] + p * i[n + 2]));
      }
      // Local touch spring enters the same elastic grid as inertia and gravity.
      if(this.touchGrab){
        const q=this.touchGrab, radius2=q.radius*q.radius;
        for(const node of this.free){
          const k=node*3, d2=(s[k]-q.point[0])**2+(s[k+1]-q.point[1])**2+(s[k+2]-q.point[2])**2;
          const weight=Math.exp(-d2/radius2);
          if(weight<.002)continue;
          for(let axis=0;axis<3;axis++)a[k+axis]+=c[node]*weight*(q.stiffness*(q.target[axis]-r[k+axis])-q.damping*i[k+axis]);
        }
      }
      let E = this.edgeA,
        D = this.edgeB,
        O = this.edgeK,
        k = this.edgeL;
      for (let e = 0; e < E.length; e++) {
        let t = E[e] * 3,
          n = D[e] * 3,
          i = O[e] * m;
        if (h > 0) {
          let a = r[n] - r[t],
            o = r[n + 1] - r[t + 1],
            s = r[n + 2] - r[t + 2],
            c = k[e] * $t,
            l = (a * a + o * o + s * s) / (c * c);
          i *= 1 + h * (l < en ? l : en);
        }
        let s = i * (o[n] - o[t]),
          c = i * (o[n + 1] - o[t + 1]),
          l = i * (o[n + 2] - o[t + 2]);
        ((a[t] += s),
          (a[t + 1] += c),
          (a[t + 2] += l),
          (a[n] -= s),
          (a[n + 1] -= c),
          (a[n + 2] -= l));
      }
      let [A, j, M] = this.h,
        N = 1 / (4 * A),
        P = 1 / (4 * j),
        F = 1 / (4 * M),
        I = this.cellCorners,
        L = this.cellVW,
        ee = u.kappa;
      for (let e = 0; e < this.cellCount; e++) {
        let t = e * 8,
          n = 0;
        for (let e = 0; e < 8; e++) {
          let r = I[t + e] * 3;
          n +=
            (e & 1 ? N : -N) * o[r] +
            (e & 2 ? P : -P) * o[r + 1] +
            (e & 4 ? F : -F) * o[r + 2];
        }
        let r = ee * L[e] * n;
        for (let e = 0; e < 8; e++) {
          let n = I[t + e] * 3;
          ((a[n] -= r * (e & 1 ? N : -N)),
            (a[n + 1] -= r * (e & 2 ? P : -P)),
            (a[n + 2] -= r * (e & 4 ? F : -F)));
        }
      }
      let R = this.nrm,
        te = this.grip;
      if (u.kGrip > 0) {
        let e = this.bonded;
        for (let t = 0; t < e.length; t++) {
          let n = e[t],
            r = n * 3,
            i = R[r],
            s = R[r + 1],
            c = R[r + 2],
            l = o[r] * i + o[r + 1] * s + o[r + 2] * c,
            d = te[n] * u.kGrip;
          ((a[r] -= d * (o[r] - l * i)),
            (a[r + 1] -= d * (o[r + 1] - l * s)),
            (a[r + 2] -= d * (o[r + 2] - l * c)));
        }
      }
      let ne = 1 / (1 + u.alpha * e),
        re = this.glueW2,
        z = this.glueC;
      for (let t = 0; t < f.length; t++) {
        let n = f[t],
          o = n * 3,
          s = l[n] * e,
          c = (i[o] + a[o] * s) * ne,
          u = (i[o + 1] + a[o + 1] * s) * ne,
          d = (i[o + 2] + a[o + 2] * s) * ne,
          p = re[n];
        if (p > 0) {
          if (p === 1 / 0) {
            ((i[o] = i[o + 1] = i[o + 2] = 0),
              (r[o] = r[o + 1] = r[o + 2] = 0));
            continue;
          }
          let t = 1 / (1 + e * z[n] + e * e * p),
            a = e * p;
          ((c = (c - a * r[o]) * t),
            (u = (u - a * r[o + 1]) * t),
            (d = (d - a * r[o + 2]) * t));
        }
        ((i[o] = c),
          (i[o + 1] = u),
          (i[o + 2] = d),
          (r[o] += c * e),
          (r[o + 1] += u * e),
          (r[o + 2] += d * e));
      }
      if ((this.constrain(), !n)) return;
      let ie = 0,
        ae = 0,
        B = 0;
      for (let e = 0; e < f.length; e++) {
        let t = f[e] * 3,
          n = i[t] * i[t] + i[t + 1] * i[t + 1] + i[t + 2] * i[t + 2],
          a = r[t] * r[t] + r[t + 1] * r[t + 1] + r[t + 2] * r[t + 2];
        (n > ae && (ae = n), a > ie && (ie = a), (B += c[f[e]] * n));
      }
      ((this.stats.maxV = Math.sqrt(ae)),
        (this.stats.maxU = Math.sqrt(ie)),
        (this.stats.kinetic = 0.5 * B));
    }
    constrain() {
      let { U: e, V: t, X: n } = this,
        r = this.nrm,
        i = this.bond,
        a = this.bonded;
      for (let n = 0; n < a.length; n++) {
        let o = a[n],
          s = o * 3,
          c = i[o],
          l = r[s],
          u = r[s + 1],
          d = r[s + 2],
          f = (e[s] * l + e[s + 1] * u + e[s + 2] * d) * c;
        ((e[s] -= f * l), (e[s + 1] -= f * u), (e[s + 2] -= f * d));
        let p = (t[s] * l + t[s + 1] * u + t[s + 2] * d) * c;
        ((t[s] -= p * l), (t[s + 1] -= p * u), (t[s + 2] -= p * d));
      }
      let o = this.cavity,
        s = this.near,
        c = this.limit;
      for (let r = 0; r < s.length; r++) {
        let i = s[r],
          a = i * 3,
          l = n[a] + e[a],
          u = n[a + 1] + e[a + 1],
          d = n[a + 2] + e[a + 2],
          f = Math.hypot(l, d),
          p = o.eval(f, u),
          m = c[i];
        if (p.d >= m) continue;
        let h = f > 1e-9 ? l / f : 0,
          g = f > 1e-9 ? d / f : 0,
          _ = p.nr * h,
          v = p.ny,
          y = p.nr * g,
          b = m - p.d;
        ((e[a] += b * _), (e[a + 1] += b * v), (e[a + 2] += b * y));
        let x = t[a] * _ + t[a + 1] * v + t[a + 2] * y;
        x < 0 && ((t[a] -= x * _), (t[a + 1] -= x * v), (t[a + 2] -= x * y));
      }
      let l = this.maxU,
        u = l * l,
        d = this.active;
      for (let n = 0; n < d.length; n++) {
        let r = d[n] * 3,
          i = e[r] * e[r] + e[r + 1] * e[r + 1] + e[r + 2] * e[r + 2];
        if (i <= u) continue;
        let a = l / Math.sqrt(i);
        ((e[r] *= a), (e[r + 1] *= a), (e[r + 2] *= a));
        let o = (t[r] * e[r] + t[r + 1] * e[r + 1] + t[r + 2] * e[r + 2]) / l;
        o > 0 &&
          ((t[r] -= (o * e[r]) / l),
          (t[r + 1] -= (o * e[r + 1]) / l),
          (t[r + 2] -= (o * e[r + 2]) / l));
      }
    }
    sample(
      e,
      t,
      n,
      r = { u: [0, 0, 0], grad: Array(9).fill(0), w: [0, 0, 0] },
    ) {
      let [i, a, o] = this.dims,
        [s, c, l] = this.h,
        [u, d, f] = this.origin,
        p = Z((e - u) / s, 0, i - 1),
        m = Z((t - d) / c, 0, a - 1),
        h = Z((n - f) / l, 0, o - 1),
        g = Math.min(i - 2, Math.floor(p)),
        _ = Math.min(a - 2, Math.floor(m)),
        v = Math.min(o - 2, Math.floor(h)),
        y = p - g,
        b = m - _,
        x = h - v,
        S = this.U,
        C = r.u,
        w = r.grad;
      C[0] = C[1] = C[2] = 0;
      for (let e = 0; e < 9; e++) w[e] = 0;
      for (let e = 0; e < 8; e++) {
        let t = e & 1,
          n = (e >> 1) & 1,
          r = (e >> 2) & 1,
          o = g + t + i * (_ + n + a * (v + r)),
          u = t ? y : 1 - y,
          d = n ? b : 1 - b,
          f = r ? x : 1 - x,
          p = u * d * f,
          m = ((t ? 1 : -1) / s) * d * f,
          h = ((n ? 1 : -1) / c) * u * f,
          T = ((r ? 1 : -1) / l) * u * d;
        for (let e = 0; e < 3; e++) {
          let t = S[o * 3 + e];
          ((C[e] += p * t),
            (w[e * 3] += m * t),
            (w[e * 3 + 1] += h * t),
            (w[e * 3 + 2] += T * t));
        }
      }
      return (
        (r.w[0] = 0.5 * (w[7] - w[5])),
        (r.w[1] = 0.5 * (w[2] - w[6])),
        (r.w[2] = 0.5 * (w[3] - w[1])),
        r
      );
    }
    describe() {
      let e = this.probe * 3;
      return {
        dims: this.dims.join(`×`),
        active: this.stats.active,
        asleep: this.asleep,
        substeps: this.stats.substeps,
        probe: [this.U[e], this.U[e + 1], this.U[e + 2]],
      };
    }
  },
  cn = class extends Lt {
    static get type() {
      return `LiquidNodeMaterial`;
    }
    _rebuildBackdrop() {
      (super._rebuildBackdrop(),
        this.volumeNode &&
          (this.backdropNode = this.backdropNode.mul(this.volumeNode)));
    }
  },
  ln = Math.sin(U.degToRad(2)),
  un = (e) => ({
    amount: Math.max(0, Number(e.attenuationAngle) || 0),
    sinRef: Math.sin(U.degToRad(Number(e.attenuationRefElevation) || 0)),
  });
function dn(e, t) {
  let { amount: n, sinRef: r } = un(e),
    i = Math.max(Math.sin(U.degToRad(t)), ln);
  return Math.max(r / i, 1) ** +n;
}
function fn(e) {
  let n = t.mul(C(0, 1, 0, 0)).z.max(ln);
  return e.distance.mul(e.angleRef.div(n).max(1).pow(e.angleAmount));
}
function pn(e) {
  let t = un(e);
  return {
    on: x(1),
    fillY: x(0.05),
    slope: x(new r()),
    meniscus: x(e.meniscusHeight / 1e3),
    absorption: x(new We(e.attenuationColor)),
    distance: x(e.attenuationDistance),
    angleAmount: x(t.amount),
    angleRef: x(t.sinRef),
    glow: x(e.glow),
    glowColor: x(new We(e.glowColor)),
    sheen: x(e.sheen),
    keyDirection: x(new F(-0.5, 0.8, -0.5)),
    maxDepth: x(0.12),
    deform: hn(),
  };
}
var mn = [96, 192];
function hn() {
  let e = new re(new Uint16Array(6912), 12, 12, 12);
  ((e.name = `Jelly displacement (soft body lattice)`),
    (e.format = E),
    (e.type = M),
    (e.minFilter = e.magFilter = ee),
    (e.wrapS = e.wrapT = e.wrapR = k),
    (e.generateMipmaps = !1),
    (e.unpackAlignment = 1),
    (e.needsUpdate = !0));
  let [t, n] = mn,
    i = new Uint16Array(t * n * 4),
    a = new Te(i, t, n, E, M);
  return (
    (a.name = `Jelly cavity SDF (r, y)`),
    (a.minFilter = a.magFilter = ee),
    (a.wrapS = a.wrapT = k),
    (a.generateMipmaps = !1),
    (a.unpackAlignment = 1),
    (a.needsUpdate = !0),
    {
      on: x(0),
      freeBody: x(0),
      map: e,
      sdfMap: a,
      sdfScale: x(new r(1, 1)),
      sdfOffset: x(new r()),
      scale: x(new F(1, 1, 1)),
      offset: x(new F()),
      lo: x(new F()),
      hi: x(new F(1, 1, 1)),
      grad: x(new F(1, 1, 1)),
      texel: x(new F(1 / 12, 1 / 12, 1 / 12)),
      surface: x(1),
      band: x(0.01),
      minClear: x(25e-5),
      adhesion: x(1),
      rimPin: x(1),
      falloff: x(0.008),
      clearance: x(5e-4),
    }
  );
}
function gn(e, t, n) {
  let r = n.mul(e.scale).add(e.offset).clamp(e.lo, e.hi);
  return t.sample(r).level(0).mul(0.001);
}
function _n(e, t, n) {
  return ke(e.sdfMap, w(t, n).mul(e.sdfScale).add(e.sdfOffset)).level(0);
}
function vn(e, t) {
  let n = e.deform,
    r = t.xz.length().max(1e-6),
    i = _n(n, r, t.y),
    a = i.x.mul(0.001).sub(n.clearance).div(n.falloff.max(1e-5)).clamp(0, 1),
    o = N(e.fillY.sub(n.band), e.fillY, t.y),
    s = I(n.adhesion, n.rimPin, o),
    c = V(1).sub(s.mul(V(1).sub(a.mul(a).mul(V(3).sub(a.mul(2)))))),
    l = s.mul(a.mul(a.oneMinus()).mul(6)).div(n.falloff.max(1e-5));
  return {
    m: c,
    grad: G(t.x.div(r).mul(i.y), i.z, t.z.div(r).mul(i.y)).mul(l),
  };
}
var yn = `positionBase`,
  bn = () => Ee(yn, `vec3`);
function xn(e) {
  let t = e.deform,
    n = Le(t.map),
    r = bn(),
    i = vn(e, r),
    a = H(() => {
      let a = oe,
        o = gn(t, n, a),
        s = I(V(1), t.surface, N(e.fillY.sub(t.band), e.fillY, a.y)),
        c = r.add(G(o.x, o.y.mul(s), o.z).mul(i.m)).toVar(),
        l = c.xz.length().max(1e-7),
        u = _n(t, l, c.y),
        d = t.minClear.sub(u.x.mul(0.001)).max(0).mul(t.freeBody.oneMinus());
      return (
        c.addAssign(G(c.x.div(l).mul(u.y), u.z, c.z.div(l).mul(u.y)).mul(d)),
        a.add(c.sub(r))
      );
    })(),
    o = H(() => {
      let r = oe,
        a = r.mul(t.scale).add(t.offset).clamp(t.lo, t.hi),
        o = t.texel,
        s = n
          .sample(a.add(G(o.x, 0, 0)))
          .level(0)
          .xyz.sub(n.sample(a.sub(G(o.x, 0, 0))).level(0).xyz)
          .mul(t.grad.x),
        c = n
          .sample(a.add(G(0, o.y, 0)))
          .level(0)
          .xyz.sub(n.sample(a.sub(G(0, o.y, 0))).level(0).xyz)
          .mul(t.grad.y),
        l = n
          .sample(a.add(G(0, 0, o.z)))
          .level(0)
          .xyz.sub(n.sample(a.sub(G(0, 0, o.z))).level(0).xyz)
          .mul(t.grad.z),
        u = I(V(1), t.surface, N(e.fillY.sub(t.band), e.fillY, r.y)),
        d = G(1, u, 1),
        f = gn(t, n, r).mul(d),
        p = L,
        m = G(p.dot(s.mul(d)), p.dot(c.mul(d)), p.dot(l.mul(d)))
          .mul(i.m)
          .add(i.grad.mul(p.dot(f)));
      return p.sub(m).normalize();
    })();
  return { position: a, normal: je(o) };
}
function Sn(e, t = xn(e)) {
  return I(v, t.position, e.deform.on);
}
function Cn(e, t) {
  return I(m.normalize(), t.normal.normalize(), e.deform.on).normalize();
}
function wn({ liquid: e, uniforms: n, pipeline: r, environment: i }) {
  let o = new cn({
    transmission: 1,
    color: new We(e.color),
    ior: e.ior,
    roughness: e.roughness,
    thickness: e.thickness,
    chromaticAberration: 0.04,
    dispersion: 0,
    attenuationColor: new We(`#ffffff`),
    attenuationDistance: 1,
    envMap: i,
    envMapIntensity: e.envMapIntensity,
    specularIntensity: 1,
    ditherStrength: 0,
    viewportBuffer: ke(r.textures.opaqueColor),
    transparent: !0,
    depthWrite: !0,
    side: 0,
  });
  o.name = `Liquid · fruit jelly`;
  let s = xn(n),
    c = Cn(n, s);
  ((o.positionNode = Sn(n, s)), (o.normalNode = a(c).normalize()));
  let l = (e) => ne(ke(e, K).x, le, S),
    u = B.z.sub(l(r.textures.liquidBackDepth)).clamp(0, n.maxDepth),
    d = ae(n.absorption.max(1e-4)).negate().div(fn(n).max(1e-4)),
    f = pe(d.mul(u).negate());
  ((o.volumeNode = f), (o.opticalThicknessNode = u.mul(Se).mul(13)), o._rebuildBackdrop());
  let p = V(1).sub(f.dot(G(0.3333))),
    m = b.dot(se).clamp(),
    h = t.mul(C(n.keyDirection, 0)).xyz.normalize(),
    g = b.dot(h).mul(0.5).add(0.5),
    _ = n.glowColor
      .mul(n.glow)
      .mul(p.mul(0.75).add(0.25))
      .mul(I(1.2, 0.85, m))
      .mul(I(0.7, 1.15, g)),
    y = N(0.75, 0.97, c.y),
    x = m.oneMinus().pow(2),
    w = I(G(1, 0.86, 0.8), n.glowColor, 0.55)
      .mul(y)
      .mul(x.mul(0.8).add(0.2))
      .mul(n.sheen),
    T = I(v.y, oe.y, n.deform.on),
    E = N(n.meniscus.mul(0.25), n.meniscus.mul(0.9), T.sub(n.fillY)).mul(
      n.meniscus.greaterThan(1e-4).select(1, 0),
    );
  o.emissiveNode = _.add(w).add(G(1, 0.9, 0.85).mul(E).mul(n.sheen).mul(0.8));
  let D = l(r.textures.opaqueDepth);
  return (
    (o.maskNode = B.z.greaterThan(D.sub(4e-5))),
    r.guard?.attach(o, { normal: b }),
    o
  );
}
function Tn(e) {
  let t = new fe({ colorWrite: !1, side: 1 });
  return (
    (t.name = `Liquid · back faces (depth)`),
    (t.positionNode = Sn(e)),
    t
  );
}
function En(e, t, n) {
  (e.color.set(n.color),
    (e.ior = n.ior),
    (e.roughness = n.roughness),
    (e.thickness = n.thickness),
    (e.envMapIntensity = n.envMapIntensity),
    t.absorption.value.set(n.attenuationColor),
    (t.distance.value = n.attenuationDistance));
  let r = un(n);
  ((t.angleAmount.value = r.amount),
    (t.angleRef.value = r.sinRef),
    (t.glow.value = n.glow),
    t.glowColor.value.set(n.glowColor),
    (t.sheen.value = n.sheen));
}
var Q = H(([e]) => {
    let t = z(G(e.x, e.y, e.x).mul(0.1031)).toVar();
    return (t.addAssign(Ge(t, t.yzx.add(33.33))), z(t.x.add(t.y).mul(t.z)));
  }),
  Dn = H(([e]) => {
    let t = z(G(e.x, e.y, e.x).mul(G(0.1031, 0.103, 0.0973))).toVar();
    return (t.addAssign(Ge(t, t.yzx.add(33.33))), z(t.xx.add(t.yz).mul(t.zy)));
  }),
  $ = (e, t = 0) => Pe(e.add(t)),
  On = (e, t) =>
    N(
      -0.1,
      0.55,
      $(e.mul(0.045), t.add(12.7)).add($(e.mul(0.14), 3.3).mul(0.35)),
    );
function kn(e, t, n) {
  let r = t.mul(0.3).add(0.15);
  return V(1).sub(
    N(r.sub(0.08), r.add(0.04), He(z(e).sub(n.mul(0.5).add(0.25)))),
  );
}
var An = (e, t, n, r) =>
    $(e.div(t.mul(1.3)).mul(0.85), n.mul(9.1))
      .mul(0.6)
      .add(Q(Ue(e.mul(r)).add(3.7)).mul(0.4))
      .add(0.2)
      .clamp(0, 1),
  jn = (e, t) => Ue(e.mul(9).add(t)).div(9),
  Mn = {
    length: 0.8,
    density: 1,
    relief: 0.1,
    smear: 1.35,
    speckle: 1,
    halo: 0.8,
  },
  Nn = 10,
  Pn =
    `edgeRoughness.bristles.flecks.edgeDarken.corner.seed.edgeNoiseScale.edgeOctaves.edgeLacunarity.edgeGain.edgeDisplacement.edgeTilt.edgeOverlap.deckle.deckleScale.edgeWidth.bristleReach.bristleLength.bristleDensity.bristleScale.bristleAngleJitter.fleckSize.fleckSpread.cornerRandom.cornerTL.cornerTR.cornerBL.cornerBR.edgeDarkenWidth.ribContrast.grainScale.ribScale.ribAngle`.split(
      `.`,
    ),
  Fn = 5,
  In = [`enabled`, `flowSmoothing`],
  Ln = [`width`, `height`, `dpr`],
  Rn = [`value`],
  zn = [`seed`],
  Bn = [`viewportFrame`, `viewportInset`, `frame`, `frameSize`, ...new Set(Pn.filter((e) => e !== `edgeDarken`))];
function Vn({ renderer: t, inputNode: n, settings: i, subjectDepth = null, subjectOpaqueDepth = null, subjectGlassDepth = null, linearInput = false }) {
  let a = V(0),
    s = {
      viewport: x(new r(1, 1)),
      dpr: x(1),
      half: x(new r(1, 1)),
      edgeScale: x(1),
      cornerRadius: x(6),
      roughness: x(0.5),
      bristles: x(0.5),
      flecks: x(0.4),
      frameOn: x(1),
      seed: x(1),
      ribScale: x(1),
      ribAngle: x(0),
      edgeDarken: x(0.12),
      paper: x(new F(0.957, 0.945, 0.918)),
      edgeNoiseScale: x(1),
      edgeOctaves: x(2),
      edgeLacunarity: x(7.5),
      edgeGain: x(0.3143),
      edgeDisplacement: x(7),
      edgeTilt: x(6),
      edgeOverlap: x(9),
      deckle: x(1),
      deckleScale: x(1),
      edgeWidth: x(1),
      bristleReach: x(1),
      bristleLength: x(1),
      bristleDensity: x(0.5),
      bristleScale: x(1),
      bristleAngle: x(0),
      fleckSize: x(1),
      fleckSpread: x(1),
      cornerRandom: x(1),
      corners: x(new Ve(1, 1, 1, 1)),
      edgeDarkenWidth: x(1.8),
      ribContrast: x(1),
      grainScale: x(1),
      styleStrength: x(1),
      stepLength: x(1),
      strokeWidth: x(3),
      density: x(0.6),
      haloWeight: x(1),
      strokeAngle: x(0),
      relief: x(0.6),
      lightDir: x(new F(0, 1, 1)),
      smear: x(0.4),
      speckle: x(0),
      speckleSize: x(1),
      subjectGrain: x(1),
      clothGrain: x(1),
      subjectSmear: x(1),
    },
    c = { width: 1, height: 1, dpr: 1 },
    l = {
      node: null,
      pipelines: new Set(),
      disposables: [],
      signature: ``,
      pending: null,
      pendingSince: 0,
      builds: 0,
      buildMs: 0,
      cssTargets: [],
      noiseRT: null,
      paperColor: ``,
      staticSeen: { settings: [], size: [] },
      noiseSeen: null,
    },
    u = H(() => {
      let e = Ie.xy.div(s.dpr),
        t = e.sub(s.viewport.mul(0.5)).toVar(),
        n = V(0.75).div(s.dpr),
        r = ze(s.ribAngle),
        i = A(s.ribAngle),
        a = w(t.x.mul(r).sub(t.y.mul(i)), t.x.mul(i).add(t.y.mul(r)))
          .div(s.ribScale)
          .toVar(),
        o = $(a.mul(0.008), 3.7)
          .mul(1.8)
          .add($(a.mul(0.04), 9.1).mul(0.4)),
        c = a.y.add(o).toVar(),
        l = $(w(a.x.mul(0.016), c.mul(0.29)), 11.3),
        u = $(w(a.x.mul(0.04), c.mul(0.55)), 27.9),
        f = $(t.mul(0.45).div(s.grainScale), 51.7),
        m = c.div(3.6),
        g = V(0.5).sub(ze(z(m).mul(Math.PI * 2)).mul(0.5)),
        _ = N(-0.45, 0.35, $(w(a.x.mul(0.055), Ue(m).mul(3.17)), 91.3)),
        v = s.ribScale.mul(3.6).mul(s.dpr),
        y = N(2.2, 3.2, v).mul(N(3, 6.5, v).mul(0.4).add(0.6)),
        b = g
          .mul(_)
          .sub(0.3)
          .mul(2)
          .mul(y)
          .mul(0.5)
          .mul(s.ribContrast)
          .add(l.mul(0.5))
          .add(u.mul(0.2))
          .add(f.mul(0.15))
          .toVar(),
        x = Oe(G(t.mul(0.0055).div(s.grainScale), 5.3), 3, 2.1, 0.5),
        S = h(0, t.x),
        T = h(0, t.y),
        E = Q(w(S, T).add(s.seed.mul(1.37))),
        D = I(
          I(s.corners.x, s.corners.y, S),
          I(s.corners.z, s.corners.w, S),
          T,
        ),
        O = s.cornerRadius
          .mul(D)
          .mul(E.sub(0.5).mul(0.9).mul(s.cornerRandom).add(1.05))
          .max(0),
        k = be(t).sub(s.half).add(O),
        j = He(p(k, 0))
          .add(d(p(k.x, k.y), 0))
          .sub(O),
        M = (e, t, n) => {
          let r = n.add(s.seed.mul(7.31)),
            i = e.mul(s.edgeNoiseScale),
            a = V(0).toVar(),
            o = V(0.004),
            c = s.edgeDisplacement;
          for (let e = 0; e < Fn; e++) {
            let t = s.edgeOctaves.sub(e).clamp(0, 1);
            (a.addAssign(
              $(G(i.mul(o), r.add(3.3 * e), 0))
                .mul(c)
                .mul(t),
            ),
              (o = o.mul(s.edgeLacunarity)),
              (c = c.mul(s.edgeGain)));
          }
          let l = Q(w(r, 5.1))
              .sub(0.5)
              .mul(s.edgeTilt)
              .mul(e.div(p(t, 1))),
            u = N(0.3, 0.62, $(G(i.mul(0.0065), r.add(21.7), 0))).mul(
              s.edgeOverlap,
            ),
            d = N(-0.25, 0.45, $(G(i.mul(0.0085), r.add(13.1), 0)));
          return { shift: a.add(l).add(u).mul(s.edgeScale), dry: d };
        },
        P = M(t.x, s.half.x, h(0, t.y).add(1)),
        F = M(t.y, s.half.y, h(0, t.x).add(3)),
        L = N(-6, 6, k.x.sub(k.y)),
        ee = I(P.shift, F.shift, L),
        R = I(P.dry, F.dry, L),
        te = t.mul(s.deckleScale),
        ne = $(G(te.mul(0.3), 31.1))
          .mul(2.4)
          .add($(G(te.mul(0.85), 47.3)).mul(1))
          .mul(s.deckle),
        re = j.sub(ee.add(ne).mul(s.roughness)).toVar(),
        ie = $(t.mul(0.003), s.seed.mul(2.9).add(17.7)).mul(s.bristleAngle),
        ae = ze(ie),
        B = A(ie),
        oe = a.x.mul(ae).sub(c.mul(B)).div(s.bristleLength),
        H = a.x.mul(B).add(c.mul(ae)).div(s.bristleScale),
        se = $(w(oe.mul(0.016), H.mul(0.36)), w(71.3, 0)),
        ce = $(w(oe.mul(0.045), H.mul(0.8)), w(83.1, 0)),
        le = se
          .mul(0.55)
          .add(ce.mul(0.3))
          .add(b.mul(0.25))
          .add(s.bristleDensity.sub(0.5).mul(1.6)),
        ue = s.bristles
          .mul(s.bristleReach)
          .mul(I(1.5, 10, R))
          .mul(I(0.45, 1, L))
          .mul(s.edgeScale),
        fe = re.negate().add(le.mul(ue)).toVar(),
        me = N(n.negate(), n, fe),
        he = de(fe.div(p(ue.mul(0.8).mul(s.edgeWidth), 1)), 0, 1),
        ge = I(N(-0.7, 0.5, ce).mul(0.5).add(0.5), V(1), he),
        _e = me.mul(I(V(1), ge, de(s.bristles, 0, 1).mul(R))),
        ve = pe(p(fe, 0).div(s.edgeDarkenWidth.max(0.05).negate())).mul(me),
        ye = p(s.fleckSize.mul(0.8), 1).mul(11),
        xe = e.div(ye),
        Se = Ue(xe),
        U = Dn(Se.add(s.seed.mul(17.1)))
          .mul(0.4)
          .add(0.3),
        Ce = Q(Se.add(91.7)).mul(0.12).add(0.05).mul(ye).mul(s.fleckSize),
        we = He(z(xe).sub(U).mul(w(0.65, 1))).mul(ye),
        Te = N(1.5, 4, re).mul(
          V(1).sub(
            N(
              s.edgeScale.mul(6).mul(s.fleckSpread),
              s.edgeScale.mul(26).mul(s.fleckSpread),
              re,
            ),
          ),
        ),
        Ee = N(0.05, 0.55, $(e.mul(0.009), s.seed.mul(5.3).add(61.3))),
        W = s.flecks.mul(Te).mul(Ee).mul(0.45),
        De = V(1)
          .sub(h(W, Q(Se.add(s.seed.mul(3.1)).add(7.3))))
          .mul(V(1).sub(N(Ce.sub(n), Ce.add(n), we))),
        ke = I(V(1), p(_e, De), s.frameOn);
      return C(ke, ve.mul(s.frameOn), b.mul(0.5).add(0.5), x.mul(0.5).add(0.5));
    }),
    f = ge(u(), null, null, { autoUpdate: !1, type: M, depthBuffer: !1 });
  f.name = `PostFX · paper + frame`;
  let m = (e) => e.sample(K),
    g = (e, t) => {
      let n = null;
      for (let r of [-0.75, -0.25, 0.25, 0.75])
        for (let i of [-0.75, -0.25, 0.25, 0.75]) {
          let a = f.sample(e.add(w(i, r)).mul(t)).level(0).x;
          n = n ? p(n, a) : a;
        }
      return n;
    },
    _ = H(() => {
      let e = K.mul(s.viewport),
        t = s.strokeWidth,
        n = t.mul(1.7),
        r = e.div(n),
        i = Ue(r),
        a = Dn(i.add(s.seed.mul(13.7)))
          .mul(0.4)
          .add(0.3),
        o = He(z(r).sub(a)).mul(n),
        c = Q(i.add(s.seed.mul(2.3)).add(41.9))
          .mul(0.28)
          .add(0.32)
          .mul(t),
        l = V(1).sub(N(c.sub(t.mul(0.1)), c.add(t.mul(0.06)), o)),
        u = Q(i.add(s.seed.mul(5.1)).add(3.7)),
        d = $(e.div(t.mul(0.1).add(1.6)), 41.3)
          .mul(0.35)
          .add($(e.div(t.mul(0.03).add(0.9)), 17.9).mul(0.15))
          .add(0.5);
      return C(l, u, d, 0);
    }),
    v = (e) =>
      H(() => {
        let t = w(1).div(s.viewport),
          n = (n, r) => e.sample(K.add(t.mul(w(n, r)))).rgb,
          r = n(-1, -1),
          i = n(0, -1),
          a = n(1, -1),
          o = n(-1, 0),
          c = n(1, 0),
          l = n(-1, 1),
          u = n(0, 1),
          d = n(1, 1),
          f = a.add(c.mul(2)).add(d).sub(r).sub(o.mul(2)).sub(l).mul(0.25),
          p = l.add(u.mul(2)).add(d).sub(r).sub(i.mul(2)).sub(a).mul(0.25),
          m = G(Ge(f, f), Ge(p, p), Ge(f, p)),
          h = m.x.add(m.y);
        return C(m.div(h.add(0.02)), h);
      })(),
    b = (e, t) =>
      H(() => {
        let n = e.sample(K),
          r = t.sample(K),
          i = K.mul(s.viewport),
          a = s.strokeAngle.add(
            $(i.mul(0.004), s.seed.mul(1.9).add(23.1)).mul(0.35),
          ),
          o = w(A(a).negate(), ze(a)),
          c = n.xyz
            .add(r.xyz.mul(s.haloWeight))
            .add(G(o.x.mul(o.x), o.y.mul(o.y), o.x.mul(o.y)).mul(0.08))
            .toVar(),
          l = w(c.x.sub(c.y), c.z.mul(2)).negate().toVar(),
          u = He(l),
          d = $(i.div(s.stepLength.mul(50)), s.seed.mul(3.1).add(77.7)).mul(
            0.42,
          ),
          f = ze(d),
          m = A(d),
          h = l.div(p(u, 1e-9));
        return C(
          h.x.mul(f).sub(h.y.mul(m)),
          h.x.mul(m).add(h.y.mul(f)),
          R(p(n.w, 0)),
          R(p(r.w, 0)),
        );
      })(),
    S = (e, t, n, { strokes: r = !0, height: i = !0 } = {}) =>
      H(() => {
        let a = w(1).div(s.viewport),
          o = K.mul(s.viewport);
        if (!r && !i) return E(e, t, a, o);
        let c = T(t, a),
          l = c(o).toVar(),
          u = n.sample(K),
          d = m(e).rgb,
          f = (e, t) => {
            let n = h(e.y, s.density),
              r = z(e.y.div(p(s.density, 0.001)).mul(7.31))
                .mul(0.45)
                .add(0.55);
            return e.x
              .mul(n)
              .mul(r)
              .mul(N(1, 0.55, t));
          },
          _ = (e, t) => e.x.mul(N(1, 0.55, t)),
          v = (e) => z(e.y.mul(13.7)).sub(0.5).mul(0.07).add(1),
          b = (e) => {
            let t = s.strokeWidth.mul(1.7),
              n = Ue(e.div(t));
            return n
              .add(
                Dn(n.add(s.seed.mul(13.7)))
                  .mul(0.4)
                  .add(0.3),
              )
              .mul(t);
          },
          x = C(d, 0).toVar(),
          S = () => {
            let t = u.z.sub(0.5).mul(0.5),
              r = f(u, 0).toVar(),
              m = u.x.toVar(),
              h = w(o).toVar(),
              g = v(u).toVar(),
              S = u.z.toVar(),
              T = V(1).toVar(),
              E = G(d).toVar(),
              D = (i) => {
                let u = w(o).toVar(),
                  d = l.mul(i).toVar();
                Be(
                  {
                    start: 1,
                    end: 11,
                    type: `int`,
                    condition: `<`,
                    name: i > 0 ? `fw` : `bw`,
                  },
                  ({ fw: i, bw: o }) => {
                    let l = V(i ?? o).div(Nn),
                      b = l.add(t),
                      x = c(u).toVar();
                    (y(Ge(x, d).lessThan(0), () => {
                      x.assign(x.negate());
                    }),
                      u.addAssign(x.mul(s.stepLength)),
                      d.assign(x));
                    let C = u.mul(a),
                      w = n.sample(C).level(0),
                      D = e.sample(C).level(0).rgb,
                      O = f(w, b);
                    (h.assign(W(O.greaterThan(r), u, h)),
                      g.assign(W(O.greaterThan(r), v(w), g)),
                      m.assign(W(O.greaterThan(r), _(w, b), m)),
                      r.assign(p(r, O)));
                    let k = ze(l.mul(Math.PI)).mul(0.5).add(0.5);
                    (S.addAssign(w.z.mul(k)),
                      E.addAssign(D.mul(k)),
                      T.addAssign(k));
                  },
                );
              };
            (D(1), D(-1));
            let O = e.sample(b(h).mul(a)).level(0).rgb.mul(g);
            if (!i) {
              x.assign(C(I(E.div(T), O, N(0.02, 0.2, r)), 0));
              return;
            }
            let k = S.div(T).sub(0.5).mul(3.2),
              A = m
                .mul(V(1).sub(m))
                .mul(4)
                .mul(N(0.02, 0.2, r)),
              j = r.add(A.mul(0.12)).add(k.mul(r.mul(0.2).add(0.16))),
              M = I(E.div(T), O, N(0.02, 0.2, r));
            x.assign(C(M, j));
          };
        return (i ? S() : y(g(o, a).greaterThan(0), S), x);
      })();
  function T(e, t) {
    return (n) => {
      let r = e.sample(n.mul(t)).level(0),
        i = ye(r.y, r.x).mul(0.5);
      return w(ze(i), A(i));
    };
  }
  function E(e, t, n, r) {
    let i = T(t, n),
      a = i(r).toVar(),
      o = m(e).rgb,
      c = C(o, 0).toVar();
    return (
      y(g(r, n).greaterThan(0), () => {
        let t = V(1).toVar(),
          l = G(o).toVar(),
          u = (o) => {
            let c = w(r).toVar(),
              u = a.mul(o).toVar();
            Be(
              {
                start: 1,
                end: 11,
                type: `int`,
                condition: `<`,
                name: o > 0 ? `fw` : `bw`,
              },
              ({ fw: r, bw: a }) => {
                let o = V(r ?? a).div(Nn),
                  d = i(c).toVar();
                (y(Ge(d, u).lessThan(0), () => {
                  d.assign(d.negate());
                }),
                  c.addAssign(d.mul(s.stepLength)),
                  u.assign(d));
                let f = e.sample(c.mul(n)).level(0).rgb,
                  p = ze(o.mul(Math.PI)).mul(0.5).add(0.5);
                (l.addAssign(f.mul(p)), t.addAssign(p));
              },
            );
          };
        (u(1), u(-1), c.assign(C(l.div(t), 0)));
      }),
      c
    );
  }
  // Use the already-rendered, elastically deformed jelly depth. Front stem and
  // ribbon pixels remain under the original post treatment. No extra draw pass.
  function subjectAt(uv) {
    if (!subjectDepth) return V(0);
    const back = ke(subjectDepth, uv).x;
    return back.lessThan(0.999999)
      .and(ke(subjectOpaqueDepth, uv).x.greaterThan(back.sub(0.000001)))
      .and(ke(subjectGlassDepth, uv).x.greaterThan(back.sub(0.000001)))
      .select(1, 0);
  }
  function subjectMask() {
    const px = w(1.5).div(s.viewport).div(s.dpr);
    const center = subjectAt(K);
    // A small inward feather avoids a hard post-processing cutout at the rim.
    return center.mul(center
      .add(subjectAt(K.add(w(px.x, 0))))
      .add(subjectAt(K.sub(w(px.x, 0))))
      .add(subjectAt(K.add(w(0, px.y))))
      .add(subjectAt(K.sub(w(0, px.y))))).div(5);
  }
  function D() {
    let e = performance.now();
    for (let e of l.disposables) e.dispose?.();
    ((l.disposables = []),
      (l.noiseRT = null),
      (l.cssTargets = []),
      (l.noiseSeen = { width: [], seed: [], size: [] }));
    let t = i;
    if (!t.enabled) return linearInput ? n : Re(n);
    let r = linearInput ? n : Re(n),
      o = (e, t, n = 1, r = {}) => {
        let i = ge(e, null, null, {
          type: M,
          depthBuffer: !1,
          resolutionScale: n / c.dpr,
          ...r,
        });
        return (
          (i.name = t),
          l.cssTargets.push({ target: i, k: n }),
          l.disposables.push(i),
          i
        );
      },
      u = ge(r, null, null, { type: M, depthBuffer: !1 });
    ((u.name = `PostFX · display`), l.disposables.push(u));
    let d = o(_(), `PostFX · stroke noise`, 1, { autoUpdate: !1 });
    l.noiseRT = d;
    let flowScale = .5 * Math.max(.5, Math.min(1, i.vrPaintScale ?? 1));
    let p = o(v(u), `PostFX · flow tensor`, flowScale),
      g = U.clamp(t.flowSmoothing, 0, 4),
      x = Ne(p, null, Math.max(1, Math.round(1 + 2 * g))),
      T = Ne(x.getTextureNode(), null, Math.max(2, Math.round(4 + 8 * g)), {
        resolutionScale: 0.5,
      });
    l.disposables.push(x, T);
    let E = o(b(x.getTextureNode(), T.getTextureNode()), `PostFX · flow`, flowScale),
      D = t.relief > 0,
      O = o(
        S(u, E, d, { strokes: t.strokeDensity > 0, height: D }),
        `PostFX · strokes`,
        Math.max(.5,Math.min(1,i.vrPaintScale ?? 1)),
      ),
      k = H(() => {
        let e = m(f),
          t = de(r.rgb, 0, 1).toVar(),
          n = m(O),
          i = w(1).div(s.viewport),
          o = s.styleStrength,
          bodyMask = subjectMask().toVar(),
          clothMask = subjectGlassDepth ? ke(subjectGlassDepth,K).x.lessThan(.999999).select(1,0) : V(0),
          grainKeep = I(I(V(1), s.subjectGrain, bodyMask),s.clothGrain,clothMask),
          smearKeep = I(V(1), s.subjectSmear, bodyMask),
          c = K.mul(s.viewport),
          l = m(E),
          d = ye(l.y, l.x).mul(0.5),
          p = w(A(d).negate(), ze(d)),
          g = s.speckleSize.mul(2.1),
          _ = c.div(g),
          v = Ue(_),
          b = Q(v.add(s.seed.mul(3.3))).toVar(),
          x = Q(v.add(s.seed.mul(1.7)).add(71.1)).toVar(),
          S = W(x.lessThan(0.5), V(1), V(-1)),
          T = g.mul(b.mul(3).add(1.2)),
          k = u.sample(K.add(p.mul(S).mul(T).mul(i))).rgb.toVar(),
          j = V(a).toVar(),
          M = D
            ? (() => {
                let e = (e, t) => O.sample(K.add(i.mul(w(e, t)))).w,
                  t = e(1, 0).sub(e(-1, 0)),
                  n = e(0, 1).sub(e(0, -1)),
                  r = G(t.negate(), n, V(1.6)).normalize(),
                  a = s.lightDir;
                return Ge(r, a)
                  .sub(Ge(G(0, 0, 1), a))
                  .toVar();
              })()
            : null,
          P = C(s.paper, 1).toVar();
        return (
          y(e.x.greaterThan(0), () => {
            let r = G(t).toVar();
            {
              let e = de(n.rgb, 0, 1).sub(r),
                t = pe(Ge(e, e).mul(-10));
              r.assign(I(r, de(n.rgb, 0, 1), de(s.smear.mul(o).mul(t).mul(smearKeep), 0, 1)));
            }
            D && r.assign(r.mul(V(1).add(M.mul(s.relief).mul(o).mul(1.6).mul(smearKeep))));
            {
              let e = N(0.02, 0.1, l.w)
                  .mul(0.85)
                  .add(N(0.03, 0.2, l.z).mul(0.3))
                  .add(0.04),
                t = Dn(v.add(5.5)),
                n = On(c, s.seed),
                i = kn(_, x, t),
                a = s.speckle.mul(o).mul(e).mul(n).mul(1.4).mul(grainKeep),
                u = h(b, a).mul(i);
              r.assign(I(r, k, u));
              let d = An(c, s.speckleSize, s.seed, s.dpr);
              r.assign(I(r, jn(r, d), de(s.speckle.mul(o).mul(0.7).mul(grainKeep), 0, 1)));
            }
            (r.assign(I(r, t, j)),
              r.assign(r.mul(V(1).sub(e.y.mul(s.edgeDarken)))),
              P.assign(C(I(s.paper, de(r, 0, 1), e.x), 1)));
          }),
          P
        );
      })();
    return ((l.buildMs = performance.now() - e), k);
  }
  function O() {
    return (
      In.map((e) => i[e]).join(`|`) + `|${i.relief > 0}|${i.strokeDensity > 0}|${i.vrPaintScale ?? 1}`
    );
  }
  function k() {
    ((l.signature = O()), (l.node = D()), l.builds++);
    for (let e of l.pipelines) ((e.outputNode = l.node), (e.needsUpdate = !0));
  }
  function j(e, t) {
    let n = new We();
    n.setStyle(e, o);
    let r = n.getRGB({ r: 0, g: 0, b: 0 }, o);
    return t.set(r.r, r.g, r.b);
  }
  function P(e) {
    let t = U.clamp(i.frameSize, 0.3, 1.2) * Math.min(c.width, c.height) * 0.5;
    if(i.viewportFrame) {
      const inset=Math.max(4,Math.min(c.width,c.height)*(i.viewportInset??.018));
      return e.set(Math.max(1,c.width*.5-inset),Math.max(1,c.height*.5-inset));
    }
    return e.set(t, t);
  }
  function L() {
    let t = i;
    (P(s.half.value),
      (s.edgeScale.value = U.clamp(
        Math.min(s.half.value.x, s.half.value.y) / 420,
        0.5,
        1.3,
      )),
      (s.cornerRadius.value = 2 + 10 * t.corner),
      (s.roughness.value = t.edgeRoughness),
      (s.bristles.value = t.bristles),
      (s.flecks.value = t.flecks),
      (s.frameOn.value = +!!t.frame),
      (s.seed.value = t.seed),
      (s.ribScale.value = Math.max(0.25, t.ribScale)),
      (s.ribAngle.value = U.degToRad(t.ribAngle)),
      (s.edgeDarken.value = t.frame ? t.edgeDarken : 0),
      t.paperColor !== l.paperColor &&
        ((l.paperColor = t.paperColor), j(t.paperColor, s.paper.value)),
      (s.edgeNoiseScale.value = Math.max(0.05, t.edgeNoiseScale)),
      (s.edgeOctaves.value = U.clamp(t.edgeOctaves, 0, Fn)),
      (s.edgeLacunarity.value = Math.max(1, t.edgeLacunarity)),
      (s.edgeGain.value = Math.max(0, t.edgeGain)),
      (s.edgeDisplacement.value = t.edgeDisplacement),
      (s.edgeTilt.value = t.edgeTilt),
      (s.edgeOverlap.value = t.edgeOverlap),
      (s.deckle.value = t.deckle),
      (s.deckleScale.value = Math.max(0.05, t.deckleScale)),
      (s.edgeWidth.value = Math.max(0.05, t.edgeWidth)),
      (s.bristleReach.value = t.bristleReach),
      (s.bristleLength.value = Math.max(0.05, t.bristleLength)),
      (s.bristleDensity.value = t.bristleDensity),
      (s.bristleScale.value = Math.max(0.05, t.bristleScale)),
      (s.bristleAngle.value = U.degToRad(t.bristleAngleJitter)),
      (s.fleckSize.value = Math.max(0.05, t.fleckSize)),
      (s.fleckSpread.value = Math.max(0.05, t.fleckSpread)),
      (s.cornerRandom.value = t.cornerRandom),
      s.corners.value.set(t.cornerTL, t.cornerTR, t.cornerBL, t.cornerBR),
      (s.edgeDarkenWidth.value = t.edgeDarkenWidth),
      (s.ribContrast.value = t.ribContrast),
      (s.grainScale.value = Math.max(0.05, t.grainScale)),
      (s.styleStrength.value = U.clamp(t.styleStrength, 0, 4)),
      (s.stepLength.value = Math.max(0.5, t.strokeLength * Mn.length) / 20),
      (s.strokeWidth.value = U.clamp(t.strokeWidth, 1, 64)),
      (s.density.value = U.clamp(t.strokeDensity * Mn.density, 0, 1)),
      (s.haloWeight.value = Math.max(0, t.halo * Mn.halo) * 5),
      (s.strokeAngle.value = U.degToRad(t.strokeAngle)),
      (s.relief.value = Math.max(0, t.relief * Mn.relief)));
    let n = U.degToRad(t.lightAngle);
    (s.lightDir.value.set(Math.cos(n), Math.sin(n), 0.9).normalize(),
      (s.smear.value = U.clamp(t.smear * Mn.smear, 0, 1)),
      (s.speckle.value = Math.max(0, t.speckle * Mn.speckle)),
      (s.speckleSize.value = U.clamp(t.speckleSize, 0.3, 6)));
    let r = l.noiseSeen,
      a = l.staticSeen;
    (l.noiseRT &&
      e(s.strokeWidth, Rn, r.width) | e(t, zn, r.seed) | e(c, Ln, r.size) &&
      (l.noiseRT.textureNeedsUpdate = !0),
      e(i, Bn, a.settings) | e(c, Ln, a.size) && (f.textureNeedsUpdate = !0));
  }
  // A VR eye has its own pixel extent. RTTNode otherwise auto-resizes to the
  // desktop mirror canvas, which is two eyes wide. Null restores desktop mode.
  function applyRenderSize() {
    for(const node of [...l.disposables,f,l.transmissionTexture]) {
      if(!node?.isRTTNode)continue;
      if(l.eyeWidth==null){
        if(node.width!==null){node.width=null;node.height=null;node.textureNeedsUpdate=true;}
      }else if(node.width!==l.eyeWidth||node.height!==l.eyeHeight){
        node.width=l.eyeWidth;node.height=l.eyeHeight;node.setSize(l.eyeWidth,l.eyeHeight);
      }
    }
  }
  let ee = {
      setRenderSize(width,height){l.eyeWidth=width;l.eyeHeight=height;applyRenderSize();},
      uniforms: s,
      settings: i,
      stats: l,
      getTransmissionTexture() {
        if (!l.transmissionTexture || l.transmissionBuild !== l.builds) {
          l.transmissionTexture?.dispose();
          l.transmissionTexture = ge(l.node, null, null, {type:M, depthBuffer:false, autoUpdate:false});
          l.transmissionTexture.name = "Painted background for jelly transmission";
          l.transmissionTexture._quadMesh.material.fragmentNode = l.node;
          l.transmissionTexture._quadMesh.material.needsUpdate = true;
          l.transmissionTexture.value.generateMipmaps = true;
          l.transmissionTexture.value.minFilter = 1008;
          l.transmissionBuild = l.builds;
        }
        applyRenderSize();return l.transmissionTexture;
      },
      attach(e) {
        return (
          l.pipelines.add(e),
          (e.outputColorTransform = !1),
          (e.outputNode = l.node),
          (e.needsUpdate = !0),
          ee
        );
      },
      setSize(e, t, n = 1) {
        let r = n !== c.dpr;
        if (
          (Object.assign(c, { width: e, height: t, dpr: n }),
          s.viewport.value.set(e, t),
          (s.dpr.value = n),
          r)
        )
          for (let { target: e, k: t } of l.cssTargets)
            e.setResolutionScale(t / n);
      },
      update() {
        L();
        let e = O();
        if (e !== l.signature) {
          let t = performance.now();
          l.pending === e
            ? t - l.pendingSince > 150 && ((l.pending = null), k())
            : ((l.pending = e), (l.pendingSince = t));
        }
        applyRenderSize();
      },
      setUIProtection(e) {
        ((a = e), k());
      },
      get frameTexture() {
        return f.value;
      },
      frameRect() {
        let e = P(new r());
        return !i.enabled || !i.frame
          ? { x: 0, y: 0, width: c.width, height: c.height }
          : {
              x: c.width * 0.5 - e.x,
              y: c.height * 0.5 - e.y,
              width: e.x * 2,
              height: e.y * 2,
            };
      },
      dispose() {
        for (let e of l.disposables) e.dispose?.();
        ((l.disposables = []), f.dispose(), l.pipelines.clear());
      },
    },
    te = t.getSize(new r());
  return (ee.setSize(te.x, te.y, t.getPixelRatio()), L(), k(), ee);
}
export {
  Wt as C,
  Rt as E,
  Ut as S,
  zt as T,
  xn as _,
  $ as a,
  qt as b,
  kn as c,
  mn as d,
  En as f,
  pn as g,
  wn as h,
  Dn as i,
  On as l,
  Tn as m,
  Vn as n,
  An as o,
  dn as p,
  Q as r,
  jn as s,
  Pn as t,
  yn as u,
  sn as v,
  Ht as w,
  Bt as x,
  Jt as y,
};
