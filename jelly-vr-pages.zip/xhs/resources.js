// Short original WAVs and binary meshes are packaged as classic JS data resources.
// The container does not admit WAV/GLB files or request-based loaders. No network API is used.
export function readBinary(path){
 const key=path.replace(/^\//,'').replace(/^jelly-painting\//,'');
 const b64=window.STAR_PACK && window.STAR_PACK[key];
 if(!b64)throw new Error('Missing packaged resource: '+key);
 const raw=atob(b64),bytes=new Uint8Array(raw.length);
 for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
 return bytes.buffer;
}
