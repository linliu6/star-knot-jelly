const KEY='jelly-public-vr32-content';
let data={},queue=Promise.resolve(),restored=false;
const memory={};
export const session={getItem:k=>memory[k]||null,setItem:(k,v)=>{memory[k]=String(v)}};
function status(text){const n=document.querySelector('#sound-status');if(n)n.textContent=text;}
export async function initStorage(){
 try{const raw=localStorage.getItem(KEY);const parsed=JSON.parse(raw||'{}');if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('Invalid save');data=parsed;restored=true;}
 catch{restored=false;}
}
export const store={
 getItem:k=>data[k]===undefined?null:data[k],
 setItem(k,v){data[k]=String(v);save();},removeItem(k){delete data[k];save();},
 snapshot:()=>({native:false,restored,keys:Object.keys(data)}),flush:()=>queue
};
function save(){
 if(!restored){status('Your choice is active. Browser storage is unavailable; saved settings have been kept.');return;}
 const payload=JSON.stringify(data);queue=queue.catch(()=>{}).then(()=>{
  try{localStorage.setItem(KEY,payload);}catch{status('Your choice is active but could not be saved. You may need to choose again next time.');}
 });
}
