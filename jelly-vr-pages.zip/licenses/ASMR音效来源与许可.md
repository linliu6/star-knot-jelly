# ASMR 录音来源与用途

采集日期：2026-10-14。20 份不同的原始录音来自 [SONNISS 官方 GDC 免费合集](https://sonniss.com/gameaudiogdc/)，从官网列出的 Your.Org 镜像取得。不是商店水印试听或从视频提取的音轨。

这些是用于 ASMR 触感设计的专业拟音候选，不是声称作者发布了专门的 ASMR 作品；中文名描述本场景的处理方向。果冻四项来自同一软胶库中的不同录音，其他项来自布料、木质和气流库。最终舒适度需要用户试听决定。

本次读取的 [GDC Bundle License](https://sonniss.com/gdc-bundle-license/) 为 2.0（2026-08-27 生效）。许可允许修改并嵌入个人或商业交互作品，无须强制署名；不允许把原始或处理后声音单独再分发为素材库，也不允许 AI/ML 训练。本项目仅作互动声音，不提供音效下载服务。版权仍属各录音作者。

完整下载地址、ZIP 内原路径、原文件 SHA-256、原始格式、截取位置、滤波和音量处理记录见 `ASMR音效来源.json`。原始 WAV 保存在本地 `audio-masters/`，不随网页发布；网页使用 `audio/` 内的 48 kHz / 16-bit / 单声道无损 WAV 片段。原录音为 96 kHz / 24-bit 或 192 kHz / 24-bit，另有一份 192 kHz / 32-bit float 布料录音。单声道处理用于保证 iPhone 外放兼容。

重新处理：在 macOS 使用带 NumPy 的 Python 运行 `scripts/prepare-audio.py`；该脚本使用系统 afconvert 重采样。原始来源清单与处理数据均已保存。网页运行不需要 Python 音频依赖。

| 分组 | 场景名称 | 原作者 / 库 | 原文件 |
|---|---|---|---|
| apple | 软胶轻按 | Mattia Cellotto / The Borax Experiment | Borax,Impact,Slime,Gore,Various05.wav |
| apple | 湿润拉伸 | Mattia Cellotto / The Borax Experiment | Borax,Impact,Slime,Gore,Various16.wav |
| apple | 厚软揉捏 | Mattia Cellotto / The Borax Experiment | Borax,Impact,Slime,Gore,Various22.wav |
| apple | 细泡黏弹 | Mattia Cellotto / The Borax Experiment | Borax,Impact,Slime,Gore,Various63.wav |
| apple | 轻水咕噜 | Eiravaein Works / Unfathomed | Unfathomed,hydrophone,submerged,largeplastic,water,foam,gurgling,gentle.wav |
| orbit | 轻柔滑过 | Airborne Sound / Organic Whooshes | Whoosh,Organic,Styrofoam,Plank,Airy,Smooth,Texture,1.wav |
| orbit | 饱满微风 | Airborne Sound / Airy Whooshes | Whoosh,Sound Design,Airy,Full,Forceful,Soft.wav |
| orbit | 缓慢气浪 | Airborne Sound / Airy Whooshes | Whoosh,Sound Design,Airy,Full,Soft,Shudder,Very Slow,Aftershock.wav |
| orbit | 短风起伏 | Airborne Sound / Airy Whooshes | Whoosh,Sound Design,Airy,Full,Soft,Buffet,Medium.wav |
| orbit | 绵软旋流 | Airborne Sound / Eclectic Whooshes 2 | Whoosh,Sound Design,Swirl,Airy,Diffuse,Medium Slow,2.wav |
| ribbon | 轻布掠过 | Airborne Sound / Organic Whooshes | Whoosh,Organic,Fabric,Glove,Airy,Breathy,Punchy.wav |
| ribbon | 窄带轻擦 | Airborne Sound / Organic Whooshes | Whoosh,Organic,Fabric,Strap,Zip,High,Stagger,Pushy.wav |
| ribbon | 织物细摩 | SoundBits / Tiny Transitions 2 | Scrape_Cloth_10.wav |
| ribbon | 棉布拂动 | Soundholder / Swipes And Whooshes | swipes and whooshes tshirt fast and short swings stereo ORTF 8040.wav |
| ribbon | 柔布扑簌 | Systematic-Sound / Sound Themes - Modern Cloth Foley 01 | SFX CLOTH Foley Jacket Synthetic Soft Shell Whoosh Flutter.wav |
| stem | 木纹轻触 | BlueZone / Wood Sound Effects | Bluezone_BC0254_wood_handling_003.wav |
| stem | 柔木轻弯 | BlueZone / Wood Sound Effects | Bluezone_BC0254_wood_creaking_tree_005.wav |
| stem | 竹环细响 | Eiravaein Works / Eulerian | Eulerian,spinning,crescendo,concavemirror,bambooring,thick,3indiameter,woody,loose,rough,light,quick,2.wav |
| stem | 木面轻擦 | Eiravaein Works / Eulerian | Eulerian,spinning,crescendo,woodsurface,woodentray,small,matte,rough,cupped,scruff,slightbounce,flatside,1.wav |
| stem | 枝纤维细响 | BlueZone / Wood Sound Effects | Bluezone_BC0254_wood_crushing_branches_001_001.wav |
