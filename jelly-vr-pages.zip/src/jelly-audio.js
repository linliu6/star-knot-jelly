import { RecordedFoley } from "./recorded-foley.js";
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const SOUND_DEFAULTS = {
  enabled: true,
  volume: 0.62,
  squeeze: 0.7,
  friction: 0.52,
  rebound: 0.76,
  tail: 0.55,
  tone: 0.5,
  apple: 1,
  ribbon: 0.72,
  stem: 0.68,
  orbit: 0.38,
  wetness: 0.55,
  fabricSoftness: 0.62,
  stemTexture: 0.55,
  tailLength: 0.5,
  forceResponse: 0.6,
  appleChoice: 0,
  ribbonChoice: 0,
  stemChoice: 0,
  orbitChoice: 0,
  ribbonFollow: 1 / 3,
  musicVolume: 0.75,
  musicFadeIn: 0.15,
  musicFadeOut: 0.3,
  musicThreshold: 0.006,
};
// Original procedural foley. Each material has its own spectral model and bus.
// Choice 0 retains the original synthesis; 1–5 use locally served licensed WAV foley.
export class JellyAudio {
  constructor(settings) {
    this.settings = settings;
    this.sugarContactGain = null;
    this.context = null;
    this.voices = new Map();
    this.held = false;
    this.target = null;
    this.tailActive = false;
    this.motionArmed = false;
    this.motionOrigin = null;
    this.events = [];
    this.serial = 0;
    this.metrics = {
      friction: 0,
      tail: 0,
      release: 0,
      ribbon: 0,
      stem: 0,
      orbit: 0,
    };
  }
  async unlock() {
    try {
      if (this.settings.enabled && navigator.audioSession)
        navigator.audioSession.type = "playback";
    } catch {}
    if (!this.context) {
      const Context = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!Context) throw Error("Audio is not available in this browser.");
      this.context = new Context({ latencyHint: "interactive" });
      this.setup();
    }
    if (this.context.state !== "running") await this.context.resume();
    this.recorded?.retry();
    void this.gel?.prepare();
    this.sync();
    if (this.pendingPress && this.held) {
      this.pendingPress = false;
      this.playPress(this.target);
    }
    return this.context.state === "running";
  }
  setup() {
    const c = this.context;
    this.master = c.createGain();
    this.master.gain.value = 0;
    this.limiter = c.createDynamicsCompressor();
    this.limiter.threshold.value = -12;
    this.limiter.knee.value = 12;
    this.limiter.ratio.value = 6;
    this.limiter.attack.value = 0.003;
    this.limiter.release.value = 0.16;
    this.master.connect(this.limiter);
    this.limiter.connect(c.destination);
    this.buses = {};
    for (const kind of ["apple", "ribbon", "stem", "orbit"]) {
      const bus = c.createGain();
      bus.connect(this.master);
      this.buses[kind] = bus;
    }
    const n = Math.round(c.sampleRate * 3);
    this.buffers = {};
    for (const kind of ["wet", "cloth", "fiber", "air"]) {
      const buffer = c.createBuffer(1, n, c.sampleRate),
        data = buffer.getChannelData(0);
      let seed = 3519 + kind.length * 171,
        brown = 0,
        pink = 0;
      for (let j = 0; j < n; j++) {
        seed = (Math.imul(seed, 1664525) + 1013904223) | 0;
        const white = (seed >>> 0) / 2147483648 - 1;
        brown = (brown + 0.04 * white) / 1.035;
        pink = pink * 0.84 + white * 0.16;
        data[j] =
          kind === "wet"
            ? brown * 2.2 + white * 0.1
            : kind === "cloth"
              ? pink * 1.3 + white * 0.23
              : kind === "fiber"
                ? pink * 0.7 + white * 0.42
                : pink * 1.2;
      }
      this.buffers[kind] = buffer;
    }
    const bed = (kind, buffer, type, freq, q) => {
      const source = c.createBufferSource(),
        filter = c.createBiquadFilter(),
        gain = c.createGain();
      source.buffer = this.buffers[buffer];
      source.loop = true;
      filter.type = type;
      filter.frequency.value = freq;
      filter.Q.value = q;
      gain.gain.value = 0;
      source.connect(filter);
      filter.connect(gain);
      gain.connect(this.buses[kind]);
      source.start();
      return { source, filter, gain };
    };
    this.beds = {
      apple: bed("apple", "wet", "bandpass", 360, 0.7),
      ribbon: bed("ribbon", "cloth", "bandpass", 2200, 0.65),
      stem: bed("stem", "fiber", "bandpass", 1350, 1.1),
      orbit: bed("orbit", "air", "lowpass", 950, 0.6),
    };
    this.beds.sugar = bed("apple", "fiber", "bandpass", 2100, 0.6);
    this.rubFilter = this.beds.apple.filter;
    this.rubGain = this.beds.apple.gain;
    this.wobble = c.createOscillator();
    this.wobble.type = "sine";
    this.wobble.frequency.value = 130;
    this.tailGain = c.createGain();
    this.tailGain.gain.value = 0;
    this.wobble.connect(this.tailGain);
    this.tailGain.connect(this.buses.apple);
    this.wobble.start();
    this.wetTail = c.createOscillator();
    this.wetTail.frequency.value = 260;
    this.wetTailGain = c.createGain();
    this.wetTailGain.gain.value = 0;
    this.wetTail.connect(this.wetTailGain);
    this.wetTailGain.connect(this.buses.apple);
    this.wetTail.start();
    this.recorded = new RecordedFoley(this);
  }
  sync() {
    if (!this.context) return;
    this.recorded?.sync();
    const t = this.context.currentTime,
      value = this.settings.enabled ? this.settings.volume : 0;
    if (value !== this.masterValue) {
      this.masterValue = value;
      this.master.gain.setTargetAtTime(value, t, 0.025);
    }
    for (const [kind, bus] of Object.entries(this.buses))
      bus.gain.setTargetAtTime(this.settings[kind] ?? 1, t, 0.025);
  }
  async prepareChoice(kind, index) {
    return this.recorded.load(kind, index);
  }
  log(type, level, material = this.target ?? "apple") {
    this.events.push({ type, material, level, t: performance.now() });
    if (this.events.length > 90) this.events.shift();
  }
  get ready() {
    return this.context?.state === "running" && this.settings.enabled;
  }
  track(source, nodes, kind) {
    if (this.voices.size >= 24) {
      const [old] = this.voices.keys();
      try {
        old.stop();
      } catch {}
      this.voices.delete(old);
    }
    this.voices.set(source, { nodes, kind });
    source.onended = () => {
      source.disconnect();
      nodes.forEach((n) => n.disconnect());
      this.voices.delete(source);
    };
    return source;
  }
  noiseBurst(
    level,
    duration,
    startFreq,
    endFreq,
    kind = "apple",
    texture = "wet",
  ) {
    if (!this.ready) return;
    const c = this.context,
      t = c.currentTime,
      source = c.createBufferSource(),
      f = c.createBiquadFilter(),
      g = c.createGain();
    source.buffer = this.buffers[texture];
    f.type = "bandpass";
    f.Q.value = kind === "stem" ? 1.7 : 0.85;
    f.frequency.setValueAtTime(startFreq, t);
    f.frequency.exponentialRampToValueAtTime(
      Math.max(60, endFreq),
      t + duration,
    );
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(level, t + 0.009);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    source.connect(f);
    f.connect(g);
    g.connect(this.buses[kind]);
    this.track(source, [g, f], kind);
    source.start(t, (this.serial++ * 0.317) % 2.2);
    source.stop(t + duration + 0.02);
  }
  tone(level, duration, start, end, kind = "apple") {
    if (!this.ready) return;
    const c = this.context,
      t = c.currentTime,
      o = c.createOscillator(),
      g = c.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(start, t);
    o.frequency.exponentialRampToValueAtTime(end, t + Math.min(0.11, duration));
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(level, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    o.connect(g);
    g.connect(this.buses[kind]);
    this.track(o, [g], kind);
    o.start();
    o.stop(t + duration + 0.02);
  }
  rubber(level, duration, deep = 0) {
    const brightness = 0.78 + this.settings.tone * 0.55,
      wet = this.settings.wetness;
    for (const [ratio, weight] of [
      [1, 1],
      [2, 0.17 + 0.1 * wet],
      [3.2, 0.045 + 0.06 * wet],
    ]) {
      const base = (174 - deep * 42) * brightness * ratio;
      this.tone(level * weight, duration, base * 2.05, base * 0.94);
    }
  }
  press(kind = "apple", sugarContactGain = null) {
    this.sugarContactGain = sugarContactGain;
    this.target = kind;
    this.motionOrigin = kind;
    this.held = true;
    this.motionArmed = true;
    if (kind === "apple") this.tailActive = false;
    this.stopVoices(kind);
    this.log(kind === "apple" ? "press" : kind + "-press", 1, kind);
    if (!this.ready) {
      this.pendingPress = true;
      return;
    }
    this.playPress(kind);
  }
  playPress(kind = "apple") {
    const s = this.settings;
    if (kind === "apple" && this.gel) {
      this.gel.press();
      return;
    }
    if (kind === "apple" && this.sugarContactGain !== null) {
      const g = this.sugarContactGain;
      this.noiseBurst(0.065 * g, 0.045, 2400, 1450, "apple", "fiber");
      this.tone(0.02 * g, 0.05, 1700, 1350);
      return;
    }
    if (this.recorded?.transient(kind, "press")) return;
    if (kind === "apple") {
      this.noiseBurst((0.18 + 0.16 * s.wetness) * s.squeeze, 0.135, 950, 190);
      this.rubber(0.1 * s.squeeze, 0.14, 0.1);
    }
    if (kind === "ribbon")
      this.noiseBurst(
        0.21,
        0.1,
        3300 - 1300 * s.fabricSoftness,
        1600 - 650 * s.fabricSoftness,
        "ribbon",
        "cloth",
      );
    if (kind === "stem") {
      this.noiseBurst(
        0.18 + 0.14 * s.stemTexture,
        0.07,
        2300,
        1100,
        "stem",
        "fiber",
      );
      this.tone(0.07, 0.065, 940, 720, "stem");
      this.tone(0.025, 0.048, 1720, 1540, "stem");
    }
  }
  release(strength, cancelled = false) {
    const kind = this.target ?? "apple";
    this.pendingPress = false;
    this.held = false;
    this.target = null;
    this.metrics.release = clamp(strength);
    if (cancelled) {
      this.hush();
      this.log("cancel", 0, kind);
      return;
    }
    if (kind === "apple" && this.gel) {
      this.gel.release();
      return;
    }
    const s = clamp(strength),
      length = 0.7 + 0.6 * this.settings.tailLength;
    if (this.recorded?.transient(kind, "release", s)) {
      this.log(
        kind === "apple"
          ? s > 0.52
            ? "release-heavy"
            : "release-soft"
          : kind + "-release",
        s,
        kind,
      );
      if (kind === "apple") {
        this.rubber(
          (0.05 + 0.1 * s) * this.settings.rebound,
          (0.18 + 0.32 * s) * length,
          s,
        );
        this.armTail();
      }
      return;
    }
    if (kind === "apple") {
      this.log(s > 0.52 ? "release-heavy" : "release-soft", s, kind);
      this.rubber(
        (0.12 + 0.34 * s) * this.settings.rebound,
        (0.18 + 0.32 * s) * length,
        s,
      );
      this.noiseBurst(
        (0.045 + 0.16 * s) *
          this.settings.rebound *
          (0.6 + 0.8 * this.settings.wetness),
        (0.12 + 0.17 * s) * length,
        550 + 400 * s,
        130,
      );
      this.armTail();
    } else {
      this.log(kind + "-release", s, kind);
      if (kind === "ribbon")
        this.noiseBurst(
          0.06 + 0.13 * s,
          (0.065 + 0.075 * s) * length,
          2100,
          1050,
          "ribbon",
          "cloth",
        );
      else {
        this.tone(
          0.025 + 0.07 * s,
          0.065 + 0.045 * s,
          670 + 180 * s,
          520,
          "stem",
        );
        this.noiseBurst(0.045 * s, 0.07, 1400, 780, "stem", "fiber");
      }
    }
  }
  crack(broken, amount, volume = 0.4) {
    const level = volume * (0.055 + 0.055 * amount);
    this.log(broken ? "sugar-break" : "sugar-crack", level, "sugar");
    this.noiseBurst(
      level,
      broken ? 0.105 : 0.048,
      broken ? 2100 : 3200,
      broken ? 850 : 1800,
      "apple",
      "fiber",
    );
    this.tone(
      level * 0.25,
      broken ? 0.065 : 0.038,
      broken ? 1750 : 2600,
      broken ? 1150 : 1700,
      "apple",
    );
    if (broken) this.noiseBurst(level * 0.5, 0.16, 1450, 500, "apple", "cloth");
  }
  armTail() {
    this.tailActive = true;
    this.motionArmed = true;
    this.tailGraceUntil = performance.now() + 450;
  }
  shake() {
    this.held = false;
    this.target = null;
    this.motionOrigin = "apple";
    this.armTail();
    this.log("shake", 1, "apple");
  }
  update({
    held,
    speed,
    strain,
    velocity,
    displacement,
    asleep,
    time,
    ribbon = 0,
    stem = 0,
    orbit = 0,
    sugarContact = 0,
    sugarIntegrity = 0,
  }) {
    const s = this.settings,
      force = (x) => Math.pow(clamp(x), 1.35 - 0.7 * s.forceResponse);
    const friction =
      held && this.target === "apple"
        ? force(speed / 650) *
          (0.3 + 0.7 * clamp(strain)) *
          (1 - clamp(sugarIntegrity) * 0.88)
        : 0;
    const energy =
      clamp(velocity / 0.14) * 0.65 + clamp(displacement / 0.009) * 0.35;
    const tail =
      !held && this.tailActive && !asleep
        ? force(energy) * (0.3 + 0.7 * Math.abs(Math.sin(time * 18)))
        : 0;
    const fabricContact =
      held && this.target === "ribbon"
        ? force(speed / 650) * (0.4 + 0.6 * strain)
        : 0;
    const stemContact =
      held && this.target === "stem"
        ? force(speed / 700) * (0.4 + 0.6 * strain)
        : 0;
    // Small motion thresholds suppress integration residue at equilibrium.
    const fabricMotion = this.motionArmed
      ? force(Math.max(0, ribbon - 0.012))
      : 0;
    const stemMotion = this.motionArmed ? force(Math.max(0, stem - 0.015)) : 0;
    const followGain =
      this.motionOrigin === "ribbon" ? 1 : (s.ribbonFollow ?? 1 / 3);
    const fabric = clamp(
      fabricContact * 0.85 +
        fabricMotion * (this.target === "ribbon" ? 0.12 : 0.27) * followGain,
    );
    const fiber = clamp(
      stemContact * 0.75 + stemMotion * (this.target === "stem" ? 0.12 : 0.18),
    );
    const gelManaged =
      this.gel?.update({
        held: held && this.target === "apple",
        speed,
        time,
      }) ?? false;
    Object.assign(this.metrics, {
      friction: gelManaged ? this.gel.metrics.pull : friction,
      tail: gelManaged ? this.gel.metrics.return : tail,
      gelManaged,
      ribbon: fabric,
      stem: fiber,
      orbit: clamp(orbit),
    });
    if (asleep && !held && performance.now() >= (this.tailGraceUntil || 0))
      this.tailActive = false;
    if (!this.context || this.context.state !== "running") return;
    const t = this.context.currentTime;
    this.sync();
    const fade = 0.028 + 0.045 * s.tailLength;
    const set = (kind, value, freq) => {
      const bed = this.beds[kind];
      bed.gain.gain.setTargetAtTime(
        this.recorded?.active(kind) ? 0 : value,
        t,
        value > 0.002 ? 0.024 : fade,
      );
      bed.filter.frequency.setTargetAtTime(freq, t, 0.045);
    };
    const sugarRub = held && !this.gel ? force(speed / 650) * sugarContact : 0;
    this.metrics.sugar = sugarRub;
    this.beds.sugar.gain.gain.setTargetAtTime(
      sugarRub * 0.065,
      t,
      sugarRub > 0.002 ? 0.025 : fade,
    );
    set(
      "apple",
      (gelManaged ? 0 : friction) * s.friction * (0.24 + 0.25 * s.wetness),
      170 + friction * 700 + strain * 180,
    );
    // Cloth's irregular swish and fibrous stem grain have different spectra.
    set(
      "ribbon",
      fabric * 0.47 * (0.82 + 0.18 * Math.sin(time * 43) * Math.sin(time * 71)),
      2800 - 1500 * s.fabricSoftness + fabric * 850,
    );
    set(
      "stem",
      fiber *
        (0.25 + 0.2 * s.stemTexture) *
        (0.78 + 0.22 * Math.sin(time * 83)),
      1000 + 600 * s.stemTexture + fiber * 600,
    );
    set("orbit", clamp(orbit) * 0.14, 650 + clamp(orbit) * 900);
    const pitch =
      (103 + 34 * Math.sin(time * 18) + 28 * energy) * (0.85 + 0.3 * s.tone);
    this.wobble.frequency.setTargetAtTime(pitch, t, 0.025);
    this.wetTail.frequency.setTargetAtTime(pitch * 2.17, t, 0.025);
    this.tailGain.gain.setTargetAtTime(
      (gelManaged ? 0 : tail) *
        s.tail *
        (this.recorded?.active("apple") ? 0.025 : 0.1),
      t,
      0.035,
    );
    this.wetTailGain.gain.setTargetAtTime(
      gelManaged || this.recorded?.active("apple")
        ? 0
        : tail * s.tail * s.wetness * 0.028,
      t,
      0.035,
    );
    this.recorded?.update(this.metrics, time);
  }
  silenceBeds() {
    if (!this.context) return;
    this.recorded?.hush();
    const t = this.context.currentTime;
    for (const b of Object.values(this.beds))
      b.gain.gain.setTargetAtTime(0, t, 0.025);
    this.tailGain.gain.setTargetAtTime(0, t, 0.025);
    this.wetTailGain.gain.setTargetAtTime(0, t, 0.025);
    for (const k of ["friction", "tail", "ribbon", "stem", "orbit"])
      this.metrics[k] = 0;
  }
  stopVoices(kind = null) {
    for (const [v, meta] of this.voices)
      if (!kind || meta.kind === kind) {
        try {
          v.stop();
        } catch {}
      }
  }
  hush() {
    this.gel?.stop();
    this.pendingPress = false;
    this.held = false;
    this.target = null;
    this.tailActive = false;
    this.motionArmed = false;
    this.motionOrigin = null;
    this.silenceBeds();
    this.stopVoices();
  }
  snapshot() {
    return {
      music: null,
      gel: this.gel?.snapshot() ?? null,
      recorded: this.recorded?.snapshot() ?? null,
      state: this.context?.state ?? "locked",
      material: this.target,
      metrics: { ...this.metrics },
      events: [...this.events],
      voices: this.voices.size,
    };
  }
}
