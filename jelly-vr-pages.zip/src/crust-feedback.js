import {GelFeedback} from './gel-feedback.js';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
// Authored, seeded microfractures. The reference recording is not a sound asset.
// Short band-limited grain clusters replace the previous pitched electronic chirp.
export function crustPacket(sampleRate,kind,seed=1){
  const duration={contact:.045,crack:.075,crush:.19,rub:.10}[kind],data=new Float32Array(Math.ceil(duration*sampleRate));
  const rand=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296),count={contact:1,crack:3,crush:10,rub:5}[kind];
  for(let g=0;g<count;g++){
    const onset=g===0?0:(g/count)**1.4*duration*.68+(rand()-.5)*.006;
    const start=Math.max(0,Math.floor(onset*sampleRate)),tau=(kind==='contact'?.011:kind==='crack'?.008:kind==='crush'?.014:.007)*( .7+rand()*.7);
    const freq=kind==='contact'?230+rand()*230:750+rand()*3100,level=(g===0?1:.26+rand()*.5)*(kind==='rub'?.6:1);
    let low=0,high=0;
    const a=1-Math.exp(-2*Math.PI*(kind==='contact'?720:6200)/sampleRate),b=1-Math.exp(-2*Math.PI*420/sampleRate);
    for(let i=start;i<data.length;i++){
      const t=(i-start)/sampleRate,noise=rand()*2-1;low+=a*(noise-low);high+=b*(noise-high);
      const env=(1-Math.exp(-t/.00045))*Math.exp(-t/tau),band=low-high;
      const body=Math.sin(t*2*Math.PI*freq)*Math.exp(-t/(tau*.45));
      data[i]+=level*env*(band*(kind==='contact'?.35:.86)+body*(kind==='contact'?.7:.14));
    }
  }
  let peak=0;for(const x of data)peak=Math.max(peak,Math.abs(x));
  for(let i=0;i<data.length;i++)data[i]=data[i]/Math.max(.001,peak)*.68*Math.min(1,(data.length-1-i)/(sampleRate*.006));
  return data;
}
export class CrustFeedback extends GelFeedback {
  constructor(owner,patch,settings){super(owner,patch);this.settings=settings;this.shell=null;this.bank=new Map();this.pending=null;this.lastPacket=-1;this.nextRub=0;this.coreGain=.2;this.serial=0;this.crust={phase:'intact',damage:0,rub:0,packets:0,cracks:0,crushes:0,rubs:0};}
  async prepare(){
    const c=this.owner.context;if(c&&!this.bank.size)for(const kind of ['contact','crack','crush','rub'])for(let n=0;n<5;n++){const data=crustPacket(c.sampleRate,kind,9187+n*311+kind.length*719),b=c.createBuffer(1,data.length,c.sampleRate);b.copyToChannel(data,0);this.bank.set(kind+n,b);}
    return super.prepare();
  }
  clip(index,level,duration,rate=1,offset=.03){super.clip(index,level*this.coreGain,duration,rate,offset);}
  press(){
    this.coreGain=.16+.84*(1-(this.shell?.integrity(this.patch.point)??1));super.press();
    this.pending=null;this.nextRub=0;
    this.packet('contact',.18*this.settings.shellSound*this.owner.settings.squeeze,.65);
  }
  fracture(event){
    if(!this.pending)this.pending={fresh:0,broken:0,crumbled:0,effort:0,t:event.t};
    for(const k of ['fresh','broken','crumbled'])this.pending[k]+=event[k];this.pending.effort=Math.max(this.pending.effort,event.effort);
  }
  packet(kind,level,strength){
    const o=this.owner;if(!o.ready||level<=0)return;
    const c=o.context,buffer=this.bank.get(kind+(this.serial++%5));if(!buffer)return;
    const source=c.createBufferSource(),filter=c.createBiquadFilter(),g=c.createGain(),t=c.currentTime;
    source.buffer=buffer;source.playbackRate.value=(kind==='crush'?.8:.94)+.14*(1-strength);
    filter.type='lowpass';filter.frequency.value=3400+o.settings.tone*3800;filter.Q.value=.45;g.gain.value=level;
    source.connect(filter);filter.connect(g);g.connect(o.buses.apple);o.track(source,[filter,g],'apple');source.start(t);
    this.crust.packets++;if(kind==='crack')this.crust.cracks++;if(kind==='crush')this.crust.crushes++;if(kind==='rub')this.crust.rubs++;
    o.log('crust-'+kind,level,'sugar');
  }
  impact(rate){
    const o=this.owner,first=this.impacts===0,strength=clamp(rate/.3)*(first?1:.65);
    this.clip(3,strength*(first?.64:.3)*o.settings.rebound,.12+.06*strength,.72,.32);
    if(o.settings.rebound>0&&strength>0)o.tone(.032*strength*this.coreGain*o.settings.rebound,.11,102,94);
    this.impacts++;o.log(first?'gel-recoil':'gel-afterbounce',strength,'apple');
  }
  update({held,speed,time}){
    const damage=1-(this.shell?.integrity(this.patch.point)??1);this.coreGain=.16+.84*damage;
    const managed=super.update({held,speed,time}),o=this.owner,s=o.settings;
    // Keep the wet core subordinate to intact shell, and let it emerge as it breaks.
    if(this.loop&&o.context?.state==='running'){
      const drive=(this.metrics.pull*s.friction*.90+this.metrics.return*s.tail*.43)*this.coreGain;
      this.loop.gain.gain.setTargetAtTime(this.active?drive:0,o.context.currentTime,drive>.001?.018:.035);
    }
    if(this.pending&&time-this.lastPacket>.052){
      const e=this.pending;this.pending=null;const crushed=e.broken+e.crumbled>0,kind=crushed?'crush':'crack',strength=clamp((e.fresh+e.broken*1.5+e.crumbled*2)/6);
      this.packet(kind,this.settings.shellSound*s.squeeze*(crushed?.52:.38)*(.55+.45*strength),strength);
      this.lastPacket=time;this.nextRub=time+.12;
    }
    const travel=this.shell?.rubRate??0,rate=Math.hypot(...this.patch.velocity);
    const drive=held?clamp((travel/.09+(this.patch.mode==='grab'?rate/.16:0))*.7)*damage:0;
    if(drive>.045&&time>=this.nextRub){
      this.packet('rub',this.settings.shellSound*s.friction*(.12+.32*drive),drive);
      this.nextRub=time+.055+(1-drive)*.085+(Math.sin(this.serial*7.13)*.5+.5)*.028;
    }
    Object.assign(this.crust,{damage,rub:drive,phase:held?(drive>.045?'kneading':damage>.65?'soft-core':damage>.05?'fracturing':'loading'):this.patch.moving?'rebound':damage>.05?'damaged-rest':'intact'});
    return managed;
  }
  stop(){super.stop();this.pending=null;this.crust.rub=0;}
  snapshot(){return {...super.snapshot(),crust:{...this.crust},generatedBuffers:this.bank.size};}
}
