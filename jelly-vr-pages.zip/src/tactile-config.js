export let VARIANT=1;
export function selectVariant(value){VARIANT=[1,2,3].includes(Number(value))?Number(value):1;}
export const TACTILE_DEFAULTS = {
  pressDepth:.016, contactRadius:.018, maxStretch:.037, softness:1,
  recovery:2.25, damping:.42, volumeKeep:1,
  shellThickness:.00065, shellHardness:.6, shellCrack:.42,
  shellSpread:1, shellAdhesion:.72, shellClarity:.83, shellSound:.4,
};
export const TACTILE_LIMITS = {
  pressDepth:[.005,.022],contactRadius:[.012,.026],maxStretch:[.015,.05],softness:[.5,1.5],
  recovery:[1.2,4],damping:[.25,.8],volumeKeep:[.5,1],shellThickness:[.0003,.0013],
  shellHardness:[.2,1],shellCrack:[.2,.8],shellSpread:[.6,1.5],shellAdhesion:[.2,1],
  shellClarity:[.6,.95],shellSound:[0,.8],
};
