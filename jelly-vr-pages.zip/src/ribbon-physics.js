import {ribbonPoint, norm, sub, cross} from './geometry.js';
const dot=(a,b)=>a.reduce((s,x,k)=>s+x*b[k],0);
// Two pinned ends per loop. Centreline length constraints preserve the band;
// elastic rest curvature and a separate torsional field supply bend/twist.
// SI metres, fixed 180 Hz integration, local inertial forces from the moving knot.
export class RibbonDynamics {
  constructor(p,side,count=25){
    this.p=p;this.side=side;this.count=count;this.rest=Array.from({length:count},(_,i)=>ribbonPoint(i/(count-1),.5,p,side));
    this.lengths=this.rest.slice(1).map((v,i)=>Math.hypot(...sub(v,this.rest[i])));
    this.reset();
  }
  reset(){this.x=this.rest.map(x=>[...x]);this.v=this.rest.map(()=>[0,0,0]);this.angle=new Float64Array(this.count);this.spin=new Float64Array(this.count);this.accumulator=0;this.deformCache=new Map();this.energy=0;this.maxStretch=0;this.contacts=0;}
  update(dt,accel,angular,collision,grab=null){
    this.deformCache.clear();this.accumulator+=Math.min(.05,dt);const h=1/180,p=this.p,n=this.count;
    while(this.accumulator>=h){
      this.accumulator-=h;
      const old=this.x.map(x=>[...x]);
      const wb=2*Math.PI*p.bowBend,wt=2*Math.PI*p.bowTwist;
      for(let i=1;i<n-1;i++){
        const d=sub(this.x[i],this.rest[i]);
        const dl=sub(this.x[i-1],this.rest[i-1]),dr=sub(this.x[i+1],this.rest[i+1]);
        for(let k=0;k<3;k++){
          let f=-wb*wb*(d[k]*.48+(2*d[k]-dl[k]-dr[k])*1.8)-accel[k]*p.bowFlex*.55+(k===1?-.55:0);
          if(grab){const influence=Math.exp(-Math.pow((i/(n-1)-grab.u)/.13,2));f+=(1700*(grab.target[k]-d[k])-38*this.v[i][k])*influence;}
          this.v[i][k]=(this.v[i][k]+f*h)*Math.exp(-2*p.bowDamping*wb*h);
          this.x[i][k]+=this.v[i][k]*h;
        }
        const tangent=norm(sub(this.rest[i+1],this.rest[i-1]));
        const torque=dot(angular,tangent)*-.5+((accel[2]*this.side-accel[1]*.35)*32)*p.bowFlex;
        const lap=this.angle[i-1]+this.angle[i+1]-2*this.angle[i];
        this.spin[i]=(this.spin[i]+(-wt*wt*this.angle[i]+wt*wt*.3*lap+torque)*h)*Math.exp(-2*p.bowDamping*wt*h);
        this.angle[i]=Math.max(-.65,Math.min(.65,this.angle[i]+this.spin[i]*h));
      }
      // Inextensibility; end nodes remain exactly at the knot.
      for(let it=0;it<40;it++){
        for(let j=0;j<n-1;j++){
          const d=sub(this.x[j+1],this.x[j]),l=Math.hypot(...d)||1e-9,e=(l-this.lengths[j])/l;
          const wa=j===0?0:1,wb=j+1===n-1?0:1,total=wa+wb;
          for(let k=0;k<3;k++){this.x[j][k]+=d[k]*e*wa/total;this.x[j+1][k]-=d[k]*e*wb/total;}
        }
        this.x[0]=[...this.rest[0]];this.x[n-1]=[...this.rest[n-1]];
      }
      this.contacts=0;
      for(let i=1;i<n-1;i++){
        if(collision&&collision(this.x[i]))this.contacts++;
        for(let k=0;k<3;k++)this.v[i][k]=(this.x[i][k]-old[i][k])/h;
      }
    }
    this.maxStretch=Math.max(...this.lengths.map((l,i)=>Math.abs(Math.hypot(...sub(this.x[i+1],this.x[i]))/l-1)));
    this.energy=Math.max(...this.v.map(v=>Math.hypot(...v)),...this.spin.map(Math.abs));
  }
  deform(u,point){
    // All vertices across one band row share a centreline frame. Cache it once
    // per simulation update; this preserves the original deformation exactly.
    this.deformCache??=new Map();let frame=this.deformCache.get(u);
    if(!frame){
      const a=Math.min(this.count-2,Math.floor(u*(this.count-1))),f=u*(this.count-1)-a;
      const mix=(v,w)=>v.map((x,k)=>x*(1-f)+w[k]*f);
      const c=mix(this.x[a],this.x[a+1]),r=mix(this.rest[a],this.rest[a+1]);
      const tangent=norm(sub(this.x[a+1],this.x[a]));
      const angle=this.angle[a]*(1-f)+this.angle[a+1]*f;
      frame={c,r,tangent,cos:Math.cos(angle),sin:Math.sin(angle)};this.deformCache.set(u,frame);
    }
    const {c,r,tangent:t,cos,sin}=frame;
    const x=point[0]-r[0],y=point[1]-r[1],z=point[2]-r[2],along=t[0]*x+t[1]*y+t[2]*z;
    return [c[0]+x*cos+(t[1]*z-t[2]*y)*sin+t[0]*along*(1-cos),
      c[1]+y*cos+(t[2]*x-t[0]*z)*sin+t[1]*along*(1-cos),
      c[2]+z*cos+(t[0]*y-t[1]*x)*sin+t[2]*along*(1-cos)];
  }
  snapshot(){return {side:this.side,peakOffset:Math.max(...this.x.map((x,i)=>Math.hypot(...sub(x,this.rest[i])))),twist:Math.max(...this.angle.map(Math.abs)),maxStretch:this.maxStretch,energy:this.energy,contacts:this.contacts,pinError:Math.max(Math.hypot(...sub(this.x[0],this.rest[0])),Math.hypot(...sub(this.x.at(-1),this.rest.at(-1))))};}
}
