// Deterministic closed-volume assets. Units are metres, matching the original.
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const norm = (v) => {
  const n = Math.hypot(...v) || 1;
  return v.map((x) => x / n);
};
export const cross = (a, b) => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];
export const sub = (a, b) => a.map((x, i) => x - b[i]);
// One meridian drives the visible surface, back-depth pass and elastic envelope.
// fullness adds shoulder/abdomen mass without changing the overall height.
export function appleMeridian(v, p) {
  const t = Math.PI * (1 - v), s = Math.max(0, Math.sin(t));
  const fullness = p.fullness ?? 0, spread = p.dimpleWidth ?? 1;
  const r = .055 * p.width * Math.pow(s, .88 - .20 * fullness)
    * (.91 + .14 * Math.cos(t)) * (1 + .07 * fullness * (.55 + .45 * s));
  const y = (.004 + .103 * (1 + Math.cos(t)) / 2
    - .009 * p.dimple * Math.exp(-((t / (.27 * spread)) ** 2))) * p.height;
  return [r, y];
}
export function applePoint(u, v, p) {
  const t = Math.PI * (1 - v), a = Math.PI / 2 + u * Math.PI * 2, s = Math.sin(t);
  const [radius, y] = appleMeridian(v, p);
  const r = radius * (1 + p.lobes * Math.cos(a * 5) * s * s);
  return [r * Math.cos(a) + .0018 * s * s * p.asymmetry, y, -r * Math.sin(a) * p.depth];
}
// Upper surface, from the recessed stem seat out to the widest shoulder.
// A denser radial curve is used for light organza contact; no flat lid plane.
export function appleCrownProfile(p) {
  const points = [];
  for (let j = 0; j <= 384; j++) {
    const q = appleMeridian(1 - j / 768, p);
    if (points.length && q[0] < points.at(-1)[0]) break;
    points.push(q);
  }
  return points;
}
export function crownHeightAt(radius, profile) {
  if (radius > profile.at(-1)[0]) return null;
  let lo = 0, hi = profile.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (profile[mid][0] < radius) lo = mid; else hi = mid; }
  const a = profile[lo], b = profile[hi], t = clamp((radius - a[0]) / (b[0] - a[0]), 0, 1);
  return a[1] + (b[1] - a[1]) * t;
}
export function surfaceFrame(fn, u, v) {
  const e = 0.0001,
    du = sub(fn(u + e, v), fn(u - e, v)),
    dv = sub(
      fn(u, clamp(v + e, 0.000001, 0.999999)),
      fn(u, clamp(v - e, 0.000001, 0.999999)),
    );
  return { normal: norm(cross(du, dv)), u: norm(du), v: norm(dv) };
}
export function appleData(p, segments = 112, rows = 80) {
  const positions = [],
    uv = [],
    indices = [],
    profile = [];
  for (let j = 0; j <= rows; j++) {
    const v = j / rows;
    const [r, y] = appleMeridian(v, p);
    profile.push([r * 1.045, y]);
    for (let i = 0; i <= segments; i++) {
      positions.push(...applePoint(i / segments, v, p));
      uv.push(i / segments, v);
    }
  }
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < segments; i++) {
      const a = j * (segments + 1) + i,
        b = a + 1,
        c = a + segments + 1,
        d = c + 1;
      if (j > 0) indices.push(a, b, c);
      if (j < rows - 1) indices.push(b, d, c);
    }
  return {
    positions,
    uv,
    indices,
    profile,
    top: Math.max(...profile.map((x) => x[1])),
    base: Math.min(...profile.map((x) => x[1])),
  };
}
// A continuous folded band: both ends enter the knot, width follows its
// centreline's frame, and the front/back folds occupy real depth.
export function ribbonPoint(u, v, p, side = -1) {
  const centre = (u) => {
    const t=u*Math.PI*2, bulge=Math.sin(Math.PI*u);
    return [side*.04*p.bowWidth*Math.pow(Math.max(0,bulge),1.12),
      (.014+(side>0?.004:0))*p.bowHeight*bulge+.005*Math.sin(t),
      .015*p.bowDepth*Math.sin(t)+.0012*(2*u-1)];
  };
  const c=centre(u), tangent=norm(sub(centre(Math.min(.999999,u+.0001)),centre(Math.max(.000001,u-.0001))));
  const n=norm(cross(tangent,[0,1,0]));
  const across=norm(cross(n,tangent));
  const angle=.42*Math.sin(u*Math.PI*2)+side*.22;
  const widthAxis=across.map((x,k)=>x*Math.cos(angle)+n[k]*Math.sin(angle));
  const face=norm(cross(tangent,widthAxis));
  const bulge=Math.sin(Math.PI*u);
  const half=.0018+.012*p.bowHeight*Math.pow(Math.max(0,bulge),.65);
  const fold=.00065*Math.sin((v-.5)*Math.PI*4+u*5)*bulge;
  return c.map((x,k)=>x+(v-.5)*half*2*widthAxis[k]+fold*face[k]);
}
export function knotData() {
  const g=ellipsoidData(0,0,0,[.0042,.0058,.0048],40,24);
  for(let i=0;i<g.positions.length;i+=3){
    const a=Math.atan2(g.positions[i+2],g.positions[i]);
    const y=g.positions[i+1]/.0058;
    const pinch=1-.13*Math.exp(-y*y*7);
    const pleat=1+.065*Math.cos(a*6+y*1.5);
    g.positions[i]*=pinch*pleat;g.positions[i+2]*=pinch*pleat;
  }
  return g;
}
export function ribbonData(p, side = -1, segments = 88, rows = 18) {
  const positions = [],
    uv = [],
    indices = [],
    n = (segments + 1) * (rows + 1),
    half = p.ribbonThickness / 2;
  for (let layer = 0; layer < 2; layer++)
    for (let j = 0; j <= rows; j++)
      for (let i = 0; i <= segments; i++) {
        const u = i / segments,
          v = j / rows,
          pt = ribbonPoint(u, v, p, side),
          fr = surfaceFrame(
            (x, y) => ribbonPoint(x, y, p, side),
            clamp(u, 0.0001, 0.9999),
            clamp(v, 0.0001, 0.9999),
          );
        const sign = layer === 0 ? 1 : -1;
        positions.push(...pt.map((x, k) => x + fr.normal[k] * half * sign));
        uv.push(u, (v + layer) * 0.5);
      }
  const tri = (a, b, c, flip) =>
    indices.push(...(flip ? [a, c, b] : [a, b, c]));
  for (let layer = 0; layer < 2; layer++)
    for (let j = 0; j < rows; j++)
      for (let i = 0; i < segments; i++) {
        const a = layer * n + j * (segments + 1) + i,
          b = a + 1,
          c = a + segments + 1,
          d = c + 1;
        tri(a, b, c, layer === 1);
        tri(b, d, c, layer === 1);
      }
  const rim = [];
  for (let i = 0; i <= segments; i++) rim.push(i);
  for (let j = 1; j <= rows; j++) rim.push(j * (segments + 1) + segments);
  for (let i = segments - 1; i >= 0; i--) rim.push(rows * (segments + 1) + i);
  for (let j = rows - 1; j > 0; j--) rim.push(j * (segments + 1));
  for (let i = 0; i < rim.length; i++) {
    const a = rim[i],
      b = rim[(i + 1) % rim.length];
    indices.push(a, a + n, b, b, a + n, b + n);
  }
  return { positions, uv, indices };
}
export function tubeData(points, radii, radial = 12) {
  const positions = [],
    uv = [],
    indices = [],
    n = points.length;
  for (let j = 0; j < n; j++) {
    const tangent = norm(
      sub(points[Math.min(n - 1, j + 1)], points[Math.max(0, j - 1)]),
    );
    const ax = norm(
        cross(tangent, Math.abs(tangent[2]) > 0.9 ? [1, 0, 0] : [0, 0, 1]),
      ),
      ay = cross(tangent, ax);
    for (let i = 0; i <= radial; i++) {
      const a = (i / radial) * Math.PI * 2,
        r = Array.isArray(radii) ? radii[j] : radii;
      positions.push(
        ...points[j].map(
          (v, k) => v + r * (Math.cos(a) * ax[k] + Math.sin(a) * ay[k]),
        ),
      );
      uv.push(i / radial, j / (n - 1));
    }
  }
  for (let j = 0; j < n - 1; j++)
    for (let i = 0; i < radial; i++) {
      const a = j * (radial + 1) + i,
        b = a + 1,
        c = a + radial + 1,
        d = c + 1;
      indices.push(a, b, c, b, d, c);
    }
  const first = positions.length / 3;
  positions.push(...points[0], ...points[n - 1]);
  uv.push(0.5, 0, 0.5, 1);
  for (let i = 0; i < radial; i++) {
    indices.push(first, i + 1, i);
    const a = (n - 1) * (radial + 1) + i;
    indices.push(first + 1, a, a + 1);
  }
  return { positions, uv, indices };
}
export function ellipsoidData(x, y, z, r, segments = 28, rows = 18) {
  const positions = [],
    uv = [],
    indices = [];
  for (let j = 0; j <= rows; j++) {
    const t = (Math.PI * j) / rows;
    for (let i = 0; i <= segments; i++) {
      const a = (2 * Math.PI * i) / segments;
      positions.push(
        x + r[0] * Math.sin(t) * Math.cos(a),
        y + r[1] * Math.cos(t),
        z + r[2] * Math.sin(t) * Math.sin(a),
      );
      uv.push(i / segments, j / rows);
    }
  }
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < segments; i++) {
      const a = j * (segments + 1) + i,
        b = a + 1,
        c = a + segments + 1,
        d = c + 1;
      if (j > 0) indices.push(a, b, c);
      if (j < rows - 1) indices.push(b, d, c);
    }
  return { positions, uv, indices };
}
export function starData(size, depth = 0.0006, points = 4) {
  const positions = [0, 0, depth / 2, 0, 0, -depth / 2],
    uv = [0.5, 0.5, 0.5, 0.5],
    indices = [];
  for (let side = 0; side < 2; side++)
    for (let i = 0; i < points * 2; i++) {
      const a = (i / (points * 2)) * Math.PI * 2 + Math.PI / 2,
        r = size * (i % 2 ? 0.25 : 1);
      positions.push(
        r * Math.cos(a),
        r * Math.sin(a),
        (side ? -0.5 : 0.5) * depth,
      );
      uv.push(
        0.5 + (Math.cos(a) * r) / size / 2,
        0.5 + (Math.sin(a) * r) / size / 2,
      );
    }
  for (let i = 0; i < points * 2; i++) {
    const a = 2 + i,
      b = 2 + ((i + 1) % (points * 2)),
      c = a + points * 2,
      d = b + points * 2;
    indices.push(0, a, b, 1, d, c, a, c, b, b, c, d);
  }
  return { positions, uv, indices };
}
export function crescentData(size, depth = 0.0006, steps = 48) {
  const d = 0.42,
    r = 0.83,
    x = (1 - r * r + d * d) / (2 * d),
    a = Math.acos(x),
    b = Math.acos((x - d) / r),
    positions = [],
    uv = [],
    indices = [],
    stride = (steps + 1) * 2;
  for (let layer = 0; layer < 2; layer++)
    for (let i = 0; i <= steps; i++) {
      const t = i / steps,
        ao = a + t * (Math.PI * 2 - 2 * a),
        ai = b + t * (Math.PI * 2 - 2 * b);
      for (const p of [
        [Math.cos(ao), Math.sin(ao)],
        [d + r * Math.cos(ai), r * Math.sin(ai)],
      ]) {
        positions.push(p[0] * size, p[1] * size, (layer ? -0.5 : 0.5) * depth);
        uv.push(p[0] * 0.5 + 0.5, p[1] * 0.5 + 0.5);
      }
    }
  for (let i = 0; i < steps; i++) {
    const a = i * 2,
      b = a + 2;
    indices.push(
      a,
      b,
      a + 1,
      a + 1,
      b,
      b + 1,
      a + stride,
      a + 1 + stride,
      b + stride,
      a + 1 + stride,
      b + 1 + stride,
      b + stride,
    );
    for (const k of [0, 1]) {
      const c = a + k,
        e = b + k;
      if (k === 0) indices.push(c, c + stride, e, e, c + stride, e + stride);
      else indices.push(c, e, c + stride, e, e + stride, c + stride);
    }
  }
  return { positions, uv, indices };
}
