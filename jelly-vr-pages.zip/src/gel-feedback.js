// Version 2 only: wet foley follows the simulated patch, including its return.
// All samples already belong to the project's licensed foley catalogue.
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const length=v=>Math.hypot(...v);
export class GelFeedback {
  constructor(owner,patch){
    this.owner=owner;this.patch=patch;this.active=false;this.axis=[0,0,1];
    this.samples=new Map();this.loading=false;this.failed=false;this.loop=null;
    this.metrics={pull:0,return:0,strain:0,rate:0,impacts:0,phase:'idle'};
    this.previousSigned=0;this.lastImpact=-1;this.releaseStrength=0;this.impacts=0;
  }
  async prepare(){
    const o=this.owner;if(!o.recorded||this.loading)return;
    const selected=o.settings.appleChoice||2;
    const ids=[...new Set([selected,3,4])];
    if(ids.every(i=>this.samples.has(i))){this.ensureLoop(selected);return;}
    this.loading=true;
    try{
      for(const i of ids)this.samples.set(i,await o.recorded.load('apple',i));
      this.failed=false;this.ensureLoop(selected);
    }catch{this.failed=true;}finally{this.loading=false;}
  }
  ensureLoop(index){
    if(this.loop?.index===index)return;
    const buffer=this.samples.get(index);if(!buffer)return;
    const o=this.owner,c=o.context,t=c.currentTime;
    if(this.loop){const old=this.loop;old.gain.gain.setTargetAtTime(0,t,.025);old.source.stop(t+.15);}
    const source=c.createBufferSource(),low=c.createBiquadFilter(),high=c.createBiquadFilter(),gain=c.createGain();
    source.buffer=o.recorded.loopBuffer(buffer);source.loop=true;source.playbackRate.value=.8;
    high.type='highpass';high.frequency.value=65;low.type='lowpass';low.frequency.value=1500;low.Q.value=.45;gain.gain.value=0;
    source.connect(high);high.connect(low);low.connect(gain);gain.connect(o.buses.apple);
    source.onended=()=>{source.disconnect();high.disconnect();low.disconnect();gain.disconnect();};source.start();
    this.loop={index,source,low,gain};
  }
  clip(index,level,duration,rate=1,offset=.03){
    const o=this.owner;if(!o.ready||level<=0)return;
    const buffer=this.samples.get(index);
    if(!buffer){o.noiseBurst(level*.21,duration,430,145,'apple','wet');return;}
    const c=o.context,t=c.currentTime,source=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();
    source.buffer=buffer;source.playbackRate.value=rate;f.type='lowpass';f.frequency.value=900+1750*o.settings.wetness;
    const start=Math.min(offset,Math.max(0,buffer.duration-duration*rate-.01));
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(level,t+.009);
    g.gain.setTargetAtTime(0,t+duration*.35,Math.max(.008,duration*.19));
    source.connect(f);f.connect(g);g.connect(o.buses.apple);o.track(source,[f,g],'apple');
    source.start(t,start);source.stop(t+duration+.05);
  }
  press(){
    this.active=true;this.impacts=0;this.releaseStrength=0;this.metrics.phase='contact';
    void this.prepare();
    this.clip(3,.38*this.owner.settings.squeeze,.13,.78);
    this.owner.log('gel-contact',this.owner.settings.squeeze,'apple');
  }
  release(){
    const p=this.patch,d=length(p.displacement),v=length(p.velocity);
    this.axis=d>.00001?p.displacement.map(x=>x/d):v>.0001?p.velocity.map(x=>x/v):[0,0,1];
    this.releaseStrength=clamp(d/p.settings.maxStretch*.85+v/.5*.15);
    this.previousSigned=p.displacement.reduce((s,x,i)=>s+x*this.axis[i],0);
    this.impacts=0;this.lastImpact=-1;this.active=d>.00001||v>.0001;
    this.owner.tailActive=false;
    this.clip(4,(.04+.20*this.releaseStrength)*this.owner.settings.wetness*this.owner.settings.rebound,.09+.05*this.releaseStrength,.75,.23);
    this.owner.log('gel-release',this.releaseStrength,'apple');
  }
  impact(rate){
    const o=this.owner,s=o.settings,first=this.impacts===0;
    const strength=clamp(rate/.30)*(first?1:.65);
    this.clip(3,strength*(first?.9:.45)*s.rebound,.12+.07*strength,.68+.12*(1-strength),.32);
    // A short, damped body thud. No octave glissando or perpetual oscillator.
    if(s.rebound>0&&strength>0)o.tone(strength*(first?.075:.025)*s.rebound,.11+.07*strength,112-20*strength,95-14*strength);
    this.impacts++;this.owner.log(first?'gel-recoil':'gel-afterbounce',strength,'apple');
  }
  update({held,speed,time}){
    if(!this.active)return false;
    const p=this.patch,o=this.owner,s=o.settings,c=o.context;
    const displacement=length(p.displacement),rate=length(p.velocity),strain=clamp(displacement/p.settings.maxStretch);
    const signed=p.displacement.reduce((sum,x,i)=>sum+x*this.axis[i],0);
    if(!held&&this.previousSigned*signed<0&&rate>.003&&time-this.lastImpact>.08&&this.impacts<4){this.impact(rate);this.lastImpact=time;}
    this.previousSigned=signed;
    // Held contact becomes silent as the real stretch settles. Stationary press
    // never adds a continuous hiss just because pressure is increasing.
    const movement=Math.max(0,rate-.0012);
    const force=x=>Math.pow(clamp(x),1.35-.7*s.forceResponse);
    const pull=held&&(p.mode==='grab'||speed>8)?force(movement/.10)*(.25+.75*strain):0;
    const returning=!held?force(movement/.13)*(.25+.75*this.releaseStrength):0;
    Object.assign(this.metrics,{pull,return:returning,strain,rate,impacts:this.impacts,phase:held?(pull>.02?'stretch':'hold'):returning>.01?'recoil':'settling'});
    if(c&&c.state==='running'){
      if((o.settings.appleChoice||2)!==this.loop?.index&&!this.loading&&!this.failed)void this.prepare();
      const t=c.currentTime,drive=pull*s.friction*.90+returning*s.tail*.43;
      if(this.loop){
        this.loop.gain.gain.setTargetAtTime(drive,t,drive>.001?.018:.035);
        this.loop.source.playbackRate.setTargetAtTime(clamp(.64+rate*2.2-strain*.10,.55,1.15),t,.035);
        this.loop.low.frequency.setTargetAtTime(650+s.wetness*1200+clamp(rate/.2)*700+s.tone*300,t,.025);
      }else if(drive>.03&&time-(this.fallbackAt??-1)>.09){o.noiseBurst(drive*.11,.10,520+strain*220,140,'apple','wet');this.fallbackAt=time;}
    }
    if(!held&&!p.moving)this.stop();
    return true;
  }
  stop(){
    this.active=false;
    if(this.loop)this.loop.gain.gain.setTargetAtTime(0,this.owner.context.currentTime,.025);
    Object.assign(this.metrics,{pull:0,return:0,strain:0,rate:0,phase:'idle'});
  }
  dispose(){this.stop();if(this.loop){try{this.loop.source.stop();}catch{}this.loop=null;}}
  snapshot(){return {...this.metrics,active:this.active,loaded:[...this.samples.keys()],fallback:this.failed};}
}
