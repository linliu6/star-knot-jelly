import {Yt as Raycaster, On as Vector3, An as Vector2} from '../jelly-painting/assets/three-CU5tkW7F.js';

// Touch-only additions. At rest the original geometry and attachment transform
// are used exactly. The apple still uses its original volumetric grab solver.
export function makePartTouch(api, graph) {
  const ray=new Raycaster(), ndc=new Vector2(), canvas=api.renderer.domElement;
  ray.layers.enableAll();
  let grab=null, bend=new Vector3(), bendVelocity=new Vector3(), previousTip=null;
  const metrics={ribbon:0,stem:0,strain:0};
  function cast(x,y){
    const rect=canvas.getBoundingClientRect();
    ndc.set((x-rect.left)/rect.width*2-1,1-(y-rect.top)/rect.height*2);
    ray.setFromCamera(ndc,api.camera);
  }
  function hit(x,y,touch=false){
    const g=graph(), entries=[{mesh:api.cup.liquid.mesh,kind:'apple'},
      {mesh:g.stem,kind:'stem'},{mesh:g.knot,kind:'ribbon',index:-1},
      ...g.bows.map((mesh,index)=>({mesh,kind:'ribbon',index}))].filter(e=>e.mesh);
    for(const e of entries){e.mesh.updateWorldMatrix(true,false);if(e.kind==='ribbon')e.mesh.geometry.computeBoundingSphere();}
    const one=(px,py)=>{
      cast(px,py);const h=ray.intersectObjects(entries.map(e=>e.mesh),false)[0];
      return h?{...h,...entries.find(e=>e.mesh===h.object)}:null;
    };
    const exact=one(x,y);
    if(exact&&exact.kind!=='apple')return exact;
    // Small screen-space tolerance for thin parts; a nearer apple occludes a
    // hidden stem/band. Never choose a far-side part through the apple.
    if(touch)for(const radius of [5,10]){
      for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1],[.7,.7],[-.7,-.7]]){
        const h=one(x+dx*radius,y+dy*radius);
        if(h&&h.kind!=='apple'&&(!exact||h.distance<exact.distance-.0005))return h;
      }
    }
    return exact;
  }
  function begin(h,x,y){
    const g=graph();
    grab={kind:h.kind,index:h.index??-1,u:h.uv?.x??.5,point:h.point.clone(),
      normal:api.camera.getWorldDirection(new Vector3()),inverse:h.mesh.parent.matrixWorld.clone().invert(),
      delta:new Vector3(),initial:new Vector3(),target:new Vector3()};
    if(grab.kind==='ribbon'&&grab.index>=0){
      const sim=g.dynamics[grab.index],i=Math.max(1,Math.min(sim.count-2,Math.round(grab.u*(sim.count-1))));
      grab.u=i/(sim.count-1);grab.initial.fromArray(sim.x[i]).sub(new Vector3(...sim.rest[i]));
      grab.target.copy(grab.initial);
      // A tiny contact impulse gives a light tap a visible, physical response.
      sim.v[i][2]+=.018;
    }else bendVelocity.z+=.05;
    return grab.kind;
  }
  function move(x,y){
    if(!grab)return;
    cast(x,y);const d=ray.ray.direction.dot(grab.normal);
    if(Math.abs(d)<1e-7)return;
    const distance=grab.point.clone().sub(ray.ray.origin).dot(grab.normal)/d;
    const world=ray.ray.at(distance,new Vector3());
    grab.delta.copy(world).applyMatrix4(grab.inverse).sub(grab.point.clone().applyMatrix4(grab.inverse));
    grab.delta.multiplyScalar(api.settings.mobile.touchGain).clampLength(0,.021);
    grab.target.copy(grab.initial).add(grab.delta).clampLength(0,.024);
    metrics.strain=Math.min(1,grab.delta.length()/.021);
  }
  const probePoint=new Vector3(),probeCenter=new Vector3(),probeVertex=new Vector3();
  function hitWorld(position,radius=.006){
    const g=graph(),point=probePoint.fromArray(position);let best=null;
    const entries=[{mesh:g.stem,kind:'stem'},{mesh:g.knot,kind:'ribbon',index:-1},...g.bows.map((mesh,index)=>({mesh,kind:'ribbon',index}))];
    for(const entry of entries){
      const mesh=entry.mesh;if(!mesh)continue;mesh.updateWorldMatrix(true,false);
      const geometry=mesh.geometry;if(!geometry.boundingSphere)geometry.computeBoundingSphere();
      const sphere=geometry.boundingSphere,scale=mesh.matrixWorld.getMaxScaleOnAxis();
      probeCenter.copy(sphere.center).applyMatrix4(mesh.matrixWorld);
      if(point.distanceTo(probeCenter)>sphere.radius*scale+radius+.025)continue;
      const a=geometry.attributes.position,uv=geometry.attributes.uv;
      for(let i=0;i<a.count;i++){
        probeVertex.fromBufferAttribute(a,i).applyMatrix4(mesh.matrixWorld);const distance=point.distanceTo(probeVertex);
        if(distance<radius&&(!best||distance<best.distance))best={...entry,distance,point:probeVertex.clone(),uv:{x:uv?.getX(i)??.5}};
      }
    }return best;
  }
  function moveWorld(position){
    if(!grab)return;
    grab.delta.fromArray(position).applyMatrix4(grab.inverse).sub(probePoint.copy(grab.point).applyMatrix4(grab.inverse));
    grab.delta.multiplyScalar(api.settings.mobile.touchGain).clampLength(0,.021);
    grab.target.copy(grab.initial).add(grab.delta).clampLength(0,.024);metrics.strain=Math.min(1,grab.delta.length()/.021);
  }
  function end(){grab=null;metrics.strain=0;}
  function bowGrab(index){return grab?.kind==='ribbon'&&grab.index===index?{u:grab.u,target:grab.target.toArray()}:null;}
  function pose(dt){
    const g=graph(),target=new Vector3();
    if(grab&&(grab.kind==='stem'||grab.index===-1))target.set((grab.delta.z+grab.delta.y*.45)/.08,0,-grab.delta.x/.08).clampLength(0,.22);
    const n=Math.max(1,Math.ceil(dt*180)),h=dt/n,w=26;
    for(let i=0;i<n;i++){
      bendVelocity.addScaledVector(target.clone().sub(bend),w*w*h).multiplyScalar(Math.exp(-2*.34*w*h));
      bend.addScaledVector(bendVelocity,h);
    }
    if(!grab&&bend.length()<1e-6&&bendVelocity.length()<1e-5){bend.set(0,0,0);bendVelocity.set(0,0,0);}
    if(bend.lengthSq()>0){
      // Pivot the existing connected stem and knot at the apple's attachment.
      // This never changes the baseline model or the apple's spring constants.
      const pivot=new Vector3(0,g.baseY,0),old=pivot.clone().applyQuaternion(g.garnish.quaternion);
      g.garnish.rotateX(bend.x);g.garnish.rotateZ(bend.z);
      g.garnish.position.add(old.sub(pivot.applyQuaternion(g.garnish.quaternion)));
    }
  }
  function measure(dt){
    const g=graph();g.stem.updateWorldMatrix(true,false);
    const box=g.stem.geometry.boundingBox;
    const tip=new Vector3(box.min.x,box.max.y,0).applyMatrix4(g.stem.matrixWorld);
    metrics.stem=previousTip?Math.min(1,tip.distanceTo(previousTip)/Math.max(.001,dt)/.18):0;
    previousTip=tip;
    metrics.ribbon=Math.min(1,Math.max(0,...g.dynamics.map(d=>d.energy-.008))/1.8);
    return {...metrics,active:grab?.kind??null,bend:bend.length(),moving:bend.lengthSq()+bendVelocity.lengthSq()>1e-10};
  }
  function reset(){end();bend.set(0,0,0);bendVelocity.set(0,0,0);previousTip=null;metrics.ribbon=metrics.stem=0;}
  return {hit,hitWorld,moveWorld,begin,move,end,bowGrab,pose,measure,reset,get strain(){return metrics.strain},get active(){return grab?.kind??null}};
}
