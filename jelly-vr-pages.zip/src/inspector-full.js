import {setIcon} from './ui-icons.js';
import {VARIANT} from './tactile-config.js';
import {mountSoundLibrary} from './sound-library.js';
export function makeInspector(A) {
  const { params: p, settings: s } = A,
    host = document.createElement("section");
  host.id = "apple-ui";
  host.innerHTML = `<button class="panel-toggle" aria-expanded="false" aria-controls="apple-inspector"></button><aside id="apple-inspector" hidden><div class="panel-head"><strong>Inspector</strong><button class="panel-close" aria-label="Close Inspector">×</button></div><div class="inspector-groups"></div><div class="preset-actions"><button data-act="save">Save</button><button data-act="restore">Restore</button><button data-act="export">Export JSON</button><label class="import-button">Import JSON<input type="file" accept="application/json,.json" hidden></label><button data-act="reset">Reset all</button></div><output id="inspector-status" aria-live="polite">Save in this browser or export a file.</output></aside><nav class="view-actions" aria-label="View angle"><button data-view="front">Front</button><button data-view="side">Side</button><button data-view="top">Top</button><button data-view="back">Back</button><button id="clay-toggle" aria-pressed="false">Clay</button></nav><footer class="study-actions"><button data-act="shake"></button><button data-act="view"></button><span></span></footer><a class="study-credit" href="https://mesq.me/jelly-painting/" target="_blank" rel="noopener">Original art and technology · mesq</a>`;
  document.body.append(host);
  setIcon(host.querySelector('.panel-toggle'),'sliders','Open Inspector');
  setIcon(host.querySelector('[data-act=shake]'),'shake','Gently shake');
  setIcon(host.querySelector('[data-act=view]'),'reset','Reset view');
  for(const b of host.querySelectorAll("[data-view]"))b.onclick=()=>A.setView(b.dataset.view);
  const clay=host.querySelector("#clay-toggle");clay.onclick=()=>{const on=clay.getAttribute("aria-pressed")!=="true";A.setClay(on);clay.setAttribute("aria-pressed",String(on));};
  const panel = host.querySelector("aside"),
    toggle = host.querySelector(".panel-toggle");
  const open = (on) => {
    panel.hidden = !on;
    document.body.classList.toggle("inspector-open",on);
    if(on)window.appleStudy?.mobile.cancel();
    toggle.setAttribute("aria-expanded", String(on));
    toggle.setAttribute("aria-label",on ? "Close Inspector" : "Open Inspector");
  };
  toggle.onclick = () => open(panel.hidden);
  host.querySelector(".panel-close").onclick = () => open(false);
  const entries = [],
    groups = host.querySelector(".inspector-groups");
  let timer;
  function section(name, items, opened = false) {
    const group = document.createElement("details");
    group.open = opened;
    group.innerHTML = `<summary>${name}</summary>`;
    groups.append(group);
    for (const [label, obj, key, min, max, step, unit] of items) {
      const row = document.createElement("label");
      row.className = "control-row";
      const input = document.createElement("input"),
        out = document.createElement("output");
      input.dataset.param = key;
      input.setAttribute("aria-label", label);
      input.type =
        typeof obj[key] === "boolean"
          ? "checkbox"
          : typeof obj[key] === "string"
            ? "color"
            : "range";
      if (input.type === "range") {
        input.min = min;
        input.max = max;
        input.step = step;
      }
      row.innerHTML = `<span>${label}</span>`;
      row.append(out, input);
      group.append(row);
      function refresh() {
        input.type === "checkbox"
          ? (input.checked = obj[key])
          : (input.value = obj[key]);
        out.value =
          input.type === "range"
            ? unit === "mm"
              ? (obj[key] * 1000).toFixed(2) + " mm"
              : Number(obj[key]).toFixed(step < 0.01 ? 3 : step < 1 ? 2 : 0)
            : "";
      }
      input.oninput = () => {
        obj[key] =
          input.type === "checkbox"
            ? input.checked
            : input.type === "range"
              ? Number(input.value)
              : input.value;
        refresh();
        clearTimeout(timer);
        timer = setTimeout(
          () => {
            try {
              A.apply();
              status("Applied. Save to keep these settings.");
            } catch (e) {
              status(e.message, true);
            }
          },
          input.type === "range" ? 100 : 0,
        );
      };
      refresh();
      entries.push(refresh);
    }
  }
  if(VARIANT>1)section("Soft jelly",[
    ["Press depth",s.tactile,"pressDepth",.005,.022,.001,"mm"],
    ["Contact radius",s.tactile,"contactRadius",.012,.026,.001,"mm"],
    ["Max stretch",s.tactile,"maxStretch",.015,.05,.001,"mm"],
    ["Softness",s.tactile,"softness",.5,1.5,.05],
    ["Recovery",s.tactile,"recovery",1.2,4,.05],
    ["Damping",s.tactile,"damping",.25,.8,.01],
    ["Volume preservation",s.tactile,"volumeKeep",.5,1,.01],
  ],true);
  if(VARIANT===3)section("Thin sugar shell",[
    ["Shell thickness",s.tactile,"shellThickness",.0003,.0013,.00005,"mm"],
    ["Shell hardness",s.tactile,"shellHardness",.2,1,.02],
    ["Shell crack",s.tactile,"shellCrack",.2,.8,.02],
    ["Shell spread",s.tactile,"shellSpread",.6,1.5,.05],
    ["Shell adhesion",s.tactile,"shellAdhesion",.2,1,.02],
    ["Shell clarity",s.tactile,"shellClarity",.6,.95,.01],
    ["Shell sound",s.tactile,"shellSound",0,.8,.01],
  ],true);
  section("Touch & sound",[
    ["Enabled",s.sound,"enabled"],
    ["Volume",s.sound,"volume",0,1,.01],
    ["Apple",s.sound,"apple",0,1,.01],
    ["Ribbon",s.sound,"ribbon",0,1,.01],
    ["Stem",s.sound,"stem",0,1,.01],
    ["Orbit",s.sound,"orbit",0,1,.01],
    ["Ribbon follow",s.sound,"ribbonFollow",0,1,.01],
    ["Squeeze",s.sound,"squeeze",0,1,.01],
    ["Friction",s.sound,"friction",0,1,.01],
    ["Rebound",s.sound,"rebound",0,1,.01],
    ["Tail",s.sound,"tail",0,1,.01],
    ["Tone",s.sound,"tone",0,1,.01],
    ["Wetness",s.sound,"wetness",0,1,.01],
    ["Fabric softness",s.sound,"fabricSoftness",0,1,.01],
    ["Stem texture",s.sound,"stemTexture",0,1,.01],
    ["Tail length",s.sound,"tailLength",0,1,.01],
    ["Force response",s.sound,"forceResponse",0,1,.01],
    ["Touch gain",s.mobile,"touchGain",.5,1.7,.05],
    ["Grip strength",s.mobile,"gripStrength",.2,1.8,.05],
    ["Object size",s.mobile,"objectSize",.56,.85,.01],
    ["Edge inset",s.mobile,"edgeInset",.005,.045,.002],
  ],true);
  section(
    "Shape & thickness",
    [
      ["Width", p, "width", 0.75, 1.3, 0.01],
      ["Height", p, "height", 0.75, 1.3, 0.01],
      ["Depth", p, "depth", 0.65, 1.2, 0.01],
      ["Fullness", p, "fullness", 0, 1.2, 0.01],
      ["Stem well depth", p, "dimple", 0.4, 2.6, 0.02],
      ["Stem well width", p, "dimpleWidth", 0.8, 1.55, 0.01],
      ["Lobes", p, "lobes", 0, 0.055, 0.001],
      ["Asymmetry", p, "asymmetry", 0, 1.5, 0.05],
      ["Stem length", p, "stemLength", 0.75, 1.3, 0.01],
      ["Bow width", p, "bowWidth", 0.7, 1.3, 0.01],
      ["Bow height", p, "bowHeight", 0.7, 1.4, 0.01],
      ["Bow depth", p, "bowDepth", 0.65, 1.35, 0.01],
      ["Ribbon thickness", p, "ribbonThickness", 0.0003, 0.0015, 0.00005, "mm"],
      ["Bow tilt", p, "bowTilt", -25, 25, 1],
    ],
    false,
  );
  section("Stem well & painted veins", [
    ["Well strength", p, "wellStrength", 0, 1, .01],
    ["Well spread", p, "wellSpread", .65, 1.35, .01],
    ["Vein bands", p, "veinBands", 0, 1, .01],
    ["Vein strength", p, "veinStrength", 0, 1, .01],
    ["Vein length", p, "veinLength", .5, 1.4, .01],
    ["Vein density", p, "veinDensity", .5, 1.5, .01],
    ["Vein width", p, "veinWidth", .5, 1.7, .01],
    ["Vein color", p, "veinColor", 0, 1, .01],
  ], false);
  section("Material & transmission", [
    ["Jelly color", p, "bodyTint"],
    ["Absorption color", p, "absorption"],
    ["Transmission", p, "transmission", 0, 1, 0.01],
    ["Absorption distance", p, "absorptionDistance", 0.025, 0.24, 0.002],
    ["Volume glow", p, "glow", 0, 1.3, 0.01],
    ["Glow tint", p, "glowTint"],
    ["Refract paper texture", p, "refractPaper"],
    ["Body grain", p, "bodyGrain", 0, 1, 0.005],
    ["Body smear", p, "bodySmear", 0, 1, 0.01],
    ["Refraction depth", p, "refractionDepth", 0.005, 0.09, 0.001, "mm"],
    ["Refraction blur", p, "refractionBlur", 0, 2, 0.01],
    ["Roughness", p, "roughness", 0.03, 0.45, 0.01],
    ["Painted texture", p, "paint", 0, 1, 0.01],
    ["Surface markings", p, "marks", 0, 1, 0.01],
    ["Ribbon color", p, "bowTint"],
    ["Ribbon transmission", p, "bowTransmission", 0, 1, 0.01],
    ["Ribbon roughness", p, "bowRoughness", 0.05, 0.8, 0.01],
    ["Ribbon weave",p,"bowWeave",0,1,.01],
    ["Ribbon sheen",p,"bowSheen",0,1,.01],
    ["Ribbon grain",p,"bowGrain",0,1,.01],
  ]);
  section("Bounce & attachments", [
    ["Frequency", s.jelly, "frequency", 1.5, 5.5, 0.1],
    ["Damping", s.jelly, "damping", 0.05, 0.6, 0.01],
    ["Stiffness", s.jelly, "stiffness", 0.2, 1.5, 0.05],
    ["Volume", s.jelly, "volume", 0.4, 1.2, 0.05],
    ["Response", s.jelly, "response", 0.12, 0.7, 0.01],
    ["Max displacement", s.jelly, "maxDisplacement", 0.003, 0.014, 0.0005, "mm"],
    ["Surface wobble", s.jelly, "surfaceWobble", 0.7, 1.6, 0.05],
    ["Attachment coupling", s.jelly, "fruitCoupling", 0.3, 1.4, 0.05],
    ["Attachment tilt", s.jelly, "fruitRotation", 0, 1.5, 0.05],
    ["Attachment lag", p, "attachmentLag", 0.015, 0.12, 0.005],
    ["Ribbon inertia", p, "bowFlex", 0, 1.4, 0.05],
    ["Ribbon bending",p,"bowBend",2,12,.1],
    ["Ribbon twisting",p,"bowTwist",2,14,.1],
    ["Ribbon damping",p,"bowDamping",.08,.8,.01],
  ]);
  section("Stars & moon", [
    ["Decoration count", p, "decorationCount", 0, 7, 1],
    ["Decoration spread", p, "decorationSpread", 0.7, 1.35, 0.01],
  ]);
  section("Lighting & shadow", [
    ["Azimuth", s.light, "azimuth", -180, 180, 1],
    ["Elevation", s.light, "elevation", 20, 80, 1],
    ["Intensity", s.light, "intensity", 1, 5, 0.1],
    ["Ambient", s.light, "ambient", 0.3, 1.5, 0.01],
    ["Exposure", s.scene, "exposure", 0.5, 1.2, 0.01],
    ["Opacity", s.cupShadow, "opacity", 0, 0.85, 0.01],
    ["Softness", s.cupShadow, "softness", 0.1, 1, 0.02],
  ]);
  section("Paint & paper", [
    ["Enabled", s.post, "enabled"],
    ["Style strength", s.post, "styleStrength", 0.2, 3, 0.05],
    ["Stroke width", s.post, "strokeWidth", 5, 45, 1],
    ["Stroke length", s.post, "strokeLength", 40, 220, 5],
    ["Speckle", s.post, "speckle", 0, 2.5, 0.05],
    ["Smear", s.post, "smear", 0, 0.7, 0.01],
    ["Frame", s.post, "frame"],
    ["Edge roughness", s.post, "edgeRoughness", 0, 1, 0.02],
    ["Paper color", s.post, "paperColor"],
  ]);
  section("Quality", [
    ["Auto quality", s.scene, "autoQuality"],
    ["Pixel ratio", s.scene, "pixelRatio", 0.75, 2, 0.25],
    ["Anti-aliasing", s.scene, "antialias"],
  ]);
  function status(text, error = false) {
    host.querySelector("#inspector-status").value = text;
    host.querySelector("#inspector-status").classList.toggle("error", error);
  }
  for (const button of host.querySelectorAll("[data-act]"))
    button.onclick = async () => {
      try {
        const act = button.dataset.act;
        if (act === "shake") A.shake();
        if (act === "view") A.resetView();
        if (act === "save") {
          A.save();
          status("Saved in this browser. These settings return when you reopen it.");
        }
        if (act === "restore") {
          await A.restore();
          refresh();
          status("Saved settings restored.");
        }
        if (act === "reset") {
          A.reset();
          refresh();
          status("Defaults restored. Your saved settings are still available.");
        }
        if (act === "export") {
          const url = URL.createObjectURL(
            new Blob([JSON.stringify(A.documentState(), null, 2)], {
              type: "application/json",
            }),
          );
          const a = document.createElement("a");
          a.href = url;
          a.download = "jelly-play-settings.json";
          a.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          status("Settings exported.");
        }
      } catch (e) {
        status(e.message, true);
      }
    };
  host.querySelector("input[type=file]").onchange = async (e) => {
    try {
      const f = e.target.files[0];
      if (!f) return;
      await A.restore(JSON.parse(await f.text()));
      refresh();
      status("Settings imported. Save to keep them next time.");
    } catch (e) {
      status("Could not import: " + e.message, true);
    }
  };
  const soundLibrary=mountSoundLibrary(A);
  function refresh() {
    soundLibrary.refresh();
    for (const f of entries) f();
  }
  return { refresh, status, open, dispose(){clearTimeout(timer);soundLibrary.dispose();host.remove();document.body.classList.remove("inspector-open");document.querySelector("#phone-qr-dialog")?.remove();} };
}
