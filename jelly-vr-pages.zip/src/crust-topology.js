// Seeded, periodic Voronoi cells: fracture boundaries without a triangular grid.
export function crustTopology(nx=24,ny=16){
  let seed=41837;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296),sites=[];
  for(let j=0;j<ny;j++)for(let i=0;i<nx;i++)sites.push({id:sites.length,u:(i+.5+(random()-.5)*.82)/nx,v:(j+.5+(random()-.5)*.82)/ny,seed:random()});
  function clip(poly,a,b,c){const out=[];for(let k=0;k<poly.length;k++){const p=poly[k],q=poly[(k+1)%poly.length],dp=a*p[0]+b*p[1]-c,dq=a*q[0]+b*q[1]-c;if(dp<=1e-11)out.push(p);if((dp<0)!==(dq<0)){const t=dp/(dp-dq);out.push([p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])]);}}return out;}
  for(const s of sites){let poly=[[s.u-.5,0],[s.u+.5,0],[s.u+.5,1],[s.u-.5,1]];for(const n of sites)for(const wrap of [-1,0,1]){if(n===s&&wrap===0)continue;const u=n.u+wrap,v=n.v;if(Math.abs(u-s.u)>.2||Math.abs(v-s.v)>.24)continue;poly=clip(poly,2*(u-s.u),2*(v-s.v),u*u+v*v-s.u*s.u-s.v*s.v);}s.polygon=poly;s.neighbors=[];}
  const edges=new Map(),label=p=>[(((p[0]%1)+1)%1).toFixed(7),p[1].toFixed(7)].join(',');
  for(const s of sites)for(let i=0;i<s.polygon.length;i++){const key=[label(s.polygon[i]),label(s.polygon[(i+1)%s.polygon.length])].sort().join('|'),other=edges.get(key);if(other!==undefined){s.neighbors.push(other);sites[other].neighbors.push(s.id);}else edges.set(key,s.id);}
  return sites;
}
