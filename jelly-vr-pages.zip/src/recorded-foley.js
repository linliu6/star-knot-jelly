import {readBinary} from '../xhs/resources.js';
import {choiceFor,choiceKey,validChoice} from './audio-catalog.js';
const clamp=x=>Math.max(0,Math.min(1,x));
// One decoded copy per AudioContext, and one active texture per material.
export class RecordedFoley {
  constructor(owner){this.owner=owner;this.c=owner.context;this.buffers=new Map();this.loading=new Map();this.layers={};this.requested={};this.errors={};this.stopped=false;}
  async load(kind,index){
    if(!validChoice(index,kind))throw Error('Invalid sound choice.');if(index===0)return null;
    const item=choiceFor(kind,index);if(!item)throw Error('Sound not found.');
    if(this.buffers.has(item.id))return this.buffers.get(item.id);
    if(this.loading.has(item.id))return this.loading.get(item.id);
    const promise=(async()=>{
      try {
        let data;try{data=readBinary(item.file);}catch{const r=await fetch(new URL('../audio/'+item.id+'.wav',import.meta.url));if(!r.ok)throw Error('Audio HTTP '+r.status);data=await r.arrayBuffer();}
        const b=await this.c.decodeAudioData(data);if(b.duration<.1)throw Error('This audio file is incomplete.');this.buffers.set(item.id,b);return b;
      }catch{throw Error('This sound could not load. Please try again.');}finally{this.loading.delete(item.id);}

    })();this.loading.set(item.id,promise);return promise;
  }
  sync(){
    for(const kind of ['apple','ribbon','stem','orbit']){
      const index=this.owner.settings[choiceKey(kind)]??0;
      if(this.requested[kind]===index)continue;this.requested[kind]=index;delete this.errors[kind];this.remove(kind);
      if(index===0)continue;
      this.load(kind,index).then(buffer=>{
        if(this.stopped||this.requested[kind]!==index)return;
        const source=this.c.createBufferSource(),filter=this.c.createBiquadFilter(),gain=this.c.createGain();
        source.buffer=this.loopBuffer(buffer);source.loop=true;source.playbackRate.value=1;filter.type='lowpass';filter.frequency.value=5000;gain.gain.value=0;
        source.connect(filter);filter.connect(gain);gain.connect(this.owner.buses[kind]);source.start();this.layers[kind]={index,source,filter,gain,buffer};
      }).catch(error=>{if(this.requested[kind]===index)this.errors[kind]=error.message;});
    }
  }
  loopBuffer(buffer){
    // Overlap the two ends, rather than placing a silent gap or a hard cut at each loop.
    const count=buffer.length,overlap=Math.min(Math.floor(this.c.sampleRate*.09),Math.floor(count*.18)),n=count-overlap;
    const loop=this.c.createBuffer(buffer.numberOfChannels,n,buffer.sampleRate);
    for(let c=0;c<buffer.numberOfChannels;c++){
      const x=buffer.getChannelData(c),y=loop.getChannelData(c);y.set(x.subarray(overlap));
      for(let i=0;i<overlap;i++){const u=i/overlap;y[n-overlap+i]=x[count-overlap+i]*(1-u)+x[i]*u;}
    }return loop;
  }
  retry(){for(const kind of Object.keys(this.errors)){delete this.requested[kind];delete this.errors[kind];}this.sync();}
  active(kind){return !!this.layers[kind]&&this.layers[kind].index===(this.owner.settings[choiceKey(kind)]??0);}
  remove(kind){const l=this.layers[kind];if(!l)return;delete this.layers[kind];const t=this.c.currentTime;l.gain.gain.setTargetAtTime(0,t,.02);try{l.source.stop(t+.12);}catch{}l.source.onended=()=>{l.source.disconnect();l.filter.disconnect();l.gain.disconnect();};}
  transient(kind,phase,strength=.4){
    const l=this.layers[kind];if(!l||!this.owner.ready)return false;
    const c=this.c,t=c.currentTime,s=this.owner.settings,source=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();
    source.buffer=l.buffer;source.playbackRate.value=phase==='press'?1.02:1.03-.18*clamp(strength);
    const duration=Math.min(l.buffer.duration*.6,(phase==='press'?.14:.2+.22*strength)*(kind==='ribbon'?1.3:1));
    const offset=phase==='press'?Math.min(.045,l.buffer.duration*.1):Math.max(0,l.buffer.duration*.45);
    const level=(phase==='press'?.6*s.squeeze:.36+.55*strength)*(phase==='release'?s.rebound:1);
    f.type='lowpass';f.frequency.value=kind==='apple'?1900+2200*s.wetness:kind==='ribbon'?5900-2800*s.fabricSoftness:2800+1300*s.stemTexture;
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(level,t+.018);g.gain.setTargetAtTime(0,t+duration*.35,duration*.18);
    source.connect(f);f.connect(g);g.connect(this.owner.buses[kind]);this.owner.track(source,[g,f],kind);source.start(t,offset);source.stop(t+duration+.05);return true;
  }
  update(metrics,time){
    const t=this.c.currentTime,s=this.owner.settings;
    for(const [kind,l] of Object.entries(this.layers)){
      let drive=kind==='apple'?(metrics.gelManaged?0:metrics.friction*s.friction+metrics.tail*s.tail*.5):metrics[kind];
      const level=clamp(drive)*({apple:.95,ribbon:.65,stem:.65,orbit:.75}[kind]);
      l.gain.gain.setTargetAtTime(level,t,level>.001?.025:.04+.04*s.tailLength);
      const freq=kind==='apple'?1200+2300*s.wetness:kind==='ribbon'?5900-2500*s.fabricSoftness:kind==='stem'?2100+2100*s.stemTexture:2600;
      l.filter.frequency.setTargetAtTime(freq*(.82+.36*s.tone),t,.055);
      l.source.playbackRate.setTargetAtTime(.85+.25*clamp(drive)+.03*Math.sin(time*5),t,.06);
    }
  }
  hush(){const t=this.c.currentTime;for(const l of Object.values(this.layers))l.gain.gain.setTargetAtTime(0,t,.018);}
  dispose(){this.stopped=true;for(const k of Object.keys(this.layers))this.remove(k);}
  snapshot(){return {selected:{...this.requested},loaded:Object.fromEntries(Object.entries(this.layers).map(([k,l])=>[k,l.index])),errors:{...this.errors},cached:this.buffers.size};}
}
