import {AUDIO_CATALOG,AUDIO_GROUPS,choiceFor,choiceKey} from './audio-catalog.js';
import {JellyAudio} from './jelly-audio.js';
export function mountSoundLibrary(A){
 const s=A.settings.sound, panel=document.querySelector('#apple-inspector');
 const phone=document.documentElement.dataset.mode==='phone';
 const names={apple:'Apple',ribbon:'Ribbon',stem:'Stem',orbit:'Turn'};
 const entry=document.createElement('section');entry.className='sound-library-entry';
 entry.innerHTML='<small>ASMR · 20 recordings</small><strong>Find your favorite sound</strong><p>Five alternatives for each material. Preview, then choose.</p><button id="open-sound-library" type="button">Sound library <span>↗</span></button><output class="sound-combination"></output>';
 panel.insertBefore(entry,panel.querySelector('.inspector-groups'));
 const dialog=document.createElement('dialog');dialog.id='sound-library-dialog';
 dialog.setAttribute('aria-labelledby','sound-library-title');
 dialog.innerHTML=`<header class="sound-library-head"><div><small>ASMR</small><h2 id="sound-library-title">Sound library</h2></div><button class="sound-library-close" aria-label="Close sound library">×</button></header><p class="sound-library-intro">${phone?'Preview a sound, then choose Use to try it.':'Each preview includes touch, movement and fade-out.'}<br>1–5 are alternatives. 0 is the original sound.</p><nav class="sound-tabs" aria-label="Sound material"></nav><div class="sound-library-scroll"><div class="sound-options"></div><p class="sound-library-note">Recordings from the official SONNISS GDC collections. Your choices are saved in this browser.</p></div><footer class="sound-library-footer"><div class="sound-preview-state"><output aria-live="polite" id="sound-library-status">Previewing keeps your current choices.</output><button id="stop-sound-preview" type="button">Stop preview</button></div><div class="sound-current" aria-label="Current sound numbers"></div><textarea id="sound-choice-text" aria-label="My sound choices" readonly rows="2" hidden></textarea><div class="sound-library-tools"><button id="copy-sound-choices" type="button">My choices</button><button id="return-to-jelly" type="button">Back to jelly</button></div></footer>`;
 document.body.append(dialog);
 let launcher=null;
 if(phone){
  launcher=document.createElement('button');launcher.id='phone-sound-library';launcher.type='button';launcher.setAttribute('aria-haspopup','dialog');launcher.setAttribute('aria-controls',dialog.id);
  launcher.innerHTML='<span>Sound library</span><small></small>';
  document.querySelector('#apple-ui').append(launcher);
 }
 let group='apple',preview=null,timer=null,token=0,operation=0,playing=null,returnFocus=null;
 const status=text=>dialog.querySelector('#sound-library-status').textContent=text;
 const current=kind=>s[choiceKey(kind)]||0;
 const selectionText=()=>Object.entries(names).map(([k,n])=>n+' '+current(k)+' ('+(choiceFor(k,current(k))?.label||'Original')+')').join(', ');
 function refresh(){
  if(launcher)launcher.querySelector('small').textContent=Object.values(names).map((_,i)=>current(Object.keys(names)[i])).join(' · ');
  dialog.querySelector('.sound-current').innerHTML=Object.entries(names).map(([k,n])=>`<span>${n}<strong>${current(k)}</strong></span>`).join('');
  dialog.querySelector('#sound-choice-text').value=selectionText();
  entry.querySelector('.sound-combination').textContent=Object.entries(AUDIO_GROUPS).map(([k,n])=>n+' · '+(choiceFor(k,current(k))?.label||'Original')).join(' / ');
  if(dialog.open)render();
 }
 function stop(message=true){
  token++;clearInterval(timer);timer=null;if(preview){preview.hush();preview.recorded?.dispose();void preview.context?.close();preview=null;}
  playing=null;if(message)status('Preview stopped.');if(dialog.open)render();
 }
 function render(){
  const scroll=dialog.querySelector('.sound-library-scroll'),previousScroll=scroll.scrollTop;
  dialog.querySelector('.sound-tabs').innerHTML=Object.entries(AUDIO_GROUPS).map(([k,n])=>`<button type="button" data-group="${k}" aria-pressed="${group===k}">${n}</button>`).join('');
  const rows=[{id:group+'-0',label:'Original',description:'The original procedural sound design',index:0},...AUDIO_CATALOG.filter(x=>x.group===group).map(x=>({...x,index:Number(x.id.split('-').at(-1))}))];
  dialog.querySelector('.sound-options').innerHTML=rows.map(x=>`<article class="sound-option ${current(group)===x.index?'chosen':''}" data-choice="${x.index}"><div class="sound-option-copy"><div class="sound-option-title"><span class="sound-number">${x.index}</span><h3>${x.label}</h3>${current(group)===x.index?'<span class="sound-selected">In use</span>':''}</div><p>${x.description}</p>${x.index?`<details class="sound-source"><summary>Source</summary><span>${x.publisher} · ${x.library}</span><span>Official SONNISS GDC collection; license included</span><small>Edited lossless excerpts of the original WAV recordings</small></details>`:'<span class="sound-original">Procedural audio created for this scene</span>'}</div><div class="sound-option-actions"><button type="button" data-audition="${x.index}" aria-label="Preview ${x.label}" aria-pressed="${playing===x.id}">${playing===x.id?'■ Stop':'▷ Preview'}</button><button type="button" data-select="${x.index}" aria-label="Use ${x.label}" ${current(group)===x.index?'disabled':''}>${current(group)===x.index?'Selected':phone?'Use':'Use'}</button></div></article>`).join('');
  scroll.scrollTop=previousScroll;
  for(const b of dialog.querySelectorAll('[data-group]'))b.onclick=()=>{operation++;stop(false);group=b.dataset.group;status('Previewing keeps your current choices.');render();scroll.scrollTop=0;};
  for(const b of dialog.querySelectorAll('[data-audition]'))b.onclick=()=>audition(group,Number(b.dataset.audition));
  for(const b of dialog.querySelectorAll('[data-select]'))b.onclick=()=>select(group,Number(b.dataset.select));
 }
 async function audition(kind,index){
  operation++;
  if(playing===kind+'-'+index){stop();return;}stop(false);const id=++token;
  // A separate short-lived engine auditions without touching the scene's settings or motion.
  const settings={...s,enabled:true,volume:Math.min(.75,s.volume||.4),[choiceKey(kind)]:index};
  for(const k of Object.keys(AUDIO_GROUPS))settings[k]=k===kind?1:0;
  const engine=new JellyAudio(settings);preview=engine;playing=kind+'-'+index;render();status('Loading preview…');
  try{
   await engine.unlock();if(index){await engine.prepareChoice(kind,index);engine.sync();await new Promise(resolve=>setTimeout(resolve,0));}
   if(id!==token)return;status('Preview: '+(choiceFor(kind,index)?.label||'Original')+' · touch → move → settle');
   const start=performance.now();let released=false;if(kind!=='orbit')engine.press(kind);
   timer=setInterval(()=>{
    const elapsed=(performance.now()-start)/1000;if(elapsed>3.6){stop(false);status('Preview finished. Choose Use to try it in the scene.');return;}
    const held=elapsed<1.85, moving=elapsed>.45&&elapsed<1.75, tail=Math.max(0,1-(elapsed-1.85)/1.35);
    if(!held&&!released&&kind!=='orbit'){released=true;engine.release(.58);}
    engine.update({held:kind==='orbit'?false:held,speed:moving?280+80*Math.sin(elapsed*7):0,strain:moving?.6:0,velocity:!held?tail*.08:0,displacement:!held?tail*.004:0,asleep:elapsed>3.2,time:elapsed,ribbon:kind==='ribbon'&&!held?tail*.25:0,stem:kind==='stem'&&!held?tail*.22:0,orbit:kind==='orbit'?(elapsed<2.5?Math.sin(Math.min(1,elapsed/2.5)*Math.PI)*.6:0):0});
   },25);
  }catch(error){if(id===token){stop(false);status(error.message+'. Select Preview to try again.');}}
 }
 async function select(kind,index){
  stop(false);const id=++operation;status('Preparing sound…');
  try{
   await A.mobile.audio.unlock();await A.mobile.audio.prepareChoice(kind,index);
   if(id!==operation||!dialog.open)return;s[choiceKey(kind)]=index;A.mobile.apply();refresh();
   // Once a phone recipe is edited locally, preserve that imported scene and stop
   // the old hash from overwriting the user's new sound choices on the next reload.
   if(phone && new URLSearchParams(location.hash.slice(1)).has('p')){
    try{A.save();const url=new URL(location.href);const hash=new URLSearchParams(url.hash.slice(1));hash.delete('p');url.hash=hash.toString();history.replaceState(history.state,'',url);}catch{}
   }
   const message='Selected '+names[kind]+' '+index+' · '+(choiceFor(kind,index)?.label||'Original');
   status(message+'. Close the panel to play.');
   if(phone){dialog.close();const hint=document.querySelector('#sound-status');if(hint)hint.textContent=s.enabled?message:message+' · Enable Sound in settings to listen.';}
  }catch(error){if(id===operation)status(error.message+'. Your current choice has been kept.');}
 }
 function open(){returnFocus=document.activeElement;A.mobile.cancel();dialog.showModal();refresh();status('Previewing keeps your current choices.');dialog.querySelector('#sound-choice-text').hidden=true;}
 entry.querySelector('button').onclick=open;
 if(launcher)launcher.onclick=open;
 dialog.querySelector('#return-to-jelly').onclick=()=>dialog.close();
 dialog.querySelector('#copy-sound-choices').onclick=async()=>{
  const field=dialog.querySelector('#sound-choice-text');field.value=selectionText();
  field.hidden=false;field.focus();field.select();status('Keep these four numbers to return to this combination.');

 };
 dialog.querySelector('.sound-library-close').onclick=()=>dialog.close();
 dialog.querySelector('#stop-sound-preview').onclick=()=>stop();
 dialog.addEventListener('close',()=>{operation++;stop(false);returnFocus?.focus();});
 dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
 const blur=()=>stop(false),visibility=()=>{if(document.hidden)stop(false);};
 window.addEventListener('blur',blur);document.addEventListener('visibilitychange',visibility);
 refresh();return {refresh,stop,dispose(){stop(false);window.removeEventListener('blur',blur);document.removeEventListener('visibilitychange',visibility);dialog.remove();}};
}
