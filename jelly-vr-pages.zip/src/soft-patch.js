// A bounded local viscoelastic displacement, superposed on the original volume grid.
// The same closed mesh feeds colour, refraction depth, normals and hit testing.
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export class SoftPatch {
  constructor(settings,profile='original'){this.settings=settings;this.profile=profile;this.reset();}
  reset(){this.point=[0,.05,.05];this.normal=[0,0,1];this.displacement=[0,0,0];this.velocity=[0,0,0];this.target=[0,0,0];this.radius=this.settings.contactRadius;this.mode='press';this.held=false;this.age=0;this.maxMove=0;this.volumeRatio=1;}
  begin(point,normal,mode='press'){
    this.point=[...point];this.normal=[...normal];this.mode=mode;this.held=true;this.age=0;
    this.target=[...this.displacement];this.radius=this.settings.contactRadius;
  }
  release(){this.held=false;this.target.fill(0);}
  step(dt){
    dt=clamp(dt,0,.05);this.age+=dt;const s=this.settings;
    const gel=this.profile==='gel',w=2*Math.PI*(this.held?(gel?3.8:4.8):s.recovery*(gel?.86:1)),z=this.held?.86:s.damping*(gel?.85:1);
    const count=Math.max(1,Math.ceil(dt*240)),h=dt/count;
    for(let k=0;k<count;k++)for(let i=0;i<3;i++){
      this.velocity[i]+=(w*w*(this.target[i]-this.displacement[i])-2*z*w*this.velocity[i])*h;
      this.displacement[i]+=this.velocity[i]*h;
    }
    if(!this.held&&Math.hypot(...this.displacement)<.000003&&Math.hypot(...this.velocity)<.00003){this.displacement.fill(0);this.velocity.fill(0);}
    this.maxMove=Math.hypot(...this.displacement);
  }
  deform(x,y,z,out=[0,0,0]){
    const d=this.displacement,n=this.normal,r=this.radius,s=this.settings;
    const dx=x-this.point[0],dy=y-this.point[1],dz=z-this.point[2];
    const along=dx*n[0]+dy*n[1]+dz*n[2];
    const tx=dx-along*n[0],ty=dy-along*n[1],tz=dz-along*n[2];
    const q=(tx*tx+ty*ty+tz*tz)/(r*r),depth=Math.exp(-along*along/(r*r*1.8));
    const gelGrab=this.profile==='gel'&&this.mode==='grab';
    const weight=(gelGrab?.8*Math.exp(-q*q*1.8)+.2*Math.exp(-q*.75):Math.exp(this.mode==='grab'?-q*q*1.8:-q*1.65))*depth;
    // A broad, low rim redistributes material around an indentation.
    const push=Math.max(0,-(d[0]*n[0]+d[1]*n[1]+d[2]*n[2]));
    const bulge=push*.24*s.volumeKeep*q*Math.exp(-q*.68)*depth;
    const neck=this.mode==='grab'?clamp(Math.hypot(...d)/s.maxStretch,0,1)*(gelGrab?.25:.20)*weight:0;
    out[0]=x+d[0]*weight+n[0]*bulge-tx*neck;
    out[1]=y+d[1]*weight+n[1]*bulge-ty*neck;
    out[2]=z+d[2]*weight+n[2]*bulge-tz*neck;
    return out;
  }
  get moving(){return this.held||Math.hypot(...this.displacement)>.000001||Math.hypot(...this.velocity)>.00001;}
  snapshot(){return {mode:this.mode,held:this.held,point:[...this.point],normal:[...this.normal],displacement:[...this.displacement],velocity:[...this.velocity],radius:this.radius,volumeRatio:this.volumeRatio};}
}
export function signedVolume(positions,indices){let v=0;for(let i=0;i<indices.length;i+=3){const a=indices[i]*3,b=indices[i+1]*3,c=indices[i+2]*3,p=positions;v+=p[a]*(p[b+1]*p[c+2]-p[b+2]*p[c+1])-p[a+1]*(p[b]*p[c+2]-p[b+2]*p[c])+p[a+2]*(p[b]*p[c+1]-p[b+1]*p[c]);}return v/6;}
