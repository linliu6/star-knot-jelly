import {TACTILE_LIMITS} from './tactile-config.js';
import {validChoice} from './audio-catalog.js';
export const DEFAULTS = {
  width: 1,
  height: 1.04,
  depth: 1.08,
  fullness: .85,
  dimple: 2.1,
  dimpleWidth: 1.32,
  lobes: 0.022,
  asymmetry: 1,
  bowWidth: 1,
  bowHeight: 1,
  bowDepth: 1,
  ribbonThickness: 0.0004,
  stemLength: 1,
  bowTilt: -8,
  attachmentLag: 0.045,
  bowFlex: 0.75,
  paint: 0.55,
  marks: 0.8,
  veinStrength: .95,
  veinLength: 1,
  veinDensity: 1,
  veinWidth: 1,
  veinColor: 1,
  wellStrength: .85,
  wellSpread: 1,
  veinBands: .8,
  decorationCount: 7,
  decorationSpread: 1,
  transmission: 1,
  bodyTint: "#fff0ec",
  absorption: "#ffa0b9",
  glow: 0.92,
  glowTint: "#ff245c",
  absorptionDistance: 0.2,
  roughness: 0.04,
  refractPaper: true,
  bodyGrain: 0.025,
  bodySmear: 0.03,
  refractionDepth: 0.05,
  refractionBlur: 0.1,
  bowTint: "#f8ecff",
  bowTransmission: 0.58,
  bowRoughness: 0.44,
  bowWeave: .35,
  bowGrain: .045,
  bowSheen: .65,
  bowBend: 6.0,
  bowTwist: 6.0,
  bowDamping: .28,
  seed: 18,
};
export const LIMITS = {
  ...Object.fromEntries(Object.entries(TACTILE_LIMITS).map(([k,v])=>["settings.tactile."+k,v])),
  "settings.mobile.touchGain":[.5,1.7],
  "settings.mobile.gripStrength":[.2,1.8],
  "settings.mobile.objectSize":[.56,.85],
  "settings.mobile.edgeInset":[.005,.045],
  ...Object.fromEntries(['volume','squeeze','friction','rebound','tail','tone','apple','ribbon','stem','orbit','wetness','fabricSoftness','stemTexture','tailLength','forceResponse','ribbonFollow','musicVolume'].map(k=>['settings.sound.'+k,[0,1]])),
  "settings.sound.musicFadeIn":[.02,.6],
  "settings.sound.musicFadeOut":[.05,1],
  "settings.sound.musicThreshold":[.001,.03],
  "shape.width": [0.75, 1.3],
  "shape.height": [0.75, 1.3],
  "shape.depth": [0.65, 1.2],
  "shape.fullness": [0, 1.2],
  "shape.dimple": [0.4, 2.6],
  "shape.dimpleWidth": [.8, 1.55],
  "shape.lobes": [0.0, 0.055],
  "shape.asymmetry": [0.0, 1.5],
  "shape.stemLength": [0.75, 1.3],
  "shape.bowWidth": [0.7, 1.3],
  "shape.bowHeight": [0.7, 1.4],
  "shape.bowDepth": [0.65, 1.35],
  "shape.ribbonThickness": [0.0003, 0.0015],
  "shape.bowTilt": [-25.0, 25.0],
  "shape.transmission": [0.0, 1.0],
  "shape.absorptionDistance": [0.025, 0.24],
  "shape.glow": [0.0, 1.3],
  "shape.bodyGrain": [0, 1],
  "shape.bodySmear": [0, 1],
  "shape.refractionDepth": [0.005, 0.09],
  "shape.refractionBlur": [0, 2],
  "shape.roughness": [0.03, 0.45],
  "shape.paint": [0.0, 1.0],
  "shape.marks": [0.0, 1.0],
  "shape.veinStrength": [0, 1],
  "shape.veinLength": [.5, 1.4],
  "shape.veinDensity": [.5, 1.5],
  "shape.veinWidth": [.5, 1.7],
  "shape.veinColor": [0, 1],
  "shape.wellStrength": [0, 1],
  "shape.wellSpread": [.65, 1.35],
  "shape.veinBands": [0, 1],
  "shape.bowTransmission": [0.0, 1.0],
  "shape.bowRoughness": [0.05, 0.8],
  "shape.bowWeave": [0,1],
  "shape.bowGrain": [0,1],
  "shape.bowSheen": [0,1],
  "shape.bowBend": [2,12],
  "shape.bowTwist": [2,14],
  "shape.bowDamping": [.08,.8],
  "settings.jelly.frequency": [1.5, 5.5],
  "settings.jelly.damping": [0.05, 0.6],
  "settings.jelly.stiffness": [0.2, 1.5],
  "settings.jelly.volume": [0.4, 1.2],
  "settings.jelly.response": [0.12, 0.7],
  "settings.jelly.maxDisplacement": [0.003, 0.014],
  "settings.jelly.surfaceWobble": [0.7, 1.6],
  "settings.jelly.fruitCoupling": [0.3, 1.4],
  "settings.jelly.fruitRotation": [0.0, 1.5],
  "shape.attachmentLag": [0.015, 0.12],
  "shape.bowFlex": [0.0, 1.4],
  "shape.decorationCount": [0.0, 7.0],
  "shape.decorationSpread": [0.7, 1.35],
  "settings.light.azimuth": [-180.0, 180.0],
  "settings.light.elevation": [20.0, 80.0],
  "settings.light.intensity": [1.0, 5.0],
  "settings.light.ambient": [0.3, 1.5],
  "settings.scene.exposure": [0.5, 1.2],
  "settings.cupShadow.opacity": [0.0, 0.85],
  "settings.cupShadow.softness": [0.1, 1.0],
  "settings.post.styleStrength": [0.2, 3.0],
  "settings.post.strokeWidth": [5.0, 45.0],
  "settings.post.strokeLength": [40.0, 220.0],
  "settings.post.speckle": [0.0, 2.5],
  "settings.post.smear": [0.0, 0.7],
  "settings.post.edgeRoughness": [0.0, 1.0],
  "settings.scene.pixelRatio": [0.75, 2.0],
};
export function normalizeState(data, baseSettings) {
  if (data?.schema !== "mesq-apple-study" || data?.version !== 1)
    throw Error("This is not a supported scene file (version 1 required).");
  const template = { shape: DEFAULTS, settings: baseSettings };
  function walk(base, value, path) {
    if (value === undefined) return structuredClone(base);
    if (base && typeof base === "object") {
      if (!value || typeof value !== "object" || Array.isArray(value))
        throw Error(path + " requires a settings object.");
      return Object.fromEntries(
        Object.entries(base).map(([k, v]) => [
          k,
          walk(v, value[k], path ? path + "." + k : k),
        ]),
      );
    }
    // Retired background music must not return through old saves, JSON or QR recipes.
    if(path==='settings.sound.orbitChoice'&&value===6)value=0;
    if(path.startsWith('settings.sound.')&&path.endsWith('Choice')&&!validChoice(value,path.split('.').at(-1).replace('Choice','')))throw Error('Invalid sound choice. Each group accepts 0–5.');
    if (typeof base !== typeof value) throw Error(path + " has an invalid type.");
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw Error(path + " requires a finite number.");
      const [lo, hi] = LIMITS[path] ?? [-10000, 10000];
      if (value < lo || value > hi)
        throw Error(path + " is outside the allowed range " + lo + "–" + hi);
    }
    if (
      typeof base === "string" &&
      base.startsWith("#") &&
      !/^#[0-9a-fA-F]{6}$/.test(value)
    )
      throw Error(path + " requires a six-digit color value.");
    return value;
  }
  // Preserve legacy material meanings; missing visual fields adopt V7 defaults.
  const legacy = {refractPaper:false, bodyGrain:1, bodySmear:1, refractionDepth:0.012, refractionBlur:1, glowTint:"#ff4932"};
  const clean = walk(template, {...data, shape:{...legacy, ...data.shape}}, "");
  clean.settings.jelly.freeBody = true;
  clean.settings.jelly.adhesion =
    clean.settings.jelly.rimPin =
    clean.settings.jelly.wallGrip =
      0;
  return { schema: "mesq-apple-study", version: 1, ...clean };
}
