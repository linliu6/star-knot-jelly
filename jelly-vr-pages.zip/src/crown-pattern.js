// Linear RGB pigment in the apple's own UV space; v=1 meets the stem.
// Three scales: feathered well colour, transparent brush ribbons, fine fans.
const TAU=Math.PI*2;
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
const linear=x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4;
const rgb=h=>[1,3,5].map(i=>linear(parseInt(h.slice(i,i+2),16)/255));
const mix=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*clamp(t));
const palette=['#bd3379','#f06d97','#9171cf','#5ebbbd','#f4d79c','#ffdfca'].map(rgb);
const wellColors=['#80515f','#b3c68a','#e8c575','#e8a397','#da6a9c'].map(rgb);
function random(seed){let n=seed>>>0;return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};}
function over(data,at,color,ink){
  ink=clamp(ink);if(ink<.002)return;
  const old=data[at+3]/255,alpha=ink+old*(1-ink);
  for(let c=0;c<3;c++)data[at+c]=Math.round((color[c]*ink+(data[at+c]/255)*old*(1-ink))/alpha*255);
  data[at+3]=Math.round(alpha*255);
}
export function makeCrownPixels(p,width=1536,height=1024){
  const rand=random(93017+p.seed*173),bands=[],lines=[];
  const count=Math.round(34*p.veinDensity);
  for(let i=0;i<count;i++){
    const a=(i+.15+rand()*.7)/count;
    const u=(a+.010*Math.sin(a*TAU*3)+.006*Math.sin(a*TAU*7)+1)%1;
    const family=i%12;
    const color=palette[family<4?0:family<6?1:family<8?2:family===8?3:family<11?4:5];
    const length=(i%6===0&&family<9?.46+rand()*.13:.21+rand()*.16)*p.veinLength;
    const base={u,length,start:.008+rand()*.011,curve:(rand()-.5)*.073,phase:rand()*TAU,
      width:(.0014+rand()*.002)*p.veinWidth,opacity:family===11?.49:.67+rand()*.2,
      color,frequency:13+rand()*16,kind:'main'};
    lines.push(base);
    const siblings=i%3===0?2:1;
    for(let j=0;j<siblings;j++)lines.push({...base,u:u+(j===0?1:-1)*(.004+rand()*.013),
      length:length*(.60+rand()*.3),width:base.width*(.24+rand()*.18),
      opacity:.30+rand()*.29,color:palette[(i+j+1)%5],phase:rand()*TAU,kind:'fine'});
    if(i%2===0)bands.push({...base,u:u-.002+rand()*.007,
      length:length*(.75+rand()*.25),width:(.006+rand()*.01)*p.veinWidth,
      opacity:(.28+rand()*.18)*p.veinBands,color:palette[i%4===0?1:i%4===2?4:2],kind:'band'});
  }
  const strands=[...bands,...lines],data=new Uint8Array(width*height*4);
  let paintedPixels=0,wellPixels=0;
  for(let y=0;y<height;y++){
    const t=1-y/(height-1);
    if(t>.86)continue;
    // The centre's colour follows the bowl, with uneven fingers at its rim.
    if(t<.20*p.wellSpread&&p.wellStrength>0){
      for(let x=0;x<width;x++){
        const a=x/width*TAU;
        const ray=Math.sin(a*17+.9*Math.sin(a*5))*.5+.5;
        const edge=(.112+.015*Math.sin(a*5+.4)+.016*Math.sin(a*11-.7)+.033*ray**3)*p.wellSpread;
        const q=t/p.wellSpread;
        let col=q<.028?mix(wellColors[0],wellColors[1],smooth(q/.028)):
          q<.064?mix(wellColors[1],wellColors[2],smooth((q-.028)/.036)):
          q<.105?mix(wellColors[2],wellColors[3],smooth((q-.064)/.041)):
          mix(wellColors[3],wellColors[4],smooth((q-.105)/.05));
        col=mix(col,palette[4],ray*.12*smooth(q/.035));
        const density=(.90-.18*smooth(q/.12))*(.92+.08*Math.sin(a*9+q*38));
        const alpha=smooth((edge-t)/.045)*p.wellStrength*density;
        if(alpha>.002){over(data,(y*width+x)*4,col,alpha);wellPixels++;}
      }
    }
    for(const s of strands){
      if(t<s.start||t>s.length)continue;
      const q=(t-s.start)/(s.length-s.start);
      const fade=smooth(q/.11)*smooth((1-q)/(s.kind==='band'?.4:.24));
      const curve=s.curve*Math.sin(q*1.7)*q+.0019*Math.sin(t*s.frequency+s.phase)*Math.sin(q*Math.PI);
      const centre=((s.u+curve)%1+1)%1;
      const half=s.width*(.46+.54*Math.sin(Math.PI*q)) / Math.max(.30,Math.sin(t*Math.PI)**.8);
      const gesture=.78+.22*Math.sin(t*57+s.phase)*Math.sin(t*23+s.phase);
      const strokeOpacity=s.opacity*fade*gesture;
      for(let x=Math.floor((centre-half*1.55)*width);x<=Math.ceil((centre+half*1.55)*width);x++){
        const d=Math.abs(x/width-centre)/half;
        const edge=s.kind==='band'?Math.exp(-d*d*1.7):Math.exp(-d*d*2.3);
        const alpha=strokeOpacity*edge;
        over(data,(y*width+(x%width+width)%width)*4,s.color,alpha);
      }
    }
  }
  for(let i=3;i<data.length;i+=4)if(data[i]>0)paintedPixels++;
  return {data,width,height,info:{strands:strands.length,mainLines:count,bands:bands.length,
    fineLines:lines.length-count,wellPixels,width,height,paintedPixels,uvAttached:true}};
}
