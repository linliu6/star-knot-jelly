import {store} from "../xhs/storage.js";
import {VARIANT,TACTILE_DEFAULTS} from './tactile-config.js';
import {installTactile} from './tactile.js';
import {mountVariants} from './variants-ui.js';
import {mobileDefaults,installMobile} from "./mobile.js";
import {makePartTouch} from "./part-touch.js";
import {PAGE_MODE,readPhoneRecipe,mountDelivery} from "./delivery.js";
import {
  ln as DataTexture,
  It as uniform,
  qt as vec3,
  ot as texture,
  ct as uv,
  B as transformNormal,
  g as PhysicalMaterial,
  H as positionLocal,
} from "../jelly-painting/assets/three-CU5tkW7F.js";
import {
  appleData,
  applePoint,
  appleCrownProfile,
  crownHeightAt,
  ribbonData,
  knotData,
  ribbonPoint,
  surfaceFrame,
  tubeData,
  ellipsoidData,
  starData,
  crescentData,
  norm,
  clamp,
} from "./geometry.js";
import { makeCrownPixels } from "./crown-pattern.js";
import { RibbonDynamics } from "./ribbon-physics.js";
import { makeInspector } from "./inspector.js";
import { DEFAULTS, normalizeState } from "./parameters.js";
export { DEFAULTS };
export function configureAppleDefaults(s) {
  s.scene.pixelRatio = 1;
  s.scene.autoQuality = true;
  s.contents.fruits = false;
  s.cream.enabled = false;
  s.lid.visible = false;
  Object.assign(s.jelly, {
    freeBody: true,
    adhesion: 0,
    rimPin: 0,
    wallGrip: 0,
    surfaceWobble: 1.25,
    maxDisplacement: 0.009,
    damping: 0.15,
  });
  s.liquid.fill = 1;
  s.liquid.meniscusHeight = 0;
  s.liquid.meniscusWidth = 0;
  Object.assign(s.camera, {
    azimuth: 113.5,
    elevation: 32.5,
    targetY: 0.075,
    fill: 0.68,
    fillWidth: 0.6,
    zoom: 1.06,
  });
  s.cup.yaw = 101.5;
  s.ui.signatureVisible = false;
  s.ui.miniVisible = false;
  mobileDefaults(s);
  s.tactile=structuredClone(TACTILE_DEFAULTS);
  if(VARIANT>1){s.jelly.frequency=2.6;s.jelly.damping=.26;}
}
const LEGACY_KEY = PAGE_MODE==='phone'?'star-apple-study-phone-v6':'star-apple-study-mobile-v6';
const PREVIOUS_KEY=LEGACY_KEY.replace('-v6','-v8-asmr');

export async function installApple(api, E) {
  const KEY = VARIANT===1?LEGACY_KEY.replace('-v6','-v82-music'):'star-apple-v9-'+PAGE_MODE+'-variant-'+VARIANT;
  const { Mesh, Geometry, Attribute, Vector3, Group, Color } = E,
    s = api.settings,
    root = api.cup.root,
    liquid = api.cup.liquid;
  const originalBackdrop = texture(api.pipeline.refractionTarget.texture);
  const params = structuredClone(DEFAULTS),
    stage = new URLSearchParams(location.search).get("stage") ?? "complete";
  const groups = [
    "tactile",
    "mobile",
    "sound",
    "interaction",
    "scene",
    "camera",
    "orbit",
    "cup",
    "light",
    "cupShadow",
    "shadowPaint",
    "post",
    "jelly",
    "sparkles",
    "table",
  ];
  const baseSettings = Object.fromEntries(
    groups.map((k) => [k, structuredClone(s[k])]),
  );
  const saved = (() => {
    try {
      const latest=store.getItem(KEY);
      if(VARIANT>1)return latest?JSON.parse(latest):null;
      const current=latest||store.getItem(PREVIOUS_KEY)||store.getItem(LEGACY_KEY.replace('-v6','-v7-assets'));
      if(current){const value=JSON.parse(current);if(!latest&&value.settings?.sound){value.settings.sound.ribbonFollow=1/3;}return value;}
      const legacy=JSON.parse(store.getItem(LEGACY_KEY)||store.getItem(LEGACY_KEY.replace('-v6','-v5'))||'null');
      // Replace the visual asset recipe once, retaining sound, touch and scene settings.
      if(!legacy)return null;
      const shape=structuredClone(DEFAULTS);
      for(const key of ['attachmentLag','bowFlex','bowBend','bowTwist','bowDamping'])
        if(legacy.shape?.[key]!==undefined)shape[key]=legacy.shape[key];
      return {...legacy,shape};
    } catch {
      return null;
    }
  })();
  if (saved && !new URLSearchParams(location.search).has("defaults")) {
    try {
      const clean = normalizeState(saved, baseSettings);
      Object.assign(params, clean.shape);
      mergeSettings(clean.settings);
      if(!store.getItem(KEY))store.setItem(KEY,JSON.stringify(clean));
    } catch (e) {
      console.warn("已忽略无法恢复的参数：", e.message);
    }
  }
  let recipeError=null;
  try {
    const shared=readPhoneRecipe(location.hash,baseSettings);
    if(shared){Object.assign(params,shared.shape);mergeSettings(shared.settings);store.setItem(KEY,JSON.stringify(shared));}
  } catch(error) {recipeError=error.message;}
  s.jelly.freeBody = true;
  s.jelly.adhesion = s.jelly.rimPin = s.jelly.wallGrip = 0;
  root.name = "Apple jelly — original Cherry runtime";
  liquid.mesh.name="Touch apple surface";
  const mobile=installMobile(api,E);
  const sourceTexture = api.cup.package.body.materials.painted.mapNode.value;
  const pixels = readTexture(sourceTexture.image),
    garnish = new Group();
  garnish.name = "Stem and tied ribbon";
  root.add(garnish);
  api.pipeline.refractionExclude=[garnish];
  const decor = new Group();
  decor.name = "Painted stars and crescent";
  api.scene.add(decor);
  const bodyNormal = makeNormal("apple");
  const paintStrength = uniform(params.paint),
    bodyNormalNode = E.normalFactory({
      map: bodyNormal,
      strength: paintStrength,
    });
  const originalDeformedNormal = liquid.material.normalNode;
  liquid.material.normalNode = originalDeformedNormal
    .add(bodyNormalNode.normal.sub(E.normalView))
    .normalize();
  const markMap = makeMarks(),
    markStrength = uniform(params.marks);
  liquid.material.colorNode = E.mix(
    uniform(liquid.material.color),
    vec3(1, 0.94, 0.86),
    texture(markMap, uv()).r.mul(markStrength),
  );
  liquid.material.needsUpdate = true;
  const originalEmission = liquid.material.emissiveNode;
  liquid.material.emissiveNode = originalEmission.add(
    vec3(1, 0.91, 0.78)
      .mul(texture(markMap, uv()).r)
      .mul(markStrength)
      .mul(0.24),
  );
  const dimpleRadius=uniform(.012*params.width*params.dimpleWidth);
  const dimpleY=uniform(applePoint(0,1,params)[1]-.007);
  const recess=positionLocal.xz.length().div(dimpleRadius).pow(2).negate().exp()
    .mul(positionLocal.y.sub(dimpleY).div(.007).clamp(0,1)).mul(.32);
  liquid.material.emissiveNode=liquid.material.emissiveNode.mul(recess.oneMinus());
  liquid.material.colorNode=liquid.material.colorNode.mul(recess.mul(.4).oneMinus());
  // Local pigment in the existing liquid pass. UVs are carried by the
  // original deforming body, so no overlay geometry or separate motion is used.
  const crownMap = new DataTexture(new Uint8Array(4), 1, 1);
  crownMap.name = "Stem crown · curved translucent pigment";
  crownMap.minFilter = crownMap.magFilter = 1006;
  crownMap.wrapS = 1000;
  const crownStrength = uniform(params.veinStrength);
  const crownColorMix = uniform(params.veinColor);
  const crown = texture(crownMap, uv());
  const crownInk = E.mix(vec3(.64, .16, .31), crown.rgb, crownColorMix);
  const crownAlpha = crown.a.mul(crownStrength);
  liquid.material.colorNode = E.mix(liquid.material.colorNode, crownInk, crownAlpha.mul(.7));
  liquid.material.emissiveNode = E.mix(liquid.material.emissiveNode,
    crownInk.mul(.72).mul(recess.mul(1.4).oneMinus()).add(liquid.material.emissiveNode.mul(.16)), crownAlpha.mul(.88));
  let crownKey = "", crownInfo = null;
  function updateCrown() {
    const key = JSON.stringify([params.veinLength, params.veinDensity, params.veinWidth, params.wellStrength, params.wellSpread, params.veinBands, params.seed]);
    if (key !== crownKey) {
      const image = makeCrownPixels(params);
      crownMap.image = {data:image.data, width:image.width, height:image.height};
      crownMap.needsUpdate = true;
      crownInfo = image.info;
      crownKey = key;
    }
    crownStrength.value = params.veinStrength;
    crownColorMix.value = params.veinColor;
  }
  let geometryKey = "",
    garnishKey = "",
    decorKey = "",
    counter = 0,
    bodyGeo = null,
    bowMeshes = [],
    stem = null,
    bowRest = [],
    bowDynamics = [],
    normals = [];
  let offset = new Vector3(),
    twist = new Vector3(),
    moving = false,
    revision = 0,
    flexState = 0;
  const anchorPrev=new Vector3(),anchorVel=new Vector3(),anchorAcc=new Vector3();
  const partTouch=makePartTouch(api,()=>({stem,bows:bowMeshes,dynamics:bowDynamics,garnish,
    knot:garnish.getObjectByName('Solid ribbon knot'),baseY:applePoint(0,1,params)[1]-.002}));
  mobile.setParts(partTouch);
  let tactile=null;
  let anchorReady=false;
  const lastAngles=new Vector3(),spinVel=new Vector3(),spinAcc=new Vector3();
  const white = new E.StandardMaterial({
    color: "#fff2de",
    roughness: 0.72,
    metalness: 0,
  });
  white.name = "Solid central knot";
  white.emissive.set("#fff2de");
  white.emissiveIntensity = 0.035;
  const markMaterial = white.clone();
  markMaterial.name = "Surface painted marks";
  markMaterial.transparent = true;
  const decorationMaterial = new E.BasicMaterial({ color: "#ffe5b3" });
  const stemLook = E.fruitLook({
    ...s.fruits,
    opacity: 1,
    edgeOpacity: 1,
    paintStrength: 0.38,
    glow: 0.08,
    core: 0.05,
    roughnessScale: 1,
    specular: 0.35,
  });
  const stemType = E.fruitType({
    color: "#75502e",
    sss: "#eab483",
    roughness: 0.65,
    clarity: 0,
  });
  const stemMaterial = E.fruitMaterial({
    look: stemLook,
    type: stemType,
    environment: E.environment.environment,
    envIntensity: 0.35,
    name: "apple stem",
  }).material;
  const bowSettings = {
    ...s.lid,
    color: params.bowTint,
    transmission: params.bowTransmission,
    roughness: params.bowRoughness,
    thickness: params.ribbonThickness,
    ior: 1.26,
    attenuationColor: "#e3d5ff",
    attenuationDistance: 0.15,
    envMapIntensity: 0.7,
  };
  const ribbonMarks = makeRibbonMarks(),
    bowTransmission = uniform(params.bowTransmission);
  const clothOpacity=uniform(1-params.bowTransmission), clothWeave=uniform(params.bowWeave), clothSheen=uniform(params.bowSheen);
  const bowUniforms = E.glassUniforms(bowSettings, s.highlights);
  bowUniforms.paintStrength.value = 0.32;
  // Every body pass shares this exact closed geometry and displacement field.
  let crownContact = [];
  liquid.build = function () {
    const key = JSON.stringify([
      params.width,
      params.height,
      params.depth,
      params.dimple,
      params.dimpleWidth,
      params.fullness,
      params.lobes,
      params.asymmetry,
    ]);
    if (key === geometryKey) return;
    geometryKey = key;
    const data = appleData(params),
      old = bodyGeo;
    crownContact = appleCrownProfile(params);
    bodyGeo = geometry(data);
    bodyGeo.name = "Closed apple jelly";
    bodyGeo.setAttribute(
      "positionBase",
      bodyGeo.getAttribute("position").clone(),
    );
    this.mesh.geometry = this.back.geometry = bodyGeo;
    this.info = {
      fillY: data.top + 0.0002,
      floorY: data.base,
      wallRadius: 0.055 * params.width * (1 + .07 * params.fullness),
      volumeMl: signedVolume(data) * 1e6,
    };
    this.cavity = data.profile;
    this.shape = null;
    this.cream = null;
    this.creamInterface = null;
    this.version++;
    this.source = "Closed apple volume, generated and editable";
    this.uniforms.fillY.value = this.info.fillY;
    this.uniforms.meniscus.value = 0;
    this.uniforms.maxDepth.value = 0.2;
    this.uniforms.deform.freeBody.value = 1;
    this.extras = {
      ...this.extras,
      height: data.top + 0.0002,
      cavityProfile: data.profile,
    };
    Object.assign(api.cup.extras, {
      height: data.top,
      rimRadius: 0.055 * params.width * (1 + .07 * params.fullness),
      lidRadius: 0.055 * params.width * (1 + .07 * params.fullness),
      lidTopY: data.top + 0.06 * params.stemLength,
      cavityProfile: data.profile,
      outerProfile: data.profile,
      baseRadius: 0.012,
      lidSkirtBottomY: data.top + 0.07,
    });
    Object.assign(api.cup.referenceExtras, api.cup.extras);
    s.jelly.bodyDepth = params.depth;
    api.jelly.setPackage({ id: "apple-" + ++counter, extras: this.extras });
    api.jelly.configure();
    api.contents.apply();
    repaintNormal(bodyNormal, "apple");
    old?.dispose();
    api.table.setCaster({
      root,
      extras: {
        ...api.cup.extras,
        lidTopY: data.top + 0.06 * params.stemLength,
        lidRadius: 0.055 * params.width * (1 + .07 * params.fullness),
      },
      lid: null,
    });
    api.table.uniforms.caster.apple.value.set(
      0.055 * params.width * (1 + .07 * params.fullness),
      0.103 * params.height,
      params.depth,
      0.004 * params.height,
    );
    E.notify();
    revision++;
  };
  const sync = api.cup.syncVisibility.bind(api.cup);
  api.cup.syncVisibility = function () {
    sync();
    for (const p of Object.values(this.packages)) {
      p.root.visible = false;
      p.body.mesh.visible = false;
      p.lid.mesh.visible = false;
    }
  };
  liquid.build();
  api.cup.syncVisibility();
  api.contents.apply();
  // Keep original paper and cursor, suppress unrelated cup theme thumbnails.
  api.themeCanvases.group.style.display = "none";
  api.pipeline.overlay = null;
  for (const study of api.themeCanvases.studies) study.mesh.visible = false;
  const link = document.querySelector(".social-link");
  if (link) {
    link.setAttribute("aria-label", "原作技术与美术：mesq");
    link.title = "Based on mesq · Jelly Painting";
  }
  function geometry(data) {
    const g = new Geometry();
    g.setAttribute(
      "position",
      new Attribute(new Float32Array(data.positions), 3),
    );
    g.setAttribute("uv", new Attribute(new Float32Array(data.uv), 2));
    g.setIndex(data.indices);
    g.computeVertexNormals();
    g.computeBoundingBox();
    g.computeBoundingSphere();
    return g;
  }
  function makeRibbonMarks() {
    const w = 512,
      h = 512,
      d = new Uint8Array(w * h * 4);
    for (let j = 0; j < h; j++)
      for (let i = 0; i < w; i++) {
        const u = i / w,
          v = ((j / h) * 2) % 1;
        let m = Math.max(0, 1 - Math.min(v, 1 - v) / 0.035);
        for (const [su, sv, sz] of [
          [0.23, 0.3, 0.056],
          [0.44, 0.67, 0.061],
          [0.73, 0.52, 0.038],
        ]) {
          const x = Math.abs(u - su) / sz,
            y = Math.abs(v - sv) / (sz * 2.2);
          m = Math.max(m, clamp((1 - Math.sqrt(x) - Math.sqrt(y)) * 9, 0, 1));
        }
        const at = (j * w + i) * 4;
        d[at] = d[at + 1] = d[at + 2] = m * 255;
        d[at + 3] = 255;
      }
    const t = new DataTexture(d, w, h);
    t.minFilter = t.magFilter = 1006;
    t.needsUpdate = true;
    return t;
  }
  function makeMarks() {
    const w = 512,
      h = 512,
      d = new Uint8Array(w * h * 4),
      spots = [
        [0.16, 0.64, 0.006, 0.025],
        [0.29, 0.39, 0.006, 0.028],
        [0.41, 0.76, 0.007, 0.028],
        [0.58, 0.5, 0.005, 0.027],
        [0.72, 0.68, 0.006, 0.02],
        [0.9, 0.33, 0.005, 0.031],
      ];
    for (let y = 0; y < h; y++)
      for (let x = 0; x < w; x++) {
        const u = x / w,
          v = y / h;
        let value = 0;
        for (let k = 0; k < 13; k++) {
          const centre =
              k / 13 + 0.003 * Math.sin(v * 6 + k + params.seed * 0.1),
            dd = Math.abs(u - centre);
          const end =
            Math.min(1, Math.max(0, (v - 0.1) * 9)) *
            Math.min(1, Math.max(0, (0.82 - v) * 10));
          value = Math.max(value, Math.max(0, 1 - dd / 0.0018) * end * 0.3);
        }
        for (const [su, sv, sx, sy] of spots) {
          const a = (u - su) / sx,
            b = (v - sv) / sy;
          value = Math.max(value, Math.max(0, 1 - a * a - b * b) * 0.88);
        }
        const i = (y * w + x) * 4;
        d[i] = d[i + 1] = d[i + 2] = Math.round(value * 255);
        d[i + 3] = 255;
      }
    const map = new DataTexture(d, w, h);
    map.minFilter = map.magFilter = 1006;
    map.needsUpdate = true;
    return map;
  }
  function readTexture(image) {
    const c = document.createElement("canvas");
    c.width = image.width;
    c.height = image.height;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(image, 0, 0);
    return ctx.getImageData(0, 0, c.width, c.height);
  }
  function sourceStroke(u, v) {
    const x = ((((u % 1) + 1) % 1) * pixels.width) | 0,
      y = (clamp(v, 0, 0.99999) * pixels.height) | 0,
      i = (y * pixels.width + x) * 4,
      a = Math.PI / 2 + u * Math.PI * 2;
    const n = [
      pixels.data[i] / 127.5 - 1,
      pixels.data[i + 1] / 127.5 - 1,
      pixels.data[i + 2] / 127.5 - 1,
    ];
    return [
      clamp(n[0] * -Math.sin(a) + n[2] * -Math.cos(a), -0.8, 0.8),
      clamp(n[1], -0.7, 0.7),
    ];
  }
  function makeNormal(kind, side = -1) {
    const t = new DataTexture(new Uint8Array(256 * 256 * 4), 256, 256);
    t.name = "Remapped original authored brush normals · " + kind;
    t.minFilter = t.magFilter = 1006;
    t.needsUpdate = true;
    repaintNormal(t, kind, side);
    return t;
  }
  function repaintNormal(tex, kind, side = -1) {
    const d = tex.image.data,
      w = tex.image.width,
      h = tex.image.height;
    for (let j = 0; j < h; j++)
      for (let i = 0; i < w; i++) {
        const u = (i + 0.5) / w,
          v = (j + 0.5) / h,
          back = kind === "ribbon" && v >= 0.5,
          q = kind === "apple" ? v : (v * 2) % 1;
        const fn =
            kind === "apple"
              ? (x, y) => applePoint(x, y, params)
              : (x, y) => ribbonPoint(x, y, params, side),
          f = surfaceFrame(fn, u, q),
          st = sourceStroke(u, q);
        let n = norm(
          f.normal.map(
            (x, k) => x + f.u[k] * st[0] * 0.20 + f.v[k] * st[1] * 0.18,
          ),
        );
        if (back) n = n.map((x) => -x);
        const at = (j * w + i) * 4;
        for (let k = 0; k < 3; k++)
          d[at + k] = Math.round(clamp(n[k] * 0.5 + 0.5, 0, 1) * 255);
        d[at + 3] = 255;
      }
    tex.needsUpdate = true;
  }
  function disposeTree(group) {
    const gs = new Set(),
      ms = new Set();
    group.traverse((o) => {
      if (o.geometry) gs.add(o.geometry);
      if (o.userData.materialSet)
        for (const m of o.userData.materialSet.all) ms.add(m);
    });
    for (const g of gs) g.dispose();
    for (const m of ms) m.dispose();
    group.clear();
  }
  function rebuildGarnish() {
    const key = JSON.stringify([
      params.bowWidth,
      params.bowHeight,
      params.bowDepth,
      params.ribbonThickness,
      params.stemLength,
      params.bowTilt,
      params.height,
      params.dimple,
      stage,
    ]);
    if (key === garnishKey) return;
    garnishKey = key;
    disposeTree(garnish);
    for (const n of normals) n.dispose();
    normals = [];
    bowMeshes = [];
    bowRest = [];
    bowDynamics = [];
    const stemBase = applePoint(0, 1, params)[1] - 0.002;
    const points = [],
      radii = [];
    for (let i = 0; i <= 44; i++) {
      const t = i / 44;
      points.push([
        -0.021 * (t * t) * params.stemLength + 0.007 * Math.sin(t * Math.PI),
        stemBase + t * 0.051 * params.stemLength,
        0.001 + Math.sin(t * Math.PI) * 0.002,
      ]);
      radii.push(
        0.00155 * (1 - 0.3 * t) +
          0.0006 * Math.exp(-(((t - 0.98) / 0.045) ** 2)),
      );
    }
    stem = new Mesh(geometry(tubeData(points, radii, 14)), stemMaterial);
    stem.name = "Connected curved stem";
    stem.castShadow = true;
    garnish.add(stem);
    const bowRoot = new Group();
    bowRoot.name = "Knot attached to stem";
    bowRoot.position.set(0.001, stemBase + 0.018 * params.stemLength, 0.0015);
    bowRoot.rotation.z = (params.bowTilt * Math.PI) / 180;
    garnish.add(bowRoot);
    const knot = new Mesh(
      geometry(knotData()),
      white,
    );
    knot.name = "Solid ribbon knot";
    knot.castShadow = true;
    bowRoot.add(knot);
    for (const side of stage === "sample" ? [-1] : [-1, 1]) {
      const g = geometry(ribbonData(params, side)),
        map = makeNormal("ribbon", side);
      normals.push(map);
      const mesh = new Mesh(g);
      mesh.name = side < 0 ? "Left folded ribbon" : "Right folded ribbon";
      const surface = E.makeGlass({
        mesh,
        map,
        glass: bowSettings,
        uniforms: bowUniforms,
        surface: null,
        environment: E.environment.environment,
        name: mesh.name,
        pipeline: api.pipeline,
      });
      mesh.userData.materialSet = surface.materials;
      mesh.userData.side = side;
      // Keep the original depth partitions, but shade each partition as a
      // thin woven surface. No glass refraction or volumetric emission.
      const replacements=new Map();
      for (const mat of surface.materials.all) {
        const fabric=new PhysicalMaterial({color:params.bowTint,roughness:params.bowRoughness,
          metalness:0,transparent:true,depthWrite:true,side:0,
          envMap:E.environment.environment,envMapIntensity:.35,
          sheen:1,sheenColor:'#fff6f2',sheenRoughness:.6,specularIntensity:.35});
        const mask=texture(ribbonMarks,uv()).r.mul(markStrength);
        const weave=uv().x.mul(2400).sin().mul(uv().y.mul(1500).sin()).mul(.5).add(.5);
        fabric.name='Organza · '+mat.name;
        fabric.maskNode=mat.maskNode;
        fabric.colorNode=E.mix(uniform(fabric.color),vec3(1,.96,.9),mask.mul(.45));
        fabric.opacityNode=clothOpacity.add(mask.mul(.45)).add(weave.mul(clothWeave).mul(.12)).clamp(.06,.92);
        fabric.userData.roughness=uniform(params.bowRoughness);
        fabric.roughnessNode=fabric.userData.roughness.add(weave.mul(clothWeave).mul(.08));
        fabric.sheenNode=clothSheen;
        fabric.emissiveNode=vec3(.30,.28,.26).add(vec3(.45,.41,.38).mul(mask));
        replacements.set(mat,fabric);
      }
      mesh.traverse(o=>{if(o.isMesh&&replacements.has(o.material))o.material=replacements.get(o.material)});
      mesh.userData.materialSet={all:[...replacements.values()]};
      for(const old of replacements.keys())old.dispose();
      mesh.castShadow = true;
      bowRoot.add(mesh);
      bowMeshes.push(mesh);
      bowRest.push(Float32Array.from(g.attributes.position.array));
      bowDynamics.push(new RibbonDynamics(params,side));
    }
    E.notify();
    revision++;
  }
  function rebuildDecor() {
    const key = JSON.stringify([
      params.decorationCount,
      params.decorationSpread,
    ]);
    if (key === decorKey) return;
    decorKey = key;
    disposeTree(decor);
    const spots = [
      [-0.105, 0.102, -0.005, 0.004],
      [0.108, 0.142, -0.045, 0.007],
      [-0.09, 0.026, 0.06, 0.003],
      [0.099, 0.034, 0.02, 0.004],
      [-0.07, 0.173, -0.075, 0.002],
      [0.07, 0.068, -0.08, 0.002],
      [0.042, 0.174, -0.065, 0.003],
    ];
    for (let i = 0; i < params.decorationCount; i++) {
      const q = spots[i % spots.length],
        m = new Mesh(
          geometry(
            i === 3 ? crescentData(q[3] * 1.5) : starData(q[3], 0.0006, 4),
          ),
          decorationMaterial,
        );
      m.name = i === 3 ? "Crescent decoration" : "Star decoration";
      m.position
        .set(q[0] * params.decorationSpread, q[1], q[2])
        .applyAxisAngle(new Vector3(0, 1, 0), (113.5 * Math.PI) / 180);
      decor.add(m);
    }
  }
  function updateMaterial() {
    updateCrown();
    Object.assign(s.liquid, {
      color: params.bodyTint,
      attenuationColor: params.absorption,
      attenuationDistance: params.absorptionDistance,
      roughness: params.roughness,
      glow: params.glow,
      glowColor: params.glowTint,
      thickness: params.refractionDepth,
    });
    liquid.configure(s.scene.environment, E.environment.keyDirection());
    liquid.material.transmission = params.transmission;
    liquid.material.blurScale = params.refractionBlur;
    liquid.uniforms.angleAmount.value=0;
    api.pipeline.paintTransmissionEnabled = params.refractPaper;
    liquid.material.viewportBuffer = params.refractPaper ? api.pipeline.transmissionBackdrop : originalBackdrop;
    api.pipeline.postfx.uniforms.subjectGrain.value = params.bodyGrain;
    api.pipeline.postfx.uniforms.subjectSmear.value = params.bodySmear;
    api.pipeline.postfx.uniforms.clothGrain.value=params.bowGrain;
    dimpleRadius.value=.012*params.width*params.dimpleWidth;dimpleY.value=applePoint(0,1,params)[1]-.007;
    paintStrength.value = params.paint;
    markStrength.value = params.marks;
    Object.assign(bowSettings, {
      color: params.bowTint,
      transmission: params.bowTransmission,
      roughness: params.bowRoughness,
      thickness: params.ribbonThickness,
    });
    E.configureGlass(bowUniforms, s.highlights, E.environment.keyDirection());
    for (const m of bowMeshes)
      for (const mat of m.userData.materialSet.all) {
        mat.color.set(params.bowTint);
        mat.opacity=1-params.bowTransmission;
        mat.roughness = params.bowRoughness;
        mat.userData.roughness.value=params.bowRoughness;
      }
    white.color.set("#fff2de");
    markMaterial.opacity = params.marks;
    bowTransmission.value = params.bowTransmission;
    clothOpacity.value=1-params.bowTransmission;clothWeave.value=params.bowWeave;clothSheen.value=params.bowSheen;
    const caster = api.table.uniforms.caster;
    caster.bowOpacity.value = 0.06 + (1 - params.bowTransmission) * 0.18;
    caster.bowSize.value.set(
      0.024 * params.bowWidth,
      0.022 * params.bowHeight,
      0.011 * params.bowDepth,
    );
    caster.bowOffset.value.set(
      0.022 * params.bowWidth,
      0.008 * params.bowHeight,
    );
  }
  function apply({ reframe = false } = {}) {
    mobile.apply();
    liquid.build();
    rebuildGarnish();
    rebuildDecor();
    updateMaterial();
    api.cup.syncVisibility();
    api.jelly.configure();
    E.refresh();
    liquid.material.transmission = params.transmission;
    api.actions.post();
    api.actions.rendering();
    api.cup.place();
    if (reframe || s.camera.fillWidth!==api.view._mobileFill) {api.actions.camera();api.view._mobileFill=s.camera.fillWidth;}
    api.scene.updateMatrixWorld(true);
    anchorReady=false;
    if(clay)setClay(true);
    E.notify();
    revision++;
  }
  function mergeSettings(data) {
    if (!data) return;
    for (const group of groups)
      if (data[group]) Object.assign(s[group], structuredClone(data[group]));
  }
  function documentState() {
    return {
      schema: "mesq-apple-study",
      version: 1,
      shape: structuredClone(params),
      settings: Object.fromEntries(
        groups.map((k) => [k, structuredClone(s[k])]),
      ),
    };
  }
  function save() {
    store.setItem(KEY, JSON.stringify(documentState()));
    return documentState();
  }
  async function restore(data) {
    if (!data) {
      data = JSON.parse(store.getItem(KEY) || "null");
    }
    const clean = normalizeState(data, baseSettings);
    Object.assign(params, clean.shape);
    mergeSettings(clean.settings);
    s.jelly.freeBody = true;
    s.jelly.adhesion = s.jelly.rimPin = s.jelly.wallGrip = 0;
    geometryKey = garnishKey = decorKey = "";
    apply({ reframe: true });
    panel?.refresh();
    return true;
  }
  let panel = null;
  function reset() {
    mobile.cancel();
    tactile?.reset();
    partTouch.reset();
    offset.set(0, 0, 0);
    twist.set(0, 0, 0);
    flexState = 0;
    anchorReady=false;
    Object.assign(params, DEFAULTS);
    mergeSettings(baseSettings);
    geometryKey = garnishKey = decorKey = "";
    api.interaction?.state.velocity.set(0, 0, 0);
    api.jelly.body?.reset();
    apply({ reframe: true });
    panel?.refresh();
  }
  function update(dt, time) {
    const b = api.jelly.body;
    if (b) {
      b.sample(0, applePoint(0, 1, params)[1] - 0.006, 0, sample);
      const rate = 1 - Math.exp(-dt / Math.max(0.008, params.attachmentLag));
      const wanted = new Vector3(...sample.u).multiplyScalar(
        s.jelly.fruitCoupling,
      );
      if(tactile){const y=applePoint(0,1,params)[1]-.006,q=tactile.patch.deform(0,y,0);wanted.add(new Vector3(q[0],q[1]-y,q[2]));}
      offset.lerp(wanted, rate);
      twist.lerp(
        new Vector3(...sample.w).multiplyScalar(s.jelly.fruitRotation),
        rate,
      );
      garnish.position.copy(offset);
      garnish.rotation.set(twist.x, twist.y, twist.z);
      partTouch.pose(dt);
      const knot=garnish.getObjectByName('Knot attached to stem');
      knot.updateWorldMatrix(true,false);
      const anchor=new Vector3().setFromMatrixPosition(knot.matrixWorld);
      const angles=new Vector3(root.rotation.x+garnish.rotation.x,root.rotation.y+garnish.rotation.y,root.rotation.z+garnish.rotation.z);
      const step=Math.max(dt,.001);
      const v=anchor.clone().sub(anchorPrev).divideScalar(step);
      const av=angles.clone().sub(lastAngles).divideScalar(step);
      if(anchorReady){
        anchorAcc.copy(v).sub(anchorVel).divideScalar(step).clampLength(0,35);
        spinAcc.copy(av).sub(spinVel).divideScalar(step).clampLength(0,100);
      }else{anchorReady=true;anchorAcc.set(0,0,0);spinAcc.set(0,0,0);}
      anchorPrev.copy(anchor);anchorVel.copy(v);lastAngles.copy(angles);spinVel.copy(av);
      // Convert world acceleration to the local axes of the tied band.
      const localA=anchorAcc.clone().transformDirection(knot.matrixWorld.clone().invert()).multiplyScalar(anchorAcc.length());
      const localW=spinAcc.toArray();
      const inv=knot.matrix.clone().invert();
      const collide=(pt)=>{
        const q=new Vector3(...pt).applyMatrix4(knot.matrix);
        // Rounded crown contact follows the well instead of a flat top plane.
        // Small clearance covers the authored lobes and asymmetry. This is a
        // kinematic contact envelope, not cloth self-collision.
        const rr=Math.hypot(q.x,q.z/params.depth);
        const shoulder=crownHeightAt(rr,crownContact);
        if(shoulder!==null&&q.y<shoulder+.0015){q.y=shoulder+.0015;q.applyMatrix4(inv);pt.splice(0,3,q.x,q.y,q.z);return true;}
        return false;
      };
      flexState=0;
      for(let k=0;k<bowMeshes.length;k++){
        const m=bowMeshes[k],sim=bowDynamics[k],pos=m.geometry.attributes.position,rest=bowRest[k],uvs=m.geometry.attributes.uv;
        sim.update(dt,localA.toArray(),localW,collide,partTouch.bowGrab(k));
        for(let i=0;i<pos.count;i++){
          const pt=sim.deform(uvs.getX(i),[rest[i*3],rest[i*3+1],rest[i*3+2]]);
          collide(pt);pos.setXYZ(i,...pt);
        }
        pos.needsUpdate=true;m.geometry.computeVertexNormals();
        flexState=Math.max(flexState,sim.energy);
      }
      moving =
        !b.asleep ||
        offset.distanceTo(wanted) > 1e-6 ||
        Math.abs(flexState) > .002;
    }
    const knot = garnish.getObjectByName("Knot attached to stem");
    if (knot) {
      knot.updateWorldMatrix(true, false);
      api.table.uniforms.caster.bowInverse.value
        .copy(knot.matrixWorld)
        .invert();
    }
    for (const m of decor.children) m.quaternion.copy(api.camera.quaternion);
    tactile?.update(dt);
    moving ||= !!tactile?.moving;
    const partMotion=partTouch.measure(dt);
    moving ||= partMotion.moving;
    mobile.update(dt,time,partMotion);
  }
  const sample = { u: [0, 0, 0], grad: Array(9).fill(0), w: [0, 0, 0] };
  function snapshot() {
    const b = api.jelly.body;
    return {
      stage,
      variant:VARIANT,
      tactile:tactile?.snapshot()??null,
      mobile:mobile.snapshot(),
      clay,
      revision,
      params: structuredClone(params),
      crown: { ...crownInfo, strength: crownStrength.value, colorMix: crownColorMix.value },
      material: {
        transmission: liquid.material.transmission,
        paint: paintStrength.value,
        bowTransmission: bowTransmission.value,
      },
      flex: flexState,
      ribbon:bowDynamics.map(d=>d.snapshot()),
      physics: b?.describe(),
      maxDisplacement: b?.stats.maxU,
      garnish: garnish.position.toArray(),
      garnishRotation: garnish.rotation.toArray(),
      renderer: api.stats.renderer,
      passes: api.stats.passes,
      parts: { bow: bowMeshes.length, decorations: decor.children.length },
      geometry: {
        vertices: bodyGeo.attributes.position.count,
        triangles: bodyGeo.index.count / 3,
      },
      errors: [],
      settings: documentState().settings,
    };
  }
  let clay=false;
  const clayMaterials=new Map();
  function setClay(on){
    clay=on;
    const list=[liquid.mesh];garnish.traverse(o=>{if(o.isMesh)list.push(o)});
    for(const o of list){
      if(on){
        if(!o.userData.surfaceMaterial)o.userData.surfaceMaterial=o.material;
        const old=o.userData.surfaceMaterial;
        if(!clayMaterials.has(old)){
          const m=new E.StandardMaterial({color:o===liquid.mesh?'#b8b8b8':'#dedede',roughness:.8,side:old.side});
          m.maskNode=old.maskNode;m.positionNode=old.positionNode;
          clayMaterials.set(old,m);
        }
        o.material=clayMaterials.get(old);
      }else if(o.userData.surfaceMaterial){o.material=o.userData.surfaceMaterial;delete o.userData.surfaceMaterial;}
    }
    E.notify();return clay;
  }
  function setView(name){
    const v={front:[113.5,32.5],side:[203.5,24],top:[113.5,80],back:[293.5,32.5]}[name]??[113.5,32.5];
    s.camera.azimuth=v[0];s.camera.elevation=v[1];apply({reframe:true});
  }
  apply({ reframe: true });
  tactile=installTactile(api,E,params,partTouch,mobile.audio);
  mobile.setTactile(tactile);
  panel = makeInspector({
    params,
    mobile,
    settings: s,
    apply,
    save,
    restore,
    reset,
    documentState,
    shake: () => api.actions.shake(),
    resetView: () => api.actions.resetView(),
    setView,
    setClay,
    notify: E.notify,
  });
  mobile.mount();
  mountDelivery({documentState,baseSettings,mobile,panel});
  mountVariants({tactile,mobile,notify:E.notify});
  if(recipeError)document.querySelector('#sound-status').textContent=recipeError;
  return {
    dispose(){panel?.dispose?.();mobile.dispose();},
    tactile,
    beforeUpdate: mobile.beforeUpdate,
    mobile,
    params,
    apply,
    update,
    snapshot,
    setView,
    setClay,
    save,
    restore,
    reset,
    documentState,
    get moving() {
      return moving;
    },
    geometry,
    root,
    garnish,
    decor,
    get body() {
      return api.jelly.body;
    },
  };
  function signedVolume(data) {
    let v = 0;
    for (let i = 0; i < data.indices.length; i += 3) {
      const a = data.indices[i] * 3,
        b = data.indices[i + 1] * 3,
        c = data.indices[i + 2] * 3,
        p = data.positions;
      v +=
        (p[a] * (p[b + 1] * p[c + 2] - p[b + 2] * p[c + 1]) -
          p[a + 1] * (p[b] * p[c + 2] - p[b + 2] * p[c]) +
          p[a + 2] * (p[b] * p[c + 1] - p[b + 1] * p[c])) /
        6;
    }
    return Math.abs(v);
  }
}
