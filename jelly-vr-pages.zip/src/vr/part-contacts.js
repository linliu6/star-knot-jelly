// Reuse the web scene's attachment, bending and ribbon solvers with 3D contact.
// One accessory grab owns the legacy accessory/audio channel; the other hand
// can still deform the apple volume. No screen-space ray or head-look targeting.
export class PartContacts {
  constructor(api,E,study,audio){this.api=api;this.E=E;this.study=study;this.parts=study.partTouch;this.audio=audio;this.owner=null;this.active=null;this.previous=null;this.pinched=false;}
  clear(cancelled=true){if(this.owner){const strain=this.parts.strain;this.parts.end();this.audio.owner.release(strain,cancelled);}this.owner=this.active=this.previous=null;this.pinched=false;this.audio.partState=null;}
  point(input){return input.pinch?input.pinchPoint:(input.joints.get('index-finger-tip')?.position??input.pinchPoint);}
  update(inputs,dt){
    if(!this.parts)return;this.api.scene.updateMatrixWorld(true);
    if(this.owner){
      const input=inputs.find(i=>i.id===this.owner);if(!input){this.clear();return;}
      const point=this.point(input),h=input.pinch?null:this.parts.hitWorld(point,.011);
      if((this.pinched&&!input.pinch)||(!input.pinch&&(!h||h.kind!==this.active))){this.clear(false);return;}
      this.parts.moveWorld(point);this.pinched=input.pinch;
      const speed=this.previous?Math.hypot(...point.map((v,i)=>v-this.previous[i]))/Math.max(.001,dt)*1000:0;
      this.previous=[...point];this.audio.partState={held:true,speed:Math.min(1400,speed),strain:this.parts.strain,displacement:0,velocity:0};return;
    }
    for(const input of inputs){
      const point=this.point(input),hit=this.parts.hitWorld(point,.007);if(!hit)continue;
      // Start the drag at the finger, avoiding a jump from the surface tolerance.
      hit.point=new this.E.Vector3(...point);this.study.tactile?.setXRContact(null,true);this.parts.begin(hit,0,0);this.owner=input.id;this.active=hit.kind;this.pinched=input.pinch;this.previous=[...point];
      this.audio.owner.press(hit.kind);this.audio.partState={held:true,speed:0,strain:0,displacement:0,velocity:0};break;
    }
  }
}
