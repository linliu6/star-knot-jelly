// Copy the already-painted eye without another lighting/color conversion.
// XRWebGLLayer may be multisampled even when antialias:false was requested.
// A textured draw supports that destination; single-sample -> MSAA blits do not.
export class EyePresenter {
  constructor(renderer) {
    this.gl=renderer.getContext();this.state=renderer.backend.state;
    const gl=this.gl,shaders=[];
    this.flags=[gl.DEPTH_TEST,gl.STENCIL_TEST,gl.BLEND,gl.CULL_FACE,gl.SCISSOR_TEST,gl.SAMPLE_ALPHA_TO_COVERAGE,gl.RASTERIZER_DISCARD];
    try {
      for(const [type,source] of [
        [gl.VERTEX_SHADER,`#version 300 es
          out vec2 vUv;
          void main(){
            vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);
            vUv=p;gl_Position=vec4(p*2.0-1.0,0.0,1.0);
          }`],
        [gl.FRAGMENT_SHADER,`#version 300 es
          precision highp float;
          uniform sampler2D paintedEye;
          in vec2 vUv;
          out vec4 color;
          void main(){color=vec4(texture(paintedEye,vUv).rgb,1.0);}`],
      ]) {
        const shader=gl.createShader(type);shaders.push(shader);
        gl.shaderSource(shader,source);gl.compileShader(shader);
        if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('VR 显示着色器：'+gl.getShaderInfoLog(shader));
      }
      this.program=gl.createProgram();for(const shader of shaders)gl.attachShader(this.program,shader);
      gl.linkProgram(this.program);
      if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error('VR 显示程序：'+gl.getProgramInfoLog(this.program));
      this.image=gl.getUniformLocation(this.program,'paintedEye');this.vao=gl.createVertexArray();
    } catch(error) {this.dispose();throw error;}
    finally {for(const shader of shaders)gl.deleteShader(shader);}
  }
  draw(texture,framebuffer,viewport) {
    if(!texture)throw Error('VR 眼画面纹理未就绪');
    const gl=this.gl,s=this.state,v=s.currentViewport;
    // Use the pinned Three backend's cache, with no per-eye synchronous GPU reads.
    const previous={program:s.currentProgram,vao:s.currentVAO,index:s.currentIndex,
      framebuffer:s.currentBoundFramebuffers[gl.DRAW_FRAMEBUFFER]??null,
      viewport:[v.x,v.y,v.z,v.w],color:s.currentColorMask??true,depth:s.currentDepthMask??true,
      slot:s.currentTextureSlot??gl.TEXTURE0,texture:{...s.currentBoundTextures[gl.TEXTURE0]},
      flags:this.flags.map(flag=>s.enabled[flag]===true)};
    try {
      // Only DRAW changes: the opaque XR framebuffer is never inspected or read.
      s.bindFramebuffer(gl.DRAW_FRAMEBUFFER,framebuffer);
      s.viewport(viewport.x,viewport.y,viewport.width,viewport.height);
      for(const flag of this.flags)s.disable(flag);
      s.setColorMask(true);s.setDepthMask(false);s.useProgram(this.program);s.setVertexState(this.vao);
      s.bindTexture(gl.TEXTURE_2D,texture,gl.TEXTURE0);gl.uniform1i(this.image,0);
      gl.drawArrays(gl.TRIANGLES,0,3);
    } finally {
      s.bindTexture(gl.TEXTURE_2D,null,gl.TEXTURE0);
      if(previous.texture.type!==undefined)s.bindTexture(previous.texture.type,previous.texture.texture,gl.TEXTURE0);
      else delete s.currentBoundTextures[gl.TEXTURE0];
      s.activeTexture(previous.slot);s.useProgram(previous.program??null);s.setVertexState(previous.vao??null,previous.index??null);
      s.setColorMask(previous.color);s.setDepthMask(previous.depth);
      this.flags.forEach((flag,i)=>previous.flags[i]?s.enable(flag):s.disable(flag));
      s.viewport(...previous.viewport);s.bindFramebuffer(gl.DRAW_FRAMEBUFFER,previous.framebuffer);
    }
  }
  dispose(){if(this.vao)this.gl.deleteVertexArray(this.vao);if(this.program)this.gl.deleteProgram(this.program);this.vao=this.program=null;}
}
