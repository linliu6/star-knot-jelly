// Route the current web edition's material/ASMR engine into one spatial source.
// Synthesis, recorded choices, crack feedback and original volume remain unchanged.
export class JellyAudio {
  constructor(settings,study){this.settings=settings;this.study=study;this.owner=study.mobile.audio;this.active=false;this.motion=null;this.last=new Map();this.held=false;}
  async unlock(){const ready=await this.owner.unlock();this.route();return ready;}
  route(){const c=this.owner.context;if(!c)return;if(!this.panner){this.panner=c.createPanner();this.panner.panningModel='HRTF';this.panner.distanceModel='inverse';this.panner.refDistance=.5;this.panner.rolloffFactor=.4;this.panner.positionZ.value=-.5;this.gain=c.createGain();this.panner.connect(this.gain);this.gain.connect(c.destination);}
    this.owner.limiter.disconnect();this.owner.limiter.connect(this.active?this.panner:c.destination);this.configure();}
  activate(value){this.active=value;this.motion=null;this.owner.hush();this.route();}
  configure(){if(this.gain)this.gain.gain.setTargetAtTime(this.settings.muted?0:this.settings.volume/.5,this.owner.context.currentTime,.03);}
  listener(position,forward,up){const c=this.owner.context;if(!c)return;for(const [name,v]of [['position',position],['forward',forward],['up',up]])for(let i=0;i<3;i++)c.listener[name+'XYZ'[i]]?.setValueAtTime(v[i],c.currentTime);}
  pressure(value,speed,position){const local=this.study.tactile?.audioState();this.motion=local??{held:this.held,speed:speed*1000,strain:value,displacement:0,velocity:0};if(this.panner)for(let i=0;i<3;i++)this.panner['position'+'XYZ'[i]].setTargetAtTime(position[i],this.owner.context.currentTime,.04);}
  event(kind,intensity,position,id='body'){if(this.study.tactile)return;const now=performance.now();if(now-(this.last.get(id)??-1000)<70)return;this.last.set(id,now);if(kind==='touch'||kind==='grab'){this.held=true;this.owner.press('apple');}else if(kind==='release'){this.held=false;this.owner.release(intensity);}}
  silence(){this.held=false;this.motion=null;this.owner.hush();}
  snapshot(){const s=this.owner.snapshot();return {...s,events:s.events.length,eventDetails:s.events,muted:this.settings.muted,volume:this.settings.volume,spatial:!!this.panner&&this.active};}
}
