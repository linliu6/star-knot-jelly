import {HAND_POSES} from './hand-poses.js';
export const JOINTS=['wrist','thumb-metacarpal','thumb-phalanx-proximal','thumb-phalanx-distal','thumb-tip',
  ...['index','middle','ring','pinky'].flatMap(f=>[`${f}-finger-metacarpal`,`${f}-finger-phalanx-proximal`,`${f}-finger-phalanx-intermediate`,`${f}-finger-phalanx-distal`,`${f}-finger-tip`])];
export const TIPS=['thumb-tip','index-finger-tip','middle-finger-tip','ring-finger-tip','pinky-finger-tip'];
// The Oculus profile is a single skinned surface, with 25 flat WebXR-named bones.
// Keep metric bind matrices intact. Root scale converts meters to scene units;
// bone translations use the reciprocal scale so their world positions match input.
export class VisibleHand {
  constructor(E,scene,side,loader,onError=()=>{}){
    this.E=E;this.side=side;this.ready=false;this.disposed=false;this.bones=[];this.error=null;
    this.mesh=new E.Group();this.mesh.name=`Tracked ${side} hand`;this.mesh.visible=false;
    this.mesh.userData.profile='oculus-hand';scene.add(this.mesh);
    this.loaded=loader.loadAsync(`/star-knot-jelly/vr/jelly-painting/assets/oculus-hand/${side}.glb`).then(gltf=>{
      const model=gltf.scene;
      const release=()=>model.traverse(o=>{o.geometry?.dispose();if(o.isSkinnedMesh)o.skeleton?.dispose();if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();});
      if(this.disposed){release();return;}
      this.release=release;this.model=model;this.mesh.add(model);
      for(const name of JOINTS){const bone=model.getObjectByName(name);if(!bone?.isBone)throw Error(`Oculus hand missing bone: ${name}`);this.bones.push(bone);}
      this.triangles=0;this.drawMeshes=0;
      model.traverse(o=>{
        o.layers.set(0);o.frustumCulled=false;
        if(o.isMesh){
          this.drawMeshes++;this.triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;
          // Neutral standard hand surface, using the asset's original grey PBR values.
          // No pressure tint, custom painted albedo, or joint markers.
          o.castShadow=false;o.receiveShadow=false;
        }
      });
      this.ready=true;if(this.latest)this.update(this.latest.joints,this.latest.scale);
    }).catch(error=>{
      if(this.disposed)return;
      this.error=error.message;this.ready=false;this.mesh.visible=false;this.release?.();this.mesh.clear();
      onError(`无法加载 ${side} Oculus 手模型：${error.message}`);
    });
  }
  update(joints,scale=1){
    this.latest={joints,scale};
    if(!this.ready||this.disposed||JOINTS.some(name=>!joints?.get(name)?.orientation)){this.mesh.visible=false;return;}
    this.mesh.scale.setScalar(1/scale);
    for(let i=0;i<JOINTS.length;i++){
      const pose=joints.get(JOINTS[i]),bone=this.bones[i];
      bone.position.fromArray(pose.position).multiplyScalar(scale);
      bone.quaternion.fromArray(pose.orientation).normalize();bone.scale.set(1,1,1);
    }
    this.mesh.visible=true;
  }
  hide(){this.mesh.visible=false;this.latest=null;}
  snapshot(){return {side:this.side,profile:'oculus-hand',ready:this.ready,visible:this.mesh.visible,triangles:this.triangles??0,drawMeshes:this.drawMeshes??0,error:this.error};}
  dispose(){this.disposed=true;this.latest=null;this.mesh.removeFromParent();this.release?.();this.mesh.clear();}
}

// Meta IWER recorded left-hand poses, mirrored for the right hand (S * M * S).
// These full joint rotations avoid twisting a skin around synthetic straight rods.
export function virtualHand(E,center,side='right',pinch=false,scale=1,tilt=0){
  const source=HAND_POSES[pinch?'pinch':'point'],map=new Map();
  const matrix=new E.Group().matrix,rotation=matrix.clone().makeRotationX(tilt);
  const q=new E.Group().quaternion,position=new E.Vector3(),size=new E.Vector3();
  const reference=source['index-finger-tip'].matrix.slice(12,15);
  if(pinch){const thumb=source['thumb-tip'].matrix;for(let i=0;i<3;i++)reference[i]=(reference[i]+thumb[12+i])*.5;}
  for(const name of JOINTS){
    const data=source[name],m=[...data.matrix];
    for(let i=0;i<3;i++)m[12+i]-=reference[i];
    if(side==='right')for(const i of [1,2,4,8,12])m[i]*=-1;
    matrix.fromArray(m).premultiply(rotation).decompose(position,q,size);
    map.set(name,{position:position.multiplyScalar(scale).add(new E.Vector3(...center)).toArray(),orientation:q.toArray(),radius:data.radius*scale});
  }
  return map;
}

export class TouchButtons {
  constructor(api,E,actions){
    this.api=api;this.E=E;this.actions=actions;this.buttons=[];this.last=-10;
    const toward=api.camera.position.clone().sub(new E.Vector3(0,.055,0));toward.y=0;toward.normalize();
    this.normal=toward;this.right=new E.Vector3(0,1,0).cross(toward).normalize();
    this.up=new E.Vector3(0,1,0);
    const center=new E.Vector3(0,.018,0).addScaledVector(toward,.105);
    for(const [i,label]of ['Mute','Center','Reset','Exit'].entries()){
      const canvas=document.createElement('canvas');canvas.width=256;canvas.height=96;
      const c=canvas.getContext('2d');c.fillStyle='#233e5c';c.beginPath();c.roundRect(2,2,252,92,24);c.fill();
      c.strokeStyle='#91bfc6';c.lineWidth=2;c.stroke();c.fillStyle='#fff0dd';c.font='38px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(label,128,49);
      const tex=new E.DataTexture(c.getImageData(0,0,256,96).data,256,96);tex.flipY=true;tex.needsUpdate=true;
      const g=new E.Geometry();g.setAttribute('position',new E.Attribute(new Float32Array([-.022,-.009,0,.022,-.009,0,.022,.009,0,-.022,.009,0]),3));
      g.setAttribute('uv',new E.Attribute(new Float32Array([0,0,1,0,1,1,0,1]),2));g.setIndex([0,1,2,0,2,3]);g.computeVertexNormals();
      const m=new E.BasicMaterial({transparent:true,side:2,depthWrite:false});m.colorNode=E.texture(tex).rgb;m.opacityNode=E.texture(tex).a;
      const mesh=new E.Mesh(g,m);mesh.position.copy(center).addScaledVector(this.right,(i-1.5)*.052);mesh.lookAt(mesh.position.clone().add(toward));mesh.layers.set(0);mesh.name=`VR ${label}`;api.scene.add(mesh);
      this.buttons.push({mesh,texture:tex,label});
    }
  }
  update(inputs){
    let hit=-1;
    for(const input of inputs)for(const tip of input.tips){
      const p=new this.E.Vector3(...tip.position);
      for(let i=0;i<this.buttons.length;i++){
        const d=p.clone().sub(this.buttons[i].mesh.position);
        if(Math.abs(d.dot(this.normal))<.008&&Math.abs(d.dot(this.right))<.022&&Math.abs(d.y)<.009)hit=i;
      }
    }
    if(hit<0){this.active=-1;return;}
    if(hit===this.active)return;this.active=hit;
    const now=performance.now()/1000;if(now-this.last<.7)return;
    this.last=now;this.actions[hit]();
  }
  dispose(){for(const b of this.buttons){b.mesh.removeFromParent();b.mesh.geometry.dispose();b.mesh.material.dispose();b.texture.dispose();}}
}
