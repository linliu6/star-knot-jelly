// Exact nearest-neighbour search over the same sampled apple surface.
// Ties use source order, matching the original exhaustive scan.
export class SurfaceIndex {
  constructor(points){
    const build=(items,depth)=>{
      if(items.length<=12)return {items};
      const axis=depth%3;items.sort((a,b)=>a.value.point[axis]-b.value.point[axis]||a.id-b.id);
      const mid=items.length>>1,pivot=items[mid];
      return {axis,pivot,left:build(items.slice(0,mid),depth+1),right:build(items.slice(mid+1),depth+1)};
    };
    this.root=build(points.map((value,id)=>({value,id})),0);this.examined=0;
  }
  nearest(p){
    let best=null,d2=Infinity,id=Infinity;this.examined=0;
    const check=item=>{this.examined++;const q=item.value.point,dx=p[0]-q[0],dy=p[1]-q[1],dz=p[2]-q[2],d=dx*dx+dy*dy+dz*dz;
      if(d<d2||(d===d2&&item.id<id)){d2=d;best=item.value;id=item.id;}};
    const visit=node=>{if(node.items){for(const item of node.items)check(item);return;}
      const delta=p[node.axis]-node.pivot.value.point[node.axis];check(node.pivot);
      visit(delta<0?node.left:node.right);if(delta*delta<=d2)visit(delta<0?node.right:node.left);
    };
    visit(this.root);return best;
  }
}
