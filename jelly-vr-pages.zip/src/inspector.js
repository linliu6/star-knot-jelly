import {setIcon} from './ui-icons.js';
import {PAGE_MODE} from './delivery.js';
import {makeInspector as makeFullInspector} from './inspector-full.js';
import {mountSoundLibrary} from './sound-library.js';
function makeCompactInspector(A){
 const host=document.createElement('section');host.id='apple-ui';
 host.innerHTML='<aside id="apple-inspector" hidden><div class="inspector-groups"></div></aside><nav class="view-actions"></nav><footer class="study-actions"><button data-act="shake"></button><button data-act="view"></button><span></span></footer><span class="study-credit">Original art and technology · mesq</span>';
 document.body.append(host);
 setIcon(host.querySelector('[data-act=shake]'),'shake','Gently shake');
 setIcon(host.querySelector('[data-act=view]'),'reset','Reset view');
 host.querySelector('[data-act=shake]').addEventListener('click',A.shake);
 host.querySelector('[data-act=view]').addEventListener('click',A.resetView);
 const sounds=mountSoundLibrary(A);
 return {refresh:sounds.refresh,status:()=>{},open:()=>{},dispose:()=>{sounds.dispose();host.remove();}};
}

export function makeInspector(A){return PAGE_MODE==='editor'?makeFullInspector(A):makeCompactInspector(A);}
