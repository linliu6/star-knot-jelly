import {VARIANT} from './tactile-config.js';
export function mountVariants({tactile,mobile,notify}){
  const host=document.querySelector('#apple-ui'),nav=document.createElement('nav');nav.className='tactile-versions';nav.setAttribute('aria-label','Choose a texture');
  const labels=['1 Classic','2 Soft','3 Crisp'];
  for(let i=1;i<=3;i++){
    const a=document.createElement('button');a.type='button';a.textContent=labels[i-1];a.dataset.variant=i;a.setAttribute('aria-current',i===VARIANT?'page':'false');nav.append(a);
    a.onclick=()=>{mobile.cancel();window.dispatchEvent(new CustomEvent('star-variant',{detail:i}));};
  }
  host.append(nav);
  if(!tactile)return;
  const tools=document.createElement('div');tools.className='tactile-tools';
  tools.innerHTML='<button data-tool="press" aria-pressed="true">Press</button><button data-tool="grab" aria-pressed="false">Pinch</button><button id="fresh-jelly">Reset jelly</button>';
  host.append(tools);
  for(const b of tools.querySelectorAll('[data-tool]'))b.onclick=()=>{
    mobile.cancel();tactile.setTool(b.dataset.tool);
    for(const x of tools.querySelectorAll('[data-tool]'))x.setAttribute('aria-pressed',String(x===b));
    hint.textContent=b.dataset.tool==='grab'?(VARIANT===2?'Pinch, pull, then release.':'Crush the shell, pull the soft center, then release.'):'Press gently, or pinch and pull with two fingers.';notify();
  };
  const hint=document.createElement('output');hint.className='tactile-hint';hint.textContent=VARIANT===3?'Press to crack, then knead the broken shell.':'Press gently. Pinch and pull, then release.';host.append(hint);
  tools.querySelector('#fresh-jelly').onclick=()=>{mobile.cancel();tactile.reset();window.jellyCup.jelly.body?.reset();hint.textContent=VARIANT===3?'Shell restored. Start with a gentle press.':'Jelly reset. Try a small pinch.';notify();};
  const intro=document.querySelector('.intro-note');if(intro)intro.textContent=VARIANT===3?'Crack the shell, then knead the soft center.':'Press, pinch and gently release.';
}
