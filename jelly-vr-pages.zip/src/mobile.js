import { setIcon } from "./ui-icons.js";
import { store } from "../xhs/storage.js";
import { VARIANT } from "./tactile-config.js";
import { JellyAudio, SOUND_DEFAULTS } from "./jelly-audio.js";
import { validChoice } from "./audio-catalog.js";
import { PAGE_MODE } from "./delivery.js";

export const MOBILE_DEFAULTS = {
  touchGain: 1,
  gripStrength: 1,
  objectSize: 0.76,
  edgeInset: 0.018,
};
export function mobileDefaults(s) {
  s.mobile = { ...MOBILE_DEFAULTS };
  s.sound = { ...SOUND_DEFAULTS };
  s.post.viewportFrame = true;
  s.camera.fillWidth = 0.76;
  s.camera.fill = 0.73;
  s.orbit.pan = false;
}
export function installMobile(api, E) {
  const SOUND_KEY =
    (VARIANT === 1
      ? "star-apple-v82-sound-"
      : "star-apple-v9-" + VARIANT + "-sound-") + PAGE_MODE;
  const s = api.settings,
    canvas = api.renderer.domElement,
    controls = api.view.controls;
  if (
    !new URLSearchParams(location.search).has("defaults") &&
    !new URLSearchParams(location.hash.slice(1)).has("p")
  )
    try {
      const latest = store.getItem(SOUND_KEY);
      const saved = JSON.parse(
        latest ||
          store.getItem(SOUND_KEY.replace("-v82-", "-v8-")) ||
          store.getItem(SOUND_KEY.replace("-v82-", "-v6-")) ||
          store.getItem(SOUND_KEY.replace("-v82-", "-v5-")) ||
          "null",
      );
      if (saved && !latest) {
        saved.ribbonFollow = 1 / 3;
      }
      for (const [key, base] of Object.entries(SOUND_DEFAULTS))
        if (saved && typeof saved[key] === typeof base)
          s.sound[key] = key.endsWith("Choice")
            ? validChoice(saved[key], key.replace("Choice", ""))
              ? saved[key]
              : 0
            : typeof base === "number"
              ? Math.min(1, Math.max(0, saved[key]))
              : saved[key];
    } catch {}
  const audio = new JellyAudio(s.sound);
  window.jellySound = audio;
  let tactile = null;
  let soundLoadMessage = "",
    parts = null,
    partPointer = null,
    partControlsWere = true,
    orbitArmed = false,
    orbitSpeed = 0,
    partMotion = {};
  const lastCamera = api.camera.quaternion.clone();
  let held = false,
    pressTime = 0,
    position = null,
    lastMove = 0,
    speed = 0,
    peakStrain = 0,
    pinch = null,
    installed = false;
  const pointers = new Map();
  const listeners = [];
  const listen = (el, type, fn, opts) => {
    el.addEventListener(type, fn, opts);
    listeners.push(() => el.removeEventListener(type, fn, opts));
  };
  const status = () => document.querySelector("#sound-status");
  function hint(text) {
    const node = status();
    if (node) node.textContent = text;
  }
  async function enable() {
    try {
      await audio.unlock();
      hint(s.sound.enabled ? "Sound on." : "Sound off.");
      syncButton();
    } catch {
      hint("Audio is unavailable. You can still play.");
    }
  }
  function syncButton() {
    const button = document.querySelector("#sound-toggle");
    if (button) {
      if (!button.hasAttribute("aria-haspopup"))
        button.setAttribute("aria-pressed", String(s.sound.enabled));
      setIcon(
        button,
        s.sound.enabled ? "sound" : "muted",
        s.sound.enabled
          ? "Sound and touch settings. Sound on."
          : "Sound and touch settings. Sound off.",
      );
    }
    const power = document.querySelector("#menu-sound-power");
    if (power) {
      power.setAttribute("aria-pressed", String(s.sound.enabled));
      power.textContent = s.sound.enabled ? "On" : "Off";
    }
  }
  function cancel() {
    tactile?.cancel();
    api.interaction?.cancel();
    parts?.end();
    partPointer = null;
    held = false;
    pointers.clear();
    pinch = null;
    delete s.mobile.gestureLock;
    controls.enabled = true;
    audio.hush();
    speed = 0;
    orbitArmed = false;
    orbitSpeed = 0;
    lastCamera.copy(api.camera.quaternion);
    const body = api.jelly.body;
    if (body) body.touchGrab = null;
  }
  function strain() {
    if (parts?.active) return parts.strain;
    return Math.min(
      1,
      Math.max(
        (api.interaction?.state.offset.length() || 0) /
          Math.max(0.006, s.interaction.maxOffset),
        (api.jelly.body?.stats.maxU || 0) / s.jelly.maxDisplacement,
      ),
    );
  }
  listen(canvas, "jelly-press", (e) => {
    held = true;
    pressTime = performance.now();
    position = [e.detail.x, e.detail.y];
    lastMove = performance.now();
    peakStrain = 0;
    speed = 0;
    audio.press();
  });
  listen(canvas, "jelly-release", (e) => {
    const force = Math.min(
      1,
      strain() * 0.7 + Math.min(speed / 1100, 0.5) + peakStrain * 0.15,
    );
    held = false;
    audio.release(force, e.detail.cancelled);
  });
  function touchDown(e) {
    if (e.target !== canvas || e.button > 0) return;
    void enable();
    if (tactile?.down(e)) return;
    if (e.pointerType === "touch")
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size >= 2) {
      e.preventDefault();
      e.stopImmediatePropagation();
      api.interaction?.cancel();
      parts?.end();
      partPointer = null;
      held = false;
      audio.hush();
      orbitArmed = false;
      s.mobile.gestureLock = true;
      controls.enabled = false;
      // Clear OrbitControls' previous one-finger state before our own pinch.
      if (controls._pointers) controls._pointers.length = 0;
      const [a, b] = [...pointers.values()];
      pinch = {
        distance: Math.max(10, Math.hypot(a.x - b.x, a.y - b.y)),
        cameraDistance: api.camera.position.distanceTo(controls.target),
      };
      try {
        canvas.setPointerCapture(e.pointerId);
      } catch {}
      return;
    }
    if (held || pinch || s.mobile.gestureLock) return;
    const hit = parts?.hit(e.clientX, e.clientY, e.pointerType === "touch");
    if (hit && hit.kind !== "apple") {
      e.preventDefault();
      e.stopImmediatePropagation();
      partPointer = e.pointerId;
      partControlsWere = controls.enabled;
      controls.enabled = false;
      s.mobile.gestureLock = true;
      parts.begin(hit, e.clientX, e.clientY);
      held = true;
      pressTime = performance.now();
      position = [e.clientX, e.clientY];
      lastMove = pressTime;
      speed = peakStrain = 0;
      orbitArmed = false;
      audio.press(hit.kind);
      canvas.dataset.cup = "held";
      try {
        canvas.setPointerCapture(e.pointerId);
      } catch {}
      E.notify();
    }
  }
  function touchMove(e) {
    if (tactile?.move(e)) return;
    if (pointers.has(e.pointerId))
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (pointers.size >= 2) {
        const [a, b] = [...pointers.values()],
          distance = Math.max(10, Math.hypot(a.x - b.x, a.y - b.y));
        const target = Math.min(
          controls.maxDistance,
          Math.max(
            controls.minDistance,
            (pinch.cameraDistance * pinch.distance) / distance,
          ),
        );
        api.camera.position
          .sub(controls.target)
          .normalize()
          .multiplyScalar(target)
          .add(controls.target);
        api.view.userMoved = true;
        api.camera.updateMatrixWorld();
        E.notify();
      }
      return;
    }
    if (partPointer !== null) {
      if (e.pointerId !== partPointer) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      parts.move(e.clientX, e.clientY);
      E.notify();
    }
    if (held && position) {
      const now = performance.now(),
        dt = Math.max(0.008, (now - lastMove) / 1000),
        d = Math.hypot(e.clientX - position[0], e.clientY - position[1]);
      speed = speed * 0.2 + Math.min(1800, d / dt) * 0.8;
      position = [e.clientX, e.clientY];
      lastMove = now;
      peakStrain = Math.max(peakStrain, strain());
    }
  }
  function touchEnd(e) {
    if (tactile?.end(e)) return;
    pointers.delete(e.pointerId);
    if (pinch) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (pointers.size === 0) {
        pinch = null;
        delete s.mobile.gestureLock;
        controls.enabled = true;
        if (controls._pointers) controls._pointers.length = 0;
      }
      return;
    }
    if (e.pointerId === partPointer) {
      e.preventDefault();
      e.stopImmediatePropagation();
      const force = Math.min(
        1,
        strain() * 0.7 + Math.min(speed / 1100, 0.5) + peakStrain * 0.15,
      );
      parts.end();
      held = false;
      partPointer = null;
      delete s.mobile.gestureLock;
      controls.enabled = partControlsWere;
      delete canvas.dataset.cup;
      audio.release(force, e.type !== "pointerup");
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {}
      E.notify();
    }
  }
  listen(window, "pointerdown", touchDown, { capture: true, passive: false });
  listen(window, "pointermove", touchMove, { capture: true, passive: false });
  listen(window, "pointerup", touchEnd, { capture: true });
  listen(window, "pointercancel", touchEnd, { capture: true });
  listen(canvas, "lostpointercapture", (e) => {
    if (e.pointerId === partPointer || tactile?.active) cancel();
  });
  const orbitStart = () => {
    if (!held && !pinch) {
      orbitArmed = true;
      lastCamera.copy(api.camera.quaternion);
    }
  };
  controls.addEventListener("start", orbitStart);
  listeners.push(() => controls.removeEventListener("start", orbitStart));
  listen(window, "blur", cancel);
  listen(window, "pagehide", () => {
    cancel();
    audio.context?.suspend();
  });
  listen(document, "visibilitychange", () => {
    if (document.hidden) {
      cancel();
      audio.context?.suspend();
    } else hint("Touch to continue. Sound follows your movements.");
  });
  const shake = api.actions.shake;
  api.actions.shake = (...args) => {
    void enable();
    audio.shake();
    return shake(...args);
  };
  const resetView = api.actions.resetView;
  api.actions.resetView = (...args) => {
    cancel();
    return resetView(...args);
  };
  listen(window, "keydown", (e) => {
    if (
      (e.key === "s" || e.key === "S") &&
      !e.target.closest("input,textarea,select")
    ) {
      void enable();
      audio.shake();
    }
  });
  function apply() {
    s.post.viewportFrame = true;
    s.post.viewportInset = s.mobile.edgeInset;
    s.camera.fillWidth = s.mobile.objectSize;
    audio.sync();
    syncButton();
    try {
      store.setItem(SOUND_KEY, JSON.stringify(s.sound));
    } catch {}
  }
  function beforeUpdate() {
    const body = api.jelly.body,
      state = api.interaction?.state;
    if (!body) return;
    if (state?.dragging && state.grabLocal && state.pull) {
      const target = state.pull.clone();
      const inward = state.grabLocal.clone();
      inward.y -= api.cup.extras.height * 0.5;
      inward.normalize();
      target
        .addScaledVector(
          inward,
          -0.0012 * Math.exp(-(performance.now() - pressTime) / 150),
        )
        .clampLength(0, s.jelly.maxDisplacement * 0.9);
      body.touchGrab = {
        point: state.grabLocal.toArray(),
        target: target.toArray(),
        radius: 0.038,
        stiffness: 1600 * s.mobile.gripStrength,
        damping: 30,
      };
      body.wake();
    } else body.touchGrab = null;
  }
  function update(dt, time, motion = {}) {
    if (performance.now() - lastMove > 55) speed *= Math.exp(-dt * 23);
    partMotion = motion;
    const angular =
      api.camera.quaternion.angleTo(lastCamera) / Math.max(0.001, dt);
    lastCamera.copy(api.camera.quaternion);
    orbitSpeed =
      orbitArmed && !held && !pinch && !tactile?.active
        ? Math.min(1, Math.max(0, angular - 0.002) / 2.3)
        : 0;
    const b = api.jelly.body,
      local = (window.questJelly?.active ? window.questJelly.audio.motion : null) ?? tactile?.audioState(),
      contact = local?.held || local?.displacement > 0.00001;
    audio.update({
      held: held || !!local?.held,
      speed: local?.held ? local.speed : speed,
      strain: local?.held ? local.strain : strain(),
      velocity: Math.max(b?.stats.maxV ?? 0, local?.velocity ?? 0),
      displacement: Math.max(b?.stats.maxU ?? 0, local?.displacement ?? 0),
      asleep: (b?.asleep ?? true) && !contact,
      time,
      sugarContact: local?.sugarContact ?? 0,
      sugarIntegrity: local?.sugarIntegrity ?? 0,
      ribbon: motion.ribbon ?? 0,
      stem: motion.stem ?? 0,
      orbit: orbitSpeed,
    });
    const message = Object.keys(audio.recorded?.errors || {}).length
      ? "Using the original sound while your selection loads. Touch to retry."
      : "";
    if (message !== soundLoadMessage) {
      soundLoadMessage = message;
      hint(message || "Sound is ready and follows your movements.");
    }
  }
  function mount() {
    if (installed) return;
    installed = true;
    const host = document.querySelector("#apple-ui"),
      panel = document.querySelector("#apple-inspector");
    const nav = host.querySelector(".view-actions");
    panel.insertBefore(nav, panel.querySelector(".inspector-groups"));
    const credit = host.querySelector(".study-credit");
    panel.append(credit);
    const actions = host.querySelector(".study-actions");
    actions.insertAdjacentHTML(
      "afterbegin",
      '<button id="sound-toggle" type="button" aria-pressed="true"></button>',
    );
    actions.insertAdjacentHTML(
      "afterend",
      '<output id="sound-status" aria-live="polite">Touch the apple, ribbon or stem to hear each material.</output>',
    );
    host.querySelector("#sound-toggle").onclick = () => {
      s.sound.enabled = !s.sound.enabled;
      void enable();
      audio.sync();
      syncButton();
      try {
        store.setItem(SOUND_KEY, JSON.stringify(s.sound));
      } catch {}
    };
    syncButton();
  }
  return {
    apply,
    beforeUpdate,
    update,
    mount,
    cancel,
    audio,
    setParts: (value) => {
      parts = value;
    },
    setTactile: (value) => {
      tactile = value;
    },
    snapshot: () => ({
      held,
      part: parts?.active ?? (held ? "apple" : null),
      partMotion,
      orbitSpeed,
      pinch: !!pinch,
      pointers: pointers.size,
      speed,
      strain: strain(),
      audio: audio.snapshot(),
    }),
    dispose: () => {
      cancel();
      listeners.forEach((f) => f());
      audio.gel?.dispose();
      audio.recorded?.dispose();
      audio.context?.close();
    },
  };
}
