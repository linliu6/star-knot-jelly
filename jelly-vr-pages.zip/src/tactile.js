import {VARIANT} from './tactile-config.js';
import {SoftPatch,signedVolume} from './soft-patch.js';
import {GelFeedback} from './gel-feedback.js';
import {CrustFeedback} from './crust-feedback.js';
import {makeSugarShell} from './sugar-shell.js';
import {applePoint,surfaceFrame} from './geometry.js';
import {Yt as Raycaster,An as Vector2} from '../jelly-painting/assets/three-CU5tkW7F.js';

export function installTactile(api,E,params,parts,audio){
  if(VARIANT===1)return null;
  const settings=api.settings.tactile,patch=new SoftPatch(settings,'gel'),canvas=api.renderer.domElement;
  if(VARIANT===2)audio.gel=new GelFeedback(audio,patch);
  if(VARIANT===3)audio.gel=new CrustFeedback(audio,patch,settings);
  const controls=api.view.controls,root=api.cup.root,ray=new Raycaster(),ndc=new Vector2();ray.layers.enableAll();
  const pointers=new Map();let held=false,owner=null,blocked=false,gesture=0,mode='press',tool='press',start=null,pair=null;
  let xrContact=null,xrActive=false;
  let lastMove=0,speed=0,pressAge=0,peak=0,geometry=null,rest=null,restVolume=0,centerY=.055,wasMoving=false,volumeScale=1;
  let shell=VARIANT===3?makeSugarShell(api,E,params,settings,patch,audio):null;
  if(shell)audio.gel.shell=shell;
  const point=new E.Vector3(),world=new E.Vector3(),normal=new E.Vector3(),delta=new E.Vector3();
  function consume(e){e.preventDefault();e.stopImmediatePropagation();}
  function cast(x,y){const r=canvas.getBoundingClientRect();ndc.set((x-r.left)/r.width*2-1,1-(y-r.top)/r.height*2);ray.setFromCamera(ndc,api.camera);return ray;}
  function localHit(h){
    const uv=h.uv??{x:.5,y:.5};const p=applePoint(uv.x,uv.y,params),n=surfaceFrame((a,b)=>applePoint(a,b,params),uv.x,Math.max(.001,Math.min(.999,uv.y))).normal;
    return {p,n};
  }
  function lock(){api.interaction?.cancel();controls.enabled=false;if(controls._pointers)controls._pointers.length=0;api.settings.mobile.gestureLock=true;canvas.dataset.cup='held';}
  function unlock(){delete api.settings.mobile.gestureLock;controls.enabled=true;delete canvas.dataset.cup;if(controls._pointers)controls._pointers.length=0;}
  function begin(h,x,y,newMode){
    const {p,n}=localHit(h);gesture++;mode=newMode;patch.begin(p,n,mode);held=true;pressAge=0;peak=speed=0;lastMove=performance.now();
    point.fromArray(p);root.updateWorldMatrix(true,false);world.copy(point).applyMatrix4(root.matrixWorld);normal.copy(api.camera.getWorldDirection(new E.Vector3()));
    start={x,y,world:world.clone(),normal:normal.clone(),inverse:root.matrixWorld.clone().invert(),initial:[...patch.displacement]};
    lock();audio.press('apple',shell&&shell.integrity(p)>.6?settings.shellSound:null);E.notify();
  }
  function down(e){
    if(e.target!==canvas||e.button>0)return false;
    const h=parts.hit(e.clientX,e.clientY,e.pointerType==='touch');
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,kind:h?.kind??'space'});
    if(pointers.size===1){owner=h?.kind==='apple'?'apple':'other';blocked=false;}
    if(owner!=='apple')return false;
    consume(e);try{canvas.setPointerCapture(e.pointerId);}catch{}
    if(blocked)return true;
    if(pointers.size===1)begin(h,e.clientX,e.clientY,e.shiftKey||tool==='grab'?'grab':'press');
    else if(pointers.size===2&&[...pointers.values()].every(p=>p.kind==='apple')){
      const [a,b]=[...pointers.values()],x=(a.x+b.x)/2,y=(a.y+b.y)/2;
      const middle=parts.hit(x,y,false);if(!middle||middle.kind!=='apple'){finish(true);blocked=true;return true;}
      begin(middle,x,y,'grab');pair={distance:Math.max(15,Math.hypot(a.x-b.x,a.y-b.y)),closed:0};
    }
    return true;
  }
  function move(e){
    if(!pointers.has(e.pointerId))return false;
    const p=pointers.get(e.pointerId);p.x=e.clientX;p.y=e.clientY;
    if(owner!=='apple')return false;consume(e);if(!held||blocked)return true;
    let x=e.clientX,y=e.clientY;
    if(pair){const [a,b]=[...pointers.values()];if(!b)return true;x=(a.x+b.x)/2;y=(a.y+b.y)/2;pair.closed=Math.max(0,Math.min(1,1-Math.hypot(a.x-b.x,a.y-b.y)/pair.distance));}
    const now=performance.now(),elapsed=Math.max(.008,(now-lastMove)/1000),old=start.last??[start.x,start.y];
    speed=Math.min(1400,Math.hypot(x-old[0],y-old[1])/elapsed);lastMove=now;start.last=[x,y];
    if(mode==='press'){
      const h=parts.hit(x,y,false);if(h?.kind==='apple'){const hit=localHit(h);patch.point=hit.p;patch.normal=hit.n;}
    }else{
      cast(x,y);const denominator=ray.ray.direction.dot(start.normal);
      if(Math.abs(denominator)>1e-7){
        const t=start.world.clone().sub(ray.ray.origin).dot(start.normal)/denominator;
        ray.ray.at(t,delta);delta.applyMatrix4(start.inverse).sub(start.world.clone().applyMatrix4(start.inverse));
        delta.multiplyScalar(api.settings.mobile.touchGain*(.5+.5*api.settings.mobile.gripStrength));
        // Squeezing a small patch gathers it outward before following the hand.
        delta.addScaledVector(new E.Vector3(...patch.normal),pair?pair.closed*.017:.006);
        delta.clampLength(0,settings.maxStretch);patch.target=delta.toArray();
      }
    }
    E.notify();return true;
  }
  function finish(cancelled=false){
    if(held){if(!cancelled)api.jelly.body?.kick(...patch.displacement.map((d,i)=>d*1.3+patch.velocity[i]*.10));patch.release();audio.release(Math.min(1,peak*.8+speed/3000),cancelled);}
    held=false;pair=null;unlock();E.notify();
  }
  function end(e){
    if(!pointers.has(e.pointerId))return false;
    pointers.delete(e.pointerId);if(owner!=='apple'){if(!pointers.size)owner=null;return false;}
    consume(e);finish(e.type!=='pointerup');
    // Do not reinterpret the remaining finger as a new camera gesture.
    blocked=pointers.size>0;if(blocked)lock();else owner=null;
    try{canvas.releasePointerCapture(e.pointerId);}catch{}return true;
  }
  function cancel(){finish(true);pointers.clear();owner=null;blocked=false;unlock();}
  function update(dt){
    const current=api.cup.liquid.mesh.geometry;
    if(current!==geometry){geometry=current;rest=Float32Array.from(current.attributes.position.array);restVolume=signedVolume(rest,current.index.array);centerY=(current.boundingBox.min.y+current.boundingBox.max.y)/2;patch.reset();shell?.reset();}
    if(held){
      pressAge+=dt;
      if(mode==='press'){
        const effort=xrActive?Math.min(1,(xrContact?.depth??0)/.008):Math.min(1,.18+pressAge/1.15);
        shell?.contact(patch.point,effort,gesture,dt);
        const resistance=shell?.integrity(patch.point)??0;
        const depth=settings.pressDepth*settings.softness*effort*(1-resistance*.73);
        patch.target=patch.normal.map(n=>-n*depth);
      }else{
        const effort=Math.min(1,Math.hypot(...patch.target)/settings.maxStretch+(pair?.closed??0)*.75);
        shell?.contact(patch.point,effort,gesture,dt);
        patch.radius=settings.contactRadius*(1-(pair?.closed??0)*.15);
      }
    }
    patch.step(dt);peak=Math.max(peak,Math.hypot(...patch.displacement)/settings.maxStretch);
    if(performance.now()-lastMove>65)speed*=Math.exp(-dt*24);
    if(patch.moving||wasMoving){
      const p=geometry.attributes.position,b=geometry.attributes.positionBase,q=[0,0,0];
      for(let i=0;i<p.count;i++){patch.deform(rest[i*3],rest[i*3+1],rest[i*3+2],q);p.setXYZ(i,...q);}
      const volume=signedVolume(p.array,geometry.index.array);
      // Exact global signed-volume correction accompanies local rim redistribution.
      volumeScale=Math.pow(Math.abs(restVolume/volume),settings.volumeKeep/3);
      volumeScale=Math.max(.96,Math.min(1.04,volumeScale));
      for(let i=0;i<p.count;i++){const x=p.getX(i)*volumeScale,y=centerY+(p.getY(i)-centerY)*volumeScale,z=p.getZ(i)*volumeScale;p.setXYZ(i,x,y,z);b.setXYZ(i,x,y,z);}
      patch.volumeRatio=signedVolume(p.array,geometry.index.array)/restVolume;
      patch.volumeScale=volumeScale;patch.centerY=centerY;
      p.needsUpdate=b.needsUpdate=true;geometry.computeVertexNormals();geometry.computeBoundingSphere();
    }
    wasMoving=patch.moving;shell?.update(dt);
  }
  function reset(){cancel();patch.reset();wasMoving=true;shell?.reset();E.notify();}
  function setXRContact(contact,cancelled=false){
    if(!contact){if(xrActive){patch.release();held=false;xrActive=false;xrContact=null;audio.release(Math.min(1,peak),cancelled);}return;}
    const nextMode=contact.mode==='grip'?'grab':'press';
    if(!xrActive||mode!==nextMode){gesture++;mode=nextMode;patch.begin(contact.point,contact.normal,mode);pressAge=0;peak=0;audio.press('apple',shell?settings.shellSound:null);}
    xrContact=contact;xrActive=true;held=true;patch.point=[...contact.point];patch.normal=[...contact.normal];
    if(mode==='grab'){const d=contact.delta,mag=Math.hypot(...d),scale=Math.min(1,settings.maxStretch/(mag||1));patch.target=d.map(v=>v*scale);}
    speed=Math.min(1400,Math.hypot(...patch.velocity)*3000);lastMove=performance.now();
  }
  return {setXRContact,down,move,end,cancel,update,reset,patch,shell,
    setTool(value){cancel();tool=value==='grab'?'grab':'press';},get tool(){return tool;},
    get active(){return held;},get moving(){return patch.moving||!!shell?.moving;},
    audioState(){const intact=held&&shell?shell.integrity(patch.point):0;return {held,speed,sugarIntegrity:intact,sugarContact:held&&shell?settings.shellSound*(.25+.75*intact):0,strain:Math.min(1,Math.hypot(...patch.displacement)/settings.maxStretch),velocity:Math.hypot(...patch.velocity),displacement:Math.hypot(...patch.displacement),asleep:!patch.moving};},
    snapshot:()=>({variant:VARIANT,held,mode,tool,pointers:pointers.size,blocked,volumeScale,patch:patch.snapshot(),shell:shell?.snapshot()??null}),
  };
}
