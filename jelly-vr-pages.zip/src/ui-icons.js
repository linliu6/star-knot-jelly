const paths={
 sound:'<path d="m11 5-6 4H2v6h3l6 4V5Z"/><path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>',
 muted:'<path d="m11 5-6 4H2v6h3l6 4V5Z"/><path d="m16 9 5 6m0-6-5 6"/>',
 shake:'<path d="M7 7c1-3 9-3 10 0l2 9c.7 4-14.7 4-14 0L7 7Z"/><path d="M2 8 1 12m21-4 1 4M9 9l-.6 3"/>',
 reset:'<path d="M3 11a9 9 0 1 1 2 7M3 4v7h7"/>',
 sliders:'<path d="M4 4v16M12 4v16M20 4v16"/><path d="M1 8h6m2 8h6m2-7h6"/>'
};
export function setIcon(button,name,label){
 button.type='button';button.classList.add('icon-button');button.setAttribute('aria-label',label);
 button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+paths[name]+'</svg>';
}
