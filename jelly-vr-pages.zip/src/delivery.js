import {VARIANT} from './tactile-config.js';
import {DEFAULTS, normalizeState} from './parameters.js';

export const SITE_ORIGIN=new URL('./',location.href).href;
export const PAGE_MODE=new URLSearchParams(location.search).get('mode')==='editor'?'editor':'phone';
document.documentElement.dataset.mode=PAGE_MODE==='phone'?'phone':'editor';

function leaves(obj,path='',out=[]){
  for(const key of Object.keys(obj).sort()){
    const value=obj[key],p=path?path+'.'+key:key;
    if(value!==null&&typeof value==='object')leaves(value,p,out);
    else out.push([p,value]);
  }
  return out;
}
function signature(paths){let n=2166136261;for(const c of paths.join('|'))n=Math.imul(n^c.charCodeAt(0),16777619);return (n>>>0).toString(36);}
function template(baseSettings){return {schema:'mesq-apple-study',version:1,shape:structuredClone(DEFAULTS),settings:structuredClone(baseSettings)};}
const encode=s=>btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const decode=s=>atob(s.replace(/-/g,'+').replace(/_/g,'/'));

export function phoneLink(documentState,baseSettings,origin=SITE_ORIGIN){
  const base=leaves(template(baseSettings)),current=new Map(leaves(normalizeState(documentState,baseSettings)));
  const changes=base.flatMap(([path,value],i)=>Object.is(value,current.get(path))?[]:[[i,current.get(path)]]);
  const payload=encode(JSON.stringify({v:1,k:signature(base.map(([p])=>p)),p:changes}));
  const link=new URL(origin);link.search='?mode=phone&variant='+VARIANT;link.hash='p='+payload;const url=link.href;
  if(url.length>2200)throw Error('These settings exceed the QR limit. Export a JSON file instead.');
  return url;
}

export function readPhoneRecipe(hash,baseSettings){
  const value=new URLSearchParams(hash.replace(/^#/, '')).get('p');
  if(!value)return null;
  if(value.length>4000||!/^[A-Za-z0-9_-]+$/.test(value))throw Error('This settings link is damaged. Please scan it again.');
  const recipe=JSON.parse(decode(value)),base=template(baseSettings);let paths=leaves(base).map(([p])=>p);
  // Keep V6 and V5.1 sound recipes readable after adding the V7 asset fields.
  // Omitted visual fields take the new asset defaults; existing sound indices keep their meaning.
  if(recipe.k!==signature(paths)){
    const visual=new Set(['fullness','dimpleWidth','veinStrength','veinLength','veinDensity','veinWidth','veinColor','wellStrength','wellSpread','veinBands'].map(k=>'shape.'+k));
    const audio=new Set(['apple','ribbon','stem','orbit','wetness','fabricSoftness','stemTexture','tailLength','forceResponse'].map(k=>'settings.sound.'+k));
    const added=new Set(['ribbonFollow','musicVolume','musicFadeIn','musicFadeOut','musicThreshold'].map(k=>'settings.sound.'+k));
    const old=paths.filter(p=>!p.startsWith('settings.tactile.'));
    const v8=old.filter(p=>!added.has(p));
    const v7=v8.filter(p=>!/^settings\.sound\.(apple|ribbon|stem|orbit)Choice$/.test(p));
    const v6=v7.filter(p=>!visual.has(p)),v51=v6.filter(p=>!audio.has(p));
    if(recipe.k===signature(old))paths=old;
    else if(recipe.k===signature(v8))paths=v8;
    else if(recipe.k===signature(v7))paths=v7;
    else if(recipe.k===signature(v6))paths=v6;
    else if(recipe.k===signature(v51))paths=v51;
    if(recipe.k===signature(paths))base.settings.sound.orbitChoice=0; // Old QR recipes used original rotation as their default.
  }
  if(recipe.v!==1||recipe.k!==signature(paths)||!Array.isArray(recipe.p)||recipe.p.length>paths.length)throw Error('Settings version mismatch. Create a new QR code in the editor.');
  const seen=new Set();
  for(const pair of recipe.p){
    if(!Array.isArray(pair)||pair.length!==2||!Number.isInteger(pair[0])||pair[0]<0||pair[0]>=paths.length||seen.has(pair[0]))throw Error('Invalid settings format. Please scan the QR code again.');
    seen.add(pair[0]);const parts=paths[pair[0]].split('.');let object=base;
    for(const part of parts.slice(0,-1))object=object[part];
    object[parts.at(-1)]=pair[1];
  }
  return normalizeState(base,baseSettings);
}

export function mountDelivery(A){
  const host=document.querySelector('#apple-ui');
  if(PAGE_MODE==='phone')return;
  const panel=host.querySelector('#apple-inspector');
  const section=document.createElement('section');section.className='phone-transfer';
  section.innerHTML='<strong>Try on your phone</strong><p>Create a QR code to try these settings on your phone.</p><button id="make-phone-qr" type="button">Create QR code</button><a href="?mode=phone" target="_blank" rel="noopener">Open phone view ↗</a>';
  section.querySelector('a').href='?mode=phone&variant='+VARIANT;
  panel.insertBefore(section,panel.querySelector('.inspector-groups'));
  panel.querySelector('.panel-head strong').textContent='Inspector';
  const modal=document.createElement('dialog');modal.id='phone-qr-dialog';
  modal.innerHTML='<button class="qr-close" aria-label="Close QR code">×</button><span class="qr-eyebrow">PHONE PREVIEW</span><h2>Take it to your phone.</h2><p>Scan with your phone camera, then touch the jelly to play.</p><div class="qr-picture"></div><output id="qr-recipe-state"></output><div class="qr-buttons"><button id="copy-phone-link">Copy link</button><a id="open-phone-link" target="_blank" rel="noopener">Open preview ↗</a></div><p class="qr-footnote">This code includes your current settings. Create a new code after making changes. No account required.</p>';
  document.body.append(modal);
  modal.querySelector('.qr-close').onclick=()=>modal.close();
  modal.addEventListener('click',event=>{if(event.target===modal){const r=modal.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)modal.close();}});
  let latest='';
  section.querySelector('button').onclick=async()=>{
    try{
      A.mobile.cancel();latest=phoneLink(A.documentState(),A.baseSettings);
      const {default:qrcode}=await import('./vendor/qrcode.mjs');
      const qr=qrcode(0,'M');qr.addData(latest,'Byte');qr.make();
      const picture=modal.querySelector('.qr-picture');picture.innerHTML=qr.createSvgTag({cellSize:6,margin:24,scalable:true});
      const svg=picture.querySelector('svg');svg.setAttribute('role','img');svg.setAttribute('aria-label','QR code for a phone preview with current settings');
      modal.querySelector('#open-phone-link').href=latest;
      modal.querySelector('#qr-recipe-state').textContent='Includes shape, materials, physics and sound settings.';
      modal.showModal();
    }catch(error){A.panel.status(error.message,true);}
  };
  modal.querySelector('#copy-phone-link').onclick=async()=>{
    try{await navigator.clipboard.writeText(latest);modal.querySelector('#qr-recipe-state').textContent='Link copied.';}
    catch{modal.querySelector('#qr-recipe-state').textContent='Copy the address of the Open preview link.';}
  };
  if(innerWidth>=900)A.panel.open(true);
}
